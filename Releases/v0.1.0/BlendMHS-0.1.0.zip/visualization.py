import bpy
import gpu
import numpy as np
from gpu_extras.batch import batch_for_shader
from bpy.app.handlers import persistent
from mathutils import Vector

class LightmapGroupVisualizer:
    def __init__(self):
        self.shader = None
        self.batches = {}
        self.need_update = True

    def create_shader(self):
        vertex_shader = '''
            uniform mat4 modelViewProjectionMatrix;

            in vec3 position;

            void main()
            {
                gl_Position = modelViewProjectionMatrix * vec4(position, 1.0);
            }
        '''

        fragment_shader = '''
            uniform vec4 color;

            out vec4 fragColor;

            void main()
            {
                fragColor = color;
            }
        '''

        self.shader = gpu.types.GPUShader(vertex_shader, fragment_shader)

    def create_batch_for_object(self, obj):
        mesh = obj.data
        mesh.calc_loop_triangles()

        vertices = np.empty((len(mesh.vertices), 3), 'f')
        indices = np.empty((len(mesh.loop_triangles), 3), 'i')

        mesh.vertices.foreach_get(
            "co", np.reshape(vertices, len(mesh.vertices) * 3))
        mesh.loop_triangles.foreach_get(
            "vertices", np.reshape(indices, len(mesh.loop_triangles) * 3))

        batch = batch_for_shader(
            self.shader, 'TRIS',
            {
                "position": vertices,
            },
            indices=indices,
        )
        return batch

    def update_batches(self, context):
        self.batches.clear()
        for group in context.scene.mhs.lightmap_groups:
            group_batches = []
            for obj_ref in group.objects:
                obj = bpy.data.objects.get(obj_ref.name)
                if obj and obj.type == 'MESH':
                    batch = self.create_batch_for_object(obj)
                    group_batches.append((obj, batch))
            self.batches[group.name] = group_batches
        self.need_update = False

    def draw(self, context):
        if self.shader is None:
            self.create_shader()

        if self.need_update:
            self.update_batches(context)

        if not context.scene.mhs.show_lightmap_group_visualization:
            return

        # Set up GPU state for overlay rendering
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_test_set('ALWAYS')
        gpu.state.depth_mask_set(False)
        gpu.state.face_culling_set('BACK')

        self.shader.bind()

        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                space = area.spaces.active
                region = area.regions[-1]
                region_3d = space.region_3d
                view_matrix = region_3d.view_matrix
                projection_matrix = region_3d.window_matrix
                modelViewProjectionMatrix = projection_matrix @ view_matrix

        for i, group in enumerate(context.scene.mhs.lightmap_groups):
            color = list(group.color)
            if len(color) == 3:
                color.append(context.scene.mhs.lightmap_visualization_alpha)
            else:
                color[3] = context.scene.mhs.lightmap_visualization_alpha

            self.shader.uniform_float("color", color)

            for obj, batch in self.batches.get(group.name, []):
                if obj.visible_get():
                    objectModelViewProjectionMatrix = modelViewProjectionMatrix @ obj.matrix_world
                    self.shader.uniform_float("modelViewProjectionMatrix", objectModelViewProjectionMatrix)
                    batch.draw(self.shader)

        # Reset GPU state
        gpu.state.blend_set('NONE')
        gpu.state.depth_test_set('LESS_EQUAL')
        gpu.state.depth_mask_set(True)
        gpu.state.face_culling_set('BACK')

visualizer = LightmapGroupVisualizer()

def draw_callback_3d():
    visualizer.draw(bpy.context)

@persistent
def load_handler(dummy):
    visualizer.need_update = True

def force_viewport_update():
    visualizer.need_update = True
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            area.tag_redraw()

def register():
    bpy.app.handlers.load_post.append(load_handler)
    bpy.types.SpaceView3D.draw_handler_add(draw_callback_3d, (), 'WINDOW', 'POST_PIXEL')

def unregister():
    bpy.app.handlers.load_post.remove(load_handler)
    for handler in bpy.app.handlers.load_post:
        if handler.__name__ == 'draw_callback_3d':
            bpy.types.SpaceView3D.draw_handler_remove(handler, 'WINDOW')
