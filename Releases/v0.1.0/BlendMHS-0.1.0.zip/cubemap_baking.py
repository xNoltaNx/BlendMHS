import bpy
import numpy as np
from mathutils import Matrix
from math import pi
import os


def create_temp_camera(scene, location):
    """Create a temporary camera for equirectangular rendering"""
    cam_data = bpy.data.cameras.new(name="EquirectangularCamera")
    cam_data.type = 'PANO'
    cam_data.lens_unit = 'FOV'
    cam_data.panorama_type = 'EQUIRECTANGULAR'  # This is the correct property

    # Set field of view to capture full 360 degrees
    cam_data.latitude_min = pi * -0.5  # Full 360 degrees in radians
    cam_data.latitude_max = pi * 0.5  # Full 360 degrees in radians
    cam_data.longitude_min = -pi  # Full 360 degrees in radians
    cam_data.longitude_max = pi  # Full 360 degrees in radians

    cam_obj = bpy.data.objects.new("EquirectangularCamera", cam_data)
    scene.collection.objects.link(cam_obj)
    cam_obj.location = location

    # Orient the camera for proper equirectangular capture
    cam_obj.rotation_euler = (0, 0, 0)  # Level camera

    return cam_obj


def setup_render_settings(scene, resolution, samples):
    """Configure render settings for equirectangular capture"""
    # For equirectangular, we want higher horizontal resolution
    # Recommended ratio is 2:1 with enough pixels to get good face resolution
    # If we want each face to be resolution x resolution,
    # equirect should be (resolution * 4) x (resolution * 2) to avoid undersampling
    print(resolution)
    scene.render.resolution_x = resolution * 4  # Increased for better sampling
    scene.render.resolution_y = resolution * 2
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = 'OPEN_EXR'
    scene.render.image_settings.color_mode = 'RGBA'
    scene.render.image_settings.color_depth = '32'
    scene.render.image_settings.exr_codec = 'ZIP'
    scene.render.use_border = False
    scene.render.use_crop_to_border = False

    # Set samples for Cycles
    scene.cycles.samples = samples
    scene.cycles.preview_samples = samples


def equirectangular_to_cubemap(eq_img, face_size, padding=2):
    """
    Convert equirectangular image to 6 cubemap faces with edge padding to prevent bleeding.
    eq_img: numpy array of shape (H, W, 4) containing the equirectangular image
    face_size: desired size of each cubemap face
    padding: number of pixels to pad each edge for sampling
    """
    # Create sampling grid with padding
    padded_size = face_size + padding * 2
    y, x = np.meshgrid(
        np.linspace(-1 - (padding/face_size), 1 + (padding/face_size), padded_size),
        np.linspace(-1 - (padding/face_size), 1 + (padding/face_size), padded_size)
    )

    # Initialize array to store the 6 faces
    faces = np.zeros((6, face_size, face_size, 4))

    # Face rotation matrices (right, left, up, down, front, back)
    rotations = [
        Matrix(((0, 0, 1),
               (0, 1, 0),
               (-1, 0, 0))),  # right
        Matrix(((0, 0, -1),
               (0, 1, 0),
               (1, 0, 0))),  # left
        Matrix(((-1, 0, 0),
               (0, 1, 0),
               (0, 0, -1))),   # up
        Matrix(((1, 0, 0),
               (0, 1, 0),
               (0, 0, 1))),  # down
        Matrix(((1, 0, 0),
               (0, 0, 1),
               (0, -1, 0))),  # front
        Matrix(((1, 0, 0),
               (0, 0, -1),
               (0, 1, 0))),  # back
    ]

    eq_height, eq_width = eq_img.shape[:2]

    for face_idx, rotation in enumerate(rotations):
        # Convert face coordinates to 3D vectors
        x_coords = x.flatten()
        y_coords = y.flatten()
        # Add small epsilon to avoid exact 0/0 division in atan2
        rays = np.stack([x_coords, y_coords, np.ones_like(x_coords) + 1e-10], axis=-1)

        # Normalize rays to ensure even sampling
        rays = rays / np.linalg.norm(rays, axis=1)[:, np.newaxis]

        # Apply rotation for this face
        rot_matrix = np.array(rotation)
        rays = np.einsum('ij,nj->ni', rot_matrix, rays)

        # Convert to spherical coordinates with safe arctangent
        theta = np.arctan2(rays[:, 0], rays[:, 2])  # azimuth
        phi = np.arctan2(rays[:, 1], np.sqrt(rays[:, 0]**2 + rays[:, 2]**2))  # elevation

        # Convert to equirectangular pixel coordinates with margin
        u = ((theta / (2 * np.pi) + 0.5) * (eq_width - 2) + 1).astype(np.float32)
        v = ((phi / np.pi + 0.5) * (eq_height - 2) + 1).astype(np.float32)

        # Bilinear interpolation coordinates
        u0 = np.floor(u).astype(np.int32)
        u1 = u0 + 1
        v0 = np.floor(v).astype(np.int32)
        v1 = v0 + 1

        # Ensure all coordinates are within bounds
        u0 = np.clip(u0, 0, eq_width - 1)
        u1 = np.clip(u1, 0, eq_width - 1)
        v0 = np.clip(v0, 0, eq_height - 1)
        v1 = np.clip(v1, 0, eq_height - 1)

        # Calculate interpolation weights
        wu = u - u0
        wv = v - v0

        # Gather pixel values for interpolation
        c00 = eq_img[v0, u0]
        c10 = eq_img[v0, u1]
        c01 = eq_img[v1, u0]
        c11 = eq_img[v1, u1]

        # Perform bilinear interpolation
        c0 = c00 * (1 - wu)[:, np.newaxis] + c10 * wu[:, np.newaxis]
        c1 = c01 * (1 - wu)[:, np.newaxis] + c11 * wu[:, np.newaxis]
        face_pixels = c0 * (1 - wv)[:, np.newaxis] + c1 * wv[:, np.newaxis]

        # Reshape to padded face dimensions
        face_pixels = face_pixels.reshape(padded_size, padded_size, 4)

        # Crop padding to get final face
        faces[face_idx] = face_pixels[padding:-padding, padding:-padding]

    return faces

def render_equirectangular(scene, camera, temp_path):
    """Render equirectangular image"""
    scene.camera = camera
    equirect_path = os.path.join(temp_path, "equirectangular.exr")
    scene.render.filepath = equirect_path
    bpy.ops.render.render(write_still=True)
    return equirect_path

def bake_lightprobe(context, probe_obj):
    """Bake a complete cubemap for a light probe object"""
    if 'lightprobe' not in probe_obj:
        return None

    scene = context.scene
    probe_properties = probe_obj.lightprobe

    # Fixed target resolution
    FACE_SIZE = 32
    STRIP_WIDTH = 192  # 6 faces * 32
    STRIP_HEIGHT = 32

    # Increased equirectangular resolution for better sampling
    EQUIRECT_WIDTH = FACE_SIZE * 8
    EQUIRECT_HEIGHT = FACE_SIZE * 8

    # Create temp directory for storage
    import tempfile
    temp_dir = tempfile.mkdtemp()

    # Store original render settings
    orig_settings = {
        'engine': scene.render.engine,
        'res_x': scene.render.resolution_x,
        'res_y': scene.render.resolution_y,
        'camera': scene.camera,
        'cycles_samples': scene.cycles.samples,
        'cycles_preview_samples': scene.cycles.preview_samples
    }

    cam_obj = None
    equirect_path = None

    try:
        # Setup for baking
        scene.render.engine = 'CYCLES'

        # Set render resolution for equirectangular
        scene.render.resolution_x = EQUIRECT_WIDTH
        scene.render.resolution_y = EQUIRECT_HEIGHT
        scene.render.resolution_percentage = 100
        scene.render.image_settings.file_format = 'OPEN_EXR'
        scene.render.image_settings.color_mode = 'RGBA'
        scene.render.image_settings.color_depth = '32'
        scene.render.image_settings.exr_codec = 'ZIP'
        scene.render.use_border = False
        scene.render.use_crop_to_border = False
        scene.render.filter_size = 0.5  # Reduced filter size for sharper edges

        scene.cycles.samples = probe_properties.samples
        scene.cycles.preview_samples = probe_properties.samples

        # Create temporary camera
        cam_obj = create_temp_camera(scene, probe_obj.location)

        # Render equirectangular image
        equirect_path = render_equirectangular(scene, cam_obj, temp_dir)

        # Load equirectangular image
        eq_img = bpy.data.images.load(equirect_path)
        eq_pixels = np.array(eq_img.pixels[:])
        eq_pixels = eq_pixels.reshape(EQUIRECT_HEIGHT, EQUIRECT_WIDTH, 4)

        # Convert to cubemap faces with padding
        cubemap_faces = equirectangular_to_cubemap(eq_pixels, FACE_SIZE, padding=2)

        # Combine faces into horizontal strip
        strip = np.hstack([face for face in cubemap_faces])

        # Create final image
        image_name = f".{probe_obj.name}"
        final_img = None

        # Check if we already have this image
        if 'baked_cubemap' in probe_obj.lightprobe:
            existing_image = probe_obj.lightprobe.baked_cubemap
            if isinstance(existing_image, str):
                # If it's a string, try to find the image
                final_img = bpy.data.images.get(existing_image)
            elif isinstance(existing_image, bpy.types.Image):
                final_img = existing_image

        # If we found the image, resize it if needed
        if final_img:
            if (final_img.size[0] != STRIP_WIDTH or
                final_img.size[1] != STRIP_HEIGHT):
                final_img.scale(STRIP_WIDTH, STRIP_HEIGHT)
        else:
            # Create new image if we couldn't find existing one
            final_img = bpy.data.images.new(
                image_name,
                width=STRIP_WIDTH,
                height=STRIP_HEIGHT,
                float_buffer=True
            )

        # Ensure the image has the correct name
        final_img.name = image_name
        final_img.use_fake_user = True

        # Update pixels
        final_img.pixels = strip.flatten()

        # Clean up the temporary equirectangular image
        bpy.data.images.remove(eq_img)

        # Store image in probe
        probe_properties.baked_cubemap = final_img
        probe_properties.needs_rebake = False

        final_img.pack()

        return final_img

    except Exception as e:
        raise e

    finally:
        # Cleanup code
        if equirect_path and os.path.exists(equirect_path):
            try:
                os.remove(equirect_path)
            except:
                pass

        if os.path.exists(temp_dir):
            try:
                os.rmdir(temp_dir)
            except:
                pass

        if cam_obj:
            try:
                bpy.data.objects.remove(cam_obj, do_unlink=True)
            except:
                pass

        # Restore original settings
        scene.render.engine = orig_settings['engine']
        scene.render.resolution_x = orig_settings['res_x']
        scene.render.resolution_y = orig_settings['res_y']
        scene.camera = orig_settings['camera']
        scene.cycles.samples = orig_settings['cycles_samples']
        scene.cycles.preview_samples = orig_settings['cycles_preview_samples']

def bake_all_probes(context):
    """Bake cubemaps for all light probes in the scene"""
    probes = [obj for obj in context.scene.objects
              if obj.type == 'EMPTY' and 'lightprobe' in obj]

    for probe_obj in probes:
        try:
            cubemap = bake_lightprobe(context, probe_obj)
            if cubemap:
                probe_obj.lightprobe.baked_cubemap = cubemap
                probe_obj.lightprobe.needs_rebake = False
        except Exception as e:
            print(f"Failed to bake probe {probe_obj.name}: {str(e)}")
            continue
