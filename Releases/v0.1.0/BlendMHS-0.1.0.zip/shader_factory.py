from shutil import register_unpack_format
import bpy, os
from bpy.props import StringProperty, BoolProperty, EnumProperty, FloatProperty, PointerProperty, CollectionProperty, IntProperty, FloatVectorProperty
from . import props
from .utils import debug_log, LogCategory

# Import centralized format configuration
from .shader_templates.base import TEMPLATE_BASED_FORMATS, DEPRECATED_FORMATS


def get_node_group_name(format_name):
    """Get the actual node group name for a given format from the template"""
    from .shader_templates import get_template
    template = get_template(format_name)
    if template:
        return template.node_group_name
    return None

def is_template_based_format(format_name):
    """Check if a format uses the new template system"""
    return format_name in TEMPLATE_BASED_FORMATS

def get_all_template_node_group_names():
    """Get all node group names from registered templates"""
    from .shader_templates import TEMPLATE_REGISTRY
    return {template.node_group_name for template in TEMPLATE_REGISTRY.values()}

def setup_material_nodes(material):
    """Main entry point for setting up material nodes"""
    if not material.mhs:
        return None

    format_name = material.mhs.material_format

    # Handle NONE format - do nothing
    if format_name == 'NONE':
        return None

    debug_log(f"Setting up material nodes: format={format_name}", LogCategory.MATERIAL_SETUP)

    # Store old connections
    old_group = get_main_group_node(material)
    old_connections = store_node_connections(old_group) if old_group else {}

    # Catalog existing texture nodes BEFORE removing the old group
    existing_textures = find_existing_texture_nodes(material)
    vertex_color_node = find_vertex_color_node(material)
    uv_transform_node = find_uv_transform_node(material)

    debug_log(f"Found {len(existing_textures)} existing textures: {list(existing_textures.keys())}", LogCategory.MATERIAL_SETUP)

    # Remove old group if it exists
    if old_group:
        material.node_tree.nodes.remove(old_group)

    # Handle template-based formats
    if is_template_based_format(format_name):
        new_group = add_template_node_group(material, format_name)
    else:
        # Unsupported format - no longer supporting legacy master .blend file loading
        debug_log(f"Unsupported format '{format_name}' - use a template-based format instead", LogCategory.MATERIAL_SETUP)
        return None

    if new_group:
        # Check if the new format supports textures
        from .shader_templates import get_template
        template = get_template(format_name)
        new_format_has_textures = template and len(template.texture_inputs) > 0

        if new_format_has_textures:
            # First try to restore direct connections (for exact socket name matches)
            restore_node_connections(material, new_group, old_connections)

            # Then intelligently reconnect texture nodes to matching inputs
            reconnect_textures_to_new_group(material, new_group, existing_textures)

            # Ensure UV transform is connected to all texture nodes
            # If there are existing textures but no UV transform node, create one
            if existing_textures and not uv_transform_node:
                from .shader_templates import uv_transform
                uv_transform_node = uv_transform.ensure_uv_transform_in_material(material)
                debug_log("Created UV transform node for existing textures", LogCategory.MATERIAL_SETUP)

            if uv_transform_node:
                reconnect_uv_transform_to_textures(material, uv_transform_node)
        else:
            # New format doesn't support textures - remove texture nodes and UV transform
            if existing_textures:
                debug_log(f"Removing {len(existing_textures)} texture nodes (format '{format_name}' doesn't use textures)", LogCategory.MATERIAL_SETUP)
                remove_texture_nodes(material, existing_textures)

            if uv_transform_node:
                debug_log("Removing UV transform node (format doesn't use textures)", LogCategory.MATERIAL_SETUP)
                material.node_tree.nodes.remove(uv_transform_node)

        # Reconnect vertex color if the new group supports it
        reconnect_vertex_color_to_new_group(material, new_group, vertex_color_node)

    return new_group

def add_template_node_group(material, format_name):
    """Add a node group using the new template system"""
    from .shader_templates import get_template

    template = get_template(format_name)
    if not template:
        debug_log(f"No template found for format: {format_name}", LogCategory.MATERIAL_GROUPS)
        return None

    debug_log(f"Using template: {template.name} -> {template.node_group_name}", LogCategory.MATERIAL_SETUP)

    # Ensure material uses nodes
    if not material.use_nodes:
        material.use_nodes = True

    # Get or create the node group from template
    node_group = template.get_or_create_node_group()

    # Create and setup group node in material
    group_node = material.node_tree.nodes.new('ShaderNodeGroup')
    group_node.node_tree = node_group
    group_node.location = (0, 0)
    group_node.name = template.node_group_name

    # Ensure output node exists
    output = material.node_tree.nodes.get("Material Output")
    if not output:
        output = material.node_tree.nodes.new('ShaderNodeOutputMaterial')
        output.location = (300, 0)

    # Connect to output if possible
    if 'BSDF' in group_node.outputs:
        material.node_tree.links.new(group_node.outputs['BSDF'], output.inputs['Surface'])

    return group_node

def get_main_group_node(material):
    """Find the main MHS node group in the material"""
    if not material.node_tree:
        return None

    # Check for template-based node groups only
    all_group_names = get_all_template_node_group_names()

    return next((node for node in material.node_tree.nodes
                if node.type == 'GROUP' and
                node.node_tree and
                node.node_tree.name in all_group_names), None)

def store_node_connections(node):
    """Store all input and output connections of a node"""
    if not node:
        return {}

    connections = {}

    # Store input connections
    for input in node.inputs:
        if input.is_linked:
            connections[f"input_{input.name}"] = input.links[0].from_socket

    # Store output connections
    for output in node.outputs:
        if output.is_linked:
            connections[f"output_{output.name}"] = [link.to_socket for link in output.links]

    return connections


def find_existing_texture_nodes(material):
    """Find all texture nodes in the material and catalog them by their purpose.

    Returns a dict mapping texture purposes to their nodes and images:
    {
        'Base Color': {'node': tex_node, 'image': image, 'alpha_linked': True},
        'MRO Texture': {'node': tex_node, 'image': image},
        ...
    }
    """
    if not material.node_tree:
        return {}

    textures = {}

    for node in material.node_tree.nodes:
        if node.type == 'TEX_IMAGE':
            # Determine the purpose of this texture node by label or name
            purpose = None

            # Check label first (most reliable)
            if node.label:
                purpose = node.label
            # Fall back to name patterns
            elif 'Base Color' in node.name or 'baseColor' in node.name.lower():
                purpose = 'Base Color'
            elif 'MRO' in node.name or 'mro' in node.name.lower():
                purpose = 'MRO Texture'
            elif 'Emissive' in node.name or 'emissive' in node.name.lower():
                purpose = 'Emissive Texture'
            elif 'Normal' in node.name or 'normal' in node.name.lower():
                purpose = 'Normal'

            if purpose and node.image:
                textures[purpose] = {
                    'node': node,
                    'image': node.image,
                    'location': node.location.copy(),
                    # Check if alpha output is linked
                    'alpha_linked': node.outputs['Alpha'].is_linked if 'Alpha' in node.outputs else False
                }

    return textures


def find_vertex_color_node(material):
    """Find vertex color node in the material"""
    if not material.node_tree:
        return None

    for node in material.node_tree.nodes:
        if node.type == 'VERTEX_COLOR':
            return node

    return None


def find_uv_transform_node(material):
    """Find the MHS_UVTransform node group in the material"""
    if not material.node_tree:
        return None

    for node in material.node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_UVTransform':
            return node

    return None


def remove_texture_nodes(material, existing_textures):
    """Remove texture nodes from the material.

    This is called when switching to a format that doesn't support textures
    (e.g., PBR Simple). The textures are removed to clean up the node tree.

    Args:
        material: The material containing the nodes
        existing_textures: Dict of texture info from find_existing_texture_nodes()
    """
    if not material.node_tree or not existing_textures:
        return

    node_tree = material.node_tree

    for tex_name, tex_info in existing_textures.items():
        tex_node = tex_info['node']
        if tex_node and tex_node.name in node_tree.nodes:
            node_tree.nodes.remove(tex_node)
            debug_log(f"Removed texture node '{tex_name}'", LogCategory.MATERIAL_SETUP)


def reconnect_textures_to_new_group(material, new_group, existing_textures):
    """Reconnect existing texture nodes to a new shader group.

    This handles:
    - Matching texture nodes to inputs by name
    - Connecting alpha channels for formats that need them
    - Setting up proper alpha mode for transparency formats
    """
    if not material.node_tree or not new_group or not existing_textures:
        return

    node_tree = material.node_tree

    # Map common texture names to potential input names
    texture_input_mapping = {
        'Base Color': ['Base Color'],
        'MRO Texture': ['MRO Texture'],
        'MRO': ['MRO Texture'],
        'Emissive Texture': ['Emissive Texture'],
        'Emissive': ['Emissive Texture'],
        'Normal': ['Normal'],
    }

    # Check if the new group has an Alpha input (for blend/masked shaders)
    has_alpha_input = 'Alpha' in new_group.inputs

    for tex_name, tex_info in existing_textures.items():
        tex_node = tex_info['node']

        # Find matching input on new group
        input_names_to_try = texture_input_mapping.get(tex_name, [tex_name])

        connected = False
        for input_name in input_names_to_try:
            if input_name in new_group.inputs:
                # Connect color output to the group input
                node_tree.links.new(tex_node.outputs['Color'], new_group.inputs[input_name])
                connected = True
                debug_log(f"Reconnected texture '{tex_name}' to input '{input_name}'", LogCategory.MATERIAL_SETUP)
                break

        # For Base Color textures, also connect alpha if the group needs it
        if tex_name == 'Base Color' and has_alpha_input:
            if 'Alpha' in tex_node.outputs:
                node_tree.links.new(tex_node.outputs['Alpha'], new_group.inputs['Alpha'])

                # Also set alpha mode to Channel Packed for proper handling
                if tex_node.image:
                    tex_node.image.alpha_mode = 'CHANNEL_PACKED'

                debug_log(f"Connected alpha channel from Base Color texture", LogCategory.MATERIAL_SETUP)

        if not connected:
            debug_log(f"Could not find matching input for texture '{tex_name}'", LogCategory.MATERIAL_SETUP)


def reconnect_vertex_color_to_new_group(material, new_group, vc_node):
    """Reconnect vertex color node to the new shader group if it has matching inputs"""
    if not material.node_tree or not new_group or not vc_node:
        return

    node_tree = material.node_tree

    # Try to connect to Vertex Color input
    if 'Vertex Color' in new_group.inputs:
        node_tree.links.new(vc_node.outputs['Color'], new_group.inputs['Vertex Color'])
        debug_log("Reconnected Vertex Color node", LogCategory.MATERIAL_SETUP)


def reconnect_uv_transform_to_textures(material, uv_transform_node):
    """Ensure all texture nodes are connected to the UV transform node"""
    if not material.node_tree or not uv_transform_node:
        return

    from .shader_templates import uv_transform

    for node in material.node_tree.nodes:
        if node.type == 'TEX_IMAGE':
            # Check if already connected to UV transform
            if not node.inputs['Vector'].is_linked:
                uv_transform.connect_texture_to_uv_transform(material, node, uv_transform_node)

def restore_node_connections(material, node, connections):
    """Restore previously stored connections to a node"""
    if not node or not connections:
        return

    # Restore input connections
    for name, socket in connections.items():
        if name.startswith("input_"):
            input_name = name[6:]  # Remove "input_" prefix
            if input_name in node.inputs:
                material.node_tree.links.new(socket, node.inputs[input_name])

        elif name.startswith("output_"):
            output_name = name[7:]  # Remove "output_" prefix
            if output_name in node.outputs:
                for to_socket in socket:
                    material.node_tree.links.new(node.outputs[output_name], to_socket)

def setup_pbr_shader(material):
    """Set up a PBR shader for a material - DEPRECATED, use setup_material_nodes instead"""
    # Ensure the material uses nodes
    material.use_nodes = True

    # Get the node group name from the material format
    format_name = material.mhs.material_format

    # Only support template-based formats now
    if not is_template_based_format(format_name):
        debug_log(f"Unsupported format: {format_name}, use ISOTROPIC_USD instead", LogCategory.MATERIAL_SETUP)
        return None

    new_group_name = get_node_group_name(format_name)

    debug_log(f"Setting up shader: format={format_name}, group={new_group_name}", LogCategory.MATERIAL_SETUP)

    # Find the existing main group node (if any)
    all_group_names = get_all_template_node_group_names()
    old_group_node = next((node for node in material.node_tree.nodes
                         if node.type == 'GROUP' and
                         node.node_tree and
                         node.node_tree.name in all_group_names), None)

    # Store connections of the old group
    old_connections = {}
    if old_group_node:
        for input in old_group_node.inputs:
            if input.is_linked:
                old_connections[input.name] = input.links[0].from_socket

        for output in old_group_node.outputs:
            if output.is_linked:
                for link in output.links:
                    old_connections[output.name] = link.to_socket

        # Remove the old group
        material.node_tree.nodes.remove(old_group_node)

    # Add the new group using template system
    new_group_node = add_template_node_group(material, format_name)
    if not new_group_node:
        debug_log(f"Failed to add node group: {new_group_name}", LogCategory.MATERIAL_GROUPS)
        return

    # Reconnect inputs and outputs
    for input_name, from_socket in old_connections.items():
        if input_name in new_group_node.inputs:
            material.node_tree.links.new(from_socket, new_group_node.inputs[input_name])

    for output in new_group_node.outputs:
        if output.name in old_connections:
            material.node_tree.links.new(output, old_connections[output.name])

    # Update dynamic properties
    material.mhs.update_dynamic_properties(new_group_node)

    return new_group_node

def update_dynamic_properties(material_system, group_node):
    """Update dynamic shader properties based on node group"""
    material_system.properties.clear()
    material_system.panels.clear()

    if not group_node.node_tree:
        return

    current_panel = None
    for item in group_node.node_tree.interface.items_tree:
        if item.item_type == 'PANEL':
            if item.name != "Output":
                current_panel = material_system.panels.add()
                current_panel.name = item.name
                current_panel.is_open = True

        elif item.item_type == 'SOCKET' and current_panel:
            if item.name in group_node.inputs and not item.name.startswith("_"):
                prop = material_system.properties.add()
                prop.name = item.name

                # Get the input socket from both the node and the interface
                input_socket = group_node.inputs[item.name]

                # Check for textures
                prop.is_texture = item.name.lower().endswith(('_tex', '_texture'))

                # Determine property type based on socket type and name
                if input_socket.type == 'RGBA' and (
                    'color' in item.name.lower() or
                    'tint' in item.name.lower() or
                    'albedo' in item.name.lower()
                ):
                    prop.is_color = True
                    prop.value_color = input_socket.default_value

                elif input_socket.type == 'BOOLEAN':
                    prop.is_bool = True
                    prop.value_float = bool(input_socket.default_value)

                # Handle vector inputs
                elif input_socket.type == 'VECTOR':
                    prop.is_vector = True  # Set the vector flag
                    # Blender VECTOR sockets return 3 components, but value_vector expects 4
                    vec = input_socket.default_value
                    if len(vec) == 3:
                        prop.value_vector = (vec[0], vec[1], vec[2], 0.0)
                    else:
                        prop.value_vector = vec

                # Handle float properties with kwargs
                elif input_socket.type == 'VALUE':
                    # Store min/max constraints on the instance, not the class
                    # Check if the interface item has min/max set
                    if hasattr(item, 'min_value'):
                        prop.float_min = item.min_value
                        prop.float_has_min = True
                    if hasattr(item, 'max_value'):
                        prop.float_max = item.max_value
                        prop.float_has_max = True

                    # Set the default value
                    prop.value_float = input_socket.default_value

                # Update the panel's property list
                if current_panel.properties:
                    current_panel.properties += f",{prop.name}"
                else:
                    current_panel.properties = prop.name

def setup_vertex_color(material, group_node):
    """Set up vertex color nodes"""
    vertex_color = material.node_tree.nodes.new(type='ShaderNodeVertexColor')
    vertex_color.location = (-300, 200)

    if 'Base Color' in group_node.inputs:
        material.node_tree.links.new(vertex_color.outputs['Color'], group_node.inputs['Base Color'])
    if 'Alpha' in group_node.inputs:
        material.node_tree.links.new(vertex_color.outputs['Alpha'], group_node.inputs['Alpha'])


def setup_lightmap_material(material, lightmap_selector_group):
    """
    Set up lightmap for a single material.
    This function should be called for each material that needs lightmap support.
    """
    # Find the MHS node group
    mhs_group = next((node for node in material.node_tree.nodes if node.type == 'GROUP' and node.node_tree.name.startswith("MHS")), None)

    if not mhs_group:
        debug_log(f"No MHS group found in material {material.name}", LogCategory.MATERIAL_LIGHTMAP)
        return None

    # Add or get the LightmapSelector node in the material
    lightmap_group_node = material.node_tree.nodes.get("LightmapSelector")
    if not lightmap_group_node:
        lightmap_group_node = material.node_tree.nodes.new(type='ShaderNodeGroup')
        lightmap_group_node.node_tree = lightmap_selector_group
        lightmap_group_node.name = "LightmapSelector"
        lightmap_group_node.location = (-400, -1000)

    # Find the _lightmap input in the MHS group
    lightmap_input = next((input for input in mhs_group.inputs if input.name.lower() == "_lightmap"), None)

    if not lightmap_input:
        debug_log(f"No _lightmap input found in MHS group for material {material.name}", LogCategory.MATERIAL_LIGHTMAP)
        return None

    # Connect the LightmapSelector output to the MHS group _lightmap input
    material.node_tree.links.new(lightmap_group_node.outputs["Selected Lightmap"], lightmap_input)

    return lightmap_group_node

def ensure_lightmap_selector_group(num_lightmaps):
    """
    Ensure the LightmapSelector group exists and is up-to-date.
    This function should be called once before processing materials.
    """
    lightmap_selector_group = bpy.data.node_groups.get("LightmapSelector")
    if lightmap_selector_group:
        rebuild_lightmap_selector_group(lightmap_selector_group, num_lightmaps)
    else:
        lightmap_selector_group = create_lightmap_selector_group(num_lightmaps)
    return lightmap_selector_group

def rebuild_lightmap_selector_group(node_group, num_lightmaps):
    # Clear existing nodes and sockets
    node_group.nodes.clear()
    node_group.interface.clear()

    # Create input and output nodes in the group
    group_inputs = node_group.nodes.new("NodeGroupInput")
    group_inputs.location = (-1000, 0)
    group_outputs = node_group.nodes.new("NodeGroupOutput")
    group_outputs.location = (600, 0)

    # Create output socket for selected lightmap
    node_group.interface.new_socket(name="Selected Lightmap", in_out='OUTPUT', socket_type='NodeSocketColor')

    # Create the UV node for lightmaps
    uv_node = node_group.nodes.new(type='ShaderNodeUVMap')
    uv_node.uv_map = "LightmapUV"
    uv_node.location = (-1000, -400)

    # Create the Attribute node for lightmap index
    attribute_node = node_group.nodes.new(type='ShaderNodeAttribute')
    attribute_node.attribute_name = "mhs.lightmap_index"
    attribute_node.attribute_type = 'OBJECT'
    attribute_node.location = (-800, 0)

    # Create a white color node for the default case
    white_node = node_group.nodes.new(type='ShaderNodeRGB')
    white_node.outputs[0].default_value = (1, 1, 1, 1)  # White color
    white_node.location = (-600, 200)

    # Create embedded lightmap texture nodes
    lightmap_nodes = []
    for i in range(num_lightmaps):
        tex_node = node_group.nodes.new(type='ShaderNodeTexImage')
        tex_node.name = f"Lightmap_{i}"
        tex_node.label = f"Lightmap {i}"
        tex_node.location = (-600, -200 * (i + 1))
        lightmap_nodes.append(tex_node)
        node_group.links.new(uv_node.outputs['UV'], tex_node.inputs['Vector'])

    # Create a cascading series of Mix RGB nodes for lightmap selection
    previous_mix = None
    for i in range(num_lightmaps):
        mix_node = node_group.nodes.new(type='ShaderNodeMixRGB')
        mix_node.location = (-400 + i * 200, 0)
        mix_node.blend_type = 'MIX'

        compare_node = node_group.nodes.new(type='ShaderNodeMath')
        compare_node.operation = 'GREATER_THAN'
        compare_node.inputs[1].default_value = i - 1 # Threshold at exactly i
        compare_node.location = (-400 + i * 200, 200)

        node_group.links.new(attribute_node.outputs["Fac"], compare_node.inputs[0])
        node_group.links.new(compare_node.outputs[0], mix_node.inputs[0])
        node_group.links.new(lightmap_nodes[i].outputs['Color'], mix_node.inputs[2])

        if previous_mix:
            node_group.links.new(previous_mix.outputs[0], mix_node.inputs[1])
        else:
            node_group.links.new(white_node.outputs[0], mix_node.inputs[1])

        previous_mix = mix_node

    # Link the last mix node to the output
    node_group.links.new(previous_mix.outputs[0], group_outputs.inputs["Selected Lightmap"])

def create_lightmap_selector_group(num_lightmaps):
    group_name = "LightmapSelector"
    node_group = bpy.data.node_groups.new(type="ShaderNodeTree", name=group_name)
    rebuild_lightmap_selector_group(node_group, num_lightmaps)
    return node_group

def set_lightmap_texture(material, lightmap_index, texture):
    lightmap_group_node = material.node_tree.nodes.get("LightmapSelector")
    if lightmap_group_node and lightmap_group_node.node_tree:
        lightmap_node = lightmap_group_node.node_tree.nodes.get(f"Lightmap_{lightmap_index}")
        if lightmap_node:
            lightmap_node.image = texture
        else:
            debug_log(f"Lightmap node {lightmap_index} not found in LightmapSelector group", LogCategory.MATERIAL_LIGHTMAP)
    else:
        debug_log("LightmapSelector group node not found in material", LogCategory.MATERIAL_LIGHTMAP)

def setup_lightmaps_for_baking(materials, num_lightmaps):
    """
    Set up lightmaps in materials after baking is complete.
    This connects the baked lightmaps to the appropriate selector nodes.

    Args:
        materials: List of materials to set up lightmaps for
        num_lightmaps: Total number of lightmap groups
    """
    # First ensure we have the LightmapSelector node group
    lightmap_selector_group = ensure_lightmap_selector_group(num_lightmaps)

    # Process each material
    for material in materials:
        if not material.use_nodes:
            continue

        # First, try to find existing LightmapSelector node
        lightmap_group_node = material.node_tree.nodes.get("LightmapSelector")

        if not lightmap_group_node:
            # If no selector exists, create one
            lightmap_group_node = material.node_tree.nodes.new(type='ShaderNodeGroup')
            lightmap_group_node.node_tree = lightmap_selector_group
            lightmap_group_node.name = "LightmapSelector"
            lightmap_group_node.location = (-400, -1000)

            # Find the MHS node group to connect to
            mhs_group = next((node for node in material.node_tree.nodes
                            if node.type == 'GROUP' and
                            node.node_tree.name.startswith("MHS")), None)

            if mhs_group:
                # Find and connect to the _lightmap input
                lightmap_input = next((input for input in mhs_group.inputs
                                     if input.name.lower() == "_lightmap"), None)
                if lightmap_input:
                    material.node_tree.links.new(
                        lightmap_group_node.outputs["Selected Lightmap"],
                        lightmap_input
                    )

        # Now connect the baked lightmaps to the selector nodes
        for lightmap_index, group in enumerate(bpy.context.scene.mhs.lightmap_groups):
            if group.baked_lightmap:
                lightmap_node = lightmap_group_node.node_tree.nodes.get(f"Lightmap_{lightmap_index}")
                if lightmap_node:
                    lightmap_node.image = group.baked_lightmap

                    # Ensure proper image settings
                    if group.baked_lightmap.colorspace_settings.name != 'Non-Color':
                        group.baked_lightmap.colorspace_settings.name = 'Non-Color'

def ensure_lightmap_selector_group(num_lightmaps):
    """
    Ensure the LightmapSelector group exists and is up-to-date.
    Rebuilds the group if the number of lightmaps has changed.

    Args:
        num_lightmaps: Number of lightmap slots needed

    Returns:
        The LightmapSelector node group
    """
    lightmap_selector_group = bpy.data.node_groups.get("LightmapSelector")

    # Check if we need to create or update the group
    needs_rebuild = False
    if lightmap_selector_group:
        # Count existing lightmap nodes to see if we need to rebuild
        existing_lightmaps = sum(1 for node in lightmap_selector_group.nodes
                               if node.name.startswith("Lightmap_"))
        needs_rebuild = existing_lightmaps != num_lightmaps
    else:
        lightmap_selector_group = bpy.data.node_groups.new(
            name="LightmapSelector",
            type="ShaderNodeTree"
        )
        needs_rebuild = True

    if needs_rebuild:
        rebuild_lightmap_selector_group(lightmap_selector_group, num_lightmaps)

    return lightmap_selector_group

def rebuild_lightmap_selector_group(node_group, num_lightmaps):
    """
    Rebuild the internal nodes of the LightmapSelector group.

    Args:
        node_group: The node group to rebuild
        num_lightmaps: Number of lightmap slots to create
    """
    # Clear existing nodes and sockets
    node_group.nodes.clear()
    node_group.interface.clear()

    # Create input and output nodes
    group_inputs = node_group.nodes.new("NodeGroupInput")
    group_inputs.location = (-1000, 0)
    group_outputs = node_group.nodes.new("NodeGroupOutput")
    group_outputs.location = (600, 0)

    # Create output socket for selected lightmap
    node_group.interface.new_socket(
        name="Selected Lightmap",
        in_out='OUTPUT',
        socket_type='NodeSocketColor'
    )

    # Create the UV node for lightmaps
    uv_node = node_group.nodes.new(type='ShaderNodeUVMap')
    uv_node.uv_map = "LightmapUV"
    uv_node.location = (-1000, -400)

    # Create the Attribute node for lightmap index
    attribute_node = node_group.nodes.new(type='ShaderNodeAttribute')
    attribute_node.attribute_name = "mhs.lightmap_index"
    attribute_node.attribute_type = 'OBJECT'
    attribute_node.location = (-800, 0)

    # Create a white color node for the default case
    white_node = node_group.nodes.new(type='ShaderNodeRGB')
    white_node.outputs[0].default_value = (1, 1, 1, 1)
    white_node.location = (-600, 200)

    # Create embedded lightmap texture nodes
    lightmap_nodes = []
    for i in range(num_lightmaps):
        tex_node = node_group.nodes.new(type='ShaderNodeTexImage')
        tex_node.name = f"Lightmap_{i}"
        tex_node.label = f"Lightmap {i}"
        tex_node.location = (-600, -200 * (i + 1))
        node_group.links.new(uv_node.outputs['UV'], tex_node.inputs['Vector'])
        lightmap_nodes.append(tex_node)

    # Create a cascading series of Mix RGB nodes
    previous_mix = None
    for i in range(num_lightmaps):
        mix_node = node_group.nodes.new(type='ShaderNodeMixRGB')
        mix_node.location = (-400 + i * 200, 0)
        mix_node.blend_type = 'MIX'

        # Create comparison node for index selection
        compare_node = node_group.nodes.new(type='ShaderNodeMath')
        compare_node.operation = 'GREATER_THAN'
        compare_node.inputs[1].default_value = i - 1
        compare_node.location = (-400 + i * 200, 200)

        # Connect nodes
        node_group.links.new(attribute_node.outputs["Fac"], compare_node.inputs[0])
        node_group.links.new(compare_node.outputs[0], mix_node.inputs[0])
        node_group.links.new(lightmap_nodes[i].outputs['Color'], mix_node.inputs[2])

        if previous_mix:
            node_group.links.new(previous_mix.outputs[0], mix_node.inputs[1])
        else:
            node_group.links.new(white_node.outputs[0], mix_node.inputs[1])

        previous_mix = mix_node

    # Connect final mix node to output
    node_group.links.new(previous_mix.outputs[0], group_outputs.inputs["Selected Lightmap"])
