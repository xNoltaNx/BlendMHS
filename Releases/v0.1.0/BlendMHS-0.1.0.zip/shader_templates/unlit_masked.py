"""
Unlit Masked Shader Template

Creates a Blender node group matching the MHS unlitMasked.surface shader.
This shader displays textures without lighting and uses alpha masking (cutout).
"""

import bpy
from .base import (
    ShaderTemplate,
    TextureInputSpec,
    get_color_space_for_input,
)


class UnlitMaskedTemplate(ShaderTemplate):
    """Template for the MHS unlitMasked.surface shader.

    This shader supports:
    - Base Color texture with alpha (sRGB) - displayed as emission with alpha cutout

    The shader bypasses all lighting calculations and displays the texture
    as-is using emission, with alpha masking (pixels below threshold are discarded).
    """

    @property
    def name(self) -> str:
        return "Unlit Masked"

    @property
    def node_group_name(self) -> str:
        return "MHS_UnlitMasked"

    @property
    def mhs_shader(self) -> str:
        return "unlitMasked.surface"

    @property
    def description(self) -> str:
        return "Unlit shader with alpha masking (cutout)"

    @property
    def texture_inputs(self) -> list[TextureInputSpec]:
        return [
            TextureInputSpec(
                name="Base Color",
                socket_name="Base Color",
                default_color=(1.0, 1.0, 1.0, 1.0),
                color_space='sRGB',
                usd_attribute='diffuseColor',
                channel_mapping={
                    'RGB': 'diffuseColor',
                    'A': 'opacity',
                },
            ),
        ]

    def _create_node_group(self) -> bpy.types.NodeTree:
        """Create the MHS_UnlitMasked node group.

        Node structure:
        - Group inputs for base color (RGBA)
        - Emission shader for color
        - Transparent shader for masked areas
        - Mix shader controlled by alpha (hard cutoff)
        - BSDF output

        Note: Alpha masking in Blender is achieved through material settings
        (clip threshold) rather than in the shader itself.
        """
        # Create the node group
        node_group = bpy.data.node_groups.new(
            name=self.node_group_name,
            type='ShaderNodeTree'
        )

        # Create group input and output nodes
        group_input = node_group.nodes.new('NodeGroupInput')
        group_input.location = (-600, 0)

        group_output = node_group.nodes.new('NodeGroupOutput')
        group_output.location = (600, 0)

        # Create interface sockets (inputs/outputs)
        textures_panel = node_group.interface.new_panel(name="Textures")

        # Base Color Texture input (includes alpha)
        base_color_socket = node_group.interface.new_socket(
            name="Base Color",
            in_out='INPUT',
            socket_type='NodeSocketColor',
            parent=textures_panel
        )
        base_color_socket.default_value = (1.0, 1.0, 1.0, 1.0)

        # Alpha input (separate for flexibility)
        alpha_socket = node_group.interface.new_socket(
            name="Alpha",
            in_out='INPUT',
            socket_type='NodeSocketFloat',
            parent=textures_panel
        )
        alpha_socket.default_value = 1.0
        alpha_socket.min_value = 0.0
        alpha_socket.max_value = 1.0

        # BSDF output
        node_group.interface.new_socket(
            name='BSDF',
            in_out='OUTPUT',
            socket_type='NodeSocketShader'
        )

        # ============================================
        # Create internal nodes
        # ============================================

        # Emission shader for unlit color
        emission = node_group.nodes.new('ShaderNodeEmission')
        emission.location = (0, 100)
        emission.name = 'Emission'
        emission.inputs['Strength'].default_value = 1.0

        # Transparent shader for masked areas
        transparent = node_group.nodes.new('ShaderNodeBsdfTransparent')
        transparent.location = (0, -100)
        transparent.name = 'Transparent'

        # Mix shader to blend emission and transparent based on alpha
        mix_shader = node_group.nodes.new('ShaderNodeMixShader')
        mix_shader.location = (300, 0)
        mix_shader.name = 'Mix_Alpha'

        # ============================================
        # Create connections
        # ============================================
        links = node_group.links

        # Base Color -> Emission Color
        links.new(group_input.outputs['Base Color'], emission.inputs['Color'])

        # Alpha controls mix (0 = transparent, 1 = emission)
        links.new(group_input.outputs['Alpha'], mix_shader.inputs['Fac'])

        # Transparent -> Mix Shader input 1 (when alpha = 0)
        links.new(transparent.outputs['BSDF'], mix_shader.inputs[1])

        # Emission -> Mix Shader input 2 (when alpha = 1)
        links.new(emission.outputs['Emission'], mix_shader.inputs[2])

        # Mix Shader -> Output
        links.new(mix_shader.outputs['Shader'], group_output.inputs['BSDF'])

        # Store metadata for export
        self._store_metadata(node_group)

        return node_group

    def _store_metadata(self, node_group: bpy.types.NodeTree):
        """Store export metadata in the node group's custom properties."""
        import json

        # USD mappings for export
        usd_mappings = {
            'Base Color': {
                'property_type': 'TEXTURE',
                'usd_attribute': 'diffuseColor',
                'texture_source_type': 'ATTRIBUTE',
                'texture_rgba_attribute': 'diffuseColor',
                'use_alpha': True,
            },
            'Alpha': {
                'property_type': 'FLOAT',
                'usd_attribute': 'opacity',
                'note': 'Alpha channel from Base Color texture (masked/cutout)',
            },
        }

        shader_settings = {
            'template': 'UnlitMasked',
            'mhs_shader': self.mhs_shader,
            'is_dynamic': True,
            'is_masked': True,
            'is_translucent': False,
        }

        node_group['mhs_usd_mappings_json'] = json.dumps(usd_mappings)
        node_group['mhs_shader_settings_json'] = json.dumps(shader_settings)
        node_group['mhs_template'] = 'UNLIT_MASKED'


def apply_to_material(material: bpy.types.Material) -> bool:
    """Convenience function to apply UnlitMasked template to a material."""
    template = UnlitMaskedTemplate()
    result = template.apply_to_material(material)

    # Set material blend mode for alpha clip (masked)
    if result:
        material.blend_method = 'CLIP'
        material.alpha_threshold = 0.5
        material.shadow_method = 'CLIP'

    return result


def get_or_create_node_group() -> bpy.types.NodeTree:
    """Convenience function to get or create the UnlitMasked node group."""
    template = UnlitMaskedTemplate()
    return template.get_or_create_node_group()


def setup_texture_node_for_input(
    material: bpy.types.Material,
    input_name: str,
    image: bpy.types.Image
) -> bpy.types.Node | None:
    """Set up a texture node and connect it to the shader group input."""
    from . import uv_transform

    if not material.use_nodes:
        return None

    node_tree = material.node_tree

    # Find the shader group node
    group_node = None
    for node in node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_UnlitMasked':
            group_node = node
            break

    if not group_node:
        return None

    # Ensure UVTransform node exists
    uv_transform_node = uv_transform.ensure_uv_transform_in_material(material)

    # Get color space from the template's input specification
    template = UnlitMaskedTemplate()
    color_space = get_color_space_for_input(template, input_name)

    # Create texture node
    tex_node = node_tree.nodes.new('ShaderNodeTexImage')
    tex_node.name = f'{input_name}_Texture'
    tex_node.label = input_name
    tex_node.image = image

    # Position relative to group node
    tex_node.location = (group_node.location.x - 300, group_node.location.y)

    # Set color space and alpha mode for images with alpha channel
    if image:
        image.colorspace_settings.name = color_space
        # Set alpha mode to Channel Packed for proper alpha handling
        image.alpha_mode = 'CHANNEL_PACKED'

    # Connect UVTransform output to texture's Vector input
    uv_transform.connect_texture_to_uv_transform(material, tex_node, uv_transform_node)

    # Connect texture outputs to group inputs
    if 'Base Color' in group_node.inputs:
        node_tree.links.new(tex_node.outputs['Color'], group_node.inputs['Base Color'])

    # Connect alpha channel from texture to Alpha input
    if 'Alpha' in group_node.inputs:
        node_tree.links.new(tex_node.outputs['Alpha'], group_node.inputs['Alpha'])

    return tex_node
