"""
Isotropic Simple USD Shader Template

Creates a Blender node group matching the MHS isotropicSimpleUsd.surface shader.
This shader uses constant color, roughness, and metallic values with vertex color support.
"""

import bpy
from .base import (
    ShaderTemplate,
    TextureInputSpec,
    PropertyInputSpec,
)


class IsotropicSimpleUSDTemplate(ShaderTemplate):
    """Template for the MHS isotropicSimpleUsd.surface shader.

    This shader supports:
    - Base Color constant (sRGB)
    - Roughness constant (0-1)
    - Metalness constant (0-1)
    - Vertex Color multiplication (uses white if no vertex colors on mesh)

    The shader multiplies base color by vertex color for visual preview in Blender.
    No textures are used - only constant material properties.
    """

    @property
    def name(self) -> str:
        return "Isotropic Simple USD"

    @property
    def node_group_name(self) -> str:
        return "MHS_IsotropicSimpleUSD"

    @property
    def mhs_shader(self) -> str:
        return "isotropicSimpleUsd.surface"

    @property
    def description(self) -> str:
        return "MHS Isotropic Simple PBR with constant color, roughness, and metallic values"

    @property
    def texture_inputs(self) -> list[TextureInputSpec]:
        # This shader doesn't use textures - only constant values
        return []

    @property
    def property_inputs(self) -> list[PropertyInputSpec]:
        return [
            PropertyInputSpec(
                name="Base Color",
                socket_name="Base Color",
                property_type='COLOR',
                default_value=(1.0, 1.0, 1.0, 1.0),
                usd_attribute='diffuseColor',
            ),
            PropertyInputSpec(
                name="Roughness",
                socket_name="Roughness",
                property_type='FLOAT',
                default_value=0.5,
                min_value=0.0,
                max_value=1.0,
                usd_attribute='roughness',
            ),
            PropertyInputSpec(
                name="Metalness",
                socket_name="Metalness",
                property_type='FLOAT',
                default_value=0.0,
                min_value=0.0,
                max_value=1.0,
                usd_attribute='metallic',
            ),
        ]

    def _create_node_group(self) -> bpy.types.NodeTree:
        """Create the MHS_IsotropicSimpleUSD node group.

        Node structure:
        - Group inputs for base color, roughness, metalness, and vertex color
        - Vertex Color input (defaults to white 1,1,1 for meshes without vertex colors)
        - Base Color * Vertex Color multiplication
        - Principled BSDF as the core shader
        - BSDF output
        """
        # Create the node group
        node_group = bpy.data.node_groups.new(
            name=self.node_group_name,
            type='ShaderNodeTree'
        )

        # Create group input and output nodes
        group_input = node_group.nodes.new('NodeGroupInput')
        group_input.location = (-600, 0)

        group_output = node_group.nodes.new('NodeGroupOutput')
        group_output.location = (600, 0)

        # Create interface sockets (inputs/outputs)
        # Using panels to organize inputs
        material_panel = node_group.interface.new_panel(name="Material Properties")

        # Base Color input (constant)
        base_color_socket = node_group.interface.new_socket(
            name="Base Color",
            in_out='INPUT',
            socket_type='NodeSocketColor',
            parent=material_panel
        )
        base_color_socket.default_value = (1.0, 1.0, 1.0, 1.0)

        # Roughness input (constant)
        roughness_socket = node_group.interface.new_socket(
            name="Roughness",
            in_out='INPUT',
            socket_type='NodeSocketFloat',
            parent=material_panel
        )
        roughness_socket.default_value = 0.5
        roughness_socket.min_value = 0.0
        roughness_socket.max_value = 1.0
        roughness_socket.subtype = 'FACTOR'

        # Metalness input (constant)
        metalness_socket = node_group.interface.new_socket(
            name="Metalness",
            in_out='INPUT',
            socket_type='NodeSocketFloat',
            parent=material_panel
        )
        metalness_socket.default_value = 0.0
        metalness_socket.min_value = 0.0
        metalness_socket.max_value = 1.0
        metalness_socket.subtype = 'FACTOR'

        # Vertex Color input (default white for meshes without vertex colors)
        vertex_color_socket = node_group.interface.new_socket(
            name="Vertex Color",
            in_out='INPUT',
            socket_type='NodeSocketColor',
            parent=material_panel
        )
        vertex_color_socket.default_value = (1.0, 1.0, 1.0, 1.0)  # White default

        # BSDF output
        node_group.interface.new_socket(
            name='BSDF',
            in_out='OUTPUT',
            socket_type='NodeSocketShader'
        )

        # ============================================
        # Create internal nodes
        # ============================================

        # Principled BSDF - main shader
        bsdf = node_group.nodes.new('ShaderNodeBsdfPrincipled')
        bsdf.location = (300, 0)
        bsdf.name = 'Principled_BSDF'

        # ============================================
        # Vertex Color multiplication
        # Base Color * Vertex Color RGB
        # ============================================
        vertex_color_mix = node_group.nodes.new('ShaderNodeMix')
        vertex_color_mix.data_type = 'RGBA'
        vertex_color_mix.blend_type = 'MULTIPLY'
        vertex_color_mix.location = (-200, 150)
        vertex_color_mix.name = 'VertexColor_Multiply'
        vertex_color_mix.inputs['Factor'].default_value = 1.0  # Full multiply

        # ============================================
        # Create connections
        # ============================================
        links = node_group.links

        # Vertex Color multiplication: Base Color * Vertex Color
        links.new(group_input.outputs['Base Color'], vertex_color_mix.inputs['A'])
        links.new(group_input.outputs['Vertex Color'], vertex_color_mix.inputs['B'])

        # Final color to Principled BSDF
        links.new(vertex_color_mix.outputs['Result'], bsdf.inputs['Base Color'])

        # Roughness -> Principled BSDF
        links.new(group_input.outputs['Roughness'], bsdf.inputs['Roughness'])

        # Metalness -> Principled BSDF
        links.new(group_input.outputs['Metalness'], bsdf.inputs['Metallic'])

        # BSDF -> Output
        links.new(bsdf.outputs['BSDF'], group_output.inputs['BSDF'])

        # Store metadata for export
        self._store_metadata(node_group)

        return node_group

    def _store_metadata(self, node_group: bpy.types.NodeTree):
        """Store export metadata in the node group's custom properties."""
        import json

        # USD constant mappings for export (no textures)
        usd_mappings = {
            'Base Color': {
                'property_type': 'COLOR',
                'source_type': 'ATTRIBUTE',
                'usd_attribute': 'diffuseColor',
            },
            'Roughness': {
                'property_type': 'FLOAT',
                'source_type': 'ATTRIBUTE',
                'usd_attribute': 'roughness',
            },
            'Metalness': {
                'property_type': 'FLOAT',
                'source_type': 'ATTRIBUTE',
                'usd_attribute': 'metallic',
            },
            'Vertex Color': {
                'property_type': 'COLOR',
                'usd_attribute': 'NONE',  # Handled separately via vertex colors
                'note': 'Multiplied with base color; uses mesh vertex colors if available',
            },
        }

        # Material map format for engine export
        material_map = {
            'name': 'usd-isotropic-simple',
            'materialType': 'usd',
            'matchMappings': True,
            'shaderTargetPath': 'meta/renderer_module@shaders/isotropicSimpleUsd.surface:shader',
            'constantMappings': {
                'matParams.baseColor': {
                    'sourceType': 'attribute',
                    'source': 'diffuseColor',
                },
                'matParams.roughness': {
                    'sourceType': 'attribute',
                    'source': 'roughness',
                },
                'matParams.metalness': {
                    'sourceType': 'attribute',
                    'source': 'metallic',
                },
            },
            'textureMappings': {},
        }

        shader_settings = {
            'template': 'Lit',
            'mhs_shader': self.mhs_shader,
            'is_dynamic': True,
            'is_masked': False,
            'is_translucent': False,
        }

        node_group['mhs_usd_mappings_json'] = json.dumps(usd_mappings)
        node_group['mhs_material_map_json'] = json.dumps(material_map)
        node_group['mhs_shader_settings_json'] = json.dumps(shader_settings)
        node_group['mhs_template'] = 'ISOTROPIC_SIMPLE_USD'


def apply_to_material(material: bpy.types.Material) -> bool:
    """Convenience function to apply IsotropicSimpleUSD template to a material.

    Args:
        material: Blender material to modify

    Returns:
        True if successful
    """
    template = IsotropicSimpleUSDTemplate()
    return template.apply_to_material(material)


def get_or_create_node_group() -> bpy.types.NodeTree:
    """Convenience function to get or create the IsotropicSimpleUSD node group.

    Returns:
        The node group
    """
    template = IsotropicSimpleUSDTemplate()
    return template.get_or_create_node_group()


def setup_vertex_color_node(material: bpy.types.Material) -> bpy.types.Node | None:
    """Set up a Vertex Color node and connect it to the shader group.

    If the mesh has vertex colors, this connects them to the Vertex Color input.
    If not, the default white (1,1,1) in the node group will be used.

    Args:
        material: Material containing the shader group

    Returns:
        The created vertex color node, or None if failed
    """
    if not material.use_nodes:
        return None

    node_tree = material.node_tree

    # Find the shader group node
    group_node = None
    for node in node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_IsotropicSimpleUSD':
            group_node = node
            break

    if not group_node:
        return None

    # Check if Vertex Color input exists
    if 'Vertex Color' not in group_node.inputs:
        return None

    # Create vertex color node
    vc_node = node_tree.nodes.new('ShaderNodeVertexColor')
    vc_node.name = 'Vertex_Color'
    vc_node.label = 'Vertex Color'
    vc_node.location = (group_node.location.x - 300, group_node.location.y + 150)

    # Connect to group input
    node_tree.links.new(vc_node.outputs['Color'], group_node.inputs['Vertex Color'])

    return vc_node


def set_material_properties(
    material: bpy.types.Material,
    base_color: tuple[float, float, float, float] | None = None,
    roughness: float | None = None,
    metalness: float | None = None
) -> bool:
    """Set the constant material properties on an IsotropicSimpleUSD material.

    Args:
        material: Material containing the shader group
        base_color: RGBA tuple for base color (optional)
        roughness: Roughness value 0-1 (optional)
        metalness: Metalness value 0-1 (optional)

    Returns:
        True if successful, False otherwise
    """
    if not material.use_nodes:
        return False

    node_tree = material.node_tree

    # Find the shader group node
    group_node = None
    for node in node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_IsotropicSimpleUSD':
            group_node = node
            break

    if not group_node:
        return False

    # Set properties if provided
    if base_color is not None and 'Base Color' in group_node.inputs:
        group_node.inputs['Base Color'].default_value = base_color

    if roughness is not None and 'Roughness' in group_node.inputs:
        group_node.inputs['Roughness'].default_value = roughness

    if metalness is not None and 'Metalness' in group_node.inputs:
        group_node.inputs['Metalness'].default_value = metalness

    return True
