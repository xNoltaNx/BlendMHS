"""
Unlit Shader Template

Creates a Blender node group matching the MHS unlit.surface shader.
This shader displays textures without any lighting calculations.
"""

import bpy
from .base import (
    ShaderTemplate,
    TextureInputSpec,
    get_color_space_for_input,
)


class UnlitTemplate(ShaderTemplate):
    """Template for the MHS unlit.surface shader.

    This shader supports:
    - Base Color texture (sRGB) - displayed as emission (no lighting)

    The shader bypasses all lighting calculations and displays the texture
    as-is using the Emission shader.
    """

    @property
    def name(self) -> str:
        return "Unlit"

    @property
    def node_group_name(self) -> str:
        return "MHS_Unlit"

    @property
    def mhs_shader(self) -> str:
        return "unlit.surface"

    @property
    def description(self) -> str:
        return "Unlit shader - displays texture without lighting"

    @property
    def texture_inputs(self) -> list[TextureInputSpec]:
        return [
            TextureInputSpec(
                name="Base Color",
                socket_name="Base Color",
                default_color=(1.0, 1.0, 1.0, 1.0),
                color_space='sRGB',
                usd_attribute='diffuseColor',
            ),
        ]

    def _create_node_group(self) -> bpy.types.NodeTree:
        """Create the MHS_Unlit node group.

        Node structure:
        - Group input for base color texture
        - Emission shader to bypass lighting
        - BSDF output
        """
        # Create the node group
        node_group = bpy.data.node_groups.new(
            name=self.node_group_name,
            type='ShaderNodeTree'
        )

        # Create group input and output nodes
        group_input = node_group.nodes.new('NodeGroupInput')
        group_input.location = (-400, 0)

        group_output = node_group.nodes.new('NodeGroupOutput')
        group_output.location = (400, 0)

        # Create interface sockets (inputs/outputs)
        textures_panel = node_group.interface.new_panel(name="Textures")

        # Base Color Texture input
        base_color_socket = node_group.interface.new_socket(
            name="Base Color",
            in_out='INPUT',
            socket_type='NodeSocketColor',
            parent=textures_panel
        )
        base_color_socket.default_value = (1.0, 1.0, 1.0, 1.0)

        # BSDF output
        node_group.interface.new_socket(
            name='BSDF',
            in_out='OUTPUT',
            socket_type='NodeSocketShader'
        )

        # ============================================
        # Create internal nodes
        # ============================================

        # Emission shader for unlit look
        emission = node_group.nodes.new('ShaderNodeEmission')
        emission.location = (100, 0)
        emission.name = 'Emission'
        emission.inputs['Strength'].default_value = 1.0

        # ============================================
        # Create connections
        # ============================================
        links = node_group.links

        # Base Color -> Emission Color
        links.new(group_input.outputs['Base Color'], emission.inputs['Color'])

        # Emission -> Output
        links.new(emission.outputs['Emission'], group_output.inputs['BSDF'])

        # Store metadata for export
        self._store_metadata(node_group)

        return node_group

    def _store_metadata(self, node_group: bpy.types.NodeTree):
        """Store export metadata in the node group's custom properties."""
        import json

        # USD mappings for export
        usd_mappings = {
            'Base Color': {
                'property_type': 'TEXTURE',
                'usd_attribute': 'diffuseColor',
                'texture_source_type': 'ATTRIBUTE',
                'texture_rgb_attribute': 'diffuseColor',
            },
        }

        shader_settings = {
            'template': 'Unlit',
            'mhs_shader': self.mhs_shader,
            'is_dynamic': True,
            'is_masked': False,
            'is_translucent': False,
        }

        node_group['mhs_usd_mappings_json'] = json.dumps(usd_mappings)
        node_group['mhs_shader_settings_json'] = json.dumps(shader_settings)
        node_group['mhs_template'] = 'UNLIT'


def apply_to_material(material: bpy.types.Material) -> bool:
    """Convenience function to apply Unlit template to a material."""
    template = UnlitTemplate()
    return template.apply_to_material(material)


def get_or_create_node_group() -> bpy.types.NodeTree:
    """Convenience function to get or create the Unlit node group."""
    template = UnlitTemplate()
    return template.get_or_create_node_group()


def setup_texture_node_for_input(
    material: bpy.types.Material,
    input_name: str,
    image: bpy.types.Image
) -> bpy.types.Node | None:
    """Set up a texture node and connect it to the shader group input."""
    from . import uv_transform

    if not material.use_nodes:
        return None

    node_tree = material.node_tree

    # Find the shader group node
    group_node = None
    for node in node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_Unlit':
            group_node = node
            break

    if not group_node:
        return None

    # Ensure UVTransform node exists
    uv_transform_node = uv_transform.ensure_uv_transform_in_material(material)

    # Get color space from the template's input specification
    template = UnlitTemplate()
    color_space = get_color_space_for_input(template, input_name)

    # Create texture node
    tex_node = node_tree.nodes.new('ShaderNodeTexImage')
    tex_node.name = f'{input_name}_Texture'
    tex_node.label = input_name
    tex_node.image = image

    # Position relative to group node
    tex_node.location = (group_node.location.x - 300, group_node.location.y)

    # Set color space based on template specification
    if image:
        image.colorspace_settings.name = color_space

    # Connect UVTransform output to texture's Vector input
    uv_transform.connect_texture_to_uv_transform(material, tex_node, uv_transform_node)

    # Connect texture color output to group input
    if input_name in group_node.inputs:
        node_tree.links.new(tex_node.outputs['Color'], group_node.inputs[input_name])

    return tex_node
