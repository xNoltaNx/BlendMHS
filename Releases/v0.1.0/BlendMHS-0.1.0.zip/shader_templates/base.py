"""
Base Shader Template Classes

Provides base class and utilities for all shader templates.
"""

import bpy
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


# Global registry for shader templates
TEMPLATE_REGISTRY: dict[str, 'ShaderTemplate'] = {}


# ═══════════════════════════════════════════════════════════════════════════════
# MATERIAL FORMAT CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════
# Edit this section to update dropdown names, descriptions, and ordering.
# Format: (identifier, display_name, description)

MATERIAL_FORMAT_CONFIG = [
    # Active formats
    ('NONE', "None", "No material format - basic Principled BSDF"),
    ('ISOTROPIC_USD', "PBR", "MHS PBR with baseColor + packed MRO texture"),
    ('ISOTROPIC_EMISSIVE_USD', "PBR - Emissive", "MHS PBR with baseColor + MRO + emissive texture"),
    ('ISOTROPIC_SIMPLE_USD', "PBR - Simple", "MHS PBR with constant color, roughness, metallic + vertex color"),
    ('UNLIT', "Unlit", "Unlit material - displays texture without lighting"),
    ('UNLIT_BLEND', "Unlit Blend", "Unlit with alpha blending transparency"),
    ('UNLIT_MASKED', "Unlit Masked", "Unlit with alpha masking (cutout)"),

    # Future formats (uncomment when implemented):
    # ('ISOTROPIC_MASKED', "Isotropic Masked", "MHS PBR with alpha masking"),
    # ('FOLIAGE', "Foliage", "Vegetation with alpha-to-coverage"),
]

# Which formats are deprecated (shown with warning) - NONE currently
DEPRECATED_FORMATS = set()

# Which formats use the new template system
TEMPLATE_BASED_FORMATS = {'ISOTROPIC_USD', 'ISOTROPIC_EMISSIVE_USD', 'ISOTROPIC_SIMPLE_USD', 'UNLIT', 'UNLIT_BLEND', 'UNLIT_MASKED'}


def get_material_format_items():
    """Get the enum items for material format dropdown.

    Returns list of tuples: (identifier, name, description)
    This is the function to call when building EnumProperty items.
    """
    return MATERIAL_FORMAT_CONFIG


def get_format_display_name(format_id: str) -> str:
    """Get the human-readable display name for a format.

    Args:
        format_id: The format identifier (e.g., 'ISOTROPIC_USD')

    Returns:
        Display name string
    """
    for fid, name, desc in MATERIAL_FORMAT_CONFIG:
        if fid == format_id:
            return name
    return format_id


def get_format_description(format_id: str) -> str:
    """Get the description for a format.

    Args:
        format_id: The format identifier

    Returns:
        Description string
    """
    for fid, name, desc in MATERIAL_FORMAT_CONFIG:
        if fid == format_id:
            return desc
    return ""


# ═══════════════════════════════════════════════════════════════════════════════


@dataclass
class TextureInputSpec:
    """Specification for a texture input in a shader template."""
    name: str
    socket_name: str
    default_color: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0)
    color_space: str = 'sRGB'  # 'sRGB' or 'Non-Color'
    usd_attribute: str = ''
    channel_mapping: dict[str, str] = field(default_factory=dict)


@dataclass
class PropertyInputSpec:
    """Specification for a non-texture property input."""
    name: str
    socket_name: str
    property_type: str  # 'FLOAT', 'COLOR', 'VECTOR', 'BOOL'
    default_value: Any = None
    min_value: float = 0.0
    max_value: float = 1.0
    usd_attribute: str = ''


class ShaderTemplate(ABC):
    """Abstract base class for shader templates.

    Each template defines how to create a Blender node group that matches
    a specific MHS shader format.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Display name for the template."""
        pass

    @property
    @abstractmethod
    def node_group_name(self) -> str:
        """Name of the node group to create (e.g., 'HSR_IsotropicUSD')."""
        pass

    @property
    @abstractmethod
    def mhs_shader(self) -> str:
        """MHS shader target (e.g., 'isotropicUsd.surface')."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Description for UI display."""
        pass

    @property
    def texture_inputs(self) -> list[TextureInputSpec]:
        """List of texture input specifications."""
        return []

    @property
    def property_inputs(self) -> list[PropertyInputSpec]:
        """List of non-texture property specifications."""
        return []

    def get_or_create_node_group(self) -> bpy.types.NodeTree:
        """Get existing node group or create a new one.

        Returns:
            The shader node group
        """
        if self.node_group_name in bpy.data.node_groups:
            return bpy.data.node_groups[self.node_group_name]
        return self._create_node_group()

    @abstractmethod
    def _create_node_group(self) -> bpy.types.NodeTree:
        """Create the node group structure.

        Subclasses must implement this to create their specific node setup.

        Returns:
            The newly created node group
        """
        pass

    def apply_to_material(self, material: bpy.types.Material) -> bool:
        """Apply this shader template to a material.

        Args:
            material: Blender material to modify

        Returns:
            True if successful
        """
        if not material.use_nodes:
            material.use_nodes = True

        node_tree = material.node_tree

        # Clear existing nodes
        node_tree.nodes.clear()

        # Create output node
        output_node = node_tree.nodes.new('ShaderNodeOutputMaterial')
        output_node.location = (400, 0)

        # Get or create the shader node group
        shader_group = self.get_or_create_node_group()

        # Create node group instance
        group_node = node_tree.nodes.new('ShaderNodeGroup')
        group_node.node_tree = shader_group
        group_node.location = (0, 0)
        group_node.name = self.node_group_name

        # Connect to output
        if 'BSDF' in group_node.outputs:
            node_tree.links.new(group_node.outputs['BSDF'], output_node.inputs['Surface'])
        elif 'Shader' in group_node.outputs:
            node_tree.links.new(group_node.outputs['Shader'], output_node.inputs['Surface'])

        return True

    def rebuild_node_group(self) -> bpy.types.NodeTree:
        """Force rebuild of the node group (deletes existing and recreates).

        Returns:
            The newly created node group
        """
        if self.node_group_name in bpy.data.node_groups:
            bpy.data.node_groups.remove(bpy.data.node_groups[self.node_group_name])
        return self._create_node_group()


def get_color_space_for_input(template: 'ShaderTemplate', input_name: str) -> str:
    """Get the expected color space for a shader input from template metadata.

    This is the authoritative source for color space - each input slot in the
    shader template defines what color space it expects, regardless of filename.

    Args:
        template: The shader template instance
        input_name: Name of the input socket

    Returns:
        Expected color space ('sRGB' or 'Non-Color')
    """
    for tex_input in template.texture_inputs:
        if tex_input.socket_name == input_name or tex_input.name == input_name:
            return tex_input.color_space
    return 'sRGB'  # Default fallback


def create_texture_node(node_tree: bpy.types.NodeTree,
                        name: str,
                        location: tuple[float, float],
                        color_space: str = 'sRGB') -> bpy.types.Node:
    """Create an image texture node with proper settings.

    Args:
        node_tree: Node tree to add node to
        name: Name for the node
        location: (x, y) location
        color_space: Color space setting

    Returns:
        The created texture node
    """
    tex_node = node_tree.nodes.new('ShaderNodeTexImage')
    tex_node.name = name
    tex_node.label = name
    tex_node.location = location

    # Color space will be set when image is assigned
    # Store the intended color space in a custom property
    tex_node['intended_color_space'] = color_space

    return tex_node


def set_texture_color_space(tex_node: bpy.types.Node, color_space: str):
    """Set the color space on a texture node's image.

    Args:
        tex_node: Texture node
        color_space: 'sRGB' or 'Non-Color'
    """
    if tex_node.image:
        tex_node.image.colorspace_settings.name = color_space
