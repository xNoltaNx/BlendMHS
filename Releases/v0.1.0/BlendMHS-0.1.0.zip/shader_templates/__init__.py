"""
Shader Templates Module

Provides programmatic creation of Blender node groups that match MHS shader formats.
Each template creates a node group with inputs matching the corresponding .surface shader.

Architecture:
    [MHS_UVTransform] --Vector--> [Texture Nodes] --Color--> [MHS_IsotropicUSD] --BSDF--> [Output]

Usage:
    from .shader_templates import get_template, TEMPLATE_REGISTRY

    # Get a specific template
    template = get_template('ISOTROPIC_USD')
    node_group = template.get_or_create_node_group()

    # Apply to a material
    template.apply_to_material(material)

    # Set up UV transform (done automatically when setting up textures)
    from .shader_templates import uv_transform
    uv_node = uv_transform.ensure_uv_transform_in_material(material)
"""

from .base import (
    ShaderTemplate,
    TEMPLATE_REGISTRY,
    # Centralized format configuration
    MATERIAL_FORMAT_CONFIG,
    DEPRECATED_FORMATS,
    TEMPLATE_BASED_FORMATS,
    get_material_format_items,
    get_format_display_name,
    get_format_description,
)
from .isotropic_usd import IsotropicUSDTemplate
from .isotropic_emissive_usd import IsotropicEmissiveUSDTemplate
from .isotropic_simple_usd import IsotropicSimpleUSDTemplate
from .unlit import UnlitTemplate
from .unlit_blend import UnlitBlendTemplate
from .unlit_masked import UnlitMaskedTemplate
from . import uv_transform

# Register all templates
TEMPLATE_REGISTRY['ISOTROPIC_USD'] = IsotropicUSDTemplate()
TEMPLATE_REGISTRY['ISOTROPIC_EMISSIVE_USD'] = IsotropicEmissiveUSDTemplate()
TEMPLATE_REGISTRY['ISOTROPIC_SIMPLE_USD'] = IsotropicSimpleUSDTemplate()
TEMPLATE_REGISTRY['UNLIT'] = UnlitTemplate()
TEMPLATE_REGISTRY['UNLIT_BLEND'] = UnlitBlendTemplate()
TEMPLATE_REGISTRY['UNLIT_MASKED'] = UnlitMaskedTemplate()


def get_template(format_name: str) -> ShaderTemplate | None:
    """Get a shader template by format name.

    Args:
        format_name: The material format name (e.g., 'ISOTROPIC_USD')

    Returns:
        ShaderTemplate instance or None if not found
    """
    return TEMPLATE_REGISTRY.get(format_name)


def get_available_formats() -> list[str]:
    """Get list of all available material format names.

    Returns:
        List of format name strings
    """
    return list(TEMPLATE_REGISTRY.keys())


def apply_format_to_material(material, format_name: str) -> bool:
    """Apply a shader format template to a material.

    Args:
        material: Blender material to modify
        format_name: The material format name

    Returns:
        True if successful, False otherwise
    """
    template = get_template(format_name)
    if template is None:
        return False
    return template.apply_to_material(material)


__all__ = [
    'ShaderTemplate',
    'TEMPLATE_REGISTRY',
    'get_template',
    'get_available_formats',
    'apply_format_to_material',
    'IsotropicUSDTemplate',
    'uv_transform',
]
