"""
Isotropic Emissive USD Shader Template

Creates a Blender node group matching the MHS isotropicEmissiveUsd.surface shader.
This shader uses packed MRO (Metallic/Roughness/Occlusion) textures plus an emissive texture.
"""

import bpy
from .base import (
    ShaderTemplate,
    TextureInputSpec,
    get_color_space_for_input,
)


class IsotropicEmissiveUSDTemplate(ShaderTemplate):
    """Template for the MHS isotropicEmissiveUsd.surface shader.

    This shader supports:
    - Base Color texture (sRGB)
    - MRO packed texture (Non-Color): R=Metallic, G=Roughness, B=Occlusion
    - Emissive texture (sRGB)
    - Vertex Color multiplication (uses white if no vertex colors on mesh)

    The shader multiplies base color by vertex color and applies AO as
    a multiply blend for visual preview in Blender. The emissive texture
    is added to the final output.
    """

    @property
    def name(self) -> str:
        return "Isotropic Emissive USD"

    @property
    def node_group_name(self) -> str:
        return "MHS_IsotropicEmissiveUSD"

    @property
    def mhs_shader(self) -> str:
        return "isotropicEmissiveUsd.surface"

    @property
    def description(self) -> str:
        return "MHS Isotropic PBR shader with baseColor + packed MRO texture + emissive"

    @property
    def texture_inputs(self) -> list[TextureInputSpec]:
        return [
            TextureInputSpec(
                name="Base Color",
                socket_name="Base Color",
                default_color=(1.0, 1.0, 1.0, 1.0),
                color_space='sRGB',
                usd_attribute='diffuseColor',
            ),
            TextureInputSpec(
                name="MRO",
                socket_name="MRO Texture",
                default_color=(0.0, 0.5, 1.0, 1.0),  # M=0, R=0.5, O=1
                color_space='Non-Color',
                usd_attribute='',  # Packed texture, uses channel mapping
                channel_mapping={
                    'R': 'metallic',
                    'G': 'roughness',
                    'B': 'occlusion',
                },
            ),
            TextureInputSpec(
                name="Emissive",
                socket_name="Emissive Texture",
                default_color=(0.0, 0.0, 0.0, 1.0),  # Black default (no emission)
                color_space='sRGB',
                usd_attribute='emissiveColor',
            ),
        ]

    def _create_node_group(self) -> bpy.types.NodeTree:
        """Create the MHS_IsotropicEmissiveUSD node group.

        Node structure:
        - Group inputs for textures, vertex color
        - Vertex Color input (defaults to white 1,1,1 for meshes without vertex colors)
        - Base Color * Vertex Color multiplication
        - AO applied via MixRGB multiply blend for visual preview
        - Separate RGB for MRO unpacking
        - Emissive added to Principled BSDF emission
        - Principled BSDF as the core shader
        - BSDF output
        """
        # Create the node group
        node_group = bpy.data.node_groups.new(
            name=self.node_group_name,
            type='ShaderNodeTree'
        )

        # Create group input and output nodes
        group_input = node_group.nodes.new('NodeGroupInput')
        group_input.location = (-1200, 0)

        group_output = node_group.nodes.new('NodeGroupOutput')
        group_output.location = (600, 0)

        # Create interface sockets (inputs/outputs)
        textures_panel = node_group.interface.new_panel(name="Textures")

        # Base Color Texture input
        base_color_socket = node_group.interface.new_socket(
            name="Base Color",
            in_out='INPUT',
            socket_type='NodeSocketColor',
            parent=textures_panel
        )
        base_color_socket.default_value = (1.0, 1.0, 1.0, 1.0)

        # MRO Texture input
        mro_socket = node_group.interface.new_socket(
            name="MRO Texture",
            in_out='INPUT',
            socket_type='NodeSocketColor',
            parent=textures_panel
        )
        mro_socket.default_value = (0.0, 0.5, 1.0, 1.0)  # M=0, R=0.5, O=1

        # Emissive Texture input
        emissive_socket = node_group.interface.new_socket(
            name="Emissive Texture",
            in_out='INPUT',
            socket_type='NodeSocketColor',
            parent=textures_panel
        )
        emissive_socket.default_value = (0.0, 0.0, 0.0, 1.0)  # Black default

        # Vertex Color input (default white for meshes without vertex colors)
        vertex_color_socket = node_group.interface.new_socket(
            name="Vertex Color",
            in_out='INPUT',
            socket_type='NodeSocketColor',
            parent=textures_panel
        )
        vertex_color_socket.default_value = (1.0, 1.0, 1.0, 1.0)  # White default

        # BSDF output
        node_group.interface.new_socket(
            name='BSDF',
            in_out='OUTPUT',
            socket_type='NodeSocketShader'
        )

        # ============================================
        # Create internal nodes
        # ============================================

        # Principled BSDF - main shader
        bsdf = node_group.nodes.new('ShaderNodeBsdfPrincipled')
        bsdf.location = (300, 0)
        bsdf.name = 'Principled_BSDF'

        # Separate RGB for MRO unpacking
        separate_rgb = node_group.nodes.new('ShaderNodeSeparateColor')
        separate_rgb.location = (-400, -150)
        separate_rgb.name = 'MRO_Separate'
        separate_rgb.mode = 'RGB'

        # ============================================
        # Vertex Color multiplication
        # Base Color * Vertex Color
        # ============================================
        vertex_color_mix = node_group.nodes.new('ShaderNodeMix')
        vertex_color_mix.data_type = 'RGBA'
        vertex_color_mix.blend_type = 'MULTIPLY'
        vertex_color_mix.location = (-400, 150)
        vertex_color_mix.name = 'VertexColor_Multiply'
        vertex_color_mix.inputs['Factor'].default_value = 1.0  # Full multiply

        # ============================================
        # Ambient Occlusion preview
        # ============================================
        ao_mix = node_group.nodes.new('ShaderNodeMix')
        ao_mix.data_type = 'RGBA'
        ao_mix.blend_type = 'MULTIPLY'
        ao_mix.location = (-100, 150)
        ao_mix.name = 'AO_Multiply'
        ao_mix.inputs['Factor'].default_value = 1.0  # Full multiply

        # Expand AO channel to RGB for the multiply
        ao_to_rgb = node_group.nodes.new('ShaderNodeCombineColor')
        ao_to_rgb.location = (-250, -50)
        ao_to_rgb.name = 'AO_ToRGB'
        ao_to_rgb.mode = 'RGB'

        # ============================================
        # Emissive multiplication with vertex color
        # Emissive * Vertex Color (RGB only)
        # ============================================
        emissive_vc_mix = node_group.nodes.new('ShaderNodeMix')
        emissive_vc_mix.data_type = 'RGBA'
        emissive_vc_mix.blend_type = 'MULTIPLY'
        emissive_vc_mix.location = (-100, -200)
        emissive_vc_mix.name = 'Emissive_VC_Multiply'
        emissive_vc_mix.inputs['Factor'].default_value = 1.0

        # ============================================
        # Create connections
        # ============================================
        links = node_group.links

        # Vertex Color multiplication: Base Color * Vertex Color
        links.new(group_input.outputs['Base Color'], vertex_color_mix.inputs['A'])
        links.new(group_input.outputs['Vertex Color'], vertex_color_mix.inputs['B'])

        # MRO -> Separate RGB
        links.new(group_input.outputs['MRO Texture'], separate_rgb.inputs['Color'])

        # Expand AO (Blue channel) to RGB for multiply
        links.new(separate_rgb.outputs['Blue'], ao_to_rgb.inputs['Red'])
        links.new(separate_rgb.outputs['Blue'], ao_to_rgb.inputs['Green'])
        links.new(separate_rgb.outputs['Blue'], ao_to_rgb.inputs['Blue'])

        # AO multiply: (Base Color * Vertex Color) * AO
        links.new(vertex_color_mix.outputs['Result'], ao_mix.inputs['A'])
        links.new(ao_to_rgb.outputs['Color'], ao_mix.inputs['B'])

        # Final color to Principled BSDF
        links.new(ao_mix.outputs['Result'], bsdf.inputs['Base Color'])

        # Separated MRO channels -> Principled BSDF
        links.new(separate_rgb.outputs['Red'], bsdf.inputs['Metallic'])
        links.new(separate_rgb.outputs['Green'], bsdf.inputs['Roughness'])

        # Emissive * Vertex Color -> Principled BSDF Emission
        links.new(group_input.outputs['Emissive Texture'], emissive_vc_mix.inputs['A'])
        links.new(group_input.outputs['Vertex Color'], emissive_vc_mix.inputs['B'])
        links.new(emissive_vc_mix.outputs['Result'], bsdf.inputs['Emission Color'])
        bsdf.inputs['Emission Strength'].default_value = 1.0

        # BSDF -> Output
        links.new(bsdf.outputs['BSDF'], group_output.inputs['BSDF'])

        # Store metadata for export
        self._store_metadata(node_group)

        return node_group

    def _store_metadata(self, node_group: bpy.types.NodeTree):
        """Store export metadata in the node group's custom properties."""
        import json

        # USD mappings for export
        usd_mappings = {
            'Base Color': {
                'property_type': 'TEXTURE',
                'usd_attribute': 'diffuseColor',
                'texture_source_type': 'ATTRIBUTE',
                'texture_rgb_attribute': 'diffuseColor',
            },
            'MRO Texture': {
                'property_type': 'TEXTURE',
                'usd_attribute': '',  # Packed texture
                'texture_source_type': 'ATTRIBUTE',
                'use_channel_mapping': True,
                'texture_r_attribute': 'metallic',
                'texture_g_attribute': 'roughness',
                'texture_b_attribute': 'occlusion',
            },
            'Emissive Texture': {
                'property_type': 'TEXTURE',
                'usd_attribute': 'emissiveColor',
                'texture_source_type': 'ATTRIBUTE',
                'texture_rgb_attribute': 'emissiveColor',
            },
            'Vertex Color': {
                'property_type': 'COLOR',
                'usd_attribute': 'NONE',
                'note': 'Multiplied with base color and emissive; uses mesh vertex colors if available',
            },
        }

        shader_settings = {
            'template': 'Lit',
            'mhs_shader': self.mhs_shader,
            'is_dynamic': True,
            'is_masked': False,
            'is_translucent': False,
        }

        node_group['mhs_usd_mappings_json'] = json.dumps(usd_mappings)
        node_group['mhs_shader_settings_json'] = json.dumps(shader_settings)
        node_group['mhs_template'] = 'ISOTROPIC_EMISSIVE_USD'


def apply_to_material(material: bpy.types.Material) -> bool:
    """Convenience function to apply IsotropicEmissiveUSD template to a material."""
    template = IsotropicEmissiveUSDTemplate()
    return template.apply_to_material(material)


def get_or_create_node_group() -> bpy.types.NodeTree:
    """Convenience function to get or create the IsotropicEmissiveUSD node group."""
    template = IsotropicEmissiveUSDTemplate()
    return template.get_or_create_node_group()


def setup_texture_node_for_input(
    material: bpy.types.Material,
    input_name: str,
    image: bpy.types.Image
) -> bpy.types.Node | None:
    """Set up a texture node and connect it to the shader group input."""
    from . import uv_transform

    if not material.use_nodes:
        return None

    node_tree = material.node_tree

    # Find the shader group node
    group_node = None
    for node in node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_IsotropicEmissiveUSD':
            group_node = node
            break

    if not group_node:
        return None

    # Ensure UVTransform node exists
    uv_transform_node = uv_transform.ensure_uv_transform_in_material(material)

    # Get color space from the template's input specification
    template = IsotropicEmissiveUSDTemplate()
    color_space = get_color_space_for_input(template, input_name)

    # Create texture node
    tex_node = node_tree.nodes.new('ShaderNodeTexImage')
    tex_node.name = f'{input_name}_Texture'
    tex_node.label = input_name
    tex_node.image = image

    # Position relative to group node
    input_names = ['Base Color', 'MRO Texture', 'Emissive Texture']
    input_index = input_names.index(input_name) if input_name in input_names else 0
    tex_node.location = (group_node.location.x - 300, group_node.location.y - (input_index * 300))

    # Set color space based on template specification
    if image:
        image.colorspace_settings.name = color_space

    # Connect UVTransform output to texture's Vector input
    uv_transform.connect_texture_to_uv_transform(material, tex_node, uv_transform_node)

    # Connect texture color output to group input
    if input_name in group_node.inputs:
        node_tree.links.new(tex_node.outputs['Color'], group_node.inputs[input_name])

    return tex_node
