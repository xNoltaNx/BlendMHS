"""
MHS UV Transform Node Group

Creates a reusable node group for UV coordinate transformation (scale/offset).
This sits outside the main shader group and feeds into texture nodes.

Architecture:
    [MHS_UVTransform] --Vector--> [Texture Nodes] --Color--> [MHS_IsotropicUSD]
"""

import bpy


NODE_GROUP_NAME = "MHS_UVTransform"


def get_or_create_node_group() -> bpy.types.NodeTree:
    """Get existing or create new MHS_UVTransform node group.

    Returns:
        The node group
    """
    existing = bpy.data.node_groups.get(NODE_GROUP_NAME)
    if existing:
        return existing

    return _create_node_group()


def _create_node_group() -> bpy.types.NodeTree:
    """Create the MHS_UVTransform node group.

    Node structure:
        Group Input (UV Scale, UV Offset)
            ↓
        UV Map Node (gets mesh UVs)
            ↓
        Mapping Node (applies scale/offset)
            ↓
        Group Output (Vector)

    Returns:
        The created node group
    """
    node_group = bpy.data.node_groups.new(
        name=NODE_GROUP_NAME,
        type='ShaderNodeTree'
    )

    # Create group input and output nodes
    group_input = node_group.nodes.new('NodeGroupInput')
    group_input.location = (-400, 0)

    group_output = node_group.nodes.new('NodeGroupOutput')
    group_output.location = (400, 0)

    # Create interface sockets
    # UV Scale input
    uv_scale_socket = node_group.interface.new_socket(
        name="UV Scale",
        in_out='INPUT',
        socket_type='NodeSocketVector',
    )
    uv_scale_socket.default_value = (1.0, 1.0, 1.0)
    uv_scale_socket.min_value = 0.001
    uv_scale_socket.max_value = 100.0

    # UV Offset input
    uv_offset_socket = node_group.interface.new_socket(
        name="UV Offset",
        in_out='INPUT',
        socket_type='NodeSocketVector',
    )
    uv_offset_socket.default_value = (0.0, 0.0, 0.0)
    uv_offset_socket.min_value = -100.0
    uv_offset_socket.max_value = 100.0

    # Vector output
    node_group.interface.new_socket(
        name='Vector',
        in_out='OUTPUT',
        socket_type='NodeSocketVector'
    )

    # Create internal nodes
    # UV Map node - gets mesh UV coordinates
    uv_map = node_group.nodes.new('ShaderNodeUVMap')
    uv_map.location = (-200, -100)
    uv_map.name = 'UV_Map'

    # Mapping node - applies scale and offset
    mapping = node_group.nodes.new('ShaderNodeMapping')
    mapping.location = (100, 0)
    mapping.name = 'UV_Mapping'
    mapping.vector_type = 'POINT'

    # Create connections
    links = node_group.links

    # UV Map -> Mapping
    links.new(uv_map.outputs['UV'], mapping.inputs['Vector'])

    # Group inputs -> Mapping
    links.new(group_input.outputs['UV Scale'], mapping.inputs['Scale'])
    links.new(group_input.outputs['UV Offset'], mapping.inputs['Location'])

    # Mapping -> Group output
    links.new(mapping.outputs['Vector'], group_output.inputs['Vector'])

    return node_group


def ensure_uv_transform_in_material(material: bpy.types.Material) -> bpy.types.Node:
    """Ensure material has an MHS_UVTransform node, creating if needed.

    Args:
        material: The material to check/update

    Returns:
        The UVTransform group node
    """
    if not material.use_nodes:
        material.use_nodes = True

    node_tree = material.node_tree

    # Check for existing UVTransform node
    for node in node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree and node.node_tree.name == NODE_GROUP_NAME:
            return node

    # Create new one
    node_group = get_or_create_node_group()
    uv_transform_node = node_tree.nodes.new('ShaderNodeGroup')
    uv_transform_node.node_tree = node_group
    uv_transform_node.name = NODE_GROUP_NAME
    uv_transform_node.label = "UV Transform"
    # Position will be set by format_nodes
    uv_transform_node.location = (-600, 0)

    return uv_transform_node


def get_uv_transform_node(material: bpy.types.Material) -> bpy.types.Node | None:
    """Get the MHS_UVTransform node from a material if it exists.

    Args:
        material: The material to search

    Returns:
        The UVTransform node or None
    """
    if not material.use_nodes or not material.node_tree:
        return None

    for node in material.node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree and node.node_tree.name == NODE_GROUP_NAME:
            return node

    return None


def connect_texture_to_uv_transform(
    material: bpy.types.Material,
    texture_node: bpy.types.Node,
    uv_transform_node: bpy.types.Node = None
) -> bool:
    """Connect a texture node's Vector input to the UVTransform output.

    Args:
        material: The material containing the nodes
        texture_node: The texture node to connect
        uv_transform_node: Optional UVTransform node (will find/create if not provided)

    Returns:
        True if connection was made
    """
    if not material.node_tree:
        return False

    # Get or create UVTransform node
    if uv_transform_node is None:
        uv_transform_node = ensure_uv_transform_in_material(material)

    # Connect Vector output to texture's Vector input
    if 'Vector' in texture_node.inputs and 'Vector' in uv_transform_node.outputs:
        material.node_tree.links.new(
            uv_transform_node.outputs['Vector'],
            texture_node.inputs['Vector']
        )
        return True

    return False


def rebuild_node_group():
    """Rebuild the MHS_UVTransform node group with latest updates.

    This removes the existing node group and creates a new one.
    All materials using it will automatically get the updated version.
    """
    existing = bpy.data.node_groups.get(NODE_GROUP_NAME)
    if existing:
        bpy.data.node_groups.remove(existing)

    _create_node_group()
