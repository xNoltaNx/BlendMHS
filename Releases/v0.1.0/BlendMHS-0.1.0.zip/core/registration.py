"""
Registration utilities for BlendMHS addon.
Provides dynamic class and keymap registration similar to MACHIN3tools.
"""

import bpy
import os

# Global storage for registered keymaps
addon_keymaps = []


def get_prefs():
    """Fast access to addon preferences."""
    return bpy.context.preferences.addons[get_name()].preferences


def get_path():
    """Get addon root directory."""
    return os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


def get_name():
    """Get addon folder name (the package name)."""
    return os.path.basename(get_path())


def register_classes(classes):
    """
    Dynamically register a list of Blender classes.

    Args:
        classes: List of class objects to register

    Returns:
        List of successfully registered classes
    """
    registered = []
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
            registered.append(cls)
        except Exception as e:
            print(f"BlendMHS: Failed to register {cls.__name__}: {e}")
    return registered


def unregister_classes(classes):
    """
    Dynamically unregister a list of Blender classes in reverse order.

    Args:
        classes: List of class objects to unregister
    """
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception as e:
            print(f"BlendMHS: Failed to unregister {cls.__name__}: {e}")


def get_keymap_item(km, idname, properties=None):
    """
    Find an existing keymap item by idname and optional properties.

    Args:
        km: Keymap to search in
        idname: Operator idname to find
        properties: Optional dict of property values to match

    Returns:
        Keymap item if found, None otherwise
    """
    for kmi in km.keymap_items:
        if kmi.idname == idname:
            if properties is None:
                return kmi
            # Check if all properties match
            match = True
            for prop_name, prop_value in properties:
                if getattr(kmi.properties, prop_name, None) != prop_value:
                    match = False
                    break
            if match:
                return kmi
    return None


def register_keymaps(keymap_defs):
    """
    Register keymaps from declarative definitions.

    Args:
        keymap_defs: List of keymap definition dicts with structure:
            {
                'label': str,           # Display name
                'keymap': str,          # Keymap name (e.g., '3D View')
                'space_type': str,      # Space type (e.g., 'VIEW_3D')
                'idname': str,          # Operator idname
                'type': str,            # Key type (e.g., 'E')
                'value': str,           # Key value (e.g., 'PRESS')
                'ctrl': bool,           # Ctrl modifier
                'shift': bool,          # Shift modifier
                'alt': bool,            # Alt modifier
                'properties': list,     # Optional: [(name, value), ...]
                'active': bool,         # Optional: Whether active by default
            }

    Returns:
        List of (keymap, keymap_item) tuples for unregistration
    """
    registered = []
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon

    if not kc:
        return registered

    for key_def in keymap_defs:
        # Skip if explicitly disabled
        if key_def.get('active', True) is False:
            continue

        try:
            km = kc.keymaps.new(
                name=key_def['keymap'],
                space_type=key_def.get('space_type', 'EMPTY')
            )

            kmi = km.keymap_items.new(
                key_def['idname'],
                type=key_def.get('type', 'NONE'),
                value=key_def.get('value', 'PRESS'),
                ctrl=key_def.get('ctrl', False),
                shift=key_def.get('shift', False),
                alt=key_def.get('alt', False),
            )

            # Set properties if provided
            for prop_name, prop_value in key_def.get('properties', []):
                setattr(kmi.properties, prop_name, prop_value)

            registered.append((km, kmi))
        except Exception as e:
            print(f"BlendMHS: Failed to register keymap '{key_def.get('label', 'Unknown')}': {e}")

    return registered


def unregister_keymaps(keymap_items):
    """
    Unregister keymaps.

    Args:
        keymap_items: List of (keymap, keymap_item) tuples
    """
    for km, kmi in keymap_items:
        try:
            km.keymap_items.remove(kmi)
        except Exception as e:
            print(f"BlendMHS: Failed to unregister keymap: {e}")


def activate(registration_func, get_classes_func, get_keys_func, is_active):
    """
    Toggle tool activation by registering/unregistering classes and keymaps.

    Args:
        registration_func: Function that tracks registered items
        get_classes_func: Function that returns list of classes to register
        get_keys_func: Function that returns list of keymap definitions
        is_active: Whether the tool should be active
    """
    global addon_keymaps

    if is_active:
        # Register classes
        classes = get_classes_func()
        registered_classes = register_classes(classes)

        # Register keymaps
        keys = get_keys_func()
        registered_keys = register_keymaps(keys)
        addon_keymaps.extend(registered_keys)

        return registered_classes, registered_keys
    else:
        # Unregister classes
        classes = get_classes_func()
        unregister_classes(classes)

        # Unregister keymaps for this tool
        keys = get_keys_func()
        idnames_to_remove = {k['idname'] for k in keys}

        keymaps_to_keep = []
        keymaps_to_remove = []

        for km, kmi in addon_keymaps:
            if kmi.idname in idnames_to_remove:
                keymaps_to_remove.append((km, kmi))
            else:
                keymaps_to_keep.append((km, kmi))

        unregister_keymaps(keymaps_to_remove)
        addon_keymaps = keymaps_to_keep

        return [], []


def get_addon_keymaps():
    """Get list of currently registered addon keymaps."""
    global addon_keymaps
    return addon_keymaps


def clear_addon_keymaps():
    """Clear and unregister all addon keymaps."""
    global addon_keymaps
    unregister_keymaps(addon_keymaps)
    addon_keymaps = []
