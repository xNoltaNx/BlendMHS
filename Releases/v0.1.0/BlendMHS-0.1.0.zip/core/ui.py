"""
UI helper functions for BlendMHS addon preferences.
Provides consistent preference layouts and keymap drawing utilities.
"""


def draw_split_row(prefs, layout, prop_name, label, factor=0.2, toggle=False):
    """
    Draw a consistent preference row with label on the right.

    Args:
        prefs: Addon preferences object
        layout: Blender UI layout
        prop_name: Name of the property to draw
        label: Label text to display
        factor: Split factor (0.0-1.0), default 0.2 for 20% control / 80% label
        toggle: If True, draw as toggle button
    """
    row = layout.row()
    split = row.split(factor=factor)

    # Left side: control
    if toggle:
        split.prop(prefs, prop_name, text="", toggle=True)
    else:
        split.prop(prefs, prop_name, text="")

    # Right side: label
    split.label(text=label)


def get_panel_fold(layout, panel_id, label, prefs=None, default_closed=False, icon='NONE'):
    """
    Create a collapsible accordion panel.

    Args:
        layout: Blender UI layout
        panel_id: Unique identifier for the panel (used for show_* property)
        label: Panel header label
        prefs: Optional preferences object with show_{panel_id} property
        default_closed: Whether panel should be closed by default
        icon: Optional icon for the header

    Returns:
        Box layout if panel is open, None if closed
    """
    prop_name = f"show_{panel_id}"

    # If prefs provided, use its property; otherwise create a local toggle
    if prefs and hasattr(prefs, prop_name):
        is_open = getattr(prefs, prop_name)

        row = layout.row()
        icon_expand = 'TRIA_DOWN' if is_open else 'TRIA_RIGHT'

        # Clickable header row
        sub = row.row(align=True)
        sub.prop(prefs, prop_name, text="", icon=icon_expand, emboss=False)
        if icon != 'NONE':
            sub.label(text=label, icon=icon)
        else:
            sub.label(text=label)

        if is_open:
            box = layout.box()
            return box
        return None
    else:
        # Fallback: simple non-collapsible box
        box = layout.box()
        if icon != 'NONE':
            box.label(text=label, icon=icon)
        else:
            box.label(text=label)
        return box


def draw_keymap_item(kc, km_name, kmi_idname, kmi_properties, layout, label=None):
    """
    Draw a single keymap item using Blender's native keymap UI.

    Args:
        kc: KeyConfig (usually wm.keyconfigs.user)
        km_name: Keymap name (e.g., '3D View')
        kmi_idname: Operator idname
        kmi_properties: List of (name, value) tuples to match
        layout: Blender UI layout
        label: Optional label to show above the keymap
    """
    km = kc.keymaps.get(km_name)
    if not km:
        layout.label(text=f"Keymap '{km_name}' not found", icon='ERROR')
        return

    kmi = find_kmi_from_idname(km, kmi_idname, kmi_properties)
    if not kmi:
        layout.label(text=f"Keymap item not found", icon='ERROR')
        return

    if label:
        layout.label(text=label)

    col = layout.column()
    col.context_pointer_set("keymap", km)

    # Use Blender's built-in keymap item template
    rna_keymap_ui = __import__('rna_keymap_ui')
    rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)


def draw_keymap_items(kc, tool_label, keymap_defs, layout):
    """
    Draw all keymap items for a tool.

    Args:
        kc: KeyConfig (usually wm.keyconfigs.user)
        tool_label: Label for the tool section
        keymap_defs: List of keymap definition dicts from registration.py format
        layout: Blender UI layout
    """
    box = layout.box()
    box.label(text=tool_label, icon='KEYINGSET')

    for key_def in keymap_defs:
        km_name = key_def.get('keymap', '3D View')
        idname = key_def['idname']
        properties = key_def.get('properties', [])
        label = key_def.get('label', None)

        km = kc.keymaps.get(km_name)
        if not km:
            continue

        kmi = find_kmi_from_idname(km, idname, properties)
        if not kmi:
            row = box.row()
            row.label(text=f"{label or idname}: Not registered", icon='ERROR')
            continue

        col = box.column()
        if label:
            col.label(text=label)

        col.context_pointer_set("keymap", km)

        try:
            import rna_keymap_ui
            rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
        except Exception as e:
            col.label(text=f"Error drawing keymap: {e}", icon='ERROR')


def find_kmi_from_idname(km, idname, properties=None):
    """
    Locate keymap item by operator ID and optional properties.

    Args:
        km: Keymap to search in
        idname: Operator idname to find
        properties: Optional list of (name, value) tuples to match

    Returns:
        Keymap item if found, None otherwise
    """
    for kmi in km.keymap_items:
        if kmi.idname != idname:
            continue

        if properties is None or len(properties) == 0:
            return kmi

        # Check if all properties match
        match = True
        for prop_name, prop_value in properties:
            if getattr(kmi.properties, prop_name, None) != prop_value:
                match = False
                break

        if match:
            return kmi

    return None


def draw_activation_toggle(prefs, layout, prop_name, label, icon='NONE'):
    """
    Draw an activation toggle with consistent styling.

    Args:
        prefs: Addon preferences object
        layout: Blender UI layout
        prop_name: Name of the bool property
        label: Label text
        icon: Optional icon
    """
    row = layout.row()
    is_active = getattr(prefs, prop_name, False)

    row.prop(
        prefs, prop_name,
        text=label,
        icon='CHECKBOX_HLT' if is_active else 'CHECKBOX_DEHLT',
        toggle=True
    )
