import bpy
import sys
import os
import math
import time
import numpy as np
from pxr import Usd, UsdGeom, Gf, Sdf, UsdShade, Vt
from .utils import sanitize_name, debug_log, LogCategory
import shutil
import hashlib
import bmesh
from mathutils import Matrix


# ═══════════════════════════════════════════════════════════════════════════════
# Edit Mode Context Manager - Preserves user state during export
# ═══════════════════════════════════════════════════════════════════════════════

class PreserveEditModeContext:
    """Context manager that temporarily exits edit mode to flush mesh changes.

    When exporting while in edit mode, Blender doesn't commit vertex changes
    to the mesh data until you exit edit mode. This context manager:
    1. Saves the current mode and selection state
    2. Exits to object mode (flushing edit mode changes)
    3. Allows export/hash computation to see the updated mesh
    4. Restores the original mode and selection

    Usage:
        with PreserveEditModeContext():
            # Mesh data is now up-to-date
            hash = compute_mesh_hash(obj, depsgraph)
    """

    def __init__(self):
        self.original_mode = None
        self.original_active = None
        self.original_selected = []
        self.edit_mode_objects = []
        self.needs_restore = False

    def __enter__(self):
        context = bpy.context

        # Check if we're in edit mode
        if context.mode == 'EDIT_MESH':
            self.needs_restore = True
            self.original_mode = 'EDIT'

            # Store the active object
            self.original_active = context.active_object

            # Store all selected objects
            self.original_selected = [obj for obj in context.selected_objects]

            # Store objects that are in edit mode (can be multiple with multi-edit)
            self.edit_mode_objects = [obj for obj in context.objects_in_mode]

            debug_log("Temporarily exiting edit mode to flush mesh changes", LogCategory.EXPORT_MESH)

            # Exit edit mode - this commits the mesh changes
            bpy.ops.object.mode_set(mode='OBJECT')

            # Force depsgraph update after exiting edit mode
            context.view_layer.update()

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if not self.needs_restore:
            return False

        context = bpy.context

        try:
            # Restore selection
            bpy.ops.object.select_all(action='DESELECT')

            for obj in self.original_selected:
                if obj and obj.name in bpy.data.objects:
                    obj.select_set(True)

            # Restore active object
            if self.original_active and self.original_active.name in bpy.data.objects:
                context.view_layer.objects.active = self.original_active

            # Return to edit mode
            if self.original_mode == 'EDIT' and context.active_object:
                bpy.ops.object.mode_set(mode='EDIT')
                debug_log("Restored edit mode after export", LogCategory.EXPORT_MESH)

        except Exception as e:
            debug_log(f"Warning: Could not fully restore edit mode state: {e}", LogCategory.EXPORT_MESH)

        # Don't suppress exceptions
        return False


def flush_edit_mode_changes():
    """Utility function to flush edit mode changes without a context manager.

    Returns a restore function that can be called to return to edit mode.

    Usage:
        restore_fn = flush_edit_mode_changes()
        # ... do work with updated mesh data ...
        restore_fn()  # Return to edit mode
    """
    context = bpy.context

    if context.mode != 'EDIT_MESH':
        # Not in edit mode, nothing to do
        return lambda: None

    # Store state
    original_active = context.active_object
    original_selected = [obj for obj in context.selected_objects]

    debug_log("Flushing edit mode changes", LogCategory.EXPORT_MESH)

    # Exit edit mode
    bpy.ops.object.mode_set(mode='OBJECT')
    context.view_layer.update()

    def restore():
        try:
            bpy.ops.object.select_all(action='DESELECT')
            for obj in original_selected:
                if obj and obj.name in bpy.data.objects:
                    obj.select_set(True)
            if original_active and original_active.name in bpy.data.objects:
                context.view_layer.objects.active = original_active
                bpy.ops.object.mode_set(mode='EDIT')
        except Exception as e:
            debug_log(f"Warning: Could not restore edit mode: {e}", LogCategory.EXPORT_MESH)

    return restore


# ═══════════════════════════════════════════════════════════════════════════════
# Animation Action Helper Functions (Phase 5 of Action Loader Enhancement)
# ═══════════════════════════════════════════════════════════════════════════════

def get_loadable_actions(armature):
    """Get all actions compatible with armature that aren't already loaded.

    Args:
        armature: The armature object to check actions for

    Returns:
        list: List of bpy.types.Action that are compatible but not yet loaded
    """
    if not armature or armature.type != 'ARMATURE':
        return []

    bone_names = set(bone.name for bone in armature.data.bones)
    if not bone_names:
        return []

    # Get already loaded actions
    loaded = set()
    for slot in armature.mhs.animation_export_actions:
        if slot.action:
            loaded.add(slot.action)

    # Find compatible actions not already loaded
    loadable = []
    for action in bpy.data.actions:
        if action not in loaded and is_action_compatible(action, bone_names):
            loadable.append(action)

    return loadable


def is_action_compatible(action, bone_names):
    """Check if action animates any bones in the given set.

    Args:
        action: The bpy.types.Action to check
        bone_names: Set of bone names from the armature

    Returns:
        bool: True if action has f-curves for bones in the bone_names set
    """
    if not action or not action.fcurves:
        return False

    for fcurve in action.fcurves:
        data_path = fcurve.data_path
        if 'pose.bones["' in data_path:
            bone_name = extract_bone_name(data_path)
            if bone_name and bone_name in bone_names:
                return True

    return False


def extract_bone_name(data_path):
    """Extract bone name from an f-curve data path.

    Args:
        data_path: F-curve data path like 'pose.bones["BoneName"].rotation_quaternion'

    Returns:
        str: Bone name, or None if not found
    """
    if 'pose.bones["' not in data_path:
        return None

    start = data_path.find('pose.bones["') + len('pose.bones["')
    end = data_path.find('"]', start)

    if end > start:
        return data_path[start:end]

    return None


def get_action_metadata(action):
    """Get comprehensive metadata for an action.

    Args:
        action: The bpy.types.Action to analyze

    Returns:
        dict: Metadata including frame range, keyframe count, bone count, etc.
    """
    if not action:
        return {
            'frame_start': 0,
            'frame_end': 0,
            'frame_count': 0,
            'keyframe_count': 0,
            'bone_count': 0,
            'has_location': False,
            'has_rotation': False,
            'has_scale': False,
        }

    # Frame range
    frame_start = int(action.frame_range[0])
    frame_end = int(action.frame_range[1])
    frame_count = frame_end - frame_start + 1

    # Count keyframes and analyze f-curves
    keyframe_count = 0
    bone_names = set()
    has_location = False
    has_rotation = False
    has_scale = False

    for fcurve in action.fcurves:
        keyframe_count += len(fcurve.keyframe_points)
        data_path = fcurve.data_path

        # Extract bone names
        if 'pose.bones["' in data_path:
            bone_name = extract_bone_name(data_path)
            if bone_name:
                bone_names.add(bone_name)

        # Check transform types
        if 'location' in data_path:
            has_location = True
        if 'rotation' in data_path:
            has_rotation = True
        if 'scale' in data_path:
            has_scale = True

    return {
        'frame_start': frame_start,
        'frame_end': frame_end,
        'frame_count': frame_count,
        'keyframe_count': keyframe_count,
        'bone_count': len(bone_names),
        'has_location': has_location,
        'has_rotation': has_rotation,
        'has_scale': has_scale,
    }


def parse_tags(tag_string):
    """Parse comma-separated tag string into set.

    Args:
        tag_string: Comma-separated string like "locomotion, combat, idle"

    Returns:
        set: Set of lowercase, stripped tag strings
    """
    if not tag_string:
        return set()

    return set(t.strip().lower() for t in tag_string.split(',') if t.strip())


def format_tags(tag_set):
    """Format tag set back to comma-separated string.

    Args:
        tag_set: Set of tag strings

    Returns:
        str: Comma-separated, sorted string
    """
    if not tag_set:
        return ""

    return ', '.join(sorted(tag_set))


def add_tag(action_slot, tag):
    """Add tag to action slot.

    Args:
        action_slot: The AnimationExportAction slot to modify
        tag: Tag string to add
    """
    tags = parse_tags(action_slot.tags)
    tags.add(tag.lower().strip())
    action_slot.tags = format_tags(tags)


def remove_tag(action_slot, tag):
    """Remove tag from action slot.

    Args:
        action_slot: The AnimationExportAction slot to modify
        tag: Tag string to remove
    """
    tags = parse_tags(action_slot.tags)
    tags.discard(tag.lower().strip())
    action_slot.tags = format_tags(tags)


def has_tag(action_slot, tag):
    """Check if action slot has a specific tag.

    Args:
        action_slot: The AnimationExportAction slot to check
        tag: Tag string to look for

    Returns:
        bool: True if tag is present
    """
    tags = parse_tags(action_slot.tags)
    return tag.lower().strip() in tags


def get_all_tags(armature):
    """Get all unique tags used across all actions on an armature.

    Args:
        armature: The armature object with animation_export_actions

    Returns:
        set: Set of all unique tags
    """
    if not armature or not hasattr(armature, 'mhs'):
        return set()

    all_tags = set()
    for slot in armature.mhs.animation_export_actions:
        if hasattr(slot, 'tags') and slot.tags:
            all_tags.update(parse_tags(slot.tags))

    return all_tags


def validate_actions_for_export(armature):
    """Pre-export validation with warnings and errors.

    Validates all enabled actions in the armature's animation_export_actions list
    before export. Checks for common issues like missing actions, empty keyframes,
    no bone animation, etc.

    Args:
        armature: The armature object with animation_export_actions list

    Returns:
        tuple: (warnings, errors) where each is a list of message strings
            - warnings: Non-blocking issues that may affect export quality
            - errors: Blocking issues that will prevent export
    """
    warnings = []
    errors = []

    if not armature:
        errors.append("No armature provided for validation")
        return warnings, errors

    if not hasattr(armature, 'mhs') or not armature.mhs.animation_export_actions:
        warnings.append(f"Armature '{armature.name}' has no actions in export list")
        return warnings, errors

    enabled_count = 0
    bone_names = set(bone.name for bone in armature.data.bones) if armature.data else set()

    for slot in armature.mhs.animation_export_actions:
        if not slot.enabled:
            continue

        enabled_count += 1

        # Check for missing action
        if not slot.action:
            errors.append(f"Slot has no action assigned (enabled but empty)")
            continue

        action_name = slot.action.name
        display_name = slot.custom_name if slot.custom_name else action_name

        # Get action metadata
        metadata = get_action_metadata(slot.action)

        # Check for empty keyframes
        if metadata['keyframe_count'] == 0:
            warnings.append(f"'{display_name}': No keyframes found")

        # Check for no bone animation
        if metadata['bone_count'] == 0:
            warnings.append(f"'{display_name}': No bone animation (may not animate this armature)")

        # Check for action compatibility with armature
        if bone_names and not is_action_compatible(slot.action, bone_names):
            warnings.append(f"'{display_name}': Action may not be compatible with armature (no matching bone names)")

        # Check custom frame range validity
        if slot.use_custom_range:
            if slot.frame_start >= slot.frame_end:
                errors.append(f"'{display_name}': Invalid custom frame range ({slot.frame_start} >= {slot.frame_end})")
            elif slot.frame_end - slot.frame_start > 10000:
                warnings.append(f"'{display_name}': Very long frame range ({slot.frame_end - slot.frame_start} frames)")

        # Check for very short animations
        if metadata['frame_count'] < 2 and metadata['frame_count'] > 0:
            warnings.append(f"'{display_name}': Very short animation ({metadata['frame_count']} frame)")

    # Check if any actions are enabled
    if enabled_count == 0:
        warnings.append(f"No actions enabled for export on armature '{armature.name}'")

    return warnings, errors

def create_project_folders(project_path):
    folders = ['layouts', 'meshes', 'animation', 'materials', 'textures']  # 'lightmaps', 'lightprobes' commented out - not currently used
    for folder in folders:
        os.makedirs(os.path.join(project_path, folder), exist_ok=True)


def resolve_folder_path(project_path, folder_template, layout_name=None):
    """
    Resolve folder path with variable substitution.

    Supports {layout} placeholder which gets replaced with the sanitized layout name.
    This allows per-layout subfolders like "materials/{layout}" → "materials/MyLayout"

    Args:
        project_path: Base project path
        folder_template: Folder path template (e.g., "meshes" or "materials/{layout}")
        layout_name: Name of the layout for {layout} substitution (optional)

    Returns:
        str: Full resolved path
    """
    resolved = folder_template

    # Substitute {layout} placeholder if layout_name is provided
    if layout_name and '{layout}' in resolved:
        resolved = resolved.replace('{layout}', sanitize_name(layout_name))

    return os.path.join(project_path, resolved)


def ensure_layout_folders(project_path, scene, layout_name):
    """
    Create folders for a specific layout, resolving {layout} placeholders.

    Args:
        project_path: Base project path
        scene: Blender scene with folder configuration
        layout_name: Name of the layout being exported
    """
    folder_templates = [
        scene.mhs.layouts_folder,
        scene.mhs.meshes_folder,
        scene.mhs.animation_folder,
        scene.mhs.materials_folder,
        scene.mhs.textures_folder,
    ]

    for template in folder_templates:
        folder_path = resolve_folder_path(project_path, template, layout_name)
        os.makedirs(folder_path, exist_ok=True)

# Export tool metadata constants
EXPORT_TOOL_NAME = "BlendMHS"
EXPORT_TOOL_VERSION = "1.0.0"

def set_stage_custom_layer_data(stage):
    """
    Set custom layer data metadata on the stage root layer.
    This adds exportTool and exportToolVersion to the USDA header.
    """
    root_layer = stage.GetRootLayer()
    custom_data = {
        "exportTool": EXPORT_TOOL_NAME,
        "exportToolVersion": EXPORT_TOOL_VERSION
    }
    root_layer.customLayerData = custom_data

def get_full_parent_path(obj, filtered_objects):
    """
    Build full hierarchical prim path for an object based on its parent chain.
    Supports multi-level hierarchies (grandparent -> parent -> child).

    Args:
        obj: Blender object to get path for
        filtered_objects: List of objects included in the export

    Returns:
        str: Full prim path (e.g., "/" for root, "/Parent" or "/Grandparent/Parent" for children)
    """
    if not obj.parent or obj.parent not in filtered_objects:
        return "/"

    # Recursively build parent path
    parent_path = get_full_parent_path(obj.parent, filtered_objects)
    parent_name = sanitize_name(obj.parent.name)

    if parent_path == "/":
        return f"/{parent_name}"
    else:
        return f"{parent_path}/{parent_name}"

def write_layout_usda(context, force_rebuild=False):
    """
    Export all enabled layout configurations.

    This is called by the "Export All Layouts" button.

    Args:
        context: Blender context
        force_rebuild: If True, ignore cache and re-export all files
    """
    from . import cache_tracker

    # Flush edit mode changes before export to ensure mesh data is up-to-date
    # This handles the case where user is editing a mesh and hits export
    with PreserveEditModeContext():
        # Set session-level force_rebuild so nested functions can access it
        cache_tracker.set_force_rebuild_session(force_rebuild)

        # Reset session-level tracking (textures exported this session, etc.)
        cache_tracker.reset_session_tracking()

        # Reset stats at the start of export
        cache_tracker.reset_stats()
        start_time = time.time()

        scene = context.scene

        if len(scene.mhs.layout_exports) == 0:
            raise ValueError("No layout exports configured. Please add at least one layout export configuration.")

        enabled_layouts = [le for le in scene.mhs.layout_exports if le.enabled]

        if not enabled_layouts:
            raise ValueError("No enabled layout exports. Please enable at least one layout export configuration.")

        debug_log(f"Exporting {len(enabled_layouts)} enabled layouts...", LogCategory.EXPORT_LAYOUT)

        results = []
        for layout_config in enabled_layouts:
            debug_log(f"\n=== Exporting Layout: {layout_config.name} ===", LogCategory.EXPORT_LAYOUT)
            try:
                result = write_layout_usda_single(context, layout_config, force_rebuild=force_rebuild)
                results.append((layout_config.name, result))
            except Exception as e:
                debug_log(f"ERROR exporting layout '{layout_config.name}': {str(e)}", LogCategory.EXPORT_LAYOUT)
                import traceback
                traceback.print_exc()
                results.append((layout_config.name, {'CANCELLED'}))

        successful = sum(1 for _, result in results if result == {'FINISHED'})
        debug_log(f"\n=== Export Summary ===", LogCategory.EXPORT_LAYOUT)
        debug_log(f"Exported {successful}/{len(enabled_layouts)} layouts successfully", LogCategory.EXPORT_LAYOUT)
        for name, result in results:
            status = "✓" if result == {'FINISHED'} else "✗"
            debug_log(f"  {status} {name}", LogCategory.EXPORT_LAYOUT)

        # Finalize stats and save cache
        elapsed_time = time.time() - start_time
        cache_tracker.finalize_stats(elapsed_time)
        cache_tracker.get_cache().save()

        # Show stats summary
        stats = cache_tracker.get_last_export_stats()
        debug_log(f"\n=== Cache Statistics ===", LogCategory.CACHE_STATS)
        debug_log(f"Files exported: {stats['exported']}", LogCategory.CACHE_STATS)
        debug_log(f"Files skipped (cached): {stats['skipped']}", LogCategory.CACHE_STATS)
        debug_log(f"Estimated time saved: {stats['time_saved']:.1f}s", LogCategory.CACHE_STATS)
        debug_log(f"Total export time: {stats['total_time']:.2f}s", LogCategory.CACHE_STATS)

    return {'FINISHED'}

def export_lightmaps(context, stage, project_path):
    # DISABLED: lightmap_groups causes AttributeError since the property doesn't exist
    # lightmaps_path = os.path.join(project_path, 'lightmaps')

    # for group in context.scene.mhs.lightmap_groups:
    #     if group.baked_lightmap:
    #         # Export the lightmap image
    #         safe_name = sanitize_name(group.name)
    #         lightmap_filename = f"{safe_name}_lightmap.exr"
    #         lightmap_path = os.path.join(lightmaps_path, lightmap_filename)
    #         group.baked_lightmap.save_render(lightmap_path)

    #         # Create a relative path for the lightmap
    #         relative_lightmap_path = os.path.relpath(lightmap_path, project_path)

    #         # Create a shader for the lightmap
    #         lightmap_shader = UsdShade.Shader.Define(stage, f"/Lightmaps/{safe_name}_shader")
    #         lightmap_shader.CreateIdAttr("UsdUVTexture")
    #         lightmap_shader.CreateInput("file", Sdf.ValueTypeNames.Asset).Set(relative_lightmap_path)
    #         lightmap_shader.CreateInput("st", Sdf.ValueTypeNames.Float2).ConnectToSource(lightmap_shader.ConnectableAPI(), "frame:st")

    #         # Assign the lightmap to objects in the group
    #         for obj_ref in group.objects:
    #             safe_name = sanitize_name(obj_ref.name)
    #             obj = bpy.data.objects.get(safe_name)
    #             if obj and obj.type == 'MESH':
    #                 obj_path = f"/root/{safe_name}"
    #                 mesh_prim = stage.GetPrimAtPath(f"{obj_path}/mesh")
    #                 if mesh_prim:
    #                     material = UsdShade.Material.Define(stage, f"{obj_path}/lightmap_material")
    #                     material.CreateSurfaceOutput().ConnectToSource(lightmap_shader.ConnectableAPI(), "rgb")
    #                     UsdShade.MaterialBindingAPI(mesh_prim).Bind(material)
    pass  # Function disabled due to lightmap_groups property being unavailable

def process_object(stage, obj, parent_path, context, project_path):
    safe_name = sanitize_name(obj.name)
    obj_path = f"{parent_path}/{safe_name}"
    xform = UsdGeom.Xform.Define(stage, obj_path)

    # Set transform
    xformable = UsdGeom.Xformable(xform)
    xformable.AddTransformOp().Set(Gf.Matrix4d(*obj.matrix_world.transposed()))

    if obj.type == 'MESH' and context.scene.mhs.export_individual_objects:
        # Export individual mesh
        mesh_path = os.path.join(project_path, 'meshes', f"{safe_name}.usda")
        write_usda(context, mesh_path, objects=[obj])

        if context.scene.mhs.reference_objects_in_layout:
            # Reference the individual mesh file
            rel_path = os.path.relpath(mesh_path, project_path)
            xform.GetPrim().GetReferences().AddReference(rel_path)
    elif obj.type == 'MESH':
        # If not exporting individually, create mesh directly in the layout file
        mesh = UsdGeom.Mesh.Define(stage, f"{obj_path}/mesh")
        export_mesh(obj, mesh, project_path)

    # Process child objects
    for child in obj.children:
        process_object(stage, child, obj_path, context, project_path)

def write_usda(context, filepath, objects=None, force_rebuild=False):
    import os
    from . import cache_tracker

    debug_log(f"write_usda called with filepath='{filepath}'", LogCategory.EXPORT_MESH)

    # Get cache and check if we can skip export
    cache = cache_tracker.get_cache()

    # Compute hash of mesh data for cache checking
    if objects and len(objects) > 0:
        depsgraph = context.evaluated_depsgraph_get()
        mesh_hash = cache_tracker.compute_mesh_hash(objects[0], depsgraph)

        # Check if we can skip (not force rebuild and hash matches)
        if not force_rebuild and not cache.should_export(filepath, mesh_hash):
            debug_log(f"Skipping unchanged mesh '{filepath}'", LogCategory.CACHE_HIT)
            cache_tracker.record_skip('mesh', filepath)
            return {'FINISHED'}
    else:
        mesh_hash = None

    # Delete existing file if it exists
    if os.path.exists(filepath):
        debug_log(f"Removing existing file '{filepath}'", LogCategory.EXPORT_MESH)
        try:
            os.remove(filepath)
        except Exception as e:
            debug_log(f"Warning - Could not remove existing file: {e}", LogCategory.EXPORT_MESH)

    # Try to create a new stage, but if it fails due to cached layer, open it instead
    try:
        stage = Usd.Stage.CreateNew(filepath)
    except Exception as create_error:
        debug_log(f"CreateNew failed ({create_error}), trying Open instead", LogCategory.EXPORT_MESH)
        # If CreateNew fails (likely due to cached layer), use Open to overwrite
        stage = Usd.Stage.Open(filepath)
        # Clear all prims to start fresh
        stage.GetRootLayer().Clear()

    root_layer = stage.GetRootLayer()

    UsdGeom.SetStageMetersPerUnit(stage, 1)

    # Always use Y-up axis (required by engine)
    up_axis = 'Y'
    debug_log(f"Using Y-up axis (engine standard)", LogCategory.EXPORT_TRANSFORM)
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.y)

    # Set custom layer data metadata
    set_stage_custom_layer_data(stage)

    if context.scene.mhs.mhs_include_root_node:
        root_prim = UsdGeom.Xform.Define(stage, "/root")
        stage.SetDefaultPrim(root_prim.GetPrim())
        export_path = "/root"
    else:
        export_path = "/"

    # Determine objects to export
    if objects is None:
        objects_to_export = context.selected_objects if context.scene.mhs.mhs_export_selected_only else context.scene.objects
    else:
        objects_to_export = objects

    debug_log(f"Exporting {len(objects_to_export)} objects with Y-up axis", LogCategory.EXPORT_MESH)

    exported_meshes = {}
    exported_materials = {}  # Cache for exported materials

    def export_hierarchy(obj, parent_path):
        """Recursively export object and its children"""
        debug_log(f"export_hierarchy for '{obj.name}' at parent path '{parent_path}'", LogCategory.EXPORT_HIERARCHY)
        prim = export_object(stage, obj, parent_path, up_axis, exported_meshes, context, filepath, exported_materials)

        # Export children
        for child in obj.children:
            if child in objects_to_export:
                export_hierarchy(child, prim.GetPath())

        return prim

    # Export root objects and their hierarchies
    root_prim = None
    for obj in objects_to_export:
        debug_log(f"Processing object '{obj.name}', parent: {obj.parent.name if obj.parent else 'None'}", LogCategory.EXPORT_MESH)
        if obj.parent is None or obj.parent not in objects_to_export:
            # This is a root object (no parent or parent not in export set)
            prim = export_hierarchy(obj, export_path)
            if root_prim is None:
                root_prim = prim
                stage.SetDefaultPrim(prim)

    stage.Save()
    debug_log(f"Stage saved to '{filepath}'", LogCategory.EXPORT_MESH)

    # Adding generated to auto collapse diffs when submitted to fbsource
    with open(filepath, 'a') as file:
        file.write('#@generated')

    # Update cache after successful export
    # Always record the export since we saved the file
    cache_tracker.record_export('mesh', filepath)
    if mesh_hash:
        cache.set_file_hash(filepath, mesh_hash, {
            "source_objects": [obj.name for obj in (objects or [])]
        })

    return {'FINISHED'}

def export_object(stage, obj, parent_path, up_axis, exported_meshes, context, export_path, exported_materials=None):
    debug_log(f"export_object called for '{obj.name}', type: {obj.type}", LogCategory.EXPORT_MESH)

    safe_name = sanitize_name(obj.name)
    obj_path = f"{parent_path}/{safe_name}" if parent_path != "/" else f"/{safe_name}"

    debug_log(f"Object path will be '{obj_path}'", LogCategory.EXPORT_MESH)

    if exported_materials is None:
        exported_materials = {}

    try:
        # Create the Xform
        debug_log(f"Creating Xform at '{obj_path}'", LogCategory.EXPORT_MESH)
        xform_prim = UsdGeom.Xform.Define(stage, obj_path)
        xformable = UsdGeom.Xformable(xform_prim)

        # Check if this object has skeletal animation
        has_skeletal_animation = False
        if obj.type == 'MESH':
            armature = get_armature_for_mesh(obj)
            if armature and hasattr(obj, 'mhs') and obj.mhs.export_animations:
                has_skeletal_animation = True
                debug_log(f"Object '{obj.name}' has skeletal animation - using identity transform", LogCategory.SKELETON_ANIMATION)

        # For mesh files exported as part of the layout workflow:
        # Always use IDENTITY transform. The mesh geometry is already converted to Y-up RUB space
        # and the layout file will apply the proper world transforms to instances.
        # This ensures no double-conversion of coordinates.

        import mathutils
        blender_matrix = obj.matrix_world

        debug_log(f"Object '{obj.name}' world position: ({blender_matrix[0][3]:.3f}, {blender_matrix[1][3]:.3f}, {blender_matrix[2][3]:.3f})", LogCategory.EXPORT_TRANSFORM)

        # Always use identity transform for mesh files
        # Mesh geometry vertices are already converted to Y-up RUB in export_mesh()
        # Layout instances will apply the world transforms
        usd_matrix = Gf.Matrix4d(1.0)
        debug_log(f"Using identity transform for mesh file '{obj.name}' (geometry already in Y-up RUB space)", LogCategory.EXPORT_TRANSFORM)

        xformable.AddTransformOp().Set(usd_matrix)

        # Get the Prim associated with the Xform
        prim = stage.GetPrimAtPath(obj_path)
        UsdShade.MaterialBindingAPI.Apply(prim)

        # Handle LODs
        if obj.type == 'MESH':
            debug_log(f"About to export mesh for '{obj.name}' at path '{obj_path}/mesh'", LogCategory.EXPORT_MESH)
            try:
                if obj.mhs.export_lods and len(obj.mhs.lod_list) > 0:
                    # Export with LODs (Manual or Decimate mode)
                    export_lod_meshes(stage, obj, obj_path, up_axis, export_path, context)
                else:
                    # Regular mesh export without LODs
                    export_mesh(stage, obj, f"{obj_path}/mesh", up_axis, export_path, exported_materials)
                debug_log(f"Finished exporting mesh for '{obj.name}'", LogCategory.EXPORT_MESH)
            except Exception as mesh_error:
                debug_log(f"ERROR in export_mesh for '{obj.name}': {str(mesh_error)}", LogCategory.EXPORT_MESH)
                import traceback
                traceback.print_exc()
                raise

    except Exception as e:
        debug_log(f"Error in export_object for {obj.name} at path {obj_path}: {str(e)}", LogCategory.EXPORT_MESH)
        import traceback
        traceback.print_exc()
        raise

    # Note: Child objects are NOT exported recursively into mesh files
    # All hierarchies are handled in the layout file using Xform nodes and references
    # This follows standard USD conventions for scene graph composition
    debug_log(f"Mesh file for '{obj.name}' created (hierarchies handled in layout)", LogCategory.EXPORT_MESH)

    return prim

def export_mesh(stage, obj, mesh_path, up_axis, export_path, exported_materials=None, force_rebuild=None):
    from pxr import UsdSkel
    from . import cache_tracker

    # If force_rebuild not explicitly set, use session-level setting
    if force_rebuild is None:
        force_rebuild = cache_tracker.get_force_rebuild_session()

    debug_log(f"Starting export_mesh for '{obj.name}' at path '{mesh_path}'", LogCategory.EXPORT_MESH)

    safe_name = sanitize_name(obj.name)

    # Check if mesh has armature modifier (for skeletal animation)
    armature = get_armature_for_mesh(obj)
    debug_log(f"Armature found: {armature.name if armature else 'None'}", LogCategory.SKELETON_JOINTS)

    # Check if animation export is enabled
    export_animations_enabled = hasattr(obj, 'mhs') and obj.mhs.export_animations
    debug_log(f"Animation export enabled on mesh: {export_animations_enabled}", LogCategory.SKELETON_ANIMATION)

    has_animation = armature is not None and export_animations_enabled

    # Initialize animation-related variables
    skeleton = None
    skel_root_path = None

    # If mesh has skeletal animation, wrap everything in SkelRoot
    if has_animation:
        debug_log(f"Mesh '{obj.name}' has armature '{armature.name}', wrapping in SkelRoot", LogCategory.SKELETON_JOINTS)

        # Store original frame and set to first frame for correct bind pose
        # Keep at frame 1 throughout entire skeleton and animation export
        original_frame = bpy.context.scene.frame_current
        bpy.context.scene.frame_set(1)
        bpy.context.view_layer.update()
        debug_log(f"Set frame to 1 for skeleton/animation export (was at frame {original_frame})", LogCategory.SKELETON_ANIMATION)

        # Create SkelRoot at the mesh_path location
        # Structure: /ParentXform/mesh becomes SkelRoot containing Skeleton and Mesh
        # Example: /Suzanne/mesh (SkelRoot) contains /Suzanne/mesh/Armature and /Suzanne/mesh/geo
        skel_root_path = mesh_path

        debug_log(f"Creating SkelRoot at '{skel_root_path}'", LogCategory.SKELETON_JOINTS)
        skel_root = UsdSkel.Root.Define(stage, skel_root_path)

        # Don't apply any rotation here - conversion is baked into skeleton transforms

        # Export skeleton inside SkelRoot (will convert to Y-up internally)
        skeleton = export_skeleton(bpy.context, stage, armature, skel_root_path, obj, up_axis)

        if not skeleton:
            debug_log(f"ERROR - Failed to export skeleton for '{armature.name}', falling back to regular mesh export", LogCategory.SKELETON_JOINTS)
            has_animation = False
            mesh = UsdGeom.Mesh.Define(stage, mesh_path)
        else:
            # Create mesh inside SkelRoot with name "geo"
            mesh_in_skel_path = f"{skel_root_path}/geo"
            debug_log(f"Creating mesh at '{mesh_in_skel_path}'", LogCategory.EXPORT_MESH)
            mesh = UsdGeom.Mesh.Define(stage, mesh_in_skel_path)
    else:
        # Regular mesh export without animation
        mesh = UsdGeom.Mesh.Define(stage, mesh_path)

    # Automatically apply modifiers if the object has visible modifiers
    # This relies on viewport visibility instead of a user toggle
    # BUT skip armature modifier as we handle it separately
    should_apply_modifiers = has_visible_modifiers(obj)

    debug_log(f"should_apply_modifiers = {should_apply_modifiers}", LogCategory.EXPORT_MESH)

    # Check if this object has geometry nodes that might produce instances
    has_geonodes = has_geometry_nodes_modifier(obj)

    # Get mesh data - with or without modifiers applied
    try:
        if should_apply_modifiers:
            # Create a dependency graph and get evaluated mesh with modifiers applied
            depsgraph = bpy.context.evaluated_depsgraph_get()
            eval_obj = obj.evaluated_get(depsgraph)
            mesh_data = eval_obj.data

            # For geometry nodes objects, check if we got valid mesh data
            # If not, try to get the realized mesh from evaluated_geometry()
            if has_geonodes and (not mesh_data.vertices or len(mesh_data.vertices) == 0):
                debug_log(f"Geometry nodes object '{obj.name}' has empty evaluated mesh, checking evaluated_geometry()", LogCategory.GEOMNODES_INSTANCES)

                # Try to get mesh from evaluated_geometry() which properly realizes geometry nodes output
                if hasattr(eval_obj, 'evaluated_geometry'):
                    geometry = eval_obj.evaluated_geometry()
                    if geometry and hasattr(geometry, 'mesh') and geometry.mesh:
                        geo_mesh = geometry.mesh
                        if hasattr(geo_mesh, 'vertices') and len(geo_mesh.vertices) > 0:
                            debug_log(f"Using evaluated_geometry().mesh with {len(geo_mesh.vertices)} vertices", LogCategory.GEOMNODES_INSTANCES)
                            mesh_data = geo_mesh
                        else:
                            debug_log(f"evaluated_geometry().mesh also has no vertices", LogCategory.GEOMNODES_INSTANCES)
                    else:
                        debug_log(f"evaluated_geometry() has no mesh attribute", LogCategory.GEOMNODES_INSTANCES)

            debug_log(f"Using evaluated mesh data with modifiers", LogCategory.EXPORT_MESH)
        else:
            # Use original mesh data without modifiers
            mesh_data = obj.data
            debug_log(f"Using original mesh data (no modifiers)", LogCategory.EXPORT_MESH)

        debug_log(f"Mesh data has {len(mesh_data.vertices)} vertices, {len(mesh_data.polygons)} faces", LogCategory.EXPORT_MESH)
    except Exception as mesh_data_error:
        debug_log(f"ERROR getting mesh data: {str(mesh_data_error)}", LogCategory.EXPORT_MESH)
        import traceback
        traceback.print_exc()
        raise

    # === Phase 1: Bulk extract vertex positions using numpy foreach_get ===
    positions = np.zeros(len(mesh_data.vertices) * 3, dtype=np.float32)
    mesh_data.vertices.foreach_get('co', positions)
    positions = positions.reshape(-1, 3)

    # Convert from Blender Z-up to RUB Y-up: (x, y, z) → (x, z, -y)
    if up_axis == 'Y':
        # Swizzle columns: (x, y, z) → (x, z, -y)
        positions = positions[:, [0, 2, 1]]
        positions[:, 2] *= -1
        debug_log(f"Converting mesh to RUB Y-up: (x, z, -y)", LogCategory.EXPORT_TRANSFORM)

    # Convert to VtVec3fArray for USD (much faster than list comprehension)
    # Flatten and convert to Python list, then create VtArray
    points = Vt.Vec3fArray.FromNumpy(positions.astype(np.float32))

    # === Phase 2: Bulk extract face data using numpy foreach_get ===
    # Face vertex counts (number of vertices per polygon)
    face_counts = np.zeros(len(mesh_data.polygons), dtype=np.int32)
    mesh_data.polygons.foreach_get('loop_total', face_counts)

    # Loop to vertex indices (maps each loop to its vertex)
    loop_vertex_indices = np.zeros(len(mesh_data.loops), dtype=np.int32)
    mesh_data.loops.foreach_get('vertex_index', loop_vertex_indices)

    # === Phase 3: Bulk extract normals using numpy foreach_get ===
    # In Blender 4.0+, split normals are automatically available via corner_normals
    # No need to call calc_normals_split() which was removed in Blender 4.0
    normals_flat = np.zeros(len(mesh_data.loops) * 3, dtype=np.float32)
    mesh_data.corner_normals.foreach_get('vector', normals_flat)
    normals_arr = normals_flat.reshape(-1, 3)

    # Convert normals to Y-up if needed
    if up_axis == 'Y':
        normals_arr = normals_arr[:, [0, 2, 1]]
        normals_arr[:, 2] *= -1

    # Convert to VtVec3fArray for USD (much faster than list comprehension)
    normals = Vt.Vec3fArray.FromNumpy(normals_arr.astype(np.float32))

    # === Phase 6: Wrap USD authoring in Sdf.ChangeBlock for batched processing ===
    with Sdf.ChangeBlock():
        mesh.CreatePointsAttr(points)
        mesh.CreateFaceVertexCountsAttr(face_counts.tolist())
        mesh.CreateFaceVertexIndicesAttr(loop_vertex_indices.tolist())
        mesh.CreateNormalsAttr(normals)
        mesh.SetNormalsInterpolation(UsdGeom.Tokens.faceVarying)

    # === Phase 4: Bulk extract UVs using numpy foreach_get ===
    if mesh_data.uv_layers:
        uv_layer = mesh_data.uv_layers.active.data if mesh_data.uv_layers.active else mesh_data.uv_layers[0].data

        # Bulk extract UVs
        uvs_flat = np.zeros(len(uv_layer) * 2, dtype=np.float32)
        uv_layer.foreach_get('uv', uvs_flat)
        uvs = uvs_flat.reshape(-1, 2)

        # Deduplicate UVs using numpy unique
        unique_uvs, inverse_indices = np.unique(uvs, axis=0, return_inverse=True)

        # Convert to VtVec2fArray for USD (much faster than list comprehension)
        st = Vt.Vec2fArray.FromNumpy(unique_uvs.astype(np.float32))
        st_indices = inverse_indices.tolist()

        primvars_api = UsdGeom.PrimvarsAPI(mesh)
        uv_primvar = primvars_api.CreatePrimvar("st", Sdf.ValueTypeNames.TexCoord2fArray, UsdGeom.Tokens.faceVarying)
        uv_primvar.Set(st)
        uv_primvar.SetIndices(st_indices)

    # Export lightmap UV (second UV channel)
    if obj.mhs.export_lightmap:
        if len(mesh_data.uv_layers) >= 2:
            lightmap_uv_layer = mesh_data.uv_layers[1].data
        else:
            # Generate a new UV map using Smart UV Project
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.uv.smart_project()
            bpy.ops.object.mode_set(mode='OBJECT')
            lightmap_uv_layer = mesh_data.uv_layers.new(name="UVMap_Lightmap").data

        # === Phase 3: Bulk extract lightmap UVs using numpy foreach_get ===
        lightmap_uvs_flat = np.zeros(len(lightmap_uv_layer) * 2, dtype=np.float32)
        lightmap_uv_layer.foreach_get('uv', lightmap_uvs_flat)
        lightmap_uvs = lightmap_uvs_flat.reshape(-1, 2)

        # Deduplicate UVs using numpy unique
        unique_lightmap_uvs, inverse_indices = np.unique(lightmap_uvs, axis=0, return_inverse=True)

        # Convert to VtVec2fArray for USD
        st1 = Vt.Vec2fArray.FromNumpy(unique_lightmap_uvs.astype(np.float32))
        st1_indices = inverse_indices.tolist()

        primvars_api = UsdGeom.PrimvarsAPI(mesh)
        lightmap_primvar = primvars_api.CreatePrimvar("st1", Sdf.ValueTypeNames.TexCoord2fArray, UsdGeom.Tokens.faceVarying)
        lightmap_primvar.Set(st1)
        lightmap_primvar.SetIndices(st1_indices)

    export_vertex_color(obj, mesh, mesh_data)

    # Export materials - automatically export if object has material slots
    if obj.material_slots:
        # === Phase 2 Optimization: Bulk extract material indices using numpy ===
        material_indices = np.zeros(len(mesh_data.polygons), dtype=np.int32)
        mesh_data.polygons.foreach_get('material_index', material_indices)

        primvars_api = UsdGeom.PrimvarsAPI(mesh)
        material_indices_primvar = primvars_api.CreatePrimvar("materialIndices", Sdf.ValueTypeNames.IntArray, UsdGeom.Tokens.uniform)
        material_indices_primvar.Set(material_indices.tolist())

        # Create material bindings for each material slot
        for i, slot in enumerate(obj.material_slots):
            if slot.material:
                # Pass is_skinned=True for animated meshes so material name gets "_Skinned" suffix
                material_prim = export_material(stage, slot.material, export_path, exported_materials, force_rebuild=force_rebuild, is_skinned=has_animation)
                if material_prim:
                    # === Phase 5 Optimization: Use numpy boolean masking for face indices ===
                    face_indices = np.where(material_indices == i)[0].tolist()
                    subset = UsdGeom.Subset.Define(stage, f"{mesh.GetPath()}/{sanitize_name(slot.name)}")
                    subset.CreateElementTypeAttr("face")
                    subset.CreateIndicesAttr(face_indices)
                    UsdShade.MaterialBindingAPI.Apply(subset.GetPrim())

                    # Bind the material to the subset
                    UsdShade.MaterialBindingAPI(subset).Bind(material_prim)

    # If this mesh has skeletal animation, export skin weights and animations
    if has_animation and skeleton:
        debug_log(f"Exporting skin weights and animations for '{obj.name}'", LogCategory.SKELETON_WEIGHTS)

        # Export skin weights
        export_skin_weights(bpy.context, obj, armature, mesh.GetPrim(), skeleton)

        # Export animations - pass mesh_obj for export settings
        project_path = bpy.context.scene.mhs.project_path if hasattr(bpy.context.scene, 'mhs') else None
        animation_paths = export_animations(bpy.context, stage, armature, skeleton, skel_root_path, project_path, obj)

        debug_log(f"Skeletal animation export complete for '{obj.name}': {len(animation_paths)} animations exported", LogCategory.SKELETON_ANIMATION)

        # Restore original frame after skeleton/animation export
        bpy.context.scene.frame_set(original_frame)
        bpy.context.view_layer.update()
        debug_log(f"Restored frame to {original_frame} after animation export", LogCategory.SKELETON_ANIMATION)

    # Return appropriate prim path based on whether we created a SkelRoot
    if has_animation:
        return stage.GetPrimAtPath(skel_root_path)
    else:
        return stage.GetPrimAtPath(mesh_path)

def export_lod_meshes(stage, obj, obj_path, up_axis, export_path, context):
    """Export LOD meshes with variant sets, supporting Manual and Decimate modes

    LOD Structure:
    - LOD0: Always the parent object (base mesh)
    - LOD1+: From lod_list items (starting at index 1)
    - lod_list[0]: Controls LOD0's distance_ratio only (object is ignored, parent is always used)
    - lod_list[1+]: Controls LOD1+ distance_ratio and mesh data
    """
    debug_log(f"\nLOD Export: Processing LODs for '{obj.name}'", LogCategory.EXPORT_MESH)
    debug_log(f"  Method: {obj.mhs.lod_method}", LogCategory.EXPORT_MESH)
    debug_log(f"  Export as references: {obj.mhs.export_lods_as_references}", LogCategory.EXPORT_MESH)
    debug_log(f"  Number of LOD levels in list: {len(obj.mhs.lod_list)}", LogCategory.EXPORT_MESH)

    # Get or create the prim
    prim = stage.GetPrimAtPath(obj_path)
    if not prim:
        debug_log(f"LOD Export: ERROR - Prim not found at {obj_path}", LogCategory.EXPORT_MESH)
        return

    # CRITICAL: If exporting LODs as references, create material references at root level of main file
    # This allows LOD files to bind to materials defined in the main file
    if obj.mhs.export_lods_as_references and obj.material_slots:
        debug_log(f"  Creating material references at root level of main file", LogCategory.EXPORT_MESH)

        # Collect unique materials
        materials_to_export = set()
        for slot in obj.material_slots:
            if slot.material:
                materials_to_export.add(slot.material)

        # Create material reference prims at root level
        for material in materials_to_export:
            safe_material_name = sanitize_name(material.name)
            material_prim_path = f"/{safe_material_name}"

            # Check if material already exists at root level
            existing_material = stage.GetPrimAtPath(material_prim_path)
            if not existing_material or not existing_material.IsValid():
                # Create material prim with reference to external material file
                # NOTE: AddReference() expects path WITHOUT @ symbols - USD adds them automatically
                # Main file is in meshes/ folder, materials are in ../materials/ relative to it
                material_ref_path = f"../materials/{safe_material_name}.usda"
                material_prim = stage.DefinePrim(material_prim_path)
                material_prim.GetReferences().AddReference(material_ref_path)
                debug_log(f"    Created material reference: {safe_material_name} -> @{material_ref_path}@", LogCategory.EXPORT_REFERENCE)

    # Create LOD variant set
    variantSets = prim.GetVariantSets()
    lodVariantSet = variantSets.AddVariantSet("LOD")

    # Prepare LOD objects list
    # LOD structure: LOD0 (parent) + LOD1+ (from list starting at index 1)
    lod_objects = []
    lod_distance_ratios = []

    # LOD0: Always the parent object
    lod_objects.append(obj)
    # Get LOD0's distance ratio from lod_list[0] if it exists, otherwise use 1.0
    lod0_distance_ratio = obj.mhs.lod_list[0].distance_ratio if len(obj.mhs.lod_list) > 0 else 1.0
    lod_distance_ratios.append(lod0_distance_ratio)
    debug_log(f"  LOD0: Using parent object '{obj.name}' with distance_ratio={lod0_distance_ratio}", LogCategory.EXPORT_MESH)

    # Process LOD1+ from the list (starting at index 1)
    if len(obj.mhs.lod_list) > 1:
        if obj.mhs.lod_method == 'MANUAL':
            # Manual mode: use objects specified by user (starting from index 1)
            for i, lod in enumerate(obj.mhs.lod_list[1:], start=1):
                if lod.object:
                    lod_objects.append(lod.object)
                    lod_distance_ratios.append(lod.distance_ratio)
                    debug_log(f"  LOD{i}: Using object '{lod.object.name}' with distance_ratio={lod.distance_ratio}", LogCategory.EXPORT_MESH)
                else:
                    debug_log(f"LOD Export: WARNING - LOD{i} entry has no object assigned, skipping", LogCategory.EXPORT_MESH)

        elif obj.mhs.lod_method == 'DECIMATE':
            # Decimate mode: create temporary decimated versions (starting from index 1)
            lod_objects_temp = create_decimated_lods(obj, obj.mhs.lod_list[1:], context, start_index=1)
            lod_objects.extend(lod_objects_temp)
            for i, lod in enumerate(obj.mhs.lod_list[1:], start=1):
                lod_distance_ratios.append(lod.distance_ratio)
                debug_log(f"  LOD{i}: Using decimated version with {lod.decimate_percentage}% and distance_ratio={lod.distance_ratio}", LogCategory.EXPORT_MESH)

    debug_log(f"  Total LOD levels to export: {len(lod_objects)}", LogCategory.EXPORT_MESH)

    # Export each LOD as a variant
    for i, (lod_obj, distance_ratio) in enumerate(zip(lod_objects, lod_distance_ratios)):
        variant_name = f"lod{i}"
        debug_log(f"  Creating variant '{variant_name}' for object '{lod_obj.name}' with distance ratio {distance_ratio}", LogCategory.EXPORT_MESH)

        # Create the variant
        lodVariantSet.AddVariant(variant_name)
        lodVariantSet.SetVariantSelection(variant_name)

        with lodVariantSet.GetVariantEditContext():
            # Create a sub-prim for this LOD level
            lod_prim_path = f"{obj_path}/{variant_name}"

            if obj.mhs.export_lods_as_references:
                # LOD0 is always embedded, LOD1+ are exported as references
                if i == 0:
                    debug_log(f"    LOD0 is always embedded in the main file", LogCategory.EXPORT_MESH)
                    export_lod_embedded(stage, lod_obj, lod_prim_path, up_axis, export_path, distance_ratio)
                else:
                    # Export LOD1+ as reference with material bindings in main file
                    lod_prim = export_lod_as_reference(stage, lod_obj, lod_prim_path, up_axis, export_path, i, distance_ratio, obj.name)

                    # Apply material bindings in the main file to the LOD prim
                    # This binds the referenced geometry to the root-level materials
                    if lod_obj.material_slots:
                        debug_log(f"    Applying material bindings to LOD{i} prim in main file", LogCategory.EXPORT_MESH)

                        # Apply MaterialBindingAPI to the LOD prim
                        UsdShade.MaterialBindingAPI.Apply(lod_prim)

                        # For single material, bind directly
                        if len(lod_obj.material_slots) == 1 and lod_obj.material_slots[0].material:
                            safe_material_name = sanitize_name(lod_obj.material_slots[0].material.name)
                            material_path = f"/{safe_material_name}"

                            # Get the material prim at root level
                            material_prim = stage.GetPrimAtPath(material_path)
                            if material_prim and material_prim.IsValid():
                                material_shader = UsdShade.Material(material_prim)
                                binding_api = UsdShade.MaterialBindingAPI(lod_prim)
                                binding_api.Bind(material_shader)
                                debug_log(f"      Bound material '{safe_material_name}' to LOD{i}", LogCategory.EXPORT_MESH)
                            else:
                                debug_log(f"      WARNING: Material '{safe_material_name}' not found at {material_path}", LogCategory.EXPORT_MESH)
                        else:
                            # Multi-material: would need to bind to subsets in the referenced geometry
                            # This is more complex and may require the engine to support it
                            debug_log(f"      Multi-material binding not yet implemented for LOD references", LogCategory.EXPORT_MESH)
            else:
                # Embed all LOD mesh data directly
                export_lod_embedded(stage, lod_obj, lod_prim_path, up_axis, export_path, distance_ratio)

    # Set default variant to lod0
    lodVariantSet.SetVariantSelection("lod0")
    debug_log(f"LOD Export: Successfully exported {len(lod_objects)} LOD levels for '{obj.name}'", LogCategory.EXPORT_MESH)

    # Cleanup temporary decimate objects if created
    if obj.mhs.lod_method == 'DECIMATE' and len(lod_objects) > 1:
        cleanup_decimated_lods(lod_objects[1:])  # Skip LOD0 (original object)

def create_decimated_lods(base_obj, lod_list, context, start_index=1):
    """Create temporary decimated LOD objects

    Args:
        base_obj: Base object to decimate from
        lod_list: List of LOD settings to process
        context: Blender context
        start_index: Starting index for LOD naming (default 1 for LOD1, LOD2, etc.)

    Returns:
        List of decimated temporary objects
    """
    debug_log(f"\nLOD Export: Creating decimated LODs for '{base_obj.name}'", LogCategory.EXPORT_MESH)
    decimated_objects = []

    # Store original selection and active object
    original_selection = context.selected_objects.copy() if hasattr(context, 'selected_objects') else []
    original_active = context.view_layer.objects.active if hasattr(context.view_layer.objects, 'active') else None

    for i, lod in enumerate(lod_list, start=start_index):
        decimate_ratio = lod.decimate_percentage / 100.0
        debug_log(f"  Creating LOD{i} with {lod.decimate_percentage}% decimation ({decimate_ratio} ratio)", LogCategory.EXPORT_MESH)

        # Duplicate the base object
        temp_obj = base_obj.copy()
        temp_obj.data = base_obj.data.copy()
        temp_obj.name = f"{base_obj.name}_LOD{i}_temp"
        context.scene.collection.objects.link(temp_obj)

        # CRITICAL: Disable LOD export on temporary objects to prevent recursive LOD export
        # We must both disable the flag AND clear the LOD list to prevent any LOD export
        if hasattr(temp_obj, 'mhs'):
            temp_obj.mhs.export_lods = False
            # Clear the LOD list to ensure no LODs are exported for temp objects
            temp_obj.mhs.lod_list.clear()
            debug_log(f"    Disabled LOD export on temporary object '{temp_obj.name}'", LogCategory.EXPORT_MESH)
        else:
            debug_log(f"    WARNING: Temporary object '{temp_obj.name}' has no mhs attribute!", LogCategory.EXPORT_MESH)

        debug_log(f"    Created temporary object '{temp_obj.name}' with {len(temp_obj.data.vertices)} vertices", LogCategory.EXPORT_MESH)

        # Add decimate modifier
        decimate_mod = temp_obj.modifiers.new(name="LOD_Decimate", type='DECIMATE')
        decimate_mod.ratio = decimate_ratio
        decimate_mod.use_collapse_triangulate = False

        debug_log(f"    Added decimate modifier with ratio={decimate_ratio}", LogCategory.EXPORT_MESH)

        # Apply the modifier using depsgraph evaluation
        # This is more reliable than using operators in Blender 4.x
        try:
            # Get depsgraph-evaluated version of the object with modifier applied
            depsgraph = context.evaluated_depsgraph_get()
            evaluated_obj = temp_obj.evaluated_get(depsgraph)

            # Create new mesh from evaluated data
            new_mesh = bpy.data.meshes.new_from_object(evaluated_obj)

            # Store original mesh data pointer
            old_mesh = temp_obj.data

            # Replace mesh data with decimated version
            temp_obj.data = new_mesh
            temp_obj.modifiers.clear()  # Remove all modifiers since they're baked in

            # Clean up old mesh data if it has no other users
            if old_mesh.users == 0:
                bpy.data.meshes.remove(old_mesh)

            debug_log(f"    Applied decimate modifier (ratio={decimate_ratio}): {len(temp_obj.data.vertices)} vertices after decimation", LogCategory.EXPORT_MESH)
        except Exception as e:
            debug_log(f"    WARNING: Failed to apply modifier: {e}", LogCategory.EXPORT_MESH)
            import traceback
            traceback.print_exc()

        decimated_objects.append(temp_obj)

    # Restore original selection and active object
    if original_active:
        context.view_layer.objects.active = original_active

    return decimated_objects

def cleanup_decimated_lods(temp_objects):
    """Remove temporary decimated LOD objects"""
    for temp_obj in temp_objects:
        if temp_obj and temp_obj.name in bpy.data.objects:
            debug_log(f"  Cleaning up temporary object: {temp_obj.name}", LogCategory.EXPORT_MESH)
            # Remove the mesh data
            mesh_data = temp_obj.data
            # Remove the object
            bpy.data.objects.remove(temp_obj, do_unlink=True)
            # Remove the orphaned mesh data
            if mesh_data and mesh_data.users == 0:
                bpy.data.meshes.remove(mesh_data)

def export_lod_as_reference(stage, lod_obj, lod_prim_path, up_axis, export_path, lod_index, distance_ratio, base_obj_name=None):
    """Export LOD as a reference to an external file

    Args:
        stage: USD stage for the main file
        lod_obj: Object to export (may be temp object for Decimate mode)
        lod_prim_path: Path for the LOD prim in the main file
        up_axis: 'Y' or 'Z'
        export_path: Path to the main export file
        lod_index: LOD index (0, 1, 2, etc.)
        distance_ratio: Distance ratio for this LOD
        base_obj_name: Name of the base object (for consistent naming, especially with temp objects)

    Returns:
        LOD prim
    """
    # Use base object name if provided, otherwise use the LOD object's name
    # This ensures consistent naming even when using temporary decimated objects
    if base_obj_name:
        safe_name = sanitize_name(base_obj_name)
    else:
        safe_name = sanitize_name(lod_obj.name)

    # File name includes LOD suffix
    ref_filename = f"{safe_name}_LOD{lod_index}.usda"
    # NOTE: ref_path should NOT include @ symbols - USD's AddReference() adds them automatically
    ref_path = f"./{ref_filename}"  # Relative path in same directory (without @)

    # Create the reference file in the same directory as the main export
    export_dir = os.path.dirname(export_path)
    ref_full_path = os.path.join(export_dir, ref_filename)

    debug_log(f"    Exporting LOD{lod_index} as reference: {ref_path}", LogCategory.EXPORT_REFERENCE)

    # Create a new stage for the referenced mesh
    # Handle existing files (USD layer cache issue)
    if os.path.exists(ref_full_path):
        debug_log(f"    Found existing LOD file '{ref_full_path}', will open and clear it", LogCategory.EXPORT_MESH)
        try:
            ref_stage = Usd.Stage.Open(ref_full_path)
            ref_stage.GetRootLayer().Clear()
            debug_log(f"    Cleared existing LOD file", LogCategory.EXPORT_MESH)
        except Exception as open_error:
            debug_log(f"    Could not open existing LOD file ({open_error}), will try CreateNew", LogCategory.EXPORT_MESH)
            ref_stage = Usd.Stage.CreateNew(ref_full_path)
    else:
        debug_log(f"    Creating new LOD file '{ref_full_path}'", LogCategory.EXPORT_MESH)
        try:
            ref_stage = Usd.Stage.CreateNew(ref_full_path)
        except Exception as create_error:
            debug_log(f"    CreateNew failed ({create_error}), using Open instead", LogCategory.EXPORT_MESH)
            ref_stage = Usd.Stage.Open(ref_full_path)
            ref_stage.GetRootLayer().Clear()

    UsdGeom.SetStageUpAxis(ref_stage, UsdGeom.Tokens.y if up_axis == 'Y' else UsdGeom.Tokens.z)
    UsdGeom.SetStageMetersPerUnit(ref_stage, 1)
    set_stage_custom_layer_data(ref_stage)

    # Export the mesh to the reference stage
    # IMPORTANT: Include LOD suffix in mesh name for proper identification
    # e.g., MonkeyLOD_LOD1.usda should contain "MonkeyLOD_LOD1" mesh
    mesh_name_with_lod = f"{safe_name}_LOD{lod_index}"
    mesh_prim_path = f"/{mesh_name_with_lod}"

    debug_log(f"    Creating mesh prim: {mesh_prim_path}", LogCategory.EXPORT_MESH)

    # LOD reference files contain ONLY geometry - no materials, no bindings
    # Pass None to skip all material export
    mesh_prim = export_mesh(ref_stage, lod_obj, mesh_prim_path, up_axis, ref_full_path, exported_materials=None)

    debug_log(f"    LOD mesh exported (geometry only)", LogCategory.EXPORT_MESH)

    # Set the default prim for the reference file
    ref_stage.SetDefaultPrim(ref_stage.GetPrimAtPath(mesh_prim_path))

    # Save the reference stage
    ref_stage.Save()

    # Create the LOD prim and add reference WITHOUT specifying a prim path
    # NOTE: AddReference() expects path WITHOUT @ symbols - USD adds them automatically
    lod_prim = stage.DefinePrim(lod_prim_path)
    # ref_path is already without @ symbols (e.g., "./MonkeyLOD_LOD1.usda")
    debug_log(f"    Adding reference: @{ref_path}@ (defaultPrim: {mesh_prim_path})", LogCategory.EXPORT_REFERENCE)
    lod_prim.GetReferences().AddReference(ref_path)
    lod_prim.CreateAttribute("distanceRatio", Sdf.ValueTypeNames.Float).Set(distance_ratio)

    return lod_prim

def export_lod_embedded(stage, lod_obj, lod_prim_path, up_axis, export_path, distance_ratio):
    """Export LOD with embedded mesh data"""
    debug_log(f"    Exporting as embedded mesh data", LogCategory.EXPORT_MESH)

    # Export the mesh directly into the variant
    mesh_prim = export_mesh(stage, lod_obj, lod_prim_path, up_axis, export_path)
    mesh_prim.CreateAttribute("distanceRatio", Sdf.ValueTypeNames.Float).Set(distance_ratio)

    return mesh_prim

def export_mesh_as_reference(stage, obj, mesh_path, up_axis, export_path):
    safe_name = sanitize_name(obj.name)
    ref_path = f"/meshes/{safe_name}.usda"

    # Create a new stage for the referenced mesh
    ref_stage = Usd.Stage.CreateNew(os.path.join(os.path.dirname(export_path), ref_path))

    # Export the mesh to the new stage
    export_mesh(ref_stage, obj, "/Mesh", up_axis, ref_path)

    # Save the new stage
    ref_stage.Save()

    # Create a reference to the new mesh in the main stage
    mesh_prim = stage.OverridePrim(mesh_path)
    mesh_prim.GetReferences().AddReference(ref_path)

    return mesh_prim

def export_material_as_separate_file(material, project_path, force_rebuild=None, is_skinned=False, layout_name=None):
    """Export a material as a separate USDa file in the materials folder

    Args:
        material: Blender material to export
        project_path: Path to project folder
        force_rebuild: Force rebuild even if cached
        is_skinned: If True, append '_Skinned' to material name for skinned mesh exports
        layout_name: Optional layout name for {layout} folder substitution
    """
    from . import cache_tracker

    if not material:
        return None

    # If force_rebuild not explicitly set, use session-level setting
    if force_rebuild is None:
        force_rebuild = cache_tracker.get_force_rebuild_session()

    # Build output name with format-based suffixes for material type identification
    safe_name = sanitize_name(material.name)

    # Get material format and add appropriate suffix for shader matching
    material_format = material.mhs.material_format if material.mhs else 'NONE'

    # Map material formats to name suffixes (for materialMap.json matching)
    format_suffixes = {
        'UNLIT_BLEND': '_Blend',
        'UNLIT_MASKED': '_Masked',
        # Other formats don't need special suffixes as they have unique texture mappings
    }

    # Add format suffix if needed (and not already present)
    format_suffix = format_suffixes.get(material_format, '')
    if format_suffix and not safe_name.endswith(format_suffix):
        safe_name = f"{safe_name}{format_suffix}"

    # Append _Skinned suffix for animated meshes (after format suffix)
    if is_skinned and not safe_name.endswith('_Skinned'):
        safe_name = f"{safe_name}_Skinned"

    material_filename = f"{safe_name}.usda"

    # Use custom folder path with {layout} support
    scene = bpy.context.scene
    materials_folder = scene.mhs.materials_folder
    materials_dir = resolve_folder_path(project_path, materials_folder, layout_name)
    os.makedirs(materials_dir, exist_ok=True)

    material_filepath = os.path.join(materials_dir, material_filename)

    # Check if this material was already exported in this session
    # This prevents duplicate record_skip calls when multiple meshes share the same material
    if cache_tracker.is_material_exported_this_session(material_filepath):
        debug_log(f"Material '{material_filename}' already exported this session, skipping", LogCategory.CACHE_HIT)
        return material_filepath

    # Get cache and compute material hash for dirty tracking
    cache = cache_tracker.get_cache()
    texture_paths = cache_tracker.get_material_texture_paths(material)
    material_hash = cache_tracker.compute_material_hash(material, texture_paths)

    # Check if we can skip export (not force rebuild and hash matches)
    if not force_rebuild and not cache.should_export(material_filepath, material_hash):
        debug_log(f"Skipping unchanged material '{material_filepath}'", LogCategory.CACHE_HIT)
        cache_tracker.mark_material_exported(material_filepath)
        cache_tracker.record_skip('material', material_filepath, estimated_write_time=0.05)
        return material_filepath

    # If file exists and is recent (less than 5 seconds old), reuse it instead of recreating
    # This prevents race conditions when multiple objects reference the same material
    if os.path.exists(material_filepath):
        file_age = time.time() - os.path.getmtime(material_filepath)
        if file_age < 5.0:
            debug_log(f"Reusing recently created material file '{material_filepath}' (age: {file_age:.2f}s)", LogCategory.MATERIAL_SETUP)
            return material_filepath

        debug_log(f"Found existing material file '{material_filepath}', will open and clear it", LogCategory.MATERIAL_SETUP)
        try:
            # Open the existing stage and clear it completely
            material_stage = Usd.Stage.Open(material_filepath)
            material_stage.GetRootLayer().Clear()
            debug_log(f"Cleared existing material file", LogCategory.MATERIAL_SETUP)
        except Exception as open_error:
            debug_log(f"Could not open existing material file ({open_error}), will try CreateNew", LogCategory.MATERIAL_SETUP)
            # If Open fails, try CreateNew as fallback
            try:
                material_stage = Usd.Stage.CreateNew(material_filepath)
            except Exception as create_error2:
                debug_log(f"Both Open and CreateNew failed, material may be locked. Reusing existing file.", LogCategory.MATERIAL_SETUP)
                return material_filepath
    else:
        # File doesn't exist, create new
        debug_log(f"Creating new material file '{material_filepath}'", LogCategory.MATERIAL_SETUP)
        try:
            material_stage = Usd.Stage.CreateNew(material_filepath)
        except Exception as create_error:
            # If CreateNew fails (cached layer), use Open which will work
            debug_log(f"CreateNew failed ({create_error}), using Open instead", LogCategory.MATERIAL_SETUP)
            try:
                material_stage = Usd.Stage.Open(material_filepath)
                material_stage.GetRootLayer().Clear()
            except Exception as open_error2:
                debug_log(f"Both CreateNew and Open failed ({open_error2})", LogCategory.MATERIAL_SETUP)
                if os.path.exists(material_filepath):
                    debug_log(f"File exists, will attempt to reuse it", LogCategory.MATERIAL_SETUP)
                    return material_filepath
                raise
    UsdGeom.SetStageMetersPerUnit(material_stage, 1)
    UsdGeom.SetStageUpAxis(material_stage, UsdGeom.Tokens.y)
    set_stage_custom_layer_data(material_stage)

    # Create the material in the new stage
    material_path = f"/{safe_name}"
    material_prim = UsdShade.Material.Define(material_stage, material_path)
    material_stage.SetDefaultPrim(material_prim.GetPrim())

    # Create a PBR shader with the material's name
    shader_path = f"{material_path}/{safe_name}_shader"
    pbr_shader = UsdShade.Shader.Define(material_stage, shader_path)
    pbr_shader.CreateIdAttr("UsdPreviewSurface")

    # Connect the PBR shader to the material output
    material_prim.CreateSurfaceOutput().ConnectToSource(pbr_shader.ConnectableAPI(), "surface")

    # Find the primary shader group node (not MHS_UVTransform which is a utility group)
    group_node = None
    for node in material.node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree:
            # Skip UV transform nodes - look for actual shader groups
            if node.node_tree.name == 'MHS_UVTransform':
                continue
            # Found a shader group node
            group_node = node
            break

    if not group_node or not group_node.node_tree:
        debug_log(f"No valid shader group node found for material {material.name}", LogCategory.MATERIAL_GROUPS)
    else:
        debug_log(f"Found shader group node '{group_node.name}' (node tree: '{group_node.node_tree.name}') for material {material.name}", LogCategory.MATERIAL_SETUP)

        # Inputs to skip during USD export (internal Blender-only inputs)
        skip_inputs = {
            'uv scale', 'uv offset',  # UV transform handled separately
            'vertex color',           # Vertex colors handled via mesh data
            'alpha',                  # Alpha typically from texture, not separate input
        }

        # Process each input of the group node
        for input in group_node.inputs:
            input_name = input.name.lower()

            debug_log(f"Processing input '{input.name}' (linked: {input.is_linked})", LogCategory.MATERIAL_SETUP)

            # Skip inputs that are for Blender preview only
            if input_name in skip_inputs:
                debug_log(f"Skipping internal input '{input.name}' for material {material.name}", LogCategory.MATERIAL_SETUP)
                continue

            # Skip _lightmap input if useLightmap is disabled
            if input_name == "_lightmap":
                # Check if useLightmap is enabled in the node group
                use_lightmap_input = next((inp for inp in group_node.inputs if inp.name.lower() == "uselightmap"), None)
                if use_lightmap_input and not use_lightmap_input.default_value:
                    debug_log(f"Skipping _lightmap input because useLightmap is disabled for material {material.name}", LogCategory.MATERIAL_LIGHTMAP)
                    continue

            # Trace back to find the actual source of the data
            source_socket, source_node = trace_to_source(input)

            if source_node.type in ['TEX_IMAGE']:
                debug_log(f"Input '{input.name}' is connected to texture node '{source_node.name}'", LogCategory.MATERIAL_SETUP)
                process_texture_node(material_stage, pbr_shader, shader_path, input_name, source_node, material, material_filepath)
            else:
                debug_log(f"Input '{input.name}' is connected to non-texture node '{source_node.name}' (type: {source_node.type})", LogCategory.MATERIAL_SETUP)
                process_value_node(pbr_shader, input_name, source_socket)

    # Save the material stage
    material_stage.Save()

    # Adding generated to auto collapse diffs when submitted to fbsource
    with open(material_filepath, 'a') as file:
        file.write('#@generated')

    # Update cache after successful export
    cache.set_file_hash(material_filepath, material_hash, {
        "texture_hashes": {p: cache_tracker.compute_texture_hash(p) for p in texture_paths}
    })
    cache_tracker.mark_material_exported(material_filepath)
    cache_tracker.record_export('material', material_filepath)

    return material_filepath

def export_material(stage, material, export_path, exported_materials=None, force_rebuild=None, is_skinned=False):
    """Export material as reference to separate material file with caching to avoid duplicate exports

    Args:
        stage: USD stage
        material: Blender material to export
        export_path: Path to the export file
        exported_materials: Dict to track already exported materials
        force_rebuild: Force rebuild even if cached
        is_skinned: If True, append '_Skinned' to material name for skinned mesh exports
    """
    from . import cache_tracker

    if not material:
        return None

    # If force_rebuild not explicitly set, use session-level setting
    if force_rebuild is None:
        force_rebuild = cache_tracker.get_force_rebuild_session()

    # Initialize cache if not provided
    if exported_materials is None:
        exported_materials = {}

    # Build cache key - include skinned suffix to cache skinned and non-skinned versions separately
    material_name = material.name
    cache_key = f"{material_name}_Skinned" if is_skinned else material_name

    if cache_key in exported_materials:
        # Material already exported, return the cached material prim
        debug_log(f"Reusing cached material '{cache_key}'", LogCategory.MATERIAL_SETUP)
        return exported_materials[cache_key]

    # Get project path from context
    project_path = bpy.context.scene.mhs.project_path

    # Export material as separate file (only once per material)
    debug_log(f"Exporting material '{material_name}' for the first time (skinned={is_skinned})", LogCategory.MATERIAL_SETUP)
    material_filepath = export_material_as_separate_file(material, project_path, force_rebuild=force_rebuild, is_skinned=is_skinned)
    if not material_filepath:
        return None

    # Create reference to the separate material file
    # Use the output name which includes _Skinned suffix if applicable
    # IMPORTANT: Use /Materials/ namespace to prevent collisions with mesh names
    safe_name = sanitize_name(material.name)
    if is_skinned and not safe_name.endswith('_Skinned'):
        safe_name = f"{safe_name}_Skinned"
    material_path = f"/Materials/{safe_name}"

    # Get relative path from current export file to material file
    mesh_dir = os.path.dirname(export_path)
    relative_material_path = os.path.relpath(material_filepath, mesh_dir)
    relative_material_path = relative_material_path.replace(os.sep, '/')  # Ensure forward slashes

    debug_log(f"Creating material reference: prim='{material_path}', file='{relative_material_path}'", LogCategory.EXPORT_REFERENCE)

    # Create a Material prim that points to the material file
    # Using UsdShade.Material.Define ensures the prim is defined as 'def Material "name"'
    # AddReference(assetPath, primPath) where:
    #   - assetPath is the relative file path to the material USD file
    #   - primPath is the prim path WITHIN that referenced file (default prim if empty string)
    material_prim = UsdShade.Material.Define(stage, material_path)

    # Use default prim from the material file (empty string as primPath)
    # This will automatically reference the default prim defined in the material file
    material_prim.GetPrim().GetReferences().AddReference(relative_material_path)

    # Create a UsdShade.Material for binding purposes
    usd_material = material_prim

    # Cache the material for reuse (use cache_key which includes _Skinned suffix if applicable)
    exported_materials[cache_key] = usd_material

    return usd_material

def trace_to_source(socket, max_depth=10):
    """Trace back through the node tree to find the source of the data.

    For group node inputs, the 'socket' is the input socket on the group node.
    We need to check if it's linked and follow the link to find the source.

    Args:
        socket: The input socket to trace from
        max_depth: Maximum traversal depth to prevent infinite loops

    Returns:
        Tuple of (source_socket, source_node) where source_node is the originating node
    """
    depth = 0
    current_socket = socket

    debug_log(f"  trace_to_source: Starting trace from socket '{socket.name}' on node '{socket.node.name}'", LogCategory.MATERIAL_SETUP)

    while depth < max_depth:
        # Check if this socket is linked
        if not current_socket.is_linked:
            debug_log(f"  trace_to_source: Socket '{current_socket.name}' is not linked, returning node '{current_socket.node.name}'", LogCategory.MATERIAL_SETUP)
            return current_socket, current_socket.node

        # Follow the link to the source socket
        link = current_socket.links[0]
        source_socket = link.from_socket
        source_node = link.from_node

        debug_log(f"  trace_to_source: Followed link to socket '{source_socket.name}' on node '{source_node.name}' (type: {source_node.type})", LogCategory.MATERIAL_SETUP)

        # Check if we found a terminal node type (texture, value, color, vertex color)
        if source_node.type in ['TEX_IMAGE', 'VALUE', 'RGB', 'VERTEX_COLOR']:
            debug_log(f"  trace_to_source: Found terminal node '{source_node.name}' of type '{source_node.type}'", LogCategory.MATERIAL_SETUP)
            return source_socket, source_node

        # If it's a GROUP node (like MHS_UVTransform), return what we have so far
        # This means we couldn't find a texture - the connection goes to a different kind of node
        if source_node.type == 'GROUP':
            debug_log(f"  trace_to_source: Hit GROUP node '{source_node.name}', returning previous socket", LogCategory.MATERIAL_SETUP)
            # Return the current socket and node (before the group)
            return current_socket, current_socket.node

        # For MIX, MATH, COMBINE_COLOR, SEPARATE_COLOR, etc., try to trace further
        # by looking at their first meaningful input
        if source_node.type in ['MIX', 'MATH', 'COMBINE_COLOR', 'SEPARATE_COLOR', 'MIX_RGB']:
            debug_log(f"  trace_to_source: Tracing through {source_node.type} node '{source_node.name}'", LogCategory.MATERIAL_SETUP)
            # Try to find an input that might lead to a texture
            found_next = False
            for inp in source_node.inputs:
                if inp.is_linked and inp.type in ['RGBA', 'VALUE', 'VECTOR']:
                    current_socket = inp
                    found_next = True
                    break
            if not found_next:
                debug_log(f"  trace_to_source: No linked inputs found on {source_node.type} node, returning it", LogCategory.MATERIAL_SETUP)
                return source_socket, source_node
        else:
            # Unknown node type, return what we found
            debug_log(f"  trace_to_source: Unknown node type '{source_node.type}', returning node '{source_node.name}'", LogCategory.MATERIAL_SETUP)
            return source_socket, source_node

        depth += 1

    debug_log(f"  trace_to_source: Max depth reached, returning current socket", LogCategory.MATERIAL_SETUP)
    return current_socket, current_socket.node

def process_texture_node(stage, pbr_shader, shader_path, input_name, source_node, material, export_path):
    texture_image = source_node.image
    if texture_image:
        # Map input names to short texture suffixes
        # Handles both legacy names (bc_texture) and new template names (base color)
        input_name_lower = input_name.lower()

        suffix_mapping = {
            # Base Color variants
            'bc_texture': 'BC',
            'base color': 'BC',
            'base_color': 'BC',
            # MRO variants
            'mro_texture': 'MRO',
            'mro texture': 'MRO',
            'mro': 'MRO',
            # Normal variants
            'n_texture': 'N',
            'normal': 'N',
            'normal_texture': 'N',
            # Emissive variants
            'e_texture': 'E',
            'emissive texture': 'E',
            'emissive_texture': 'E',
            'emissive': 'E',
        }

        # Get the short suffix, fallback to sanitized input name
        suffix = suffix_mapping.get(input_name_lower, input_name.replace(' ', '').upper()[:4])

        # Sanitize input name for USD node path (replace spaces with underscores)
        safe_input_name = input_name.replace(' ', '_')
        texture_node = UsdShade.Shader.Define(stage, f"{shader_path}/{safe_input_name}")
        texture_node.CreateIdAttr("UsdUVTexture")

        # Export texture with short suffix
        texture_path = export_texture(texture_image, suffix)

        # Get the project path from the scene properties
        project_path = bpy.context.scene.mhs.project_path

        mesh_dir = os.path.dirname(export_path)
        relative_texture_path = os.path.relpath(texture_path, mesh_dir)
        relative_texture_path = relative_texture_path.replace(os.sep, '/')  # Ensure forward slashes
        texture_node.CreateInput("file", Sdf.ValueTypeNames.Asset).Set(relative_texture_path)
        texture_node.CreateInput("st", Sdf.ValueTypeNames.Float2).ConnectToSource(pbr_shader.ConnectableAPI(), "frame:st")

        # Set sourceColorSpace
        # MRO textures should always be linear/data, not sRGB
        is_mro = input_name_lower in ['mro_texture', 'mro texture', 'mro']

        if is_mro:
            texture_node.CreateInput("sourceColorSpace", Sdf.ValueTypeNames.Token).Set("linear")
        elif source_node.image.colorspace_settings.name == "sRGB":
            texture_node.CreateInput("sourceColorSpace", Sdf.ValueTypeNames.Token).Set("sRGB")
        else:
            texture_node.CreateInput("sourceColorSpace", Sdf.ValueTypeNames.Token).Set("linear")

        # Connect texture to appropriate input
        # Handle both legacy names (bc_texture) and new template names (base color)
        is_base_color = input_name_lower in ['bc_texture', 'base color', 'base_color']
        is_emissive = input_name_lower in ['e_texture', 'emissive texture', 'emissive_texture', 'emissive']
        is_normal = input_name_lower in ['n_texture', 'normal', 'normal_texture']

        if is_base_color:
            pbr_shader.CreateInput("diffuseColor", Sdf.ValueTypeNames.Color3f).ConnectToSource(texture_node.ConnectableAPI(), "rgb")

            # For Unlit Blend and Unlit Masked materials, also export opacity from alpha channel
            material_format = material.mhs.material_format if material.mhs else 'NONE'
            if material_format in ['UNLIT_BLEND', 'UNLIT_MASKED']:
                pbr_shader.CreateInput("opacity", Sdf.ValueTypeNames.Float).ConnectToSource(texture_node.ConnectableAPI(), "a")
                debug_log(f"Exported opacity channel for {material_format} material", LogCategory.MATERIAL_SETUP)

        elif is_mro:
            pbr_shader.CreateInput("metallic", Sdf.ValueTypeNames.Float).ConnectToSource(texture_node.ConnectableAPI(), "r")
            pbr_shader.CreateInput("roughness", Sdf.ValueTypeNames.Float).ConnectToSource(texture_node.ConnectableAPI(), "g")
            pbr_shader.CreateInput("occlusion", Sdf.ValueTypeNames.Float).ConnectToSource(texture_node.ConnectableAPI(), "b")
        elif is_normal:
            pbr_shader.CreateInput("normal", Sdf.ValueTypeNames.Normal3f).ConnectToSource(texture_node.ConnectableAPI(), "rgb")
        elif is_emissive:
            pbr_shader.CreateInput("emissiveColor", Sdf.ValueTypeNames.Color3f).ConnectToSource(texture_node.ConnectableAPI(), "rgb")

        # Set wrap modes
        texture_node.CreateInput("wrapS", Sdf.ValueTypeNames.Token).Set(material.mhs.texture_wrap_s)
        texture_node.CreateInput("wrapT", Sdf.ValueTypeNames.Token).Set(material.mhs.texture_wrap_t)


def process_value_node(pbr_shader, input_name, source_socket):
    socket_value = get_socket_value(source_socket)

    # Map Blender input names to USD standard names
    # USD attribute names cannot contain spaces and must be valid identifiers
    input_name_lower = input_name.lower()
    usd_input_map = {
        "color": "diffuseColor",
        "base color": "diffuseColor",
        "basecolor": "diffuseColor",
        "diffuse": "diffuseColor",
        "roughness": "roughness",
        "metalness": "metallic",
        "metallic": "metallic",
        "normal": "normal",
        "emissive": "emissiveColor",
        "emissive color": "emissiveColor",
        "opacity": "opacity",
        "alpha": "opacity",
        "occlusion": "occlusion",
        "ao": "occlusion",
    }

    usd_input_name = usd_input_map.get(input_name_lower, input_name.replace(" ", ""))

    if isinstance(socket_value, float):
        pbr_shader.CreateInput(usd_input_name, Sdf.ValueTypeNames.Float).Set(socket_value)
    elif isinstance(socket_value, (tuple, list)):
        if len(socket_value) == 3:
            pbr_shader.CreateInput(usd_input_name, Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*socket_value))
        elif len(socket_value) == 4:
            # For diffuseColor, use only RGB components (ignore alpha)
            if usd_input_name == "diffuseColor":
                pbr_shader.CreateInput(usd_input_name, Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(socket_value[0], socket_value[1], socket_value[2]))
                # If there's an alpha component and it's not 1.0, create opacity input
                if socket_value[3] != 1.0:
                    pbr_shader.CreateInput("opacity", Sdf.ValueTypeNames.Float).Set(socket_value[3])
            else:
                # For other attributes, use the full 4-component vector
                pbr_shader.CreateInput(usd_input_name, Sdf.ValueTypeNames.Color4f).Set(Gf.Vec4f(*socket_value))

def get_socket_value(socket):
    """Helper function to get the actual value from a socket."""
    if socket.type == 'RGBA':
        return tuple(socket.default_value)
    elif socket.type in ['VALUE', 'INT']:
        return socket.default_value
    elif socket.type == 'VECTOR':
        return tuple(socket.default_value)
    return None

def export_texture(texture, suffix, layout_name=None):
    from . import cache_tracker

    if not texture.filepath:
        return None

    # Get the project path from the scene properties
    scene = bpy.context.scene
    project_path = scene.mhs.project_path

    # Get the original filename and extension
    original_filename = texture.name
    name, ext = os.path.splitext(original_filename)
    ext = ".png"

    name = name.rsplit('_', 1)[0]

    # Generate a filename for the texture with the correct extension
    texture_filename = f"{name}_{suffix}{ext}"

    # Use custom folder path with {layout} support
    textures_folder = scene.mhs.textures_folder
    textures_dir = resolve_folder_path(project_path, textures_folder, layout_name)
    os.makedirs(textures_dir, exist_ok=True)

    texture_path = os.path.join(textures_dir, texture_filename)
    
    # Resolve source path early so we can use it for session tracking
    source_path = bpy.path.abspath(texture.filepath)

    # Check if this texture was already exported in this session
    # This prevents duplicate exports AND duplicate skip recordings
    # when multiple meshes share the same texture
    # Pass source_path to detect mid-session texture modifications
    if cache_tracker.is_texture_exported_this_session(texture_path, source_path):
        debug_log(f"Texture '{texture_filename}' already exported this session, skipping", LogCategory.CACHE_HIT)
        # Don't record_skip here - we only want to count unique textures, not every attempt
        return texture_path.replace(os.sep, '/')

    # Check if force rebuild is enabled
    force_rebuild = cache_tracker.get_force_rebuild_session()

    # If the texture doesn't exist in the textures directory, copy it there
    needs_copy = not os.path.exists(texture_path) or force_rebuild
    
    # Get source mtime for cache tracking
    source_mtime = 0.0
    if os.path.exists(source_path):
        try:
            source_mtime = os.path.getmtime(source_path)
        except OSError:
            pass

    if not needs_copy:
        # Check if source texture is newer than destination
        if os.path.exists(source_path) and source_mtime > 0:
            dest_mtime = os.path.getmtime(texture_path)
            if source_mtime > dest_mtime:
                needs_copy = True

    if needs_copy:
        if os.path.exists(source_path):
            try:
                # If destination exists and we're force rebuilding, try to remove read-only flag
                if os.path.exists(texture_path):
                    try:
                        import stat
                        os.chmod(texture_path, stat.S_IWRITE | stat.S_IREAD)
                    except (OSError, PermissionError) as chmod_err:
                        debug_log(f"Warning - Could not modify permissions on '{texture_filename}': {chmod_err}", LogCategory.EXPORT_MESH)

                shutil.copy2(source_path, texture_path)
                cache_tracker.mark_texture_exported(texture_path, source_mtime)
                cache_tracker.record_export('texture', texture_path)
            except PermissionError as e:
                # File is locked - check if it's the same content, if so we can skip safely
                debug_log(f"Warning - Permission denied writing '{texture_filename}', file may be in use", LogCategory.EXPORT_MESH)
                if os.path.exists(texture_path):
                    # File exists, mark as exported this session to avoid repeated failures
                    debug_log(f"Using existing texture file '{texture_filename}'", LogCategory.EXPORT_MESH)
                    cache_tracker.mark_texture_exported(texture_path, source_mtime)
                    cache_tracker.record_skip('texture', texture_path, estimated_write_time=0.05)
                else:
                    # File doesn't exist and we can't create it - this is a real error
                    raise
        else:
            debug_log(f"Warning - Source texture not found: {source_path}", LogCategory.EXPORT_MESH)
    else:
        # Texture already exists and is up-to-date (cache hit)
        cache_tracker.mark_texture_exported(texture_path, source_mtime)
        cache_tracker.record_skip('texture', texture_path, estimated_write_time=0.05)

    return texture_path.replace(os.sep, '/')


def export_vertex_color(obj, mesh, mesh_data):
    # Automatically export vertex colors if the mesh has color attributes
    # This detects if the data exists rather than relying on a user toggle
    if mesh_data.color_attributes:
        # Try to find a valid color attribute - first try active, then search all
        color_attribute = None

        # First, try the active color attribute
        if mesh_data.color_attributes.active and \
           mesh_data.color_attributes.active.data_type in ['BYTE_COLOR', 'FLOAT_COLOR']:
            color_attribute = mesh_data.color_attributes.active
        else:
            # If no active color or not a valid color type, search through all attributes
            for attr in mesh_data.color_attributes:
                if attr.data_type in ['BYTE_COLOR', 'FLOAT_COLOR']:
                    color_attribute = attr
                    break

        if color_attribute:
            # === Phase 5: Bulk extract vertex colors using numpy foreach_get ===
            data_len = len(color_attribute.data)

            # Bulk extract RGBA colors
            colors_flat = np.zeros(data_len * 4, dtype=np.float32)
            color_attribute.data.foreach_get('color', colors_flat)
            colors = colors_flat.reshape(-1, 4)

            # Split RGB and Alpha - use VtVec3fArray.FromNumpy for display colors
            rgb_colors = colors[:, :3].copy()  # Get RGB columns (need copy for contiguous array)
            display_colors = Vt.Vec3fArray.FromNumpy(rgb_colors.astype(np.float32))
            display_opacities = colors[:, 3].tolist()

            if color_attribute.domain == 'POINT':
                interpolation = UsdGeom.Tokens.vertex
            elif color_attribute.domain == 'CORNER':
                interpolation = UsdGeom.Tokens.faceVarying
            else:
                debug_log(f"Unsupported color attribute domain: {color_attribute.domain}", LogCategory.EXPORT_MESH)
                return

            primvars_api = UsdGeom.PrimvarsAPI(mesh)
            color_primvar = primvars_api.CreatePrimvar("displayColor", Sdf.ValueTypeNames.Color3fArray, interpolation)
            color_primvar.Set(display_colors)

            opacity_primvar = primvars_api.CreatePrimvar("displayOpacity", Sdf.ValueTypeNames.FloatArray, interpolation)
            opacity_primvar.Set(display_opacities)


def get_mesh_data_key(obj):
    """
    Generate a unique key for mesh data to identify instances.
    Objects sharing the same mesh data (instances) will have the same key.
    This also considers modifiers that affect the mesh geometry.

    Args:
        obj: Blender object to generate key for

    Returns:
        str: Unique key for the mesh data including modifiers
    """
    if obj.type != 'MESH':
        return None

    # Start with the mesh data pointer/name as the base
    mesh_data_key_parts = [obj.data.name]

    # Add material information - automatically include if object has material slots
    if obj.material_slots:
        material_names = []
        for slot in obj.material_slots:
            if slot.material:
                material_names.append(slot.material.name)
            else:
                material_names.append("None")
        mesh_data_key_parts.append("Materials:" + "|".join(material_names))

    # Add modifier information if the object has visible modifiers
    # This automatically includes modifiers in the mesh key if they exist
    if has_visible_modifiers(obj):
        modifier_info = []
        for modifier in obj.modifiers:
            if modifier.show_viewport:
                # Create a simple string representation of the modifier
                modifier_info.append(f"{modifier.type}:{modifier.name}")
        if modifier_info:
            mesh_data_key_parts.append("Modifiers:" + "|".join(modifier_info))

    # Additional considerations that affect mesh geometry
    export_settings = []
    if hasattr(obj, 'mhs'):
        if obj.mhs.export_lightmap:
            export_settings.append("lightmap")
        # Check if vertex colors exist in the mesh data
        if obj.data and hasattr(obj.data, 'color_attributes') and obj.data.color_attributes:
            export_settings.append("vertex_color")

    if export_settings:
        mesh_data_key_parts.append("Settings:" + "|".join(export_settings))

    # Create the final key by joining all parts
    full_key = "#".join(mesh_data_key_parts)

    # Use a hash for shorter, more consistent keys
    return hashlib.md5(full_key.encode('utf-8')).hexdigest()

def get_collection_hierarchy(collection):
    """
    Get collection and all its descendant collections recursively.

    Args:
        collection: Blender collection

    Returns:
        set: Set of collections including the input and all descendants
    """
    collections = {collection}

    for child in collection.children:
        collections.update(get_collection_hierarchy(child))

    return collections


def is_animated_asset(obj):
    """
    Check if object is an animated asset that should be filtered from layout exports.
    Animated assets should be exported as separate asset files, not included in layouts.

    Args:
        obj: Blender object to check

    Returns:
        bool: True if object is an animated asset, False otherwise
    """
    has_animation_export = hasattr(obj, 'mhs') and obj.mhs.export_animations

    has_armature = False
    if obj.type == 'MESH':
        for modifier in obj.modifiers:
            if modifier.type == 'ARMATURE' and modifier.object:
                has_armature = True
                break

    return has_animation_export and has_armature


def get_layout_export_objects(context, layout_config):
    """
    Get all objects to export for a specific layout configuration.

    Args:
        context: Blender context
        layout_config: LayoutExportConfig PropertyGroup

    Returns:
        tuple: (objects_to_export, animated_objects_filtered, geometry_nodes_filtered, layout_collections)
            - objects_to_export: List of objects to include in export
            - animated_objects_filtered: List of animated objects that were filtered out
            - geometry_nodes_filtered: List of geometry nodes objects that were filtered out
            - layout_collections: List of collections that define this layout (for cache hashing)
    """
    all_collections = set()

    for coll_ref in layout_config.collections:
        if coll_ref.collection:
            all_collections.update(get_collection_hierarchy(coll_ref.collection))

    all_objects = set()
    for collection in all_collections:
        for obj in collection.objects:
            all_objects.add(obj)

    objects_to_export = []
    animated_objects_filtered = []
    geometry_nodes_filtered = []

    for obj in all_objects:
        # Always filter animated assets - they don't work in layouts and should be separate asset files
        if is_animated_asset(obj):
            animated_objects_filtered.append(obj)
        # Filter geometry nodes objects - not currently supported in layout exports
        elif has_geometry_nodes_modifier(obj):
            geometry_nodes_filtered.append(obj)
        else:
            objects_to_export.append(obj)

    # Return layout collections for cache hashing (used to detect collection hierarchy changes)
    layout_collections = [coll_ref.collection for coll_ref in layout_config.collections if coll_ref.collection]

    return objects_to_export, animated_objects_filtered, geometry_nodes_filtered, layout_collections


def write_layout_usda_single(context, layout_config, force_rebuild=False):
    """
    Export a single layout configuration.

    Args:
        context: Blender context
        layout_config: LayoutExportConfig to export
        force_rebuild: If True, ignore cache and re-export all files

    Returns:
        dict: {'FINISHED'} or {'CANCELLED'}
    """
    from . import cache_tracker

    project_path = context.scene.mhs.project_path
    if not project_path:
        raise ValueError("Project path is not set")

    scene = context.scene
    layout_name = layout_config.name

    # Ensure all folders are created (including layout-specific ones)
    create_project_folders(project_path)
    ensure_layout_folders(project_path, scene, layout_name)

    # Use custom folder path for layout file
    layouts_folder = resolve_folder_path(project_path, scene.mhs.layouts_folder, layout_name)
    layout_file_path = os.path.join(layouts_folder, f"{layout_name}.usda")

    objects_to_export, animated_objects_filtered, geometry_nodes_filtered, layout_collections = get_layout_export_objects(context, layout_config)

    if not objects_to_export:
        debug_log(f"No objects to export for layout '{layout_config.name}'", LogCategory.EXPORT_LAYOUT)
        return {'CANCELLED'}

    if animated_objects_filtered:
        animated_names = [obj.name for obj in animated_objects_filtered]
        debug_log(f"WARNING - Filtered {len(animated_objects_filtered)} animated assets from layout '{layout_config.name}':", LogCategory.EXPORT_LAYOUT)
        debug_log(f"  Animated assets (not exported in layout): {', '.join(animated_names)}", LogCategory.EXPORT_LAYOUT)
        debug_log(f"  These objects should be exported as separate animated asset files.", LogCategory.EXPORT_LAYOUT)

    if geometry_nodes_filtered:
        geonode_names = [obj.name for obj in geometry_nodes_filtered]
        debug_log(f"WARNING - Filtered {len(geometry_nodes_filtered)} geometry nodes objects from layout '{layout_config.name}':", LogCategory.EXPORT_LAYOUT)
        debug_log(f"  Geometry nodes objects (not exported): {', '.join(geonode_names)}", LogCategory.EXPORT_LAYOUT)
        debug_log(f"  Geometry nodes export is not currently supported and will be added in a future update.", LogCategory.EXPORT_LAYOUT)

    # Compute layout hash for cache checking (includes collection hierarchy for change detection)
    cache = cache_tracker.get_cache()
    layout_hash = cache_tracker.compute_layout_hash(objects_to_export, layout_collections=layout_collections)

    # Check if we can skip layout export (not force rebuild and hash matches)
    if not force_rebuild and not cache.should_export(layout_file_path, layout_hash):
        debug_log(f"Skipping unchanged layout '{layout_file_path}'", LogCategory.CACHE_HIT)
        cache_tracker.record_skip('layout', layout_file_path, estimated_write_time=0.2)

        # When layout is cached, also record the nested items (meshes, materials, textures)
        # that were implicitly cached. This provides accurate statistics.
        unique_meshes = set()
        unique_materials = set()
        unique_textures = set()

        for obj in objects_to_export:
            if obj.type == 'MESH':
                mesh_key = get_mesh_data_key(obj)
                if mesh_key:
                    unique_meshes.add(mesh_key)

                # Count unique materials
                for slot in obj.material_slots:
                    if slot.material:
                        unique_materials.add(slot.material.name)

                        # Count unique textures from materials
                        if slot.material.use_nodes and slot.material.node_tree:
                            for node in slot.material.node_tree.nodes:
                                if node.type == 'TEX_IMAGE' and node.image and node.image.filepath:
                                    unique_textures.add(node.image.filepath)

        # Record implicit cache hits for nested items
        for _ in unique_meshes:
            cache_tracker.record_skip('mesh', '', estimated_write_time=0.1)
        for _ in unique_materials:
            cache_tracker.record_skip('material', '', estimated_write_time=0.05)
        for _ in unique_textures:
            cache_tracker.record_skip('texture', '', estimated_write_time=0.05)

        debug_log(f"  (Layout cache includes: {len(unique_meshes)} meshes, {len(unique_materials)} materials, {len(unique_textures)} textures)", LogCategory.CACHE_HIT)

        return {'FINISHED'}

    # NOTE: Auto-export of shaders (.surface files) and materialMap updates is disabled.
    # This feature will be extended and re-enabled in a future update.
    # For now, shaders should be exported manually via the dedicated shader export tools.
    #
    # try:
    #     from .material_map import auto_export_materials_for_layout
    #     auto_result = auto_export_materials_for_layout(context, objects_to_export)
    #     if 'error' not in auto_result:
    #         if auto_result.get('shaders_exported'):
    #             debug_log(f"Auto-generated {len(auto_result['shaders_exported'])} shader files", LogCategory.SHADER_GENERATE)
    #         if auto_result.get('material_map_updated'):
    #             debug_log(f"Updated materialMap.json with new material entries", LogCategory.MATERIALMAP_EXPORT)
    #         if auto_result.get('shaders_skipped'):
    #             debug_log(f"Skipped {len(auto_result['shaders_skipped'])} existing shader files (use manual export to overwrite)", LogCategory.SHADER_GENERATE)
    # except Exception as e:
    #     debug_log(f"Warning - Material auto-export failed: {e}", LogCategory.MATERIALMAP_EXPORT)
    #     import traceback
    #     traceback.print_exc()

    collection_names = [coll_ref.collection.name for coll_ref in layout_config.collections if coll_ref.collection]
    debug_log(f"Exporting layout '{layout_config.name}' with {len(collection_names)} root collections:", LogCategory.EXPORT_LAYOUT)
    debug_log(f"  Collections: {', '.join(collection_names)}", LogCategory.EXPORT_LAYOUT)
    debug_log(f"  Total objects to export: {len(objects_to_export)}", LogCategory.EXPORT_LAYOUT)

    stage = Usd.Stage.CreateNew(layout_file_path)
    UsdGeom.SetStageMetersPerUnit(stage, 1)
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.y)
    set_stage_custom_layer_data(stage)
    debug_log(f"Layout using Y-up axis (engine standard)", LogCategory.EXPORT_LAYOUT)

    # Create root level empty transform to contain all scene objects
    # Use sanitized layout name as the root prim name
    root_prim_name = sanitize_name(layout_config.name)
    root_prim_path = f"/{root_prim_name}"
    root_xform = UsdGeom.Xform.Define(stage, root_prim_path)
    stage.SetDefaultPrim(root_xform.GetPrim())
    debug_log(f" Created root transform '{root_prim_path}' for layout")

    exported_meshes = {}
    mesh_instances = {}

    # NOTE: Geometry nodes data collection is disabled for this release.
    # Geometry nodes objects are filtered out in get_layout_export_objects().
    # This feature will be extended and re-enabled in a future update.
    # geometry_nodes_data = {}

    # Sort objects so parents come before children
    # This ensures deterministic mesh file naming (parent's name is used for shared mesh data)
    def get_hierarchy_depth(obj):
        """Calculate depth in parent hierarchy (0 for root, 1 for first level child, etc.)"""
        depth = 0
        current = obj
        while current.parent:
            depth += 1
            current = current.parent
        return depth

    # Sort by hierarchy depth (parents first), then by name for deterministic ordering
    objects_to_export_sorted = sorted(objects_to_export, key=lambda o: (get_hierarchy_depth(o), o.name))
    debug_log(f" Sorted {len(objects_to_export_sorted)} objects for deterministic mesh naming")

    for obj in objects_to_export_sorted:
        # NOTE: Geometry nodes processing is disabled for this release.
        # Geometry nodes objects are filtered out in get_layout_export_objects().
        # This code block is preserved for re-enabling in a future update.
        #
        # if has_geometry_nodes_modifier(obj):
        #     debug_log(f" Object '{obj.name}' has geometry nodes modifier")
        #     geo_nodes_result = extract_geometry_nodes_instances(context, obj)
        #     ... (geometry nodes processing code)
        #     continue

        if obj.type == 'MESH':
            mesh_data_key = get_mesh_data_key(obj)

            if mesh_data_key not in exported_meshes:
                mesh_file_name = f"{sanitize_name(obj.name)}.usda"
                mesh_file_path = os.path.join(project_path, 'meshes', mesh_file_name)
                exported_meshes[mesh_data_key] = mesh_file_path
                mesh_instances[mesh_data_key] = []

            mesh_instances[mesh_data_key].append(obj)

    total_meshes_exported = 0
    total_instances_created = 0
    total_geometry_nodes_instances = 0

    for mesh_data_key, mesh_file_path in exported_meshes.items():
        instances = mesh_instances[mesh_data_key]
        representative_obj = instances[0]

        debug_log(f" Exporting mesh '{representative_obj.name}' (type: {representative_obj.type}) to {mesh_file_path}")

        armature_check = get_armature_for_mesh(representative_obj)
        debug_log(f" Representative object '{representative_obj.name}' armature check: {armature_check.name if armature_check else 'None'}")
        debug_log(f" Representative object has mhs properties: {hasattr(representative_obj, 'mhs')}")
        if hasattr(representative_obj, 'mhs'):
            debug_log(f" export_animations setting: {representative_obj.mhs.export_animations}")

        if not representative_obj or representative_obj.type != 'MESH':
            debug_log(f" Error - Invalid representative object '{representative_obj.name}' (type: {representative_obj.type})")
            continue

        if not representative_obj.data:
            debug_log(f" Error - Representative object '{representative_obj.name}' has no mesh data")
            continue

        if not hasattr(representative_obj.data, 'vertices') or len(representative_obj.data.vertices) == 0:
            debug_log(f" Error - Representative object '{representative_obj.name}' has no vertices")
            continue

        try:
            write_usda(context, mesh_file_path, objects=[representative_obj], force_rebuild=force_rebuild)
            total_meshes_exported += 1
            debug_log(f" Successfully exported mesh '{representative_obj.name}'")

            layout_dir = os.path.dirname(layout_file_path)
            relative_mesh_path = os.path.relpath(mesh_file_path, layout_dir)
            relative_mesh_path = relative_mesh_path.replace(os.sep, '/')
            exported_meshes[mesh_data_key] = relative_mesh_path
        except Exception as e:
            debug_log(f" Failed to export mesh '{representative_obj.name}': {str(e)}")
            import traceback
            traceback.print_exc()
            continue

        if len(instances) > 1:
            mesh_names = [obj.name for obj in instances]
            debug_log(f" Creating {len(instances)} instances of mesh '{representative_obj.data.name}' for objects: {', '.join(mesh_names)}")

        for obj in instances:
            is_geometry_nodes_source = (
                (hasattr(obj, '_geometry_nodes_source') and obj._geometry_nodes_source) or
                (hasattr(bpy.types.Scene, '_geometry_nodes_source_objects') and
                 obj.name in bpy.types.Scene._geometry_nodes_source_objects)
            )

            if is_geometry_nodes_source:
                debug_log(f" Skipping geometry-nodes-source object '{obj.name}' from layout")
                continue

            parent_path_in_layout = get_full_parent_path(obj, objects_to_export)

            obj_sanitized_name = sanitize_name(obj.name)
            # All objects are now under the root transform
            if parent_path_in_layout == "/":
                instance_prim_path = f"{root_prim_path}/{obj_sanitized_name}"
            else:
                # Parent path needs to be prefixed with root prim path
                instance_prim_path = f"{root_prim_path}{parent_path_in_layout}/{obj_sanitized_name}"

            # Create parent xform hierarchy under root if needed
            full_parent_path = f"{root_prim_path}{parent_path_in_layout}" if parent_path_in_layout != "/" else root_prim_path
            if parent_path_in_layout != "/" and not stage.GetPrimAtPath(full_parent_path).IsValid():
                # Need to create any missing parent prims in the hierarchy
                # Split the path and create each level if missing
                path_parts = parent_path_in_layout.strip("/").split("/")
                current_path = root_prim_path
                for part in path_parts:
                    current_path = f"{current_path}/{part}"
                    if not stage.GetPrimAtPath(current_path).IsValid():
                        debug_log(f" Creating parent Xform at '{current_path}' for child '{obj.name}'")
                        UsdGeom.Xform.Define(stage, current_path)

            xform = UsdGeom.Xform.Define(stage, instance_prim_path)
            xformable = UsdGeom.Xformable(xform)

            # Compute transform relative to parent in the export hierarchy
            # For nested hierarchies, we need: child_local = parent_world.inverted() @ child_world
            # This ensures proper relative transforms for USD composition
            if obj.parent and obj.parent in objects_to_export:
                # Compute local transform relative to parent using matrix inversion
                # This handles all cases including non-uniform scales and complex transforms
                blender_matrix = obj.parent.matrix_world.inverted() @ obj.matrix_world
                debug_log(f" Using computed relative transform for child '{obj.name}' relative to parent '{obj.parent.name}'")
            else:
                # Root object or parent not in export - use world transform
                blender_matrix = obj.matrix_world
                debug_log(f" Using world transform for root object '{obj.name}'")

            m = blender_matrix

            tx, ty, tz = m[0][3], m[1][3], m[2][3]

            import mathutils

            conversion = mathutils.Matrix((
                (1,  0,  0, 0),
                (0,  0,  1, 0),
                (0, -1,  0, 0),
                (0,  0,  0, 1)
            ))

            converted_matrix = conversion @ blender_matrix @ conversion.inverted()

            usd_matrix = Gf.Matrix4d(*converted_matrix.transposed())
            xformable.AddTransformOp().Set(usd_matrix)
            debug_log(f" Layout instance '{obj.name}' - Blender position ({tx:.3f}, {ty:.3f}, {tz:.3f}) → USD ({tx:.3f}, {tz:.3f}, {-ty:.3f})")

            mesh_data_name = sanitize_name(representative_obj.name)
            relative_mesh_path = exported_meshes[mesh_data_key]
            xform.GetPrim().GetReferences().AddReference(relative_mesh_path, f"/{mesh_data_name}")
            total_instances_created += 1

    # NOTE: Geometry nodes PointInstancer export is disabled for this release.
    # Geometry nodes objects are filtered out in get_layout_export_objects().
    # This feature will be extended and re-enabled in a future update.
    #
    # for obj, geo_nodes_result in geometry_nodes_data.items():
    #     instances = geo_nodes_result['instances']
    #     source_meshes = geo_nodes_result['source_meshes']
    #     point_instancer_data = geo_nodes_result.get('point_instancer_data')
    #     ... (PointInstancer export code)

    total_filtered_objects = len([obj for obj in objects_to_export if obj.type == 'MESH'])
    # geometry_nodes_data is disabled, so set to 0
    total_geometry_nodes_objects = 0

    debug_log(f"Export Summary: Exported {total_meshes_exported} unique meshes for {total_filtered_objects} mesh objects ({total_instances_created} instances created)", LogCategory.EXPORT_MESH)

    if total_geometry_nodes_objects > 0:
        debug_log(f"  Geometry Nodes: Processed {total_geometry_nodes_objects} objects with geometry nodes ({total_geometry_nodes_instances} geometry nodes instances created)", LogCategory.GEOMNODES_INSTANCES)

    export_lightmaps(context, stage, project_path)

    stage.Save()

    # Update cache after successful layout export
    cache.set_file_hash(layout_file_path, layout_hash, {
        "instance_count": len(objects_to_export)
    })
    cache_tracker.record_export('layout', layout_file_path)

    return {'FINISHED'}

def has_visible_modifiers(obj):
    """
    Check if the object has any modifiers with viewport visibility enabled.

    Args:
        obj: Blender object to check

    Returns:
        bool: True if object has visible modifiers, False otherwise
    """
    if not hasattr(obj, 'modifiers') or not obj.modifiers:
        return False

    # Check if any modifier is visible in viewport
    for modifier in obj.modifiers:
        if modifier.show_viewport:
            return True

    return False

def has_geometry_nodes_modifier(obj):
    """
    Check if the object has a visible Geometry Nodes modifier.

    Args:
        obj: Blender object to check

    Returns:
        bool: True if object has visible Geometry Nodes modifier, False otherwise
    """
    if not hasattr(obj, 'modifiers') or not obj.modifiers:
        return False

    # Check for Geometry Nodes modifiers with viewport visibility
    for modifier in obj.modifiers:
        if modifier.type == 'NODES' and modifier.show_viewport:
            return True

    return False

def extract_geometry_nodes_instances(context, obj):
    """
    Extract instance data from objects with Geometry Nodes modifiers using the
    Blender 4.x evaluated_geometry() API.

    This provides proper access to:
    - Instance transforms (4x4 matrices)
    - Reference indices (which prototype each instance uses)
    - Custom attributes on instances (exported as USD primvars)
    - Source mesh references

    Args:
        context: Blender context
        obj: Object with Geometry Nodes modifier

    Returns:
        dict: Dictionary containing instance data with structure:
        {
            'instances': [list of instance data dicts],
            'source_meshes': [list of source mesh objects found],
            'use_point_instancer': bool - True if PointInstancer should be used,
            'point_instancer_data': dict - Data from get_geonode_instance_data()
        }
    """
    if not has_geometry_nodes_modifier(obj):
        return {'instances': [], 'source_meshes': [], 'use_point_instancer': False, 'point_instancer_data': None}

    debug_log(f" Analyzing geometry nodes on object '{obj.name}'", LogCategory.GEOMNODES_INSTANCES)

    depsgraph = context.evaluated_depsgraph_get()
    instances = []
    source_meshes = set()

    # Also check node tree for additional source objects (collections, object inputs)
    source_objects = find_geometry_nodes_source_objects(obj)
    source_meshes.update(source_objects)
    debug_log(f" Found {len(source_objects)} source objects in node tree: {[o.name for o in source_objects]}", LogCategory.GEOMNODES_INSTANCES)

    # Use Blender 4.x evaluated_geometry() API
    geonode_data = get_geonode_instance_data(obj, depsgraph)

    if not geonode_data or geonode_data['count'] == 0:
        debug_log(f" No instances found via evaluated_geometry() API for '{obj.name}'", LogCategory.GEOMNODES_INSTANCES)
        return {
            'instances': [],
            'source_meshes': list(source_meshes),
            'use_point_instancer': False,
            'point_instancer_data': None
        }

    debug_log(f" Extracted {geonode_data['count']} instances via evaluated_geometry() API", LogCategory.GEOMNODES_INSTANCES)
    debug_log(f" Custom attributes: {list(geonode_data['custom_attrs'].keys())}", LogCategory.GEOMNODES_INSTANCES)

    # Process references to find source meshes
    references = geonode_data['references']
    for i, ref in enumerate(references):
        if hasattr(ref, 'mesh') and ref.mesh:
            mesh_data_name = ref.mesh.name
            debug_log(f"   Reference[{i}] mesh data: '{mesh_data_name}'", LogCategory.GEOMNODES_INSTANCES)

            # Find the original object with this mesh data
            for scene_obj in bpy.data.objects:
                if (scene_obj.type == 'MESH' and
                    scene_obj.data and
                    scene_obj.data.name == mesh_data_name):
                    source_meshes.add(scene_obj)
                    debug_log(f"   -> Found source object '{scene_obj.name}'", LogCategory.GEOMNODES_INSTANCES)
                    break

    # Build legacy-format instance list for compatibility with existing layout export code
    # This allows gradual migration to PointInstancer
    transforms = geonode_data['transforms']
    ref_indices = geonode_data['ref_indices']

    import mathutils

    for i in range(geonode_data['count']):
        ref_idx = ref_indices[i]
        ref = references[ref_idx] if ref_idx < len(references) else None

        # Find the source object for this reference
        source_obj = None
        mesh_data_name = None
        if ref and hasattr(ref, 'mesh') and ref.mesh:
            mesh_data_name = ref.mesh.name
            for scene_obj in bpy.data.objects:
                if (scene_obj.type == 'MESH' and
                    scene_obj.data and
                    scene_obj.data.name == mesh_data_name):
                    source_obj = scene_obj
                    break

        # Convert numpy transform to mathutils.Matrix
        np_mat = transforms[i]
        bl_mat = mathutils.Matrix((
            (np_mat[0][0], np_mat[0][1], np_mat[0][2], np_mat[0][3]),
            (np_mat[1][0], np_mat[1][1], np_mat[1][2], np_mat[1][3]),
            (np_mat[2][0], np_mat[2][1], np_mat[2][2], np_mat[2][3]),
            (np_mat[3][0], np_mat[3][1], np_mat[3][2], np_mat[3][3]),
        ))

        instance_data = {
            'object': source_obj,
            'matrix': bl_mat,
            'original_object': obj,
            'instance_index': i,
            'mesh_data_name': mesh_data_name,
            'reference_index': ref_idx
        }
        instances.append(instance_data)

    debug_log(f" Final result for '{obj.name}': {len(instances)} instances, {len(source_meshes)} source meshes", LogCategory.GEOMNODES_INSTANCES)

    return {
        'instances': instances,
        'source_meshes': list(source_meshes),
        'use_point_instancer': True,
        'point_instancer_data': geonode_data
    }

def find_source_mesh_from_instance(instance_obj):
    """
    Try to find the original source mesh object from an instance.

    Args:
        instance_obj: The instanced object

    Returns:
        Object: The original source object if found, None otherwise
    """
    # For now, return the instance object itself
    # This could be enhanced to trace back to original source objects
    return instance_obj

def find_geometry_nodes_source_objects(obj):
    """
    Find source mesh objects referenced in Geometry Nodes modifiers.

    Args:
        obj: Object with Geometry Nodes modifier

    Returns:
        set: Set of source mesh objects found in the node tree
    """
    source_objects = set()

    try:
        for modifier in obj.modifiers:
            if modifier.type == 'NODES' and modifier.show_viewport and modifier.node_group:
                debug_log(f" Checking geometry nodes modifier '{modifier.name}' with node group '{modifier.node_group.name}'")

                # Traverse the node tree to find object and collection inputs
                node_tree = modifier.node_group
                source_objects.update(_traverse_node_tree_for_objects(node_tree))

                # Check modifier interface inputs (the new way in Blender 4.x)
                if hasattr(modifier, 'node_group') and modifier.node_group:
                    for input in modifier.node_group.interface.items_tree:
                        if input.item_type == 'SOCKET' and input.in_out == 'INPUT':
                            # Check if this is an object input
                            if hasattr(input, 'socket_type') and 'Object' in input.socket_type:
                                input_id = input.identifier
                                if input_id in modifier:
                                    input_value = modifier[input_id]
                                    if input_value and hasattr(input_value, 'type') and input_value.type == 'MESH':
                                        source_objects.add(input_value)
                                        debug_log(f" Found object input '{input.name}': {input_value.name}")

                # Also check modifier keys directly (older method, still useful as fallback)
                for input_name in modifier.keys():
                    try:
                        input_value = modifier[input_name]
                        if hasattr(input_value, 'type') and input_value.type == 'MESH':
                            source_objects.add(input_value)
                            debug_log(f" Found object via modifier key '{input_name}': {input_value.name}")
                        elif hasattr(input_value, 'objects'):  # Collection
                            for coll_obj in input_value.objects:
                                if coll_obj.type == 'MESH':
                                    source_objects.add(coll_obj)
                                    debug_log(f" Found object via collection '{input_name}': {coll_obj.name}")
                    except Exception as e:
                        debug_log(f" Error accessing modifier input '{input_name}': {e}")
                        continue

    except Exception as e:
        debug_log(f"Error finding source objects for {obj.name}: {str(e)}")
        import traceback
        traceback.print_exc()

    return source_objects

def _traverse_node_tree_for_objects(node_tree, visited=None):
    """
    Recursively traverse a node tree to find object and collection references.

    Args:
        node_tree: The node tree to traverse
        visited: Set of already visited node trees (to prevent infinite recursion)

    Returns:
        set: Set of mesh objects found in the node tree
    """
    if visited is None:
        visited = set()

    if node_tree in visited:
        return set()

    visited.add(node_tree)
    objects = set()

    try:
        for node in node_tree.nodes:
            # Check for object input nodes
            if hasattr(node, 'object') and node.object and node.object.type == 'MESH':
                objects.add(node.object)

            # Check for collection input nodes
            if hasattr(node, 'collection') and node.collection:
                for obj in node.collection.objects:
                    if obj.type == 'MESH':
                        objects.add(obj)

            # Recursively check nested node groups
            if hasattr(node, 'node_tree') and node.node_tree:
                objects.update(_traverse_node_tree_for_objects(node.node_tree, visited))

    except Exception as e:
        debug_log(f"Error traversing node tree {node_tree.name}: {str(e)}")

    return objects


# =============================================================================
# Geometry Nodes Instance Export (Blender 4.x API)
# =============================================================================

def get_geonode_instance_data(obj, depsgraph):
    """
    Extract instance data from a geometry nodes object using the Blender 4.x
    evaluated_geometry() API. This provides access to instance transforms,
    reference indices, and custom attributes.

    Args:
        obj: Blender object with geometry nodes modifier
        depsgraph: Evaluated dependency graph

    Returns:
        dict: Instance data containing:
            - count: Number of instances
            - transforms: numpy array of 4x4 matrices
            - ref_indices: numpy array of reference indices
            - references: List of referenced geometries
            - custom_attrs: Dict of custom attribute data
            - has_mesh_output: True if geometry nodes also outputs mesh data
        Or None if no instances found
    """
    try:
        ob_eval = depsgraph.id_eval_get(obj)

        # Check if evaluated_geometry() method exists (Blender 4.x+)
        if not hasattr(ob_eval, 'evaluated_geometry'):
            debug_log(f"  evaluated_geometry() method not available for '{obj.name}'", LogCategory.GEOMNODES_INSTANCES)
            return None

        geometry = ob_eval.evaluated_geometry()

        if geometry is None:
            debug_log(f"  evaluated_geometry() returned None for '{obj.name}'", LogCategory.GEOMNODES_INSTANCES)
            return None

        # Check if instances_pointcloud method exists
        if not hasattr(geometry, 'instances_pointcloud'):
            debug_log(f"  instances_pointcloud() method not available for '{obj.name}'", LogCategory.GEOMNODES_INSTANCES)
            return None

        pc = geometry.instances_pointcloud()

        # Check if geometry nodes outputs mesh data (in addition to or instead of instances)
        has_mesh_output = False
        if hasattr(geometry, 'mesh') and geometry.mesh is not None:
            mesh = geometry.mesh
            if hasattr(mesh, 'vertices') and len(mesh.vertices) > 0:
                has_mesh_output = True
                debug_log(f"  Geometry has mesh output with {len(mesh.vertices)} vertices", LogCategory.GEOMNODES_INSTANCES)

        if pc is None:
            debug_log(f"  No instances_pointcloud for '{obj.name}' (has_mesh_output={has_mesh_output})", LogCategory.GEOMNODES_INSTANCES)
            # If there's mesh output but no instances, return a special marker
            if has_mesh_output:
                return {
                    'count': 0,
                    'transforms': np.array([], dtype=np.float32),
                    'ref_indices': np.array([], dtype=np.int32),
                    'references': [],
                    'custom_attrs': {},
                    'original_object': obj,
                    'has_mesh_output': True
                }
            return None

        # Check if 'position' attribute exists
        if 'position' not in pc.attributes:
            debug_log(f"  No 'position' attribute in instances_pointcloud for '{obj.name}'", LogCategory.GEOMNODES_INSTANCES)
            return None

        num_instances = len(pc.attributes['position'].data)
        if num_instances == 0:
            debug_log(f"  Zero instances in pointcloud for '{obj.name}' (has_mesh_output={has_mesh_output})", LogCategory.GEOMNODES_INSTANCES)
            if has_mesh_output:
                return {
                    'count': 0,
                    'transforms': np.array([], dtype=np.float32),
                    'ref_indices': np.array([], dtype=np.int32),
                    'references': [],
                    'custom_attrs': {},
                    'original_object': obj,
                    'has_mesh_output': True
                }
            return None

        debug_log(f"  Found {num_instances} instances via instances_pointcloud", LogCategory.GEOMNODES_INSTANCES)

        # Extract transforms (4x4 matrices)
        transform_attr = pc.attributes.get('instance_transform')
        if transform_attr:
            transforms = np.zeros(num_instances * 16, dtype=np.float32)
            transform_attr.data.foreach_get('value', transforms)
            transforms = transforms.reshape(-1, 4, 4)
        else:
            debug_log(f"  Warning: No instance_transform attribute found", LogCategory.GEOMNODES_INSTANCES)
            transforms = np.tile(np.eye(4, dtype=np.float32), (num_instances, 1, 1))

        # Extract reference indices
        ref_attr = pc.attributes.get('.reference_index')
        if ref_attr:
            ref_indices = np.zeros(num_instances, dtype=np.int32)
            ref_attr.data.foreach_get('value', ref_indices)
        else:
            debug_log(f"  Warning: No .reference_index attribute found", LogCategory.GEOMNODES_INSTANCES)
            ref_indices = np.zeros(num_instances, dtype=np.int32)

        # Get references (the actual instanced geometries)
        references = geometry.instance_references()
        debug_log(f"  Found {len(references)} unique prototype references", LogCategory.GEOMNODES_INSTANCES)

        # Extract custom attributes (non-builtin)
        builtin_attrs = {'.reference_index', 'instance_transform', 'position'}
        custom_attrs = {}

        for attr in pc.attributes:
            if attr.name not in builtin_attrs:
                attr_data = _extract_geonode_attribute(attr, num_instances)
                if attr_data is not None:
                    custom_attrs[attr.name] = attr_data
                    debug_log(f"    Custom attribute '{attr.name}': {attr_data['type']}", LogCategory.GEOMNODES_INSTANCES)

        return {
            'count': num_instances,
            'transforms': transforms,
            'ref_indices': ref_indices,
            'references': references,
            'custom_attrs': custom_attrs,
            'original_object': obj
        }

    except AttributeError as e:
        # This API may not be available in older Blender versions
        debug_log(f"  evaluated_geometry() API not available: {e}", LogCategory.GEOMNODES_INSTANCES)
        return None
    except Exception as e:
        debug_log(f"  Error extracting instance data from '{obj.name}': {e}", LogCategory.GEOMNODES_INSTANCES)
        import traceback
        traceback.print_exc()
        return None


def _extract_geonode_attribute(attr, count):
    """
    Extract attribute data based on its type.

    Args:
        attr: Blender attribute
        count: Number of elements

    Returns:
        dict: Attribute data with 'type' and 'data' keys, or None
    """
    try:
        data_type = attr.data_type

        if data_type == 'FLOAT':
            data = np.zeros(count, dtype=np.float32)
            attr.data.foreach_get('value', data)
            return {'type': 'float', 'data': data}

        elif data_type == 'INT':
            data = np.zeros(count, dtype=np.int32)
            attr.data.foreach_get('value', data)
            return {'type': 'int', 'data': data}

        elif data_type == 'FLOAT_VECTOR':
            data = np.zeros(count * 3, dtype=np.float32)
            attr.data.foreach_get('vector', data)
            return {'type': 'vector3', 'data': data.reshape(-1, 3)}

        elif data_type == 'FLOAT_COLOR':
            data = np.zeros(count * 4, dtype=np.float32)
            attr.data.foreach_get('color', data)
            return {'type': 'color', 'data': data.reshape(-1, 4)}

        elif data_type == 'QUATERNION':
            data = np.zeros(count * 4, dtype=np.float32)
            attr.data.foreach_get('value', data)
            return {'type': 'quat', 'data': data.reshape(-1, 4)}

        elif data_type == 'FLOAT4X4':
            data = np.zeros(count * 16, dtype=np.float32)
            attr.data.foreach_get('value', data)
            return {'type': 'matrix4', 'data': data.reshape(-1, 4, 4)}

        elif data_type == 'BOOLEAN':
            data = np.zeros(count, dtype=np.bool_)
            attr.data.foreach_get('value', data)
            return {'type': 'bool', 'data': data}

        else:
            debug_log(f"    Unsupported attribute type: {data_type}")
            return None

    except Exception as e:
        debug_log(f"    Error extracting attribute: {e}")
        return None


def export_point_instancer(stage, path, instance_data, prototype_paths, up_axis='Y'):
    """
    Export instances as a USD PointInstancer with proper coordinate conversion.

    Args:
        stage: USD stage
        path: USD path for the PointInstancer
        instance_data: dict from get_geonode_instance_data()
        prototype_paths: list of Sdf.Path for each prototype
        up_axis: Target up axis ('Y' for RUB conversion)

    Returns:
        UsdGeom.PointInstancer or None on error
    """
    from pxr import UsdSkel
    import mathutils

    try:
        instancer = UsdGeom.PointInstancer.Define(stage, path)

        count = instance_data['count']
        transforms = instance_data['transforms']
        ref_indices = instance_data['ref_indices']

        # Decompose transforms into positions, orientations, scales
        positions = []
        orientations = []
        scales = []

        # Conversion matrix for Z-up to Y-up RUB
        conversion = mathutils.Matrix((
            (1,  0,  0, 0),
            (0,  0,  1, 0),
            (0, -1,  0, 0),
            (0,  0,  0, 1)
        ))

        for i in range(count):
            # Convert numpy matrix to mathutils.Matrix for coordinate conversion
            np_mat = transforms[i]
            bl_mat = mathutils.Matrix((
                (np_mat[0][0], np_mat[0][1], np_mat[0][2], np_mat[0][3]),
                (np_mat[1][0], np_mat[1][1], np_mat[1][2], np_mat[1][3]),
                (np_mat[2][0], np_mat[2][1], np_mat[2][2], np_mat[2][3]),
                (np_mat[3][0], np_mat[3][1], np_mat[3][2], np_mat[3][3]),
            ))

            # Apply Z-up to Y-up conversion if needed
            if up_axis == 'Y':
                converted_mat = conversion @ bl_mat @ conversion.inverted()
            else:
                converted_mat = bl_mat

            # Create Gf.Matrix4d for decomposition
            gf_mat = Gf.Matrix4d(
                converted_mat[0][0], converted_mat[0][1], converted_mat[0][2], converted_mat[0][3],
                converted_mat[1][0], converted_mat[1][1], converted_mat[1][2], converted_mat[1][3],
                converted_mat[2][0], converted_mat[2][1], converted_mat[2][2], converted_mat[2][3],
                converted_mat[3][0], converted_mat[3][1], converted_mat[3][2], converted_mat[3][3],
            )

            # Extract translation
            pos = gf_mat.ExtractTranslation()
            positions.append(Gf.Vec3f(float(pos[0]), float(pos[1]), float(pos[2])))

            # Extract rotation as quaternion
            rot = gf_mat.ExtractRotation().GetQuaternion()
            real = rot.GetReal()
            imag = rot.GetImaginary()
            # USD uses (real, i, j, k) format
            orientations.append(Gf.Quath(float(real), float(imag[0]), float(imag[1]), float(imag[2])))

            # Extract scale (approximate from matrix columns)
            scale_x = math.sqrt(converted_mat[0][0]**2 + converted_mat[0][1]**2 + converted_mat[0][2]**2)
            scale_y = math.sqrt(converted_mat[1][0]**2 + converted_mat[1][1]**2 + converted_mat[1][2]**2)
            scale_z = math.sqrt(converted_mat[2][0]**2 + converted_mat[2][1]**2 + converted_mat[2][2]**2)
            scales.append(Gf.Vec3f(float(scale_x), float(scale_y), float(scale_z)))

        # Set PointInstancer attributes
        instancer.GetPositionsAttr().Set(Vt.Vec3fArray(positions))
        instancer.GetOrientationsAttr().Set(Vt.QuathArray(orientations))
        instancer.GetScalesAttr().Set(Vt.Vec3fArray(scales))
        instancer.GetProtoIndicesAttr().Set(Vt.IntArray(ref_indices.tolist()))

        # Set prototypes relationship
        instancer.GetPrototypesRel().SetTargets(prototype_paths)

        # Export custom attributes as primvars
        for attr_name, attr_data in instance_data['custom_attrs'].items():
            _export_instance_primvar(instancer, attr_name, attr_data)

        debug_log(f"  Created PointInstancer at '{path}' with {count} instances, {len(prototype_paths)} prototypes", LogCategory.GEOMNODES_INSTANCES)
        return instancer

    except Exception as e:
        debug_log(f"  Error creating PointInstancer: {e}", LogCategory.GEOMNODES_INSTANCES)
        import traceback
        traceback.print_exc()
        return None


def _export_instance_primvar(instancer, name, attr_data):
    """
    Export a custom attribute as a primvar on the PointInstancer.

    Args:
        instancer: UsdGeom.PointInstancer
        name: Attribute name
        attr_data: Dict with 'type' and 'data' keys
    """
    try:
        primvars_api = UsdGeom.PrimvarsAPI(instancer)

        attr_type = attr_data['type']
        data = attr_data['data']

        if data is None:
            return

        # Sanitize attribute name for USD
        safe_name = sanitize_name(name)

        if attr_type == 'float':
            primvar = primvars_api.CreatePrimvar(
                safe_name, Sdf.ValueTypeNames.FloatArray, UsdGeom.Tokens.varying
            )
            primvar.Set(Vt.FloatArray(data.tolist()))

        elif attr_type == 'int':
            primvar = primvars_api.CreatePrimvar(
                safe_name, Sdf.ValueTypeNames.IntArray, UsdGeom.Tokens.varying
            )
            primvar.Set(Vt.IntArray(data.tolist()))

        elif attr_type == 'bool':
            primvar = primvars_api.CreatePrimvar(
                safe_name, Sdf.ValueTypeNames.BoolArray, UsdGeom.Tokens.varying
            )
            primvar.Set(Vt.BoolArray(data.tolist()))

        elif attr_type == 'vector3':
            primvar = primvars_api.CreatePrimvar(
                safe_name, Sdf.ValueTypeNames.Vector3fArray, UsdGeom.Tokens.varying
            )
            vectors = [Gf.Vec3f(float(v[0]), float(v[1]), float(v[2])) for v in data]
            primvar.Set(Vt.Vec3fArray(vectors))

        elif attr_type == 'color':
            primvar = primvars_api.CreatePrimvar(
                safe_name, Sdf.ValueTypeNames.Color3fArray, UsdGeom.Tokens.varying
            )
            # USD Color3f is RGB, so use first 3 channels
            colors = [Gf.Vec3f(float(c[0]), float(c[1]), float(c[2])) for c in data]
            primvar.Set(Vt.Vec3fArray(colors))

        elif attr_type == 'quat':
            primvar = primvars_api.CreatePrimvar(
                safe_name, Sdf.ValueTypeNames.QuatfArray, UsdGeom.Tokens.varying
            )
            quats = [Gf.Quatf(float(q[0]), float(q[1]), float(q[2]), float(q[3])) for q in data]
            primvar.Set(Vt.QuatfArray(quats))

        debug_log(f"    Exported primvar '{safe_name}' ({attr_type})", LogCategory.GEOMNODES_INSTANCES)

    except Exception as e:
        debug_log(f"    Error exporting primvar '{name}': {e}")


def export_geonode_prototype_mesh(stage, prototype_path, reference_geometry, exported_materials, force_rebuild=False):
    """
    Export a geometry nodes prototype reference as a USD mesh.

    Args:
        stage: USD stage
        prototype_path: USD path for the prototype
        reference_geometry: Blender geometry reference from instance_references()
        exported_materials: Dict of already exported materials
        force_rebuild: Force rebuild even if cached

    Returns:
        UsdGeom.Mesh or None on error
    """
    try:
        # Check if this reference has mesh data
        if not hasattr(reference_geometry, 'mesh') or reference_geometry.mesh is None:
            debug_log(f"    Prototype has no mesh data, creating empty Xform", LogCategory.GEOMNODES_INSTANCES)
            return UsdGeom.Xform.Define(stage, prototype_path)

        mesh_data = reference_geometry.mesh

        # Validate mesh has vertices
        if not mesh_data.vertices or len(mesh_data.vertices) == 0:
            debug_log(f"    Warning: Prototype mesh has no vertices", LogCategory.GEOMNODES_INSTANCES)
            return UsdGeom.Xform.Define(stage, prototype_path)

        debug_log(f"    Exporting prototype mesh with {len(mesh_data.vertices)} vertices", LogCategory.GEOMNODES_INSTANCES)

        # Create the mesh
        mesh = UsdGeom.Mesh.Define(stage, prototype_path)

        # Extract vertex positions using numpy
        positions = np.zeros(len(mesh_data.vertices) * 3, dtype=np.float32)
        mesh_data.vertices.foreach_get('co', positions)
        positions = positions.reshape(-1, 3)

        # Convert from Blender Z-up to RUB Y-up: (x, y, z) → (x, z, -y)
        positions = positions[:, [0, 2, 1]]
        positions[:, 2] *= -1

        points = Vt.Vec3fArray.FromNumpy(positions.astype(np.float32))

        # Extract face data
        face_counts = np.zeros(len(mesh_data.polygons), dtype=np.int32)
        mesh_data.polygons.foreach_get('loop_total', face_counts)

        loop_vertex_indices = np.zeros(len(mesh_data.loops), dtype=np.int32)
        mesh_data.loops.foreach_get('vertex_index', loop_vertex_indices)

        # Extract normals
        normals_flat = np.zeros(len(mesh_data.loops) * 3, dtype=np.float32)
        mesh_data.corner_normals.foreach_get('vector', normals_flat)
        normals_arr = normals_flat.reshape(-1, 3)

        # Convert normals to Y-up
        normals_arr = normals_arr[:, [0, 2, 1]]
        normals_arr[:, 2] *= -1

        normals = Vt.Vec3fArray.FromNumpy(normals_arr.astype(np.float32))

        # Set mesh attributes
        with Sdf.ChangeBlock():
            mesh.CreatePointsAttr(points)
            mesh.CreateFaceVertexCountsAttr(face_counts.tolist())
            mesh.CreateFaceVertexIndicesAttr(loop_vertex_indices.tolist())
            mesh.CreateNormalsAttr(normals)
            mesh.SetNormalsInterpolation(UsdGeom.Tokens.faceVarying)

        # Extract UVs if present
        if mesh_data.uv_layers and mesh_data.uv_layers.active:
            uv_layer = mesh_data.uv_layers.active.data
            uvs_flat = np.zeros(len(uv_layer) * 2, dtype=np.float32)
            uv_layer.foreach_get('uv', uvs_flat)
            uvs = uvs_flat.reshape(-1, 2)

            unique_uvs, inverse_indices = np.unique(uvs, axis=0, return_inverse=True)
            st = Vt.Vec2fArray.FromNumpy(unique_uvs.astype(np.float32))

            primvars_api = UsdGeom.PrimvarsAPI(mesh)
            uv_primvar = primvars_api.CreatePrimvar("st", Sdf.ValueTypeNames.TexCoord2fArray, UsdGeom.Tokens.faceVarying)
            uv_primvar.Set(st)
            uv_primvar.SetIndices(inverse_indices.tolist())

        return mesh

    except Exception as e:
        debug_log(f"    Error exporting prototype mesh: {e}", LogCategory.GEOMNODES_INSTANCES)
        import traceback
        traceback.print_exc()
        return None


def convert_z_up_to_y_up(vector):
    """
    Convert a vector from Blender's Z-up to USD's Y-up coordinate system.
    Transformation: X stays X, Y becomes -Z, Z becomes Y

    Args:
        vector: Vector or point (x, y, z)

    Returns:
        Converted vector (x, -z, y)
    """
    if hasattr(vector, 'x'):  # Blender Vector
        return type(vector)((vector.x, -vector.z, vector.y))
    else:  # Tuple or list
        return (vector[0], -vector[2], vector[1])


def convert_matrix_z_up_to_y_up(matrix):
    """
    Convert a 4x4 matrix from Blender's Z-up to USD's Y-up coordinate system.

    Args:
        matrix: Blender Matrix (4x4)

    Returns:
        Converted matrix
    """
    import mathutils

    # Conversion matrix: rotate -90 degrees around X-axis
    # This transforms Z-up to Y-up
    conversion = mathutils.Matrix.Rotation(math.radians(-90), 4, 'X')

    # Apply conversion: conversion * matrix * conversion.inverted()
    return conversion @ matrix @ conversion.inverted()


def get_armature_for_mesh(obj):
    """
    Find the armature object that affects a mesh through an Armature modifier.

    Args:
        obj: Mesh object to check

    Returns:
        Armature object or None
    """
    if not obj or obj.type != 'MESH':
        return None

    for modifier in obj.modifiers:
        if modifier.type == 'ARMATURE' and modifier.object:
            return modifier.object

    return None


def get_actions_for_armature(armature):
    """
    Get all actions associated with an armature.

    Args:
        armature: Armature object

    Returns:
        List of Action objects
    """
    if not armature or not armature.animation_data:
        return []

    actions = []

    if armature.animation_data.action:
        actions.append(armature.animation_data.action)

    for track in armature.animation_data.nla_tracks:
        for strip in track.strips:
            if strip.action and strip.action not in actions:
                actions.append(strip.action)

    return actions


def detect_keyframe_range(action):
    """
    Detect the start and end keyframe times from an action.

    Args:
        action: Blender Action object

    Returns:
        Tuple of (start_frame, end_frame)
    """
    if not action or not action.fcurves:
        return (0, 0)

    start_frame = float('inf')
    end_frame = float('-inf')

    for fcurve in action.fcurves:
        if fcurve.keyframe_points:
            for keyframe in fcurve.keyframe_points:
                frame = keyframe.co[0]
                start_frame = min(start_frame, frame)
                end_frame = max(end_frame, frame)

    if start_frame == float('inf'):
        return (0, 0)

    return (int(start_frame), int(end_frame))


def build_joint_hierarchy(armature):
    """
    Build ordered joint hierarchy from armature bones.

    Args:
        armature: Armature object

    Returns:
        List of bone names in hierarchical order using forward slash paths (e.g., "bone", "bone/bone_001")
    """
    if not armature or not armature.data:
        debug_log(f" ERROR - No armature or armature.data")
        return []

    debug_log(f" Building joint hierarchy for armature '{armature.name}'")
    debug_log(f" Armature has {len(armature.data.bones)} total bones")

    # List all bones for debugging
    for bone in armature.data.bones:
        parent_name = bone.parent.name if bone.parent else "None"
        children_names = [child.name for child in bone.children]
        debug_log(f"   Bone '{bone.name}': parent='{parent_name}', children={children_names}")

    joint_names = []

    def add_bone_hierarchy(bone, parent_path=""):
        # Sanitize bone name: replace '.' with '_' for engine compatibility
        bone_name_sanitized = bone.name.replace('.', '_')

        # Build hierarchical path using forward slashes
        # Root bones have no prefix: "bone"
        # Child bones include parent path: "bone/bone_001"
        if parent_path:
            joint_path = f"{parent_path}/{bone_name_sanitized}"
        else:
            joint_path = bone_name_sanitized

        joint_names.append(joint_path)
        debug_log(f" Added joint '{joint_path}' to hierarchy (original: '{bone.name}')")

        # Recursively add children with current joint as parent path
        for child in bone.children:
            add_bone_hierarchy(child, joint_path)

    # Start with root bones (bones with no parent)
    root_bones = [bone for bone in armature.data.bones if bone.parent is None]
    debug_log(f" Found {len(root_bones)} root bones in armature '{armature.name}'")
    for root_bone in root_bones:
        debug_log(f"   Root bone: '{root_bone.name}'")

    for bone in root_bones:
        add_bone_hierarchy(bone)

    debug_log(f" Built joint hierarchy with {len(joint_names)} joints: {joint_names}")
    return joint_names


def export_skeleton(context, stage, armature, skel_root_path, mesh_obj, up_axis='Y'):
    """
    Export armature as USD Skeleton with bind and rest transforms.

    Note: Frame position should be set by the caller (export_mesh) before calling this function.
    This ensures bind pose is calculated at the correct frame (typically frame 1).

    Args:
        context: Blender context
        stage: USD stage
        armature: Armature object
        skel_root_path: Path to SkelRoot prim
        mesh_obj: Mesh object for bind transform calculation

    Returns:
        Skeleton prim
    """
    from pxr import UsdSkel

    if not armature or not armature.data:
        debug_log(f" No valid armature to export")
        return None

    debug_log(f" Exporting skeleton for armature '{armature.name}'")

    # Build joint hierarchy
    joint_names = build_joint_hierarchy(armature)
    if not joint_names:
        debug_log(f" No joints found in armature '{armature.name}'")
        return None

    debug_log(f" Found {len(joint_names)} joints: {joint_names}")

    # Create Skeleton prim
    skel_path = f"{skel_root_path}/{sanitize_name(armature.name)}"
    skeleton = UsdSkel.Skeleton.Define(stage, skel_path)

    # Apply SkelBindingAPI
    skel_binding_api = UsdSkel.BindingAPI.Apply(skeleton.GetPrim())

    # Set joints attribute
    skeleton.CreateJointsAttr(joint_names)

    # Calculate bind transforms and rest transforms
    bind_transforms = []
    rest_transforms = []

    # Store bone objects in order for later use
    # joint_names contain hierarchical paths like "bone/bone_001"
    # Extract just the bone name from the path
    bone_list = []
    for joint_path in joint_names:
        # Extract the bone name from the path (last component after /)
        bone_name = joint_path.split('/')[-1]

        # Find the bone by name
        bone_found = armature.data.bones.get(bone_name)

        if bone_found:
            bone_list.append(bone_found)
            debug_log(f" Matched joint path '{joint_path}' to bone '{bone_found.name}'")
        else:
            debug_log(f" Warning - Could not find bone for joint path '{joint_path}' (bone name: '{bone_name}')")
            bone_list.append(None)

    # Calculate transforms
    # Convert from Blender Z-up to RUB Y-up using matrix swizzle
    # RUB Y-up means: X=right, Y=up, Z=back (toward camera)
    # Transformation: (x, y, z) → (x, z, -y)

    import mathutils

    # Helper function to convert matrix from Z-up to RUB Y-up
    def convert_matrix_to_rub_yup(matrix):
        """Convert 4x4 matrix from Blender Z-up to RUB Y-up"""
        m = matrix
        # Swizzle: row0 stays, row2→row1, -row1→row2
        return mathutils.Matrix((
            (m[0][0], m[0][1], m[0][2], m[0][3]),
            (m[2][0], m[2][1], m[2][2], m[2][3]),
            (-m[1][0], -m[1][1], -m[1][2], -m[1][3]),
            (m[3][0], m[3][1], m[3][2], m[3][3])
        ))

    for bone in bone_list:
        if not bone:
            # Use identity matrix for missing bones
            bind_transforms.append(Gf.Matrix4d(1.0))
            rest_transforms.append(Gf.Matrix4d(1.0))
            continue

        # Get bone matrices in armature space (Z-up)
        # Bind transform: inverse of bone's world matrix (for skinning)
        bone_world_matrix = armature.matrix_world @ bone.matrix_local
        bone_world_inv = bone_world_matrix.inverted()

        # Convert inverted matrix to RUB Y-up
        bone_world_inv_yup = convert_matrix_to_rub_yup(bone_world_inv)
        bind_transform = Gf.Matrix4d(*bone_world_inv_yup.transposed())
        bind_transforms.append(bind_transform)

        # Rest transform: local transform relative to parent
        if bone.parent:
            parent_world = armature.matrix_world @ bone.parent.matrix_local
            local_matrix = parent_world.inverted() @ (armature.matrix_world @ bone.matrix_local)
        else:
            local_matrix = armature.matrix_world.inverted() @ (armature.matrix_world @ bone.matrix_local)

        # Convert local matrix to RUB Y-up
        local_matrix_yup = convert_matrix_to_rub_yup(local_matrix)
        rest_transform = Gf.Matrix4d(*local_matrix_yup.transposed())
        rest_transforms.append(rest_transform)

    # Set bind transforms
    skeleton.CreateBindTransformsAttr(bind_transforms)

    # Set rest transforms
    skeleton.CreateRestTransformsAttr(rest_transforms)

    debug_log(f" Skeleton '{armature.name}' exported with {len(joint_names)} joints")

    return skeleton


def export_skin_weights(context, mesh_obj, armature, mesh_prim, skeleton):
    """
    Export vertex group skin weights as USD primvars.
    Optimized with numpy for high-poly meshes.

    Args:
        context: Blender context
        mesh_obj: Mesh object with vertex groups
        armature: Armature object
        mesh_prim: USD Mesh prim
        skeleton: USD Skeleton prim

    Returns:
        bool: Success status
    """
    from pxr import UsdSkel

    if not mesh_obj or not armature or not mesh_prim or not skeleton:
        return False

    debug_log(f" Exporting skin weights for mesh '{mesh_obj.name}'", LogCategory.SKELETON_WEIGHTS)

    # Get joint names from skeleton
    joint_names = skeleton.GetJointsAttr().Get()
    if not joint_names:
        debug_log(f" No joints found in skeleton", LogCategory.SKELETON_WEIGHTS)
        return False

    # Create bone name to index mapping
    # joint_names are hierarchical paths like "bone/bone_001"
    # Extract bone names and map to indices for vertex group matching
    bone_name_to_index = {}
    for idx, joint_path in enumerate(joint_names):
        # Extract bone name from path (last component after /)
        bone_name = joint_path.split('/')[-1]
        bone_name_to_index[bone_name] = idx

    debug_log(f" Created bone name to index mapping with {len(bone_name_to_index)} entries", LogCategory.SKELETON_WEIGHTS)

    # Get mesh data
    mesh_data = mesh_obj.data
    vertex_count = len(mesh_data.vertices)

    # === Numpy-optimized skin weight extraction ===
    max_influences = 4

    # Create vertex group name to joint index mapping
    vg_to_joint_idx = {}
    for vg in mesh_obj.vertex_groups:
        if vg.name in bone_name_to_index:
            vg_to_joint_idx[vg.index] = bone_name_to_index[vg.name]

    # Pre-allocate arrays for joint indices and weights
    # Shape: (vertex_count, max_influences)
    joint_indices_arr = np.zeros((vertex_count, max_influences), dtype=np.int32)
    joint_weights_arr = np.zeros((vertex_count, max_influences), dtype=np.float32)

    # Collect all vertex group data
    # For each vertex, collect (joint_idx, weight) pairs
    weighted_vertex_count = 0

    for vertex in mesh_data.vertices:
        if not vertex.groups:
            continue

        # Collect valid influences for this vertex
        influences = []
        for group in vertex.groups:
            if group.weight > 0.0001 and group.group in vg_to_joint_idx:
                joint_idx = vg_to_joint_idx[group.group]
                influences.append((joint_idx, group.weight))

        if not influences:
            continue

        weighted_vertex_count += 1

        # Sort by weight (descending) and keep top max_influences
        influences.sort(key=lambda x: x[1], reverse=True)
        influences = influences[:max_influences]

        # Normalize weights
        total_weight = sum(w for _, w in influences)
        if total_weight > 0:
            for i, (joint_idx, weight) in enumerate(influences):
                joint_indices_arr[vertex.index, i] = joint_idx
                joint_weights_arr[vertex.index, i] = weight / total_weight

    debug_log(f" Found skin weights for {weighted_vertex_count} / {vertex_count} vertices", LogCategory.SKELETON_WEIGHTS)

    if weighted_vertex_count == 0:
        debug_log(f" Warning - No weighted vertices found", LogCategory.SKELETON_WEIGHTS)
        return False

    # Flatten arrays for USD
    joint_indices = joint_indices_arr.flatten().tolist()
    joint_weights = joint_weights_arr.flatten().tolist()

    # Apply SkelBindingAPI to mesh
    skel_binding_api = UsdSkel.BindingAPI.Apply(mesh_prim)

    # Create relationship to skeleton
    skel_binding_api.CreateSkeletonRel().SetTargets([skeleton.GetPath()])

    # Create primvars for joint indices and weights
    primvars_api = UsdGeom.PrimvarsAPI(mesh_prim)

    # Joint indices primvar
    joint_indices_primvar = primvars_api.CreatePrimvar(
        "skel:jointIndices",
        Sdf.ValueTypeNames.IntArray,
        UsdGeom.Tokens.vertex
    )
    joint_indices_primvar.Set(joint_indices)
    joint_indices_primvar.SetElementSize(max_influences)

    # Joint weights primvar
    joint_weights_primvar = primvars_api.CreatePrimvar(
        "skel:jointWeights",
        Sdf.ValueTypeNames.FloatArray,
        UsdGeom.Tokens.vertex
    )
    joint_weights_primvar.Set(joint_weights)
    joint_weights_primvar.SetElementSize(max_influences)

    # Create geomBindTransform (transform from mesh to skeleton space)
    # This is typically identity if mesh and skeleton are in same space
    bind_transform = mesh_obj.matrix_world.inverted() @ armature.matrix_world
    geom_bind_transform = Gf.Matrix4d(*bind_transform.transposed())

    geom_bind_transform_primvar = primvars_api.CreatePrimvar(
        "skel:geomBindTransform",
        Sdf.ValueTypeNames.Matrix4d
    )
    geom_bind_transform_primvar.Set(geom_bind_transform)

    debug_log(f" Skin weights exported successfully", LogCategory.SKELETON_WEIGHTS)

    return True


def export_animations(context, stage, armature, skeleton, skel_root_path, project_path, mesh_obj=None):
    """
    Export all actions on armature as USD SkelAnimation prims.

    Args:
        context: Blender context
        stage: USD stage
        armature: Armature object
        skeleton: USD Skeleton prim
        skel_root_path: Path to SkelRoot prim
        project_path: Project root path for separate file export
        mesh_obj: Mesh object (optional, for export settings)

    Returns:
        List of SkelAnimation prim paths
    """
    from pxr import UsdSkel

    if not armature or not skeleton:
        return []

    # Get export settings
    scene_props = context.scene.mhs
    sampling_rate = scene_props.animation_sampling_rate

    # Get actions to export from the armature's animation_export_actions list
    # If the list is empty, fall back to getting all actions from the armature
    actions_to_export = []  # List of tuples: (action, custom_name, frame_start, frame_end, is_loop)

    if hasattr(armature, 'mhs') and armature.mhs.animation_export_actions:
        # Use the per-action enabled state and metadata from the UI list
        for action_item in armature.mhs.animation_export_actions:
            if action_item.enabled and action_item.action:
                action = action_item.action

                # Use custom name if specified, otherwise use action name
                custom_name = action_item.custom_name if action_item.custom_name else action.name

                # Use custom frame range if specified, otherwise will detect from keyframes
                if action_item.use_custom_range:
                    frame_start = action_item.frame_start
                    frame_end = action_item.frame_end
                else:
                    frame_start = None  # Will be auto-detected
                    frame_end = None

                is_loop = action_item.is_loop

                actions_to_export.append((action, custom_name, frame_start, frame_end, is_loop))
        debug_log(f" Using action list from armature - {len(actions_to_export)} enabled actions")
    else:
        # Fall back to getting all actions (list not populated yet)
        fallback_actions = get_actions_for_armature(armature)
        for action in fallback_actions:
            actions_to_export.append((action, action.name, None, None, False))
        debug_log(f" Action list not populated, using all {len(actions_to_export)} actions from armature")

    if not actions_to_export:
        debug_log(f" No actions found on armature '{armature.name}'")
        return []

    debug_log(f" Exporting {len(actions_to_export)} actions for armature '{armature.name}'")

    # Get joint names from skeleton
    joint_names = skeleton.GetJointsAttr().Get()
    if not joint_names:
        debug_log(f" No joints found in skeleton")
        return []

    # Store original action and frame
    original_action = armature.animation_data.action if armature.animation_data else None
    original_frame = context.scene.frame_current

    animation_paths = []

    try:
        for action_tuple in actions_to_export:
            # Unpack the tuple: (action, custom_name, frame_start, frame_end, is_loop)
            action, custom_name, custom_frame_start, custom_frame_end, is_loop = action_tuple

            # Set this action as active
            if not armature.animation_data:
                armature.animation_data_create()
            armature.animation_data.action = action

            debug_log(f" Processing action '{action.name}' (export as: '{custom_name}', loop: {is_loop})")

            # Use custom frame range if specified, otherwise detect from keyframes
            if custom_frame_start is not None and custom_frame_end is not None:
                start_frame = custom_frame_start
                end_frame = custom_frame_end
                debug_log(f" Using custom frame range: {start_frame} to {end_frame}")
            else:
                start_frame, end_frame = detect_keyframe_range(action)
                debug_log(f" Auto-detected frame range: {start_frame} to {end_frame}")

            if start_frame == 0 and end_frame == 0:
                debug_log(f" Warning - No keyframes found in action '{action.name}'")
                continue

            debug_log(f" Action '{action.name}' frame range: {start_frame} to {end_frame}")

            # Create SkelAnimation prim using custom_name for export
            anim_name = sanitize_name(custom_name)
            anim_path = f"{skel_root_path}/{sanitize_name(armature.name)}/{anim_name}"
            skel_anim = UsdSkel.Animation.Define(stage, anim_path)

            # Set joints
            skel_anim.CreateJointsAttr(joint_names)

            # Set loop metadata as custom data if is_loop is True
            if is_loop:
                skel_anim.GetPrim().SetCustomDataByKey("isLoop", True)
                debug_log(f" Set isLoop=True custom data on animation '{anim_name}'")

            # Sample animation data
            frames_to_sample = range(int(start_frame), int(end_frame) + 1)

            # Initialize arrays for all frames
            all_translations = []
            all_rotations = []
            all_scales = []

            for frame in frames_to_sample:
                context.scene.frame_set(frame)
                context.view_layer.update()

                frame_translations = []
                frame_rotations = []
                frame_scales = []

                # Sample each bone - joint_names are hierarchical paths like "bone/bone_001"
                for joint_path in joint_names:
                    # Extract bone name from path (last component after /)
                    bone_name = joint_path.split('/')[-1]

                    # Find the pose bone by name
                    pose_bone = armature.pose.bones.get(bone_name)

                    if not pose_bone:
                        # Use identity transforms for missing bones
                        debug_log(f" WARNING - Could not find pose bone for joint '{joint_path}' (bone name: '{bone_name}')")
                        frame_translations.append(Gf.Vec3f(0, 0, 0))
                        frame_rotations.append(Gf.Quatf(1, 0, 0, 0))
                        frame_scales.append(Gf.Vec3h(1, 1, 1))
                        continue

                    # Get local transform (relative to parent)
                    matrix = pose_bone.matrix_basis

                    # Decompose matrix
                    translation, rotation, scale = matrix.decompose()

                    # Convert to USD types
                    # Note: Blender quaternion is (w, x, y, z), USD Quatf is also (w, x, y, z)
                    frame_translations.append(Gf.Vec3f(translation.x, translation.y, translation.z))
                    frame_rotations.append(Gf.Quatf(rotation.w, rotation.x, rotation.y, rotation.z))
                    frame_scales.append(Gf.Vec3h(scale.x, scale.y, scale.z))

                all_translations.extend(frame_translations)
                all_rotations.extend(frame_rotations)
                all_scales.extend(frame_scales)

            # Create attributes with time samples
            translations_attr = skel_anim.CreateTranslationsAttr()
            rotations_attr = skel_anim.CreateRotationsAttr()
            scales_attr = skel_anim.CreateScalesAttr()

            # Write time samples
            for i, frame in enumerate(frames_to_sample):
                time_code = float(frame)
                start_idx = i * len(joint_names)
                end_idx = start_idx + len(joint_names)

                translations_attr.Set(all_translations[start_idx:end_idx], time_code)
                rotations_attr.Set(all_rotations[start_idx:end_idx], time_code)
                scales_attr.Set(all_scales[start_idx:end_idx], time_code)

            # Set interpolation to linear
            translations_attr.SetMetadata('interpolation', 'linear')
            rotations_attr.SetMetadata('interpolation', 'linear')
            scales_attr.SetMetadata('interpolation', 'linear')

            animation_paths.append(anim_path)
            debug_log(f" Animation '{action.name}' exported with {len(frames_to_sample)} frames")

    finally:
        # Restore original action and frame
        if armature.animation_data:
            armature.animation_data.action = original_action
        context.scene.frame_set(original_frame)
        context.view_layer.update()

    # Bind animations to skeleton
    if animation_paths:
        skel_binding_api = UsdSkel.BindingAPI.Apply(skeleton.GetPrim())
        anim_source_rel = skel_binding_api.CreateAnimationSourceRel()
        anim_source_rel.SetTargets([Sdf.Path(p) for p in animation_paths])
        debug_log(f" Bound {len(animation_paths)} animations to skeleton")

    return animation_paths

# def create_lightmap_uvs(obj, angle_limit, island_margin, area_weight):
#     # Implementation of lightmap UV creation
#     pass

# def bake_lightmap(obj, resolution):
#     # Implementation of lightmap baking
#     pass
