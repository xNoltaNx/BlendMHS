import bpy
from bpy.props import (StringProperty, BoolProperty, EnumProperty, FloatProperty,
                      PointerProperty, FloatVectorProperty, CollectionProperty)
from bpy.types import PropertyGroup, Material, Image

# Import the centralized format configuration
from .shader_templates.base import (
    get_material_format_items,
    DEPRECATED_FORMATS,
    TEMPLATE_BASED_FORMATS,
)


class MaterialFormat(PropertyGroup):
    """Core material format properties - DEPRECATED, use MaterialSystem directly"""

    material_format: EnumProperty(
        name="Material Format",
        description="Material export format",
        items=get_material_format_items(),
        default='NONE',
        update=lambda self, context: self.id_data.mhs.update_shader()
    )

    texture_wrap_s: EnumProperty(
        name="Texture Wrap S",
        description="S (U) wrap mode for textures",
        items=[
            ('repeat', "Repeat", "Repeat the texture"),
            ('clamp', "Clamp", "Clamp to edge"),
            ('mirror', "Mirror", "Mirror the texture"),
        ],
        default='repeat'
    )

    texture_wrap_t: EnumProperty(
        name="Texture Wrap T",
        description="T (V) wrap mode for textures",
        items=[
            ('repeat', "Repeat", "Repeat the texture"),
            ('clamp', "Clamp", "Clamp to edge"),
            ('mirror', "Mirror", "Mirror the texture"),
        ],
        default='repeat'
    )

    show_texture_properties: BoolProperty(
        name="Show Texture Properties",
        description="Show or hide texture properties",
        default=True
    )

class DynamicShaderProperty(PropertyGroup):
    """Property storage for dynamic shader inputs"""
    name: StringProperty()

    value_bool: BoolProperty(
        default=False,
        update=lambda self, context: self.sync_value_to_node_group(context)
    )

    # Use soft limits for the property itself - actual clamping happens in the setter
    value_float: FloatProperty(
        name="Value",
        soft_min=0.0,
        soft_max=1.0,
        update=lambda self, context: self.sync_value_to_node_group(context)
    )

    # Store the actual min/max constraints from the node group interface
    float_min: FloatProperty(default=-10000.0)
    float_max: FloatProperty(default=10000.0)
    float_has_min: BoolProperty(default=False)
    float_has_max: BoolProperty(default=False)

    value_vector: FloatVectorProperty(
        size=4,
        default=(0.0, 0.0, 0.0, 1.0),
        update=lambda self, context: self.sync_value_to_node_group(context)
    )
    value_color: FloatVectorProperty(
        size=4,
        subtype='COLOR',
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0, 1.0),
        update=lambda self, context: self.sync_value_to_node_group(context)
    )
    value_image: PointerProperty(
        type=Image,
        update=lambda self, context: self.sync_value_to_node_group(context)
    )
    is_texture: BoolProperty()
    is_color: BoolProperty(default=False)
    is_bool: BoolProperty(default=False)
    is_vector: BoolProperty(default=False)

    def get_clamped_float(self):
        """Get the float value clamped to the stored min/max range"""
        val = self.value_float
        if self.float_has_min and val < self.float_min:
            return self.float_min
        if self.float_has_max and val > self.float_max:
            return self.float_max
        return val

    def set_clamped_float(self, value):
        """Set the float value, clamping to the stored min/max range"""
        if self.float_has_min:
            value = max(value, self.float_min)
        if self.float_has_max:
            value = min(value, self.float_max)
        self.value_float = value

    def sync_value_to_node_group(self, context):
        """Sync the current property value back to the node group"""
        material = self.id_data  # Get the material this property belongs to
        if not material or not material.node_tree:
            return

        # Find the main node group
        from . import shader_factory
        main_group = shader_factory.get_main_group_node(material)
        if not main_group or self.name not in main_group.inputs:
            return

        # Get the input socket
        socket = main_group.inputs[self.name]

        # Update the socket value based on property type
        if self.is_texture:
            # For textures, we need to find or create the texture node
            shader_factory.add_texture_node(material, main_group, self.name, self.value_image)
        elif self.is_color:
            socket.default_value = self.value_color
        elif self.is_bool:
            socket.default_value = self.value_bool
        elif self.is_vector:
            # Handle vector size mismatch - socket expects 3 components, value_vector stores 4
            if socket.type == 'VECTOR':
                socket.default_value = self.value_vector[:3]
            else:
                socket.default_value = self.value_vector
        else:  # float
            socket.default_value = self.value_float

class ShaderPanel(PropertyGroup):
    """UI panel organization for shader properties"""
    name: StringProperty()
    is_open: BoolProperty(default=True)
    properties: StringProperty()  # Store property names as comma-separated string

class MaterialSystem(PropertyGroup):
    """Main material system implementation"""

    # Direct properties
    material_format: EnumProperty(
        name="Material Format",
        description="Material export format",
        items=get_material_format_items(),
        default='NONE',
        update=lambda self, context: self.update_shader()
    )

    texture_wrap_s: EnumProperty(
        name="Texture Wrap S",
        description="S (U) wrap mode for textures",
        items=[
            ('repeat', "Repeat", "Repeat the texture"),
            ('clamp', "Clamp", "Clamp to edge"),
            ('mirror', "Mirror", "Mirror the texture"),
        ],
        default='repeat'
    )

    texture_wrap_t: EnumProperty(
        name="Texture Wrap T",
        description="T (V) wrap mode for textures",
        items=[
            ('repeat', "Repeat", "Repeat the texture"),
            ('clamp', "Clamp", "Clamp to edge"),
            ('mirror', "Mirror", "Mirror the texture"),
        ],
        default='repeat'
    )

    show_texture_properties: BoolProperty(
        name="Show Texture Properties",
        description="Show or hide texture properties",
        default=True
    )

    # Collections for dynamic properties
    panels: CollectionProperty(type=ShaderPanel)
    properties: CollectionProperty(type=DynamicShaderProperty)
    active_panel: StringProperty()

    def update_shader(self):
        """Update shader nodes based on material format"""
        material = self.id_data
        if not material or not isinstance(material, Material):
            return

        from . import shader_factory

        # Handle NONE format - remove MHS node groups
        if self.material_format == 'NONE':
            self._remove_mhs_nodes(material)
            return

        # Set up the main shader
        new_group = shader_factory.setup_material_nodes(material)

        if new_group:
            # Update dynamic properties
            shader_factory.update_dynamic_properties(self, new_group)

            # Set up lightmap using object settings
            self.setup_lightmap()

        # Configure material blend settings based on format
        # These settings affect EEVEE rendering
        self._configure_blend_settings(material)

    def _remove_mhs_nodes(self, material):
        """Remove all MHS-related nodes from the material's node tree.

        This is called when the material format is set to NONE.
        Removes:
        - MHS shader group nodes (MHS_IsotropicUSD, MHS_IsotropicEmissiveUSD, etc.)
        - MHS_UVTransform node groups

        Preserves:
        - Texture nodes (user may want to reuse them)
        - Vertex color nodes
        - Material output node
        """
        if not material.use_nodes or not material.node_tree:
            return

        from . import shader_factory

        node_tree = material.node_tree

        # Get all MHS node group names from templates
        mhs_group_names = shader_factory.get_all_template_node_group_names()
        # Also include the UVTransform group
        mhs_group_names.add('MHS_UVTransform')

        # Find and remove all MHS group nodes
        nodes_to_remove = []
        for node in node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree:
                if node.node_tree.name in mhs_group_names:
                    nodes_to_remove.append(node)

        for node in nodes_to_remove:
            node_tree.nodes.remove(node)

    def _configure_blend_settings(self, material):
        """Configure material blend/shadow settings based on format.

        This sets up the correct blend mode for EEVEE rendering:
        - UNLIT_BLEND: Alpha Blend for smooth transparency
        - UNLIT_MASKED: Alpha Clip for cutout/masked transparency
        - Others: Opaque (default)
        """
        material_format = self.material_format

        if material_format == 'UNLIT_BLEND':
            # Alpha blending for smooth transparency
            material.blend_method = 'BLEND'
            material.show_transparent_back = True
            # shadow_method was removed in Blender 4.x
            if hasattr(material, 'shadow_method'):
                material.shadow_method = 'HASHED'

        elif material_format == 'UNLIT_MASKED':
            # Alpha clip for hard cutout
            material.blend_method = 'CLIP'
            material.alpha_threshold = 0.5
            if hasattr(material, 'shadow_method'):
                material.shadow_method = 'CLIP'

        elif material_format in ('ISOTROPIC_USD', 'ISOTROPIC_EMISSIVE_USD', 'UNLIT'):
            # Opaque materials
            material.blend_method = 'OPAQUE'
            if hasattr(material, 'shadow_method'):
                material.shadow_method = 'OPAQUE'

    def setup_lightmap(self):
        """Set up lightmap nodes for this material"""
        material = self.id_data
        if not material or not material.node_tree:
            return

        # Check if lightmap_groups property exists (it's disabled due to Vulkan visualization errors)
        if not hasattr(bpy.context.scene.mhs, 'lightmap_groups'):
            return

        from . import shader_factory

        # Get number of lightmap groups from scene
        num_lightmaps = len(bpy.context.scene.mhs.lightmap_groups)

        # Only proceed if we have lightmap groups
        if num_lightmaps == 0:
            return

        # Ensure lightmap selector group exists with correct number of slots
        selector_group = shader_factory.ensure_lightmap_selector_group(num_lightmaps)

        # Set up the lightmap selector node and connect to main shader
        lightmap_node = shader_factory.setup_lightmap_material(material, selector_group)

        # Find objects using this material and apply their lightmap settings
        for obj in bpy.data.objects:
            if obj.type == 'MESH' and obj.mhs.export_lightmap:
                for slot in obj.material_slots:
                    if slot.material == material:
                        lightmap_index = obj.mhs.lightmap_index
                        if lightmap_index >= 0 and lightmap_index < num_lightmaps:
                            group = bpy.context.scene.mhs.lightmap_groups[lightmap_index]
                            if group.baked_lightmap:
                                shader_factory.set_lightmap_texture(material, lightmap_index, group.baked_lightmap)
                        break


def register():
    bpy.utils.register_class(DynamicShaderProperty)
    bpy.utils.register_class(ShaderPanel)
    bpy.utils.register_class(MaterialFormat)
    bpy.utils.register_class(MaterialSystem)

    # Add to materials
    Material.mhs = PointerProperty(type=MaterialSystem)

def unregister():
    # Remove from materials
    del Material.mhs

    bpy.utils.unregister_class(MaterialSystem)
    bpy.utils.unregister_class(MaterialFormat)
    bpy.utils.unregister_class(ShaderPanel)
    bpy.utils.unregister_class(DynamicShaderProperty)
