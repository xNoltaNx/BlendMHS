"""
BlendMHS Addon Preferences with tabbed UI, activation toggles, and dynamic keymapping.
"""

import bpy
import os
from bpy.props import StringProperty, BoolProperty, EnumProperty, FloatProperty
from bpy.types import AddonPreferences

from .registration import update_activate_quick_export_pie, update_activate_layout_setup_pie, keys
from .core.ui import draw_split_row, get_panel_fold, draw_keymap_items


class MHS_AddonPreferences(AddonPreferences):
    bl_idname = __package__

    # ═══════════════════════════════════════════════════════════════════════════════
    # Tab Navigation
    # ═══════════════════════════════════════════════════════════════════════════════

    tabs: EnumProperty(
        name="Tabs",
        items=[
            ('GENERAL', "General", "General settings and activation toggles"),
            ('KEYMAPS', "Keymaps", "Customize keyboard shortcuts"),
            ('ABOUT', "About", "Version info and support links"),
        ],
        default='GENERAL'
    )

    # ═══════════════════════════════════════════════════════════════════════════════
    # Activation Toggles
    # ═══════════════════════════════════════════════════════════════════════════════

    activate_quick_export_pie: BoolProperty(
        name="Quick Export Pie",
        description="Enable the Quick Export pie menu (Ctrl+Shift+E)",
        default=True,
        update=update_activate_quick_export_pie
    )

    activate_layout_setup_pie: BoolProperty(
        name="Layout Setup Pie",
        description="Enable the Layout Setup pie menu (Ctrl+Shift+C)",
        default=True,
        update=update_activate_layout_setup_pie
    )

    # ═══════════════════════════════════════════════════════════════════════════════
    # Collapsible Panel States
    # ═══════════════════════════════════════════════════════════════════════════════

    show_naming_section: BoolProperty(default=True)
    show_debug_section: BoolProperty(default=False)
    show_developer_section: BoolProperty(default=False)
    show_auto_export_section: BoolProperty(default=True)

    # ═══════════════════════════════════════════════════════════════════════════════
    # Auto-Export Settings
    # ═══════════════════════════════════════════════════════════════════════════════

    use_tooltip_notification: BoolProperty(
        name="Use Tooltip Notifications",
        description="Show compact mouse-following notifications instead of popup dialogs for auto-export results",
        default=True
    )

    notification_duration: FloatProperty(
        name="Notification Duration",
        description="How long to show export notifications (seconds)",
        default=0.5,
        min=0.25,
        max=10.0,
        step=10,
        precision=2,
        subtype='TIME_ABSOLUTE'
    )

    # ═══════════════════════════════════════════════════════════════════════════════
    # Naming Convention Settings
    # ═══════════════════════════════════════════════════════════════════════════════

    vertex_color_layer_name: StringProperty(
        name="Vertex Color Layer Name",
        description="Default name for the vertex color layer",
        default="Color"
    )

    lightmap_uv_layer_name: StringProperty(
        name="Lightmap UV Layer Name",
        description="Default name for the lightmap UV layer",
        default="LightmapUV"
    )

    # ═══════════════════════════════════════════════════════════════════════════════
    # Debug Settings
    # ═══════════════════════════════════════════════════════════════════════════════

    enable_debug_logging: BoolProperty(
        name="Enable Debug Logging",
        description="Enable verbose debug logging to the console (for troubleshooting)",
        default=False
    )

    # ═══════════════════════════════════════════════════════════════════════════════
    # Developer Settings
    # ═══════════════════════════════════════════════════════════════════════════════

    # NOTE: Advanced Mode is disabled for initial release since Shader Creator
    # and MaterialMap Export features are not yet complete.
    # advanced_mode: BoolProperty(
    #     name="Advanced Mode",
    #     description="Show advanced panels (Shader Creator, MaterialMap Export). These features are for development use",
    #     default=False
    # )

    # ═══════════════════════════════════════════════════════════════════════════════
    # Main Draw Method
    # ═══════════════════════════════════════════════════════════════════════════════

    def draw(self, context):
        layout = self.layout

        # Version/Header Banner
        self.draw_header(layout)

        # Tab Selector
        row = layout.row()
        row.prop(self, "tabs", expand=True)

        layout.separator()

        # Tab Content
        if self.tabs == 'GENERAL':
            self.draw_general(context, layout)
        elif self.tabs == 'KEYMAPS':
            self.draw_keymaps(context, layout)
        elif self.tabs == 'ABOUT':
            self.draw_about(layout)

    # ═══════════════════════════════════════════════════════════════════════════════
    # Header
    # ═══════════════════════════════════════════════════════════════════════════════

    def draw_header(self, layout):
        """Draw version header banner."""
        from . import bl_info
        version = '.'.join(str(v) for v in bl_info.get('version', (0, 0, 0)))

        row = layout.row()
        row.label(text=f"BlendMHS v{version}", icon='NODE_COMPOSITING')

    # ═══════════════════════════════════════════════════════════════════════════════
    # General Tab
    # ═══════════════════════════════════════════════════════════════════════════════

    def draw_general(self, context, layout):
        """Draw the General settings tab."""
        # Two-column layout
        split = layout.split(factor=0.4)

        # Left column: Activation toggles
        self.draw_activate(split)

        # Right column: Settings
        self.draw_settings(split)

    def draw_activate(self, layout):
        """Draw activation toggles for pies and tools."""
        box = layout.box()
        box.label(text="Activate", icon='CHECKMARK')

        # Pie Menus section
        col = box.column(align=True)
        col.label(text="Pie Menus", icon='MESH_CIRCLE')

        # Use column for vertical alignment
        col.prop(
            self, "activate_quick_export_pie",
            text="Quick Export Pie",
            icon='CHECKBOX_HLT' if self.activate_quick_export_pie else 'CHECKBOX_DEHLT',
            toggle=True
        )

        col.prop(
            self, "activate_layout_setup_pie",
            text="Layout Setup Pie",
            icon='CHECKBOX_HLT' if self.activate_layout_setup_pie else 'CHECKBOX_DEHLT',
            toggle=True
        )

        # Future: Add more activation toggles here
        # col.separator()
        # col.label(text="Tools", icon='TOOL_SETTINGS')
        # col.prop(self, "activate_export_tools", ...)

    def draw_settings(self, layout):
        """Draw settings organized by category."""
        box = layout.box()
        box.label(text="Settings", icon='PREFERENCES')

        # Naming Conventions (collapsible)
        panel = get_panel_fold(box, "naming_section", "Naming Conventions", prefs=self, icon='SORTALPHA')
        if panel:
            col = panel.column()
            draw_split_row(self, col, 'vertex_color_layer_name', "Vertex Color Layer", factor=0.5)
            draw_split_row(self, col, 'lightmap_uv_layer_name', "Lightmap UV Layer", factor=0.5)

        # Debug (collapsible, closed by default)
        panel = get_panel_fold(box, "debug_section", "Debug", prefs=self, icon='CONSOLE')
        if panel:
            col = panel.column()

            row = col.row()
            row.prop(self, "enable_debug_logging")
            if self.enable_debug_logging:
                row.label(icon='ERROR')

            if self.enable_debug_logging:
                sub = col.column()
                sub.scale_y = 0.8
                sub.separator()
                sub.label(text="Output appears in System Console:", icon='INFO')
                sub.label(text="  Window → Toggle System Console")
                sub.separator()
                sub.label(text="Log categories:", icon='FILTER')
                sub.label(text="  EXPORT, SKELETON, CACHE, MATERIAL, GEOMNODES")

            # Shader Templates utilities
            col.separator()
            col.label(text="Shader Templates:", icon='NODETREE')
            col.operator("mhs.rebuild_shader", text="Rebuild All Shader Templates", icon='FILE_REFRESH')

        # Auto-Export Settings (collapsible)
        panel = get_panel_fold(box, "auto_export_section", "Auto-Export", prefs=self, icon='FILE_BLEND')
        if panel:
            col = panel.column()

            # Notification style toggle
            row = col.row()
            row.prop(self, "use_tooltip_notification")

            # Duration (only shown when tooltip is enabled)
            if self.use_tooltip_notification:
                row = col.row()
                row.prop(self, "notification_duration", text="Duration (seconds)")

            # Info about the options
            col.separator()
            info_col = col.column()
            info_col.scale_y = 0.8
            if self.use_tooltip_notification:
                info_col.label(text="Tooltip: Compact notification near cursor", icon='INFO')
            else:
                info_col.label(text="Popup: Full export statistics dialog", icon='INFO')

        # Developer Options (collapsible, closed by default)
        # NOTE: Advanced Mode is disabled for initial release since Shader Creator
        # and MaterialMap Export features are not yet complete.
        # panel = get_panel_fold(box, "developer_section", "Developer", prefs=self, icon='PREFERENCES')
        # if panel:
        #     col = panel.column()
        #     col.prop(self, "advanced_mode")
        #
        #     # Rebuild shader templates
        #     col.separator()
        #     col.label(text="Shader Templates:", icon='NODETREE')
        #     col.operator("mhs.rebuild_shader", text="Rebuild All Shader Templates", icon='FILE_REFRESH')

    # ═══════════════════════════════════════════════════════════════════════════════
    # Keymaps Tab
    # ═══════════════════════════════════════════════════════════════════════════════

    def draw_keymaps(self, context, layout):
        """Draw keymap customization UI using Blender's native keymap editor."""
        wm = context.window_manager
        kc = wm.keyconfigs.user

        if not kc:
            layout.label(text="Keymap configuration not available", icon='ERROR')
            return

        box = layout.box()
        box.label(text="Keyboard Shortcuts", icon='KEYINGSET')

        col = box.column()
        col.label(text="Customize shortcuts below. Changes take effect immediately.")
        col.label(text="Keymaps are stored in Blender's user preferences.", icon='INFO')

        col.separator()

        # Draw keymaps for Quick Export Pie (if active)
        if self.activate_quick_export_pie:
            draw_keymap_items(kc, "Quick Export Pie", keys['QUICK_EXPORT_PIE'], layout)
        else:
            info_box = layout.box()
            info_box.label(text="Quick Export Pie is disabled", icon='INFO')
            info_box.label(text="Enable it in the General tab to configure its keymap")

        layout.separator()

        # Draw keymaps for Layout Setup Pie (if active)
        if self.activate_layout_setup_pie:
            draw_keymap_items(kc, "Layout Setup Pie", keys['LAYOUT_SETUP_PIE'], layout)
        else:
            info_box = layout.box()
            info_box.label(text="Layout Setup Pie is disabled", icon='INFO')
            info_box.label(text="Enable it in the General tab to configure its keymap")

        # Future: Add more keymap sections here as tools are added
        # if self.activate_other_tool:
        #     draw_keymap_items(kc, "Other Tool", keys['OTHER_TOOL'], layout)

    # ═══════════════════════════════════════════════════════════════════════════════
    # About Tab
    # ═══════════════════════════════════════════════════════════════════════════════

    def draw_about(self, layout):
        """Draw about/version info tab."""
        from . import bl_info

        box = layout.box()
        box.label(text="About BlendMHS", icon='INFO')

        col = box.column()

        # Version info
        version = '.'.join(str(v) for v in bl_info.get('version', (0, 0, 0)))
        col.label(text=f"Version: {version}")
        col.label(text=f"Author: {bl_info.get('author', 'Unknown')}")
        col.label(text=f"Category: {bl_info.get('category', 'Unknown')}")

        col.separator()
        col.label(text="Description:", icon='TEXT')
        col.label(text=bl_info.get('description', ''))

        col.separator()

        # Blender version requirement
        blender_req = bl_info.get('blender', (0, 0, 0))
        col.label(text=f"Requires Blender: {'.'.join(str(v) for v in blender_req)}+")

        # Location info
        col.separator()
        col.label(text="Location:", icon='TRACKER')
        col.label(text=f"  {bl_info.get('location', 'Unknown')}")

        # Documentation link
        col.separator()
        doc_box = layout.box()
        doc_box.label(text="Documentation & Support", icon='HELP')
        row = doc_box.row()
        row.scale_y = 1.5
        row.operator("mhs.open_documentation", text="BlendMHS Documentation", icon='URL')


def get_prefs():
    """Get addon preferences. For use by other modules."""
    return bpy.context.preferences.addons[__package__].preferences


def register():
    bpy.utils.register_class(MHS_AddonPreferences)


def unregister():
    bpy.utils.unregister_class(MHS_AddonPreferences)
