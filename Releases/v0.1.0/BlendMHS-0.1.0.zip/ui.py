from cProfile import label
from msilib.schema import Icon
import bpy
import os
from bpy.types import Panel, UIList, Operator, Menu
from bpy.props import StringProperty, IntProperty, BoolProperty
from . import mhs_statics
from . import cache_tracker


def is_valid_project_path(path):
    """Check if the given path is a valid Horizon project path.

    A valid project path must:
    1. Exist on the filesystem
    2. Contain a .hzproject file (created by Meta Horizon Studio)
       Note: The file is named like ProjectName.hzproject (extension, not filename)

    Returns:
        True if valid project path, False otherwise
    """
    if not path:
        return False
    if not os.path.exists(path):
        return False
    # Look for any file with .hzproject extension (e.g., ProjectName.hzproject)
    try:
        for filename in os.listdir(path):
            if filename.endswith('.hzproject'):
                return True
    except OSError:
        return False
    return False


def has_hzproject_file(path):
    """Check if the given path contains a .hzproject file.
    Returns the filename if found, None otherwise."""
    if not path or not os.path.exists(path):
        return None
    try:
        for filename in os.listdir(path):
            if filename.endswith('.hzproject'):
                return filename
    except OSError:
        return None
    return None


# ═══════════════════════════════════════════════════════════════════════════════
# Pie Menu
# ═══════════════════════════════════════════════════════════════════════════════

class MHS_OT_open_documentation(Operator):
    """Open BlendMHS documentation in your web browser"""
    bl_idname = "mhs.open_documentation"
    bl_label = "BlendMHS Documentation"
    bl_description = "Open BlendMHS documentation in your web browser"

    def execute(self, context):
        import webbrowser
        webbrowser.open("https://xnoltanx.github.io/BlendMHS-docs/")
        return {'FINISHED'}


class MHS_OT_dismiss_layout_hint(Operator):
    """Dismiss the layout setup hint"""
    bl_idname = "mhs.dismiss_layout_hint"
    bl_label = "Dismiss"
    bl_description = "Dismiss this hint (you can always set up layouts later in Layout Setup panel)"

    def execute(self, context):
        context.scene.mhs.layout_hint_dismissed = True
        return {'FINISHED'}


class MHS_OT_open_layout_setup(Operator):
    """Open the Layout Setup panel"""
    bl_idname = "mhs.open_layout_setup"
    bl_label = "Open Layout Setup"
    bl_description = "Dismiss this hint and scroll down to Layout Setup panel"

    def execute(self, context):
        # Dismiss the hint since user is taking action
        context.scene.mhs.layout_hint_dismissed = True

        # Note: Blender doesn't provide an API to programmatically expand/collapse
        # individual panels in the sidebar. The user needs to manually expand
        # the Layout Setup panel below.
        self.report({'INFO'}, "Expand the 'Layout Setup' panel below to configure layouts")

        return {'FINISHED'}


class MHS_MT_quick_export_pie(Menu):
    """Quick Export Pie Menu - accessible via Ctrl+Shift+E"""
    bl_idname = "MHS_MT_quick_export_pie"
    bl_label = "Quick Export"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        scene = context.scene

        # Count items for dynamic labels
        layout_count = sum(1 for le in scene.mhs.layout_exports if le.enabled)
        static_count, animated_count = count_selected_meshes(context)

        # West (left) - Static Meshes
        op = pie.operator("mhs.export_mesh",
                         text=f"Export Meshes ({static_count})",
                         icon='MESH_DATA')

        # East (right) - Animated Meshes
        op = pie.operator("mhs.export_animated_selection",
                         text=f"Export Animated ({animated_count})",
                         icon='ARMATURE_DATA')

        # South (bottom) - Open Project Folder
        pie.operator("mhs.open_export_folder",
                    text="Open Project",
                    icon='FILE_FOLDER')

        # North (top) - Layouts
        op = pie.operator("mhs.export_layout",
                         text=f"Export Layouts ({layout_count})",
                         icon='SCENE_DATA')


class MHS_MT_move_to_collection(Menu):
    """Submenu for moving selected objects to a collection"""
    bl_idname = "MHS_MT_move_to_collection"
    bl_label = "Move to Collection"

    def draw(self, context):
        layout = self.layout

        # "New Collection" option at the top
        layout.operator("mhs.create_collection_from_selection",
                       text="New Collection",
                       icon='ADD')

        layout.separator()

        # List all existing collections
        for collection in bpy.data.collections:
            op = layout.operator("mhs.move_selection_to_collection",
                               text=collection.name,
                               icon='OUTLINER_COLLECTION')
            op.collection_name = collection.name


class MHS_OT_layout_setup_popup(Operator):
    """Layout Setup Popup - accessible via Ctrl+Shift+C"""
    bl_idname = "mhs.layout_setup_popup"
    bl_label = "Layout Setup"
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=280)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Build layer collection map for visibility checking
        layer_coll_map = {}
        self._build_layer_collection_map(context.view_layer.layer_collection, layer_coll_map)

        # Draw the layout list
        self._draw_layout_list(context, layout, scene, layer_coll_map)

    def execute(self, context):
        return {'FINISHED'}

    def _build_layer_collection_map(self, layer_collection, result_map):
        """Recursively build a map of collection name -> layer_collection"""
        result_map[layer_collection.name] = layer_collection
        for child in layer_collection.children:
            self._build_layer_collection_map(child, result_map)

    def _draw_layout_list(self, context, layout, scene, layer_coll_map):
        """Draw the dynamic layout list inside the popup."""
        col = layout.column(align=True)
        col.ui_units_x = 14  # Make the box wider

        # Header row with title only (buttons moved elsewhere)
        header_row = col.row(align=True)
        header_row.label(text="Layouts", icon='SCENE_DATA')

        col.separator()

        if len(scene.mhs.layout_exports) == 0:
            col.label(text="No layouts configured", icon='INFO')
            # Add Layout button at bottom when no layouts exist
            col.separator()
            col.operator("mhs.add_layout_export", text="Add Layout", icon='ADD')
            return

        # Layout list with controls - each layout in its own box
        for index, layout_config in enumerate(scene.mhs.layout_exports):
            # Create a box for each layout
            layout_box = col.box()
            box_col = layout_box.column(align=True)

            # Layout header row - taller for better visibility
            row = box_col.row(align=True)
            row.scale_y = 1.3  # Make the row taller

            # Active layout indicator (emboss on the name button shows active state)
            is_active = (scene.mhs.active_layout_index == index)

            # Enabled checkbox (embossed for visibility)
            icon_enabled = 'CHECKBOX_HLT' if layout_config.enabled else 'CHECKBOX_DEHLT'
            op = row.operator("mhs.toggle_layout_enabled", text="", icon=icon_enabled, emboss=True)
            op.layout_index = index

            # Layout name with collection count (select on click)
            # Use depress=True for active layout to make it visually distinct
            coll_count = len(layout_config.collections)
            name_row = row.row(align=True)
            name_row.scale_x = 1.5  # Make name button wider
            op = name_row.operator("mhs.select_layout", text=f"{layout_config.name} ({coll_count})", emboss=True, depress=is_active)
            op.layout_index = index

            # Visibility toggle
            any_visible = False
            for coll_ref in layout_config.collections:
                if coll_ref.collection:
                    layer_coll = layer_coll_map.get(coll_ref.collection.name)
                    if layer_coll and not layer_coll.hide_viewport:
                        any_visible = True
                        break
            vis_icon = 'HIDE_OFF' if any_visible else 'HIDE_ON'
            op = row.operator("mhs.toggle_layout_visibility", text="", icon=vis_icon, emboss=True)
            op.layout_index = index

            # Solo button
            is_soloed = (scene.mhs.soloed_layout_index == index)
            solo_icon = 'SOLO_ON' if is_soloed else 'SOLO_OFF'
            op = row.operator("mhs.solo_layout_visibility", text="", icon=solo_icon, emboss=True)
            op.layout_index = index

            # Export button
            op = row.operator("mhs.export_single_layout", text="", icon='EXPORT', emboss=True)
            op.layout_index = index

            # Remove layout button (X) with confirmation
            op = row.operator("mhs.remove_layout_export", text="", icon='X', emboss=True)
            op.layout_index = index

            # Small separator before collections
            box_col.separator(factor=0.5)

            # Show collections under this layout (indented) with +/- buttons and object count
            if len(layout_config.collections) > 0:
                # Get selected objects once for efficiency
                selected_objects = context.selected_objects
                selected_names = {obj.name for obj in selected_objects}

                for coll_ref in layout_config.collections:
                    if coll_ref.collection:
                        coll_row = box_col.row(align=True)
                        coll_row.separator(factor=2.0)  # Indent

                        # Collection name with object count (on left side)
                        obj_count = len(coll_ref.collection.objects)
                        coll_row.label(text=f"└ {coll_ref.collection.name} ({obj_count})", icon='OUTLINER_COLLECTION')

                        # Determine which buttons to show based on selection
                        coll_object_names = {obj.name for obj in coll_ref.collection.objects}

                        # Check if any selected objects are NOT in this collection (show +)
                        any_selected_not_in_coll = bool(selected_names - coll_object_names)
                        # Check if any selected objects ARE in this collection (show -)
                        any_selected_in_coll = bool(selected_names & coll_object_names)

                        # Add (+) button - only show if there are selected objects not in collection
                        if any_selected_not_in_coll:
                            op = coll_row.operator("mhs.add_selection_to_collection", text="", icon='ADD', emboss=True)
                            op.collection_name = coll_ref.collection.name

                        # Remove (-) button - only show if there are selected objects in collection
                        if any_selected_in_coll:
                            op = coll_row.operator("mhs.remove_selection_from_collection", text="", icon='REMOVE', emboss=True)
                            op.collection_name = coll_ref.collection.name

            # Add Collection button at bottom of each layout's collection list
            add_coll_row = box_col.row(align=True)
            add_coll_row.separator(factor=3.5)  # Indent more to not align with +/- buttons
            op = add_coll_row.operator("mhs.add_collection_to_layout", text="Add Collection", icon='COLLECTION_NEW')
            op.layout_index = index

            # Add separator between layout boxes for visual separation
            col.separator(factor=0.3)

        # Add Layout button at the bottom of all layouts
        col.separator()
        col.operator("mhs.add_layout_export", text="Add Layout", icon='ADD')

        # Separator between Add Layout and Export button
        col.separator(factor=1.5)

        # Export Selected Layouts button (exports all enabled layouts)
        enabled_count = sum(1 for le in scene.mhs.layout_exports if le.enabled)
        export_row = col.row()
        export_row.scale_y = 1.5
        export_row.enabled = enabled_count > 0
        export_row.operator("mhs.export_layout", text=f"Export Layouts ({enabled_count})", icon='EXPORT')


def draw_export_status_bar(layout, scene):
    """Draw compact export status bar with popup button in a box.

    Two-row layout:
    Row 1: "Last Export:" label + Info button
    Row 2: Columns for Exported | Cached | Time with icons below counts

    Args:
        layout: Blender UI layout to draw into
        scene: Blender scene for accessing stats
    """
    box = layout.box()

    # Row 1: Header with Info button
    row = box.row(align=True)
    row.label(text="Last Export:")
    row.operator("mhs.show_export_results", text="", icon='INFO')

    if scene.mhs.last_export_total > 0:
        exported = scene.mhs.last_export_exported
        skipped = scene.mhs.last_export_skipped
        total_time = scene.mhs.last_export_total_time

        # Row 2: Three columns - Exported | Cached | Time
        row = box.row(align=True)

        # Column 1: Exported
        col = row.column(align=True)
        col.label(text=f"{exported} exported")
        # Icons row for exported types (use split to give each icon space)
        icon_row = col.row(align=True)
        if scene.mhs.last_export_layouts_exported > 0:
            icon_row.label(text="", icon='SCENE_DATA')
        if scene.mhs.last_export_meshes_exported > 0:
            icon_row.label(text="", icon='MESH_DATA')
        if scene.mhs.last_export_materials_exported > 0:
            icon_row.label(text="", icon='MATERIAL')
        if scene.mhs.last_export_textures_exported > 0:
            icon_row.label(text="", icon='TEXTURE')
        if scene.mhs.last_export_animations_exported > 0:
            icon_row.label(text="", icon='ARMATURE_DATA')
        # Add empty label if no icons to maintain row height
        if exported == 0:
            icon_row.label(text="")

        # Column 2: Cached
        col = row.column(align=True)
        col.label(text=f"{skipped} cached")
        # Icons row for cached types
        icon_row = col.row(align=True)
        if scene.mhs.last_export_layouts_skipped > 0:
            icon_row.label(text="", icon='SCENE_DATA')
        if scene.mhs.last_export_meshes_skipped > 0:
            icon_row.label(text="", icon='MESH_DATA')
        if scene.mhs.last_export_materials_skipped > 0:
            icon_row.label(text="", icon='MATERIAL')
        if scene.mhs.last_export_textures_skipped > 0:
            icon_row.label(text="", icon='TEXTURE')
        if scene.mhs.last_export_animations_skipped > 0:
            icon_row.label(text="", icon='ARMATURE_DATA')
        # Add empty label if no icons to maintain row height
        if skipped == 0:
            icon_row.label(text="")

        # Column 3: Time
        col = row.column(align=True)
        col.label(text=f"{total_time:.1f}s")
        col.label(text="")  # Empty row to align with icons
    else:
        row = box.row()
        row.label(text="No exports yet")


def draw_export_results(layout, scene, export_type='layout'):
    """Draw export results UI. Reusable for different export types.

    Args:
        layout: Blender UI layout to draw into
        scene: Blender scene for accessing stats
        export_type: 'layout', 'mesh', or 'animated_mesh' - determines which stats to show
    """
    if not scene.mhs.show_export_stats:
        return

    # Read stats from scene properties for persistence
    stats = {
        'exported': scene.mhs.last_export_exported,
        'skipped': scene.mhs.last_export_skipped,
        'total': scene.mhs.last_export_total,
        'time_saved': scene.mhs.last_export_time_saved,
        'total_time': scene.mhs.last_export_total_time,
        'layouts': {
            'exported': scene.mhs.last_export_layouts_exported,
            'skipped': scene.mhs.last_export_layouts_skipped
        },
        'meshes': {
            'exported': scene.mhs.last_export_meshes_exported,
            'skipped': scene.mhs.last_export_meshes_skipped
        },
        'materials': {
            'exported': scene.mhs.last_export_materials_exported,
            'skipped': scene.mhs.last_export_materials_skipped
        },
        'textures': {
            'exported': scene.mhs.last_export_textures_exported,
            'skipped': scene.mhs.last_export_textures_skipped
        }
    }

    box = layout.box()
    row = box.row()
    row.label(text="Export Results", icon='CHECKMARK')
    # Close button (embossed)
    row.prop(scene.mhs, "show_export_stats", text="", icon='X', emboss=True)

    # Use a grid-like layout for better readability (3 columns for uniformity)
    summary_col = box.column(align=False)

    row = summary_col.row()
    row.label(text="Exported:")
    row.label(text=f"{stats['exported']}")
    row.label(text="")

    row = summary_col.row()
    row.label(text="Cache Hits:")
    row.label(text=f"{stats['skipped']}")
    row.label(text="")

    row = summary_col.row()
    row.label(text="Time Saved:")
    row.label(text=f"~{stats['time_saved']:.1f}s")
    row.label(text="")

    row = summary_col.row()
    row.label(text="Total Time:")
    row.label(text=f"{stats['total_time']:.2f}s")
    row.label(text="")

    # Progress-style visual showing cache hit rate
    if stats['total'] > 0:
        skip_pct = (stats['skipped'] / stats['total']) * 100
        row = summary_col.row()
        row.label(text="Cache Hit Rate:")
        row.label(text=f"{skip_pct:.0f}%")
        row.label(text="")

    # Breakdown by type - show different sections based on export_type
    summary_col.separator()
    breakdown_col = box.column(align=False)

    if export_type == 'layout':
        # Show all types for layout export
        row = breakdown_col.row()
        row.label(text="Layouts:", icon='SCENE_DATA')
        row.label(text=f"{stats['layouts']['exported']} exported")
        row.label(text=f"{stats['layouts']['skipped']} cached")

        row = breakdown_col.row()
        row.label(text="Meshes:", icon='MESH_DATA')
        row.label(text=f"{stats['meshes']['exported']} exported")
        row.label(text=f"{stats['meshes']['skipped']} cached")

        row = breakdown_col.row()
        row.label(text="Materials:", icon='MATERIAL')
        if stats['materials']['exported'] == 0 and stats['materials']['skipped'] == 0:
            row.label(text="N/A")
            row.label(text="(meshes cached)")
        else:
            row.label(text=f"{stats['materials']['exported']} exported")
            row.label(text=f"{stats['materials']['skipped']} cached")

        row = breakdown_col.row()
        row.label(text="Textures:", icon='TEXTURE')
        if stats['textures']['exported'] == 0 and stats['textures']['skipped'] == 0:
            row.label(text="N/A")
            row.label(text="(materials cached)")
        else:
            row.label(text=f"{stats['textures']['exported']} exported")
            row.label(text=f"{stats['textures']['skipped']} cached")

    elif export_type in ('mesh', 'animated_mesh'):
        # Show mesh-relevant types only
        row = breakdown_col.row()
        row.label(text="Meshes:", icon='MESH_DATA')
        row.label(text=f"{stats['meshes']['exported']} exported")
        row.label(text=f"{stats['meshes']['skipped']} cached")

        row = breakdown_col.row()
        row.label(text="Materials:", icon='MATERIAL')
        if stats['materials']['exported'] == 0 and stats['materials']['skipped'] == 0:
            row.label(text="N/A")
            row.label(text="(meshes cached)")
        else:
            row.label(text=f"{stats['materials']['exported']} exported")
            row.label(text=f"{stats['materials']['skipped']} cached")

        row = breakdown_col.row()
        row.label(text="Textures:", icon='TEXTURE')
        if stats['textures']['exported'] == 0 and stats['textures']['skipped'] == 0:
            row.label(text="N/A")
            row.label(text="(materials cached)")
        else:
            row.label(text=f"{stats['textures']['exported']} exported")
            row.label(text=f"{stats['textures']['skipped']} cached")


class MHS_UL_animation_actions(UIList):
    """Enhanced UIList for displaying animation actions with filtering and metadata"""

    def _get_armature(self, context):
        """Get the armature from context"""
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def draw_filter(self, context, layout):
        """Draw the filter bar with search, tag filter, and sort options"""
        obj = context.object
        if not obj or not hasattr(obj, 'mhs'):
            return

        # Get the armature (might be the object itself or via modifier)
        armature = None
        if obj.type == 'ARMATURE':
            armature = obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    armature = modifier.object
                    break

        if not armature:
            return

        # Main filter row
        row = layout.row(align=True)

        # Name filter with search icon
        sub = row.row(align=True)
        sub.prop(armature.mhs, "action_filter_name", text="", icon='VIEWZOOM')

        # Tag filter
        sub = row.row(align=True)
        sub.prop(armature.mhs, "action_filter_tag", text="", icon='BOOKMARKS')

        # Filter options row
        row = layout.row(align=True)

        # Tag exclusive toggle (AND vs OR)
        sub = row.row(align=True)
        sub.scale_x = 0.8
        exclusive_icon = 'FULLSCREEN_ENTER' if armature.mhs.action_filter_tag_exclusive else 'FULLSCREEN_EXIT'
        sub.prop(armature.mhs, "action_filter_tag_exclusive", text="", icon=exclusive_icon, toggle=True)

        # Invert filter toggle
        sub = row.row(align=True)
        sub.scale_x = 0.8
        invert_icon = 'ARROW_LEFTRIGHT' if armature.mhs.action_filter_invert else 'BLANK1'
        sub.prop(armature.mhs, "action_filter_invert", text="", icon=invert_icon, toggle=True)

        # Alphabetical sort toggle
        sub = row.row(align=True)
        sub.scale_x = 0.8
        sort_icon = 'SORTALPHA' if armature.mhs.action_sort_alphabetical else 'SORTTIME'
        sub.prop(armature.mhs, "action_sort_alphabetical", text="", icon=sort_icon, toggle=True)

    def filter_items(self, context, data, propname):
        """Multi-layer filtering: name + tag with optional inversion and sorting"""
        items = getattr(data, propname)
        helper_funcs = bpy.types.UI_UL_list

        # Initialize with all items visible
        filtered = [self.bitflag_filter_item] * len(items)
        ordered = list(range(len(items)))

        # Get filter settings from the armature
        obj = context.object
        if not obj:
            return filtered, ordered

        # Find the armature
        armature = None
        if obj.type == 'ARMATURE':
            armature = obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    armature = modifier.object
                    break

        if not armature or not hasattr(armature, 'mhs'):
            return filtered, ordered

        filter_name = armature.mhs.action_filter_name.lower().strip()
        filter_tag = armature.mhs.action_filter_tag.lower().strip()
        exclusive = armature.mhs.action_filter_tag_exclusive
        invert = armature.mhs.action_filter_invert
        sort_alpha = armature.mhs.action_sort_alphabetical

        # Apply filters
        for i, item in enumerate(items):
            # Handle LABEL and FOLDER slot types - always show them
            if hasattr(item, 'slot_type') and item.slot_type in ('LABEL', 'FOLDER'):
                continue

            # Skip items without valid actions
            if not item.action:
                filtered[i] &= ~self.bitflag_filter_item
                continue

            # Layer 1: Name filter
            match_name = True
            if filter_name:
                action_name = item.action.name.lower()
                # Also check custom_name if set
                custom_name = item.custom_name.lower() if hasattr(item, 'custom_name') and item.custom_name else ""
                match_name = filter_name in action_name or filter_name in custom_name

            # Layer 2: Tag filter
            match_tag = True
            if filter_tag:
                # Parse item tags
                item_tags_str = item.tags if hasattr(item, 'tags') else ""
                item_tags = set(t.strip().lower() for t in item_tags_str.split(',') if t.strip())

                # Parse filter tags
                filter_tags = set(t.strip().lower() for t in filter_tag.split(',') if t.strip())

                if exclusive:
                    # All filter tags must be present in item tags (AND logic)
                    match_tag = filter_tags.issubset(item_tags)
                else:
                    # Any filter tag matches any item tag (OR logic)
                    match_tag = bool(filter_tags & item_tags)

            # Combine filters
            matches = match_name and match_tag

            # Apply inversion if enabled
            if invert:
                matches = not matches

            if not matches:
                filtered[i] &= ~self.bitflag_filter_item

        # Apply alphabetical sorting if enabled
        if sort_alpha:
            def get_sort_key(idx):
                item = items[idx]
                if not item.action:
                    return "zzz"  # Put missing actions at end
                # Use custom_name if set, otherwise action name
                if hasattr(item, 'custom_name') and item.custom_name:
                    return item.custom_name.lower()
                return item.action.name.lower()

            ordered = sorted(range(len(items)), key=get_sort_key)

        return filtered, ordered

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # Handle LABEL slot type - draw as separator
            if hasattr(item, 'slot_type') and item.slot_type == 'LABEL':
                row = layout.row(align=True)
                row.alignment = 'CENTER'
                label_text = item.label if hasattr(item, 'label') and item.label else "---"
                row.label(text=f"── {label_text} ──")
                # Remove button for label
                op = row.operator("mhs.remove_animation_action", text="", icon='X', emboss=False)
                op.action_index = index
                return

            row = layout.row(align=True)

            # Export enabled checkbox
            icon_enabled = 'CHECKBOX_HLT' if item.enabled else 'CHECKBOX_DEHLT'
            row.prop(item, "enabled", text="", icon=icon_enabled, emboss=False)

            # Play/Stop button - show stop if this action is currently playing
            is_this_action_playing = False
            if item.action and context.screen.is_animation_playing:
                # Check if armature's active action matches this item's action
                armature = self._get_armature(context)
                if armature and armature.animation_data and armature.animation_data.action == item.action:
                    is_this_action_playing = True

            if is_this_action_playing:
                op = row.operator("mhs.stop_action", text="", icon='SNAP_FACE', emboss=False)
            else:
                op = row.operator("mhs.play_action", text="", icon='PLAY', emboss=False)
                op.action_index = index

            # Action name (use custom_name if set, otherwise action name)
            if item.action:
                display_name = item.custom_name if (hasattr(item, 'custom_name') and item.custom_name) else item.action.name
                row.label(text=display_name)

                # Frame range display [start-end]
                if hasattr(item, 'use_custom_range') and item.use_custom_range:
                    frame_text = f"[{item.frame_start}-{item.frame_end}]"
                elif item.action.fcurves:
                    # Calculate frame range from action
                    frame_range = item.action.frame_range
                    frame_text = f"[{int(frame_range[0])}-{int(frame_range[1])}]"
                else:
                    frame_text = "[0-0]"

                sub = row.row(align=True)
                sub.scale_x = 0.6
                sub.label(text=frame_text)

                # Tags display (compact)
                if hasattr(item, 'tags') and item.tags:
                    sub = row.row(align=True)
                    sub.scale_x = 0.8
                    # Truncate tags if too long
                    tags_display = item.tags[:15] + "..." if len(item.tags) > 15 else item.tags
                    sub.label(text=tags_display)
            else:
                row.label(text="(missing action)")

            # Duplicate button for this action (embossed)
            op = row.operator("mhs.duplicate_action", text="", icon='DUPLICATE', emboss=True)
            op.action_index = index

            # Remove button for this action (embossed)
            op = row.operator("mhs.remove_animation_action", text="", icon='X', emboss=True)
            op.action_index = index

        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.prop(item, "enabled", text="")


class MHS_UL_animated_objects(UIList):
    """UIList for displaying animated objects (mesh :: armature) in the scene"""
    bl_idname = "MHS_UL_animated_objects"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # Show armature name and mesh name in three columns: armature | pipe | object
            mesh_name = item.mesh_object.name if item.mesh_object else "???"
            armature_name = item.armature_object.name if item.armature_object else "???"

            # Check if this item's armature or mesh is currently selected
            is_selected = (context.active_object == item.armature_object or
                          context.active_object == item.mesh_object)

            row = layout.row(align=True)

            # Main content split (85% for names, 15% for visibility buttons)
            main_split = row.split(factor=0.85)
            names_row = main_split.row(align=True)

            # Use split for three columns: armature name | pipe | object name
            # Left column (45%) - Armature name with icon (BLANK1 for non-selected to maintain alignment)
            split = names_row.split(factor=0.45)
            left = split.row()
            left.alignment = 'LEFT'
            armature_icon = 'ARMATURE_DATA' if is_selected else 'BLANK1'
            left.label(text=armature_name, icon=armature_icon)

            # Right side split for pipe and object name
            right_split = split.split(factor=0.1)

            # Center column (small) - Pipe separator
            center = right_split.row()
            center.alignment = 'CENTER'
            center.label(text="|")

            # Right column - Object name with icon (BLANK1 for non-selected to maintain alignment)
            right = right_split.row()
            right.alignment = 'LEFT'
            mesh_icon = 'OUTLINER_OB_MESH' if is_selected else 'BLANK1'
            right.label(text=mesh_name, icon=mesh_icon)

            # Visibility controls column (far right)
            vis_row = main_split.row(align=True)

            # Determine visibility icon based on current state
            any_visible = False
            if item.mesh_object and not item.mesh_object.hide_viewport:
                any_visible = True
            if item.armature_object and not item.armature_object.hide_viewport:
                any_visible = True
            vis_icon = 'HIDE_OFF' if any_visible else 'HIDE_ON'

            # Toggle visibility button
            op = vis_row.operator("mhs.toggle_animated_object_visibility", text="", icon=vis_icon, emboss=False)
            op.index = index

            # Solo button - show different icon if this object is soloed
            is_soloed = (context.scene.mhs.soloed_animated_object_index == index)
            solo_icon = 'SOLO_ON' if is_soloed else 'SOLO_OFF'
            op = vis_row.operator("mhs.solo_animated_object_visibility", text="", icon=solo_icon, emboss=False)
            op.index = index

        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='ARMATURE_DATA')


class MHS_OT_refresh_animated_objects(Operator):
    """Refresh the list of animated objects in the scene"""
    bl_idname = "mhs.refresh_animated_objects"
    bl_label = "Refresh Animated Objects"
    bl_description = "Scan the scene and update the list of animated objects (meshes with armatures)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene

        # Clear existing list
        scene.mhs.animated_objects.clear()

        # Find all meshes with armature modifiers
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                for modifier in obj.modifiers:
                    if modifier.type == 'ARMATURE' and modifier.object:
                        # Add to the list
                        item = scene.mhs.animated_objects.add()
                        item.mesh_object = obj
                        item.armature_object = modifier.object
                        break  # Only add once per mesh

        count = len(scene.mhs.animated_objects)
        self.report({'INFO'}, f"Found {count} animated object(s)")
        return {'FINISHED'}


class MHS_OT_select_animated_object(Operator):
    """Select the armature associated with the animated object"""
    bl_idname = "mhs.select_animated_object"
    bl_label = "Select Animated Object"
    bl_description = "Select the armature in the outliner"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(
        name="Index",
        description="Index of the animated object to select",
        default=0
    )

    def execute(self, context):
        scene = context.scene

        if self.index < 0 or self.index >= len(scene.mhs.animated_objects):
            self.report({'WARNING'}, "Invalid index")
            return {'CANCELLED'}

        item = scene.mhs.animated_objects[self.index]

        if not item.armature_object:
            self.report({'WARNING'}, "No armature found for this object")
            return {'CANCELLED'}

        # Deselect all objects
        bpy.ops.object.select_all(action='DESELECT')

        # Select the armature
        item.armature_object.select_set(True)
        context.view_layer.objects.active = item.armature_object

        self.report({'INFO'}, f"Selected armature: {item.armature_object.name}")
        return {'FINISHED'}


class MHS_OT_refresh_animation_actions(Operator):
    """Remove deleted actions from the animation export list"""
    bl_idname = "mhs.refresh_animation_actions"
    bl_label = "Clean Invalid Actions"
    bl_description = "Remove any actions that have been deleted from the blend file"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}

        # Get the armature
        if obj.type == 'ARMATURE':
            armature = obj
        elif obj.type == 'MESH':
            armature = None
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    armature = modifier.object
                    break
        else:
            self.report({'WARNING'}, "Select a mesh with armature or an armature")
            return {'CANCELLED'}

        if not armature:
            self.report({'WARNING'}, "No armature found")
            return {'CANCELLED'}

        # Find actions to remove: ONLY actions that no longer exist in bpy.data.actions
        all_blender_actions = set(bpy.data.actions)
        indices_to_remove = []
        for i, item in enumerate(armature.mhs.animation_export_actions):
            if item.action and item.action not in all_blender_actions:
                indices_to_remove.append(i)

        # Remove deleted actions (iterate backwards to avoid index issues)
        for i in sorted(indices_to_remove, reverse=True):
            armature.mhs.animation_export_actions.remove(i)

        removed_count = len(indices_to_remove)

        if removed_count > 0:
            self.report({'INFO'}, f"Removed {removed_count} deleted actions (total: {len(armature.mhs.animation_export_actions)})")
        else:
            self.report({'INFO'}, f"No invalid actions found ({len(armature.mhs.animation_export_actions)} actions)")
        return {'FINISHED'}


class MHS_OT_select_all_animation_actions(Operator):
    """Select all animation actions for export"""
    bl_idname = "mhs.select_all_animation_actions"
    bl_label = "Select All"
    bl_description = "Enable all actions for export"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        armature = self._get_armature(context)
        if not armature:
            return {'CANCELLED'}

        for item in armature.mhs.animation_export_actions:
            item.enabled = True

        return {'FINISHED'}

    def _get_armature(self, context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None


class MHS_OT_deselect_all_animation_actions(Operator):
    """Deselect all animation actions for export"""
    bl_idname = "mhs.deselect_all_animation_actions"
    bl_label = "Deselect All"
    bl_description = "Disable all actions for export"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        armature = self._get_armature(context)
        if not armature:
            return {'CANCELLED'}

        for item in armature.mhs.animation_export_actions:
            item.enabled = False

        return {'FINISHED'}

    def _get_armature(self, context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None


class MHS_OT_remove_animation_action(Operator):
    """Remove action from this object. Shift+Click to remove entirely from blend file"""
    bl_idname = "mhs.remove_animation_action"
    bl_label = "Remove Action"
    bl_description = "Remove Action Slot from this Object. Shift+Click to Remove Action from Blend File"
    bl_options = {'REGISTER', 'UNDO'}

    action_index: IntProperty(
        name="Action Index",
        description="Index of the action to remove",
        default=-1
    )

    remove_from_file: BoolProperty(
        name="Remove from Blend File",
        description="Remove the action entirely from the blend file",
        default=False
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        return len(armature.mhs.animation_export_actions) > 0

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def invoke(self, context, event):
        # Check if shift is held
        self.remove_from_file = event.shift

        if self.remove_from_file:
            # Show confirmation dialog
            return context.window_manager.invoke_confirm(self, event)
        else:
            return self.execute(context)

    def execute(self, context):
        armature = self._get_armature_static(context)
        if not armature:
            self.report({'WARNING'}, "No armature found")
            return {'CANCELLED'}

        # Use action_index if provided, otherwise fall back to active index
        idx = self.action_index if self.action_index >= 0 else armature.mhs.active_animation_action_index

        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            self.report({'WARNING'}, "No action selected")
            return {'CANCELLED'}

        action_item = armature.mhs.animation_export_actions[idx]
        action = action_item.action
        action_name = action.name if action else "Unknown"

        if self.remove_from_file and action:
            # Remove action from blend file entirely
            bpy.data.actions.remove(action)
            self.report({'INFO'}, f"Removed action '{action_name}' from blend file")
        else:
            self.report({'INFO'}, f"Removed action '{action_name}' from export list")

        # Remove from the list
        armature.mhs.animation_export_actions.remove(idx)

        # Adjust active index
        if armature.mhs.active_animation_action_index >= len(armature.mhs.animation_export_actions):
            armature.mhs.active_animation_action_index = max(0, len(armature.mhs.animation_export_actions) - 1)

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        armature = self._get_armature_static(context)
        if armature:
            idx = self.action_index if self.action_index >= 0 else armature.mhs.active_animation_action_index
            if 0 <= idx < len(armature.mhs.animation_export_actions):
                action = armature.mhs.animation_export_actions[idx].action
                if action:
                    layout.label(text=f"Delete action '{action.name}' from blend file?", icon='ERROR')
                    layout.label(text="This cannot be undone!")


def count_selected_meshes(context):
    """Count selected static and animated meshes"""
    static_count = 0
    animated_count = 0

    for obj in context.selected_objects:
        if obj.type == 'ARMATURE':
            animated_count += 1
        elif obj.type == 'MESH':
            # Check if has armature modifier
            has_armature = any(mod.type == 'ARMATURE' for mod in obj.modifiers)
            if has_armature:
                animated_count += 1
            else:
                static_count += 1

    return static_count, animated_count


class MHS_PT_quick_export_panel(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BlendMHS"
    bl_label = "Quick Export"
    bl_parent_id = "MHS_PT_base_panel"
    bl_options = set()  # No options = always open by default

    @classmethod
    def poll(cls, context):
        """Only show when a valid project path is set"""
        return is_valid_project_path(context.scene.mhs.project_path)

    def draw_header(self, context):
        self.layout.label(icon='EXPORT')

    def draw_header_preset(self, context):
        """Draw content on the far right of the panel header"""
        layout = self.layout
        scene = context.scene
        is_active = scene.mhs.auto_export_layout_on_save

        # Auto-save toggle button (far right of panel header)
        row = layout.row(align=True)
        row.alert = is_active  # Highlight when active
        row.prop(scene.mhs, "auto_export_layout_on_save", text="", icon='FILE_TICK')

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Status bar row at top
        draw_export_status_bar(layout, scene)

        layout.separator()

        # Count enabled layouts
        layout_count = sum(1 for le in scene.mhs.layout_exports if le.enabled)

        # Layouts button row (full width, tall) with Auto-Export toggle on right
        row = layout.row(align=True)
        row.scale_y = 2.0

        # Main export button takes most space
        sub = row.row(align=True)
        sub.scale_x = 3.0
        sub.enabled = layout_count > 0 and scene.mhs.project_path != ""
        sub.operator("mhs.export_layout", text=f"Export Layouts ({layout_count})", icon='SCENE_DATA')

        # Auto-export toggle (larger button on the right with save icon)
        sub = row.row(align=True)
        sub.scale_x = 1.5
        sub.prop(scene.mhs, "auto_export_layout_on_save", text="", icon='FILE_TICK', toggle=True)

        # Static + Animated row (side by side, tall, connected)
        static_count, animated_count = count_selected_meshes(context)

        row = layout.row(align=True)
        row.scale_y = 2.0

        # Static meshes button
        sub = row.row(align=True)
        sub.enabled = static_count > 0 and scene.mhs.project_path != ""
        sub.operator("mhs.export_mesh", text=f"Export Meshes ({static_count})", icon='MESH_DATA')

        # Animated meshes button (connected to static meshes button)
        sub = row.row(align=True)
        sub.enabled = animated_count > 0 and scene.mhs.project_path != ""
        sub.operator("mhs.export_animated_selection", text=f"Export Animated ({animated_count})", icon='ARMATURE_DATA')

        # Export Options (collapsible, hidden by default)
        box = layout.box()
        row = box.row()
        row.prop(scene.mhs, "show_export_options",
                 icon='TRIA_DOWN' if scene.mhs.show_export_options else 'TRIA_RIGHT',
                 text="Export Options", emboss=False)

        if scene.mhs.show_export_options:
            col = box.column(align=True)
            row = col.row(align=True)
            row.operator(
                "mhs.toggle_force_rebuild",
                text="Force Rebuild (ignore cache)",
                icon='CHECKBOX_HLT' if scene.mhs.force_rebuild else 'CHECKBOX_DEHLT',
                depress=scene.mhs.force_rebuild
            )
            row.operator("mhs.clear_cache", text="", icon='TRASH')

            # Open project folder button
            col.separator()
            col.operator("mhs.open_export_folder", text="Open Project Folder", icon='FILE_FOLDER')

            # Purge Section
            col.separator()
            purge_box = box.box()
            purge_box.label(text="⚠️ Purge Project Files", icon='ERROR')

            purge_col = purge_box.column(align=True)
            purge_col.label(text="This will DELETE exported files!")

            # Show total file count
            project_path = scene.mhs.project_path
            if project_path and os.path.exists(project_path):
                total_files = 0
                folders = [
                    scene.mhs.layouts_folder,
                    scene.mhs.meshes_folder,
                    scene.mhs.animation_folder,
                    scene.mhs.materials_folder,
                    scene.mhs.textures_folder,
                ]
                for folder_name in folders:
                    folder_path = os.path.join(project_path, folder_name)
                    total_files += get_folder_file_count(folder_path)

                # Check for cache file
                cache = cache_tracker.get_cache()
                cache_file_path = cache.get_cache_filepath()
                if cache_file_path and os.path.exists(cache_file_path):
                    total_files += 1

                purge_col.label(text=f"Total: {total_files} files across all folders")

            purge_col.separator()
            row = purge_col.row()
            row.scale_y = 1.5
            row.alert = True
            row.operator("mhs.purge_project", text="Purge All Project Files...", icon='ERROR')


# Helper function to count files in a folder
def get_folder_file_count(folder_path):
    """Count files in a folder recursively"""
    if not os.path.exists(folder_path):
        return 0
    count = 0
    for root, dirs, files in os.walk(folder_path):
        count += len(files)
    return count


class MHS_PT_project_management_panel(Panel):
    """Panel for project folder management, cache control, and purge functionality"""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BlendMHS"
    bl_label = "Project Management"
    bl_parent_id = "MHS_PT_base_panel"
    bl_options = set()  # No options = always open by default (first panel users see)

    @classmethod
    def poll(cls, context):
        """Only show when a valid project path is set"""
        return is_valid_project_path(context.scene.mhs.project_path)

    def draw_header(self, context):
        self.layout.label(icon='FILE_FOLDER')

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        project_path = scene.mhs.project_path

        # Project Path at the top of Project Management panel
        path_box = layout.box()
        row = path_box.row()
        row.label(text="Project Path:", icon='CHECKMARK')
        path_box.prop(scene.mhs, "project_path", text="")


        # Folder Structure visualization
        box = layout.box()
        box.label(text="Folder Structure", icon='OUTLINER')

        col = box.column(align=True)

        # Show project root - strip trailing separators to get correct basename
        project_name = os.path.basename(project_path.rstrip('/\\')) or 'project_root'
        col.label(text=f"📁 {project_name}/")

        # Show subfolders with file counts
        folders = [
            (scene.mhs.layouts_folder, 'SCENE_DATA'),
            (scene.mhs.meshes_folder, 'MESH_DATA'),
            (scene.mhs.animation_folder, 'ARMATURE_DATA'),
            (scene.mhs.materials_folder, 'MATERIAL'),
            (scene.mhs.textures_folder, 'TEXTURE'),
        ]

        for folder_name, icon in folders:
            folder_path = os.path.join(project_path, folder_name)
            count = get_folder_file_count(folder_path)
            exists = os.path.exists(folder_path)

            row = col.row()
            row.label(text=f"    ├── 📁 {folder_name}/")
            if exists:
                row.label(text=f"{count} files")
            else:
                row.label(text="(not created)")

        # Folder Paths Section (collapsible)
        folder_box = layout.box()
        row = folder_box.row()
        row.prop(scene.mhs, "show_folder_paths",
                 icon='TRIA_DOWN' if scene.mhs.show_folder_paths else 'TRIA_RIGHT',
                 text="Folder Paths", emboss=False)

        if scene.mhs.show_folder_paths:
            col = folder_box.column(align=True)
            col.prop(scene.mhs, "layouts_folder", text="Layouts")
            col.prop(scene.mhs, "meshes_folder", text="Meshes")
            col.prop(scene.mhs, "animation_folder", text="Animation")
            col.prop(scene.mhs, "materials_folder", text="Materials")
            col.prop(scene.mhs, "textures_folder", text="Textures")

            # Hint about {layout} syntax
            col.separator()
            hint_box = folder_box.box()
            hint_col = hint_box.column(align=True)
            hint_col.scale_y = 0.8
            hint_col.label(text="💡 Use {layout} for per-layout subfolders", icon='INFO')
            hint_col.label(text="   e.g., materials/{layout} → materials/MyLayout")

            row = folder_box.row()
            row.operator("mhs.reset_folder_paths", text="Reset to Defaults", icon='FILE_REFRESH')

        # Advanced Section (collapsible - contains Cache and Purge)
        adv_box = layout.box()
        row = adv_box.row()
        row.prop(scene.mhs, "show_advanced_options",
                 icon='TRIA_DOWN' if scene.mhs.show_advanced_options else 'TRIA_RIGHT',
                 text="Advanced", emboss=False)

        if scene.mhs.show_advanced_options:
            # Cache Section
            cache_box = adv_box.box()
            cache_box.label(text="Cache", icon='FILE_CACHE')

            # Get cache info using the proper method
            cache = cache_tracker.get_cache()
            cache_stats = cache.get_stats()
            cache_entries = cache_stats.get('file_count', 0)

            col = cache_box.column(align=True)
            col.label(text=f"Cached Files: {cache_entries} entries")

            row = col.row()
            row.operator("mhs.clear_cache", text="Clear Cache", icon='TRASH')

            # Purge Section
            purge_box = adv_box.box()
            purge_box.label(text="⚠️ Purge Project Files", icon='ERROR')

            col = purge_box.column(align=True)
            col.label(text="This will DELETE exported files!")

            # Show total file count
            total_files = 0
            for folder_name, _ in folders:
                folder_path = os.path.join(project_path, folder_name)
                total_files += get_folder_file_count(folder_path)

            # Check for cache file
            cache_file_path = cache.get_cache_filepath()
            if cache_file_path and os.path.exists(cache_file_path):
                total_files += 1

            col.label(text=f"Total: {total_files} files across all folders")

            col.separator()
            row = col.row()
            row.scale_y = 1.5
            row.alert = True
            row.operator("mhs.purge_project", text="Purge All Project Files...", icon='ERROR')


class MHS_PT_base_panel(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BlendMHS"
    bl_label = ""

    def draw_header(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.label(text="BlendMHS")
        row.operator("mhs.open_documentation", text="", icon='QUESTION')

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        project_path = scene.mhs.project_path

        # Check if we have a valid project path
        if is_valid_project_path(project_path):
            # Valid project path - show layout setup hint if needed
            # Layout setup hint (dismissible)
            # Only show if: not dismissed, AND no layouts configured
            has_layouts = len(scene.mhs.layout_exports) > 0
            if not scene.mhs.layout_hint_dismissed and not has_layouts:
                hint_box = layout.box()
                hint_box.alert = False

                # Header row with dismiss button
                row = hint_box.row()
                row.label(text="💡 Tip: Set up Layouts for Export", icon='INFO')
                row.operator("mhs.dismiss_layout_hint", text="", icon='X', emboss=False)

                # Description
                col = hint_box.column()
                col.label(text="Use the Layout Setup Panel to export scene compositions to MHS.")

                # Button to dismiss
                col.separator()
                row = col.row()
                row.scale_y = 1.5
                row.operator("mhs.open_layout_setup", text="Got it!", icon='CHECKMARK')
        else:
            # No valid project path - show onboarding UI
            self._draw_onboarding_ui(layout, scene, project_path)

    def _draw_onboarding_ui(self, layout, scene, project_path):
        """Draw the new user experience onboarding UI"""

        # Combined Welcome and Getting Started box
        welcome_box = layout.box()
        welcome_box.label(text="Welcome to BlendMHS!", icon='HEART')
        welcome_box.label(text="Export Blender scenes to Meta Horizon Studio format")
        welcome_box.separator()
        welcome_box.label(text="Getting Started", icon='INFO')
        welcome_box.label(text="Select your MHS project folder")

        layout.separator()

        # Large Browse button
        col = layout.column()
        col.scale_y = 2.0
        col.prop(scene.mhs, "project_path", text="")

        # Show validation message if path is entered but invalid
        if project_path:
            if not os.path.exists(project_path):
                # Path doesn't exist
                error_box = layout.box()
                error_box.alert = True
                row = error_box.row()
                row.label(text="Path does not exist!", icon='ERROR')
            else:
                # Path exists but no .hzproject file
                if not has_hzproject_file(project_path):
                    error_box = layout.box()
                    error_box.alert = True
                    col = error_box.column()
                    col.label(text="Invalid project path", icon='ERROR')
                    col.label(text="No .hzproject file found in path")
                    col.separator()
                    col.label(text="Please select an existing MHS project.")

        layout.separator()

        # Documentation link (2x height)
        col = layout.column()
        col.scale_y = 2.0
        col.operator("mhs.open_documentation", text="View Documentation", icon='URL')

class MHS_UL_layout_exports(UIList):
    """UIList for displaying layout export configurations"""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)

            # Enabled checkbox with visible icon
            icon_enabled = 'CHECKBOX_HLT' if item.enabled else 'CHECKBOX_DEHLT'
            row.prop(item, "enabled", text="", icon=icon_enabled, emboss=False)

            # Layout name (editable)
            row.prop(item, "name", text="", emboss=False, icon='SCENE_DATA')

            # Collection count indicator
            collection_count = len(item.collections)
            row.label(text=f"({collection_count})", icon='OUTLINER_COLLECTION')

            # Visibility controls sub-row
            vis_row = row.row(align=True)

            # Build layer collection map for visibility checking
            layer_coll_map = {}
            self._build_layer_collection_map(context.view_layer.layer_collection, layer_coll_map)

            # Toggle visibility button - determine icon based on current visibility state
            any_visible = False
            for coll_ref in item.collections:
                if coll_ref.collection:
                    layer_coll = layer_coll_map.get(coll_ref.collection.name)
                    if layer_coll and not layer_coll.hide_viewport:
                        any_visible = True
                        break
            vis_icon = 'HIDE_OFF' if any_visible else 'HIDE_ON'
            op = vis_row.operator("mhs.toggle_layout_visibility", text="", icon=vis_icon, emboss=False)
            op.layout_index = index

            # Solo visibility button - show different icon if this layout is soloed
            is_soloed = (context.scene.mhs.soloed_layout_index == index)
            solo_icon = 'SOLO_ON' if is_soloed else 'SOLO_OFF'
            op = vis_row.operator("mhs.solo_layout_visibility", text="", icon=solo_icon, emboss=False)
            op.layout_index = index

            # Export single layout button
            op = row.operator("mhs.export_single_layout", text="", icon='EXPORT', emboss=False)
            op.layout_index = index

        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.prop(item, "enabled", text="")

    def _build_layer_collection_map(self, layer_collection, result_map):
        """Recursively build a map of collection name -> layer_collection"""
        result_map[layer_collection.name] = layer_collection
        for child in layer_collection.children:
            self._build_layer_collection_map(child, result_map)

class MHS_UL_layout_collections(UIList):
    """UIList for displaying collections in a layout export"""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)

            # Collection icon and name
            collection = item.collection
            if collection:
                row.label(text=collection.name, icon='OUTLINER_COLLECTION')
                # Show child count
                child_count = len(collection.children)
                if child_count > 0:
                    row.label(text=f"+{child_count} child(ren)", icon='DOWNARROW_HLT')
            else:
                row.label(text="(missing collection)", icon='ERROR')

        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='OUTLINER_COLLECTION')

class MHS_PT_layout_panel(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BlendMHS"
    bl_label = "Layout Setup"
    bl_parent_id = "MHS_PT_base_panel"
    bl_options = {'DEFAULT_CLOSED'}
    bl_icon = 'SCENE_DATA'

    @classmethod
    def poll(cls, context):
        """Only show when a valid project path is set"""
        return is_valid_project_path(context.scene.mhs.project_path)

    def draw_header(self, context):
        self.layout.label(icon='SCENE_DATA')

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Check if any layout exports are configured
        has_layouts = len(scene.mhs.layout_exports) > 0
        has_enabled_layouts = any(le.enabled for le in scene.mhs.layout_exports)

        # Warning box if no layouts configured
        if not has_layouts:
            box = layout.box()
            box.label(text="No layout exports configured!", icon='ERROR')
            box.label(text="Add a layout export below to enable export")

            # Add Layout Export button
            row = box.row()
            row.scale_y = 1.5
            row.operator("mhs.add_layout_export", text="Add Layout Export", icon='ADD')
        elif not has_enabled_layouts:
            box = layout.box()
            box.label(text="No enabled layout exports!", icon='ERROR')
            box.label(text="Enable at least one layout to export")

        # Layout exports list
        list_box = layout.box()
        list_box.label(text="Layout Exports:", icon='EXPORT')

        row = list_box.row()
        row.template_list(
            "MHS_UL_layout_exports", "",
            scene.mhs, "layout_exports",
            scene.mhs, "active_layout_index",
            rows=3
        )

        col = row.column(align=True)
        col.operator("mhs.add_layout_export", icon='ADD', text="")
        col.operator("mhs.remove_layout_export", icon='REMOVE', text="")

        # Active layout configuration
        if len(scene.mhs.layout_exports) > 0:
            active_layout = scene.mhs.layout_exports[scene.mhs.active_layout_index]

            box = layout.box()
            box.label(text=f"Configure: {active_layout.name}", icon='SETTINGS')

            # Layout name
            box.prop(active_layout, "name")

            # Collections list
            box.label(text="Collections to Export:")
            row = box.row()
            row.template_list(
                "MHS_UL_layout_collections", "",
                active_layout, "collections",
                active_layout, "active_collection_index",
                rows=3
            )

            col = row.column(align=True)
            col.operator("mhs.add_collection_to_layout", icon='ADD', text="")
            col.operator("mhs.remove_collection_from_layout", icon='REMOVE', text="")


class MHS_PT_layout_exports_config_panel(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BlendMHS"
    bl_label = "Layout Export Configuration"
    bl_parent_id = "MHS_PT_layout_panel"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        """Only show when a valid project path is set"""
        return is_valid_project_path(context.scene.mhs.project_path)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Layout exports list
        box = layout.box()
        box.label(text="Layout Exports:", icon='SCENE_DATA')

        row = box.row()
        row.template_list(
            "MHS_UL_layout_exports", "",
            scene.mhs, "layout_exports",
            scene.mhs, "active_layout_index",
            rows=3
        )

        col = row.column(align=True)
        col.operator("mhs.add_layout_export", icon='ADD', text="")
        col.operator("mhs.remove_layout_export", icon='REMOVE', text="")

        # Show collection configuration for active layout
        if len(scene.mhs.layout_exports) > 0 and scene.mhs.active_layout_index < len(scene.mhs.layout_exports):
            active_layout = scene.mhs.layout_exports[scene.mhs.active_layout_index]

            # Single box containing all layout settings
            settings_box = layout.box()

            # Export Enabled toggle at the top
            row = settings_box.row(align=True)
            row.scale_y = 1.3
            row.prop(active_layout, "enabled", text="Export Enabled", icon='CHECKMARK' if active_layout.enabled else 'CHECKBOX_DEHLT', toggle=True)

            # Only show remaining options if export is enabled
            if active_layout.enabled:
                settings_box.separator()

                # Collections label
                settings_box.label(text=f"Collections to Export in: '{active_layout.name}'", icon='OUTLINER_COLLECTION')

                # Collections list
                row = settings_box.row()
                row.template_list(
                    "MHS_UL_layout_collections", "",
                    active_layout, "collections",
                    active_layout, "active_collection_index",
                    rows=3
                )

                col = row.column(align=True)
                col.operator("mhs.add_collection_to_layout", icon='ADD', text="")
                col.operator("mhs.remove_collection_from_layout", icon='REMOVE', text="")

                # Info about child collections
                if len(active_layout.collections) > 0:
                    row = settings_box.row()
                    row.scale_y = 0.8
                    row.label(text="Note: All child collections are automatically included", icon='INFO')

class MHS_PT_export_panel(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BlendMHS"
    bl_label = "Mesh Setup"
    bl_parent_id = "MHS_PT_base_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        self.layout.label(icon='MESH_CUBE')

    @classmethod
    def poll(cls, context):
        """Hide Mesh Export panel when no valid project or animated object selected"""
        # First check for valid project path
        if not is_valid_project_path(context.scene.mhs.project_path):
            return False

        obj = context.active_object
        if not obj:
            return False

        # Hide panel if armature is selected
        if obj.type == 'ARMATURE':
            return False

        # Hide panel if mesh with armature modifier is selected
        if obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return False

        return True

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        obj = context.active_object

        if obj and obj.type == 'MESH':
            # Mesh Info box (collapsible)
            info_box = layout.box()
            row = info_box.row()
            row.prop(obj.mhs, "show_mesh_info",
                    icon="TRIA_DOWN" if obj.mhs.show_mesh_info else "TRIA_RIGHT",
                    text="Mesh Info", emboss=False)

            if obj.mhs.show_mesh_info:
                col = info_box.column(align=True)

                # Object name
                row = col.row()
                row.label(text=f"Object: {obj.name}", icon='OBJECT_DATA')

                # Mesh data stats (base mesh)
                mesh = obj.data
                if mesh:
                    row = col.row()
                    row.label(text=f"Vertices: {len(mesh.vertices):,}", icon='VERTEXSEL')

                    row = col.row()
                    row.label(text=f"Faces: {len(mesh.polygons):,}", icon='FACESEL')

                    # Triangles count (useful for game export)
                    tri_count = sum(len(p.vertices) - 2 for p in mesh.polygons)
                    row = col.row()
                    row.label(text=f"Triangles: {tri_count:,}", icon='MOD_TRIANGULATE')

                # Materials count
                mat_count = len(obj.material_slots)
                row = col.row()
                row.label(text=f"Materials: {mat_count}", icon='MATERIAL')

                # UV Maps count
                uv_count = len(mesh.uv_layers) if mesh else 0
                row = col.row()
                if uv_count > 0:
                    row.label(text=f"UV Maps: {uv_count}", icon='UV')
                else:
                    row.label(text="No UV Maps", icon='ERROR')

                # Modifiers count (excluding armature since this panel is for static meshes)
                mod_count = len([m for m in obj.modifiers if m.type != 'ARMATURE'])
                if mod_count > 0:
                    row = col.row()
                    row.label(text=f"Modifiers: {mod_count}", icon='MODIFIER')

                    # Evaluated mesh stats (cached - updated via Refresh button)
                    # Check if cache is stale (older than timeout)
                    import time
                    cache_age = time.time() - obj.mhs.eval_cache_timestamp if obj.mhs.eval_cache_timestamp > 0 else float('inf')
                    is_cache_valid = obj.mhs.eval_verts_cached >= 0 and cache_age < 5.0  # 5 second timeout

                    eval_box = col.box()
                    eval_col = eval_box.column(align=True)
                    eval_col.scale_y = 0.9

                    # Header row with label and info button
                    header_row = eval_col.row()
                    header_row.label(text="Evaluated Mesh Data (after modifiers):", icon='BLANK1')
                    header_row.operator("mhs.refresh_evaluated_mesh", text="", icon='INFO')

                    # Show cached values only if cache is valid (not stale)
                    if is_cache_valid:
                        # Use split layout for indentation
                        row = eval_col.row()
                        row.separator(factor=2.0)
                        row.label(text=f"Vertices: {obj.mhs.eval_verts_cached:,}", icon='VERTEXSEL')
                        row = eval_col.row()
                        row.separator(factor=2.0)
                        row.label(text=f"Faces: {obj.mhs.eval_faces_cached:,}", icon='FACESEL')
                        row = eval_col.row()
                        row.separator(factor=2.0)
                        row.label(text=f"Triangles: {obj.mhs.eval_tris_cached:,}", icon='MOD_TRIANGULATE')
                    else:
                        row = eval_col.row()
                        row.separator(factor=2.0)
                        row.label(text="Click refresh to calculate", icon='INFO')

                # LOD status
                if obj.mhs.export_lods and len(obj.mhs.lod_list) > 0:
                    row = col.row()
                    row.label(text=f"LODs: {len(obj.mhs.lod_list)} configured", icon='MOD_DECIM')

            # Export Options box
            box = layout.box()
            box.label(text="Export Options", icon='EXPORT')

            col = box.column()
            row = col.row()
            row.scale_y = 1.5
            row.prop(obj.mhs, "export_lods", icon='OUTLINER_OB_MESH', text_ctxt="", expand=True)
            # col.prop(obj.mhs, "export_lightmap", icon='UV', text_ctxt="", expand=True)  # DISABLED: Lightmap export

            # Show LOD settings inline if export_lods is enabled
            if obj.mhs.export_lods:
                lod_box = box.box()
                lod_box.label(text="LOD Settings", icon='MOD_DECIM')
                col = lod_box.column()
                col.prop(obj.mhs, "lod_method")
                # col.prop(obj.mhs, "export_lods_as_references")
                col.template_list("MHS_UL_LOD_list", "", obj.mhs, "lod_list", obj.mhs, "lod_list_index")

                row = col.row(align=True)
                row.operator("mhs.lod_add", text="Add LOD", icon='ADD')
                row.operator("mhs.lod_remove", text="Remove LOD", icon='REMOVE')

class MHS_PT_animation_export_panel(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BlendMHS"
    bl_label = "Animation Setup"
    bl_parent_id = "MHS_PT_base_panel"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        # Only require valid project path - animated objects list should always be visible
        if not is_valid_project_path(context.scene.mhs.project_path):
            return False

        return True

    def draw_header(self, context):
        # Always show armature icon for Animation Export panel
        self.layout.label(icon='ARMATURE_DATA')

    def get_armature_for_mesh(self, obj):
        """Get the armature associated with a mesh via its Armature modifier"""
        if not obj or obj.type != 'MESH':
            return None
        for modifier in obj.modifiers:
            if modifier.type == 'ARMATURE' and modifier.object:
                return modifier.object
        return None

    def get_mesh_for_armature(self, armature):
        """Get the first mesh object that uses this armature via an Armature modifier"""
        if not armature or armature.type != 'ARMATURE':
            return None
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                for modifier in obj.modifiers:
                    if modifier.type == 'ARMATURE' and modifier.object == armature:
                        return obj
        return None

    def get_actions_for_armature(self, armature):
        if not armature or not armature.animation_data:
            return []
        actions = []
        if armature.animation_data.action:
            actions.append(armature.animation_data.action)
        for track in armature.animation_data.nla_tracks:
            for strip in track.strips:
                if strip.action and strip.action not in actions:
                    actions.append(strip.action)
        return actions

    def count_weighted_vertices(self, obj, armature):
        if not obj or not obj.data or not armature:
            return 0
        bone_names = {bone.name for bone in armature.data.bones}
        weighted_verts = 0
        for vert in obj.data.vertices:
            for group in vert.groups:
                if group.weight > 0:
                    vg = obj.vertex_groups[group.group]
                    if vg.name in bone_names:
                        weighted_verts += 1
                        break
        return weighted_verts

    def _get_compatible_actions(self, armature):
        """Get all actions compatible with this armature by checking bone f-curves."""
        if not armature or armature.type != 'ARMATURE':
            return set()

        bone_names = {bone.name for bone in armature.data.bones}
        if not bone_names:
            return set()

        compatible = set()
        for action in bpy.data.actions:
            if self._is_action_compatible(action, bone_names):
                compatible.add(action)
        return compatible

    def _is_action_compatible(self, action, bone_names):
        """Check if action has f-curves for bones in this armature."""
        if not action.fcurves:
            return False
        for fcurve in action.fcurves:
            data_path = fcurve.data_path
            if 'pose.bones["' in data_path:
                start = data_path.find('pose.bones["') + len('pose.bones["')
                end = data_path.find('"]', start)
                if end > start:
                    bone_name = data_path[start:end]
                    if bone_name in bone_names:
                        return True
        return False

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        obj = context.active_object

        # ========================================
        # Animated Objects List (collapsible) - Only in 3D View
        # ========================================
        animated_box = layout.box()
        row = animated_box.row()
        row.prop(scene.mhs, "show_animated_objects",
                icon="TRIA_DOWN" if scene.mhs.show_animated_objects else "TRIA_RIGHT",
                text="Animated Objects", emboss=False)

        # Refresh button in header
        row.operator("mhs.refresh_animated_objects", text="", icon='FILE_REFRESH')

        if scene.mhs.show_animated_objects:
            # Show status message
            count = len(scene.mhs.animated_objects)
            if count == 0:
                row = animated_box.row()
                row.label(text="No animated objects found", icon='INFO')
                row = animated_box.row()
                row.operator("mhs.refresh_animated_objects", text="Scan Scene", icon='FILE_REFRESH')
            else:
                # Check if an animated asset is selected
                is_animated_selected = False
                for item in scene.mhs.animated_objects:
                    if context.active_object == item.armature_object or context.active_object == item.mesh_object:
                        is_animated_selected = True
                        break

                # Show selection status
                if is_animated_selected:
                    row = animated_box.row()
                    row.label(text="Animated asset selected", icon='CHECKMARK')
                else:
                    row = animated_box.row()
                    row.label(text="No animated asset selected", icon='INFO')

                # Draw the list
                animated_box.template_list(
                    "MHS_UL_animated_objects", "",
                    scene.mhs, "animated_objects",
                    scene.mhs, "active_animated_object_index",
                    rows=3
                )

        # Global Animation Settings Flyout (collapsible box) - below the animated objects list
        global_box = layout.box()
        row = global_box.row()
        row.prop(scene.mhs, "show_global_settings",
                icon="TRIA_DOWN" if scene.mhs.show_global_settings else "TRIA_RIGHT",
                text="Global Animation Settings", emboss=False)

        if scene.mhs.show_global_settings:
            col = global_box.column()

            # Frame Rate using Blender's built-in preset menu with Custom option
            row = col.row(align=True)
            row.label(text="Frame Rate")
            # Get the current FPS display text
            fps = scene.render.fps
            fps_base = scene.render.fps_base
            if fps_base == 1.0:
                fps_text = f"{fps} fps"
            else:
                fps_text = f"{fps / fps_base:.2f} fps"
            row.menu("MHS_MT_framerate_presets", text=fps_text)

            # Show FPS and Base fields only when Custom is selected (like Blender does)
            if scene.mhs.use_custom_framerate:
                sub = col.column(align=True)
                sub.prop(scene.render, "fps")
                sub.prop(scene.render, "fps_base", text="Base")

        # Check if we have an animated object selected
        has_animated_selection = False
        mesh_obj = None
        armature = None

        if obj and obj.type == 'ARMATURE':
            armature = obj
            mesh_obj = self.get_mesh_for_armature(armature)
            has_animated_selection = True
        elif obj and obj.type == 'MESH':
            armature = self.get_armature_for_mesh(obj)
            if armature:
                mesh_obj = obj
                has_animated_selection = True

        # Only show animation info/settings if an animated object is selected
        if not has_animated_selection:
            # Show a hint to select an animated object
            hint_box = layout.box()
            hint_box.label(text="Select an animated object to view animation settings", icon='INFO')
            return

        # Determine the mesh object and armature based on selection
        # If armature is selected, find its associated mesh
        # If mesh is selected, use it directly
        if obj.type == 'ARMATURE':
            armature = obj
            mesh_obj = self.get_mesh_for_armature(armature)
        else:  # obj.type == 'MESH'
            mesh_obj = obj
            armature = self.get_armature_for_mesh(obj)

        # ========================================
        # Armature Parent Box - wraps all armature-specific settings
        # ========================================
        armature_parent_box = layout.box()
        armature_header = armature_parent_box.row()
        armature_header.alignment = 'LEFT'
        armature_header.label(text="Selection:")
        armature_header.label(text=armature.name, icon='ARMATURE_DATA')
        armature_header.label(text="|")
        armature_header.label(text=mesh_obj.name, icon='OUTLINER_OB_MESH')

        # Animation Info (collapsible)
        status_box = armature_parent_box.box()
        row = status_box.row()
        row.prop(mesh_obj.mhs, "show_animation_info",
                icon="TRIA_DOWN" if mesh_obj.mhs.show_animation_info else "TRIA_RIGHT",
                text="Animation Info", emboss=False)

        if mesh_obj.mhs.show_animation_info:
            if armature:
                col = status_box.column(align=True)

                row = col.row()
                row.label(text=f"Armature: {armature.name}", icon='ARMATURE_DATA')

                row = col.row()
                row.label(text=f"Mesh: {mesh_obj.name}", icon='MESH_DATA')

                weighted_verts = self.count_weighted_vertices(mesh_obj, armature)
                row = col.row()
                if weighted_verts > 0:
                    row.label(text=f"Skin Weights: {weighted_verts} vertices", icon='MOD_VERTEX_WEIGHT')
                else:
                    row.label(text="No skin weights found", icon='ERROR')

                # Show enabled action count
                enabled_actions = [a for a in armature.mhs.animation_export_actions if a.enabled]
                total_actions = len(armature.mhs.animation_export_actions)
                row = col.row()
                if total_actions > 0:
                    row.label(text=f"Actions: {len(enabled_actions)}/{total_actions} enabled", icon='ACTION')
                else:
                    row.label(text="No actions loaded (click refresh)", icon='ERROR')
            else:
                col = status_box.column()
                col.label(text="No armature detected", icon='INFO')
                col.label(text="Add an Armature modifier to export animations")

        if mesh_obj:
            export_box = armature_parent_box.box()
            export_box.label(text="Export Options", icon='EXPORT')

            col = export_box.column()
            row = col.row()
            row.scale_y = 1.5
            row.prop(mesh_obj.mhs, "export_animations", icon='ARMATURE_DATA')

            # Actions List (from armature)
            if mesh_obj.mhs.export_animations and armature:
                # col.prop(mesh_obj.mhs, "export_animations_separate")
                actions_box = export_box.box()

                # ========================================
                # Action Commander Style Header
                # ========================================

                # Row 1: "X Actions Loaded" header
                total_actions = len(armature.mhs.animation_export_actions)
                header_row = actions_box.row()
                header_row.label(text=f"{total_actions} Actions Loaded", icon='ACTION')

                # Check if active action is not in the list - show simple load button
                if armature.animation_data and armature.animation_data.action:
                    active_action = armature.animation_data.action
                    action_in_list = any(item.action == active_action for item in armature.mhs.animation_export_actions)
                    if not action_in_list:
                        row = actions_box.row()
                        row.scale_y = 1.3
                        row.operator("mhs.add_active_action", text=f"Load Active: {active_action.name}", icon='ACTION')

                # Row 2: New / Load / Dropdown Menu
                button_row = actions_box.row(align=True)
                button_row.operator("mhs.new_action", text="New", icon='ADD')
                button_row.operator("mhs.load_all_actions", text="Load")
                button_row.menu("MHS_MT_action_extras_menu", text="", icon='DOWNARROW_HLT')

                # Actions list - only show if there are actions
                if total_actions > 0:
                    actions_box.template_list(
                        "MHS_UL_animation_actions", "",
                        armature.mhs, "animation_export_actions",
                        armature.mhs, "active_animation_action_index",
                        rows=3
                    )

                    # ========================================
                    # Selected Action Detail (collapsible)
                    # ========================================
                    idx = armature.mhs.active_animation_action_index
                    if 0 <= idx < total_actions:
                        active_item = armature.mhs.animation_export_actions[idx]
                        if active_item.action:
                            action = active_item.action

                            # Action detail foldout header
                            detail_box = actions_box.box()
                            header_row = detail_box.row(align=True)

                            # Foldout toggle
                            icon = "TRIA_DOWN" if armature.mhs.show_action_detail else "TRIA_RIGHT"
                            header_row.prop(armature.mhs, "show_action_detail", text="", icon=icon, emboss=False)

                            # Action name (editable via action itself)
                            header_row.prop(action, "name", text="")

                            # Duplicate button
                            header_row.operator("mhs.duplicate_action", text="", icon='DUPLICATE')

                            # Enabled checkbox (use_fake_user for the action)
                            icon_enabled = 'CHECKBOX_HLT' if active_item.enabled else 'CHECKBOX_DEHLT'
                            header_row.prop(active_item, "enabled", text="", icon=icon_enabled, emboss=True)

                            # Remove button
                            op = header_row.operator("mhs.remove_animation_action", text="", icon='X')
                            op.action_index = idx

                            # Show detail contents if expanded
                            if armature.mhs.show_action_detail:
                                # Action Slot (editable dropdown - uses Blender 4.5's action slots)
                                row = detail_box.row(align=True)
                                row.label(text="Action Slot:")
                                if hasattr(action, 'slots') and len(action.slots) > 0:
                                    # Use prop_search with our StringProperty against action.slots
                                    # This displays the clean name (e.g., "MonkeyRig") instead of the identifier ("OBMonkeyRig")
                                    row.prop_search(active_item, "action_slot", action, "slots", text="")
                                else:
                                    # Fallback display for older Blender or no slots
                                    row.label(text=armature.name, icon='ARMATURE_DATA')

                                # Frame Range (Start / End)
                                row = detail_box.row(align=True)
                                if action.use_frame_range:
                                    # Manual frame range - use action's frame_start/frame_end
                                    row.prop(action, "frame_start", text="Start")
                                    row.prop(action, "frame_end", text="End")
                                else:
                                    # Auto range from keyframes
                                    row.prop(action, "curve_frame_range", text="Start", index=0)
                                    row.prop(action, "curve_frame_range", text="End", index=1)

                                # Is Loop
                                detail_box.prop(active_item, "is_loop", text="Is Loop")

                                # Manual Frame Range (Blender native action property)
                                detail_box.prop(action, "use_frame_range", text="Manual Frame Range")

                                # Use Cyclic (Blender native action property)
                                detail_box.prop(action, "use_cyclic", text="Use Cyclic")

                                # Tags
                                detail_box.prop(active_item, "tags", text="Tags")

                                # Use Bake Range
                                detail_box.prop(active_item, "use_bake_range", text="Use Bake Range")
                                if active_item.use_bake_range:
                                    bake_row = detail_box.row(align=True)
                                    bake_row.prop(active_item, "bake_range_start", text="Bake Start")
                                    bake_row.prop(active_item, "bake_range_end", text="Bake End")

                                # Pose Markers (collapsible)
                                pm_box = detail_box.box()
                                pm_header = pm_box.row()
                                pm_icon = "TRIA_DOWN" if armature.mhs.show_pose_markers else "TRIA_RIGHT"
                                pm_header.prop(armature.mhs, "show_pose_markers", text="", icon=pm_icon, emboss=False)
                                pm_header.label(text="Pose Markers")

                                if armature.mhs.show_pose_markers:
                                    # Always show pose markers list with controls (even if empty)
                                    row = pm_box.row()
                                    row.template_list(
                                        "UI_UL_list", "pose_markers",
                                        action, "pose_markers",
                                        action, "pose_markers_index",
                                        rows=3
                                    )
                                    col = row.column(align=True)
                                    # Add marker
                                    col.operator("mhs.add_pose_marker", text="", icon='ADD')
                                    # Remove marker
                                    col.operator("mhs.remove_pose_marker", text="", icon='REMOVE')
                                    # Extras menu
                                    col.menu("MHS_MT_pose_marker_extras_menu", text="", icon='DOWNARROW_HLT')
                                    col.separator()
                                    # Move up
                                    op = col.operator("mhs.reorder_pose_marker", text="", icon='TRIA_UP')
                                    op.direction = 'UP'
                                    # Move down
                                    op = col.operator("mhs.reorder_pose_marker", text="", icon='TRIA_DOWN')
                                    op.direction = 'DOWN'
                                    col.separator()
                                    # Move to marker
                                    col.operator("mhs.move_to_pose_marker", text="", icon='TIME')

                                    # Use Pose Marker As Range
                                    pm_box.prop(active_item, "use_pose_marker_as_range", text="Use Pose Marker As Range")

                                    if active_item.use_pose_marker_as_range:
                                        range_box = pm_box.box()

                                        # Pose Marker A
                                        range_box.label(text="Pose Marker A")
                                        row = range_box.row(align=True)
                                        row.prop_search(
                                            active_item, "pose_marker_a",
                                            action, "pose_markers",
                                            text="", icon='PMARKER_ACT'
                                        )
                                        # Show frame if marker exists
                                        marker_a = action.pose_markers.get(active_item.pose_marker_a)
                                        if marker_a:
                                            row.prop(marker_a, "frame", text="")

                                        # Pose Marker B
                                        range_box.label(text="Pose Marker B")
                                        row = range_box.row(align=True)
                                        row.prop_search(
                                            active_item, "pose_marker_b",
                                            action, "pose_markers",
                                            text="", icon='PMARKER_ACT'
                                        )
                                        # Show frame if marker exists
                                        marker_b = action.pose_markers.get(active_item.pose_marker_b)
                                        if marker_b:
                                            row.prop(marker_b, "frame", text="")

                    # ========================================
                    # Action Box (collapsible operations)
                    # ========================================
                    action_ops_box = actions_box.box()
                    # Header row for Action Box
                    row = action_ops_box.row()
                    row.prop(armature.mhs, "show_action_box",
                            icon="TRIA_DOWN" if armature.mhs.show_action_box else "TRIA_RIGHT",
                            text="Action Box", emboss=False)

                    if armature.mhs.show_action_box:
                        col = action_ops_box.column(align=True)

                        # Play button (tall)
                        row = col.row()
                        row.scale_y = 1.3
                        row.operator("mhs.play_action", text="Play", icon='PLAY')

                        # Flip Action
                        row = col.row()
                        row.scale_y = 1.3
                        row.operator("mhs.flip_action", text="Flip Action", icon='MOD_MIRROR')

                        # Bake This Action
                        row = col.row()
                        row.scale_y = 1.3
                        row.operator("mhs.bake_action", text="Bake This Action", icon='KEYTYPE_KEYFRAME_VEC')

                        # Push to NLA
                        row = col.row()
                        row.scale_y = 1.3
                        row.operator("mhs.push_action_to_nla", text="Push To NLA", icon='NLA_PUSHDOWN')

                        # Duplicate
                        row = col.row()
                        row.scale_y = 1.3
                        row.operator("mhs.duplicate_action", text="Duplicate", icon='DUPLICATE')

            # Add LOD export option (migrated from Mesh Export panel)
            col = export_box.column()
            row = col.row()
            row.scale_y = 1.5
            row.prop(mesh_obj.mhs, "export_lods", icon='OUTLINER_OB_MESH', text_ctxt="", expand=True)

            # Show LOD settings inline if export_lods is enabled
            if mesh_obj.mhs.export_lods:
                lod_box = export_box.box()
                lod_box.label(text="LOD Settings", icon='MOD_DECIM')
                lod_col = lod_box.column()
                lod_col.prop(mesh_obj.mhs, "lod_method")
                # lod_col.prop(mesh_obj.mhs, "export_lods_as_references")
                lod_col.template_list("MHS_UL_LOD_list", "", mesh_obj.mhs, "lod_list", mesh_obj.mhs, "lod_list_index")

                row = lod_col.row(align=True)
                row.operator("mhs.lod_add", text="Add LOD", icon='ADD')
                row.operator("mhs.lod_remove", text="Remove LOD", icon='REMOVE')
        else:
            # Armature selected but no mesh found
            box = layout.box()
            box.label(text="No mesh found using this armature", icon='ERROR')
            box.label(text="Select a mesh with an Armature modifier")

class MHS_UL_LOD_list(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.label(text=f"LOD{index}:")
            row.prop(item, "distance_ratio", text="Dist Ratio", emboss=False)
            if data.lod_method == 'MANUAL':
                # For LOD0 (index 0), show parent object (read-only), for others show object picker
                if index == 0:
                    # LOD0 always uses parent object - show it but disabled
                    parent_obj = context.active_object if context.active_object else data
                    row.label(text=f"{parent_obj.name} (parent)", icon='MESH_DATA')
                else:
                    # LOD1+ can have objects assigned
                    row.prop(item, "object", text="", emboss=False)
            elif data.lod_method == 'DECIMATE':
                # For LOD0, don't show decimate percentage (it's always 100%)
                if index == 0:
                    row.label(text="100% (base)", icon='MESH_DATA')
                else:
                    row.prop(item, "decimate_percentage", text="Decimate %", emboss=False)
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='OBJECT_DATAMODE')

class MHS_PT_material_settings_panel(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BlendMHS"
    bl_label = "Material Settings"
    bl_parent_id = "MHS_PT_base_panel"

    def draw_header(self, context):
        self.layout.label(icon='MATERIAL')

    @classmethod
    def poll(cls, context):
        # First check for valid project path
        if not is_valid_project_path(context.scene.mhs.project_path):
            return False

        obj = context.active_object
        if obj is None:
            return False

        # Show material panel for mesh objects
        if obj.type == 'MESH':
            return True

        # Show material panel for armatures that have an associated mesh
        if obj.type == 'ARMATURE':
            # Check if any mesh uses this armature
            for mesh_obj in bpy.data.objects:
                if mesh_obj.type == 'MESH':
                    for modifier in mesh_obj.modifiers:
                        if modifier.type == 'ARMATURE' and modifier.object == obj:
                            return True

        return False

    def get_mesh_for_armature(self, armature):
        """Get the first mesh object that uses this armature via an Armature modifier"""
        if not armature or armature.type != 'ARMATURE':
            return None
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                for modifier in obj.modifiers:
                    if modifier.type == 'ARMATURE' and modifier.object == armature:
                        return obj
        return None

    def draw_property(self, layout, prop):
        """Helper function to draw a property with the appropriate UI widget"""
        # Skip properties starting with "_"
        if prop.name.startswith("_"):
            return

        # Determine property type and draw appropriate widget
        if prop.is_texture:
            layout.template_ID_preview(prop, "value_image", open="image.open")
        elif prop.is_color:
            layout.prop(prop, "value_color", text=prop.name)
        elif prop.is_bool:
            layout.prop(prop, "value_bool", text=prop.name, toggle=True)
        elif prop.is_vector:  # Use the vector flag instead of checking attributes
            layout.prop(prop, "value_vector", text=prop.name)
        else:  # Standard float value with custom min/max handling
            row = layout.row(align=True)

            # Draw the slider
            row.prop(prop, "value_float", text=prop.name, slider=True)

            # Clamp value if it exceeds stored bounds (fix for existing broken values)
            if prop.float_has_min and prop.value_float < prop.float_min:
                prop.value_float = prop.float_min
            if prop.float_has_max and prop.value_float > prop.float_max:
                prop.value_float = prop.float_max

    def draw(self, context):
        layout = self.layout
        obj = context.active_object

        # If armature is selected, get its associated mesh
        if obj.type == 'ARMATURE':
            mesh_obj = self.get_mesh_for_armature(obj)
            if not mesh_obj:
                layout.label(text="No mesh found for this armature", icon='ERROR')
                return
        else:
            mesh_obj = obj

        # Show which mesh we're displaying materials for (if armature selected)
        if obj.type == 'ARMATURE':
            box = layout.box()
            box.label(text=f"Materials for: {mesh_obj.name}", icon='MESH_DATA')

        # Always show material slots list
        row = layout.row()
        row.template_list("MATERIAL_UL_matslots", "", mesh_obj, "material_slots",
                         mesh_obj, "active_material_index", rows=4)

        col = row.column(align=True)
        col.operator("object.material_slot_add", icon='ADD', text="")
        col.operator("object.material_slot_remove", icon='REMOVE', text="")
        col.menu("MATERIAL_MT_context_menu", icon='DOWNARROW_HLT', text="")
        col.separator()
        col.operator("mhs.material_slot_move", icon='TRIA_UP', text="").direction = 'UP'
        col.operator("mhs.material_slot_move", icon='TRIA_DOWN', text="").direction = 'DOWN'

        # Edit mode operators (only show if mesh is in edit mode)
        if mesh_obj.mode == 'EDIT' and mesh_obj.type == 'MESH':
            row = layout.row(align=True)
            row.operator("object.material_slot_assign", text="Assign")
            row.operator("object.material_slot_select", text="Select")
            row.operator("object.material_slot_deselect", text="Deselect")

        # Material selector - searchable dropdown with label
        row = layout.row()
        row.scale_y = 1.5
        split = row.split(factor=0.25)
        split.label(text="Select Material:")
        split.prop_search(mesh_obj, "active_material", bpy.data, "materials", text="", icon='MATERIAL')

        mat = mesh_obj.active_material

        if not mat:
            # No material in active slot - show create button
            row = layout.row()
            row.scale_y = 2.0
            row.operator("mhs.create_material", icon='ADD', text="Create MHS Material")
            return

        # MHS Material Settings
        if mat.mhs:
            box = layout.box()

            # Material Format selector - prominent 2x scale with left padding
            row = box.row()
            row.scale_y = 2.0
            row.separator(factor=0.5)  # Left padding
            row.prop(mat.mhs, "material_format", text="Material Format", icon='MATERIAL')

            # Draw format-specific UI based on selected format
            material_format = mat.mhs.material_format

            # New template-based formats
            if material_format == 'ISOTROPIC_USD':
                self.draw_isotropic_usd_ui(layout, mat, mesh_obj)

            elif material_format == 'ISOTROPIC_EMISSIVE_USD':
                self.draw_isotropic_emissive_usd_ui(layout, mat, mesh_obj)

            elif material_format == 'ISOTROPIC_SIMPLE_USD':
                self.draw_isotropic_simple_usd_ui(layout, mat, mesh_obj)

            elif material_format == 'UNLIT':
                self.draw_unlit_ui(layout, mat, mesh_obj)

            elif material_format == 'UNLIT_BLEND':
                self.draw_unlit_blend_ui(layout, mat, mesh_obj)

            elif material_format == 'UNLIT_MASKED':
                self.draw_unlit_masked_ui(layout, mat, mesh_obj)

            # NONE format - show basic info
            elif material_format == 'NONE':
                info_box = layout.box()
                info_box.label(text="No MHS shader applied", icon='INFO')
                info_box.label(text="Select a format to configure material")

    def draw_isotropic_usd_ui(self, layout, mat, mesh_obj):
        """Draw the UI for Isotropic USD material format"""

        # Get the node tree to find texture nodes
        node_tree = mat.node_tree if mat.use_nodes else None

        # Find the MHS_IsotropicUSD group node
        group_node = None
        if node_tree:
            for node in node_tree.nodes:
                if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_IsotropicUSD':
                    group_node = node
                    break

        # ========================================
        # Shader Info Section (right under format)
        # ========================================
        info_box = layout.box()
        row = info_box.row()
        row.separator(factor=0.5)  # Left padding
        row.label(text="MHS Shader Target:")
        row.label(text="isotropicUsd.surface")

        # ========================================
        # Material Properties Section
        # ========================================
        props_box = layout.box()
        row = props_box.row()
        row.prop(mat.mhs, "show_texture_properties",
                icon="TRIA_DOWN" if mat.mhs.show_texture_properties else "TRIA_RIGHT",
                text="Material Properties", emboss=False)

        if mat.mhs.show_texture_properties:
            col = props_box.column()

            # Base Color texture
            self.draw_texture_slot(col, node_tree, "Base Color",
                                   "baseColorTex", "sRGB")

            col.separator()

            # MRO Texture
            self.draw_texture_slot(col, node_tree, "MRO Texture",
                                   "metalnessRoughnessOcclusionTex", "Non-Color")

            # UV Transform Settings
            col.separator()
            uv_box = col.box()
            uv_box.label(text="UV Transform", icon='UV')

            # Find the MHS_UVTransform node for UV Scale/Offset values
            uv_transform_node = None
            for node in node_tree.nodes:
                if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_UVTransform':
                    uv_transform_node = node
                    break

            if uv_transform_node:
                uv_col = uv_box.column()

                # UV Scale (X, Y)
                if 'UV Scale' in uv_transform_node.inputs:
                    row = uv_col.row(align=True)
                    row.label(text="Scale:")
                    sub = row.row(align=True)
                    sub.prop(uv_transform_node.inputs['UV Scale'], "default_value", index=0, text="X")
                    sub.prop(uv_transform_node.inputs['UV Scale'], "default_value", index=1, text="Y")

                # UV Offset (X, Y)
                if 'UV Offset' in uv_transform_node.inputs:
                    row = uv_col.row(align=True)
                    row.label(text="Offset:")
                    sub = row.row(align=True)
                    sub.prop(uv_transform_node.inputs['UV Offset'], "default_value", index=0, text="X")
                    sub.prop(uv_transform_node.inputs['UV Offset'], "default_value", index=1, text="Y")
            else:
                # No UVTransform node yet - it will be created when textures are added
                uv_box.label(text="Add a texture to enable UV controls", icon='INFO')

            # Texture Wrap Settings
            col.separator()
            wrap_box = col.box()
            wrap_box.label(text="Texture Wrap", icon='MOD_UVPROJECT')
            wrap_col = wrap_box.column()
            wrap_col.prop(mat.mhs, "texture_wrap_s", text="U")
            wrap_col.prop(mat.mhs, "texture_wrap_t", text="V")

        # ========================================
        # Vertex Color Section
        # ========================================
        vc_box = layout.box()
        row = vc_box.row()
        row.label(text="Vertex Color:", icon='VPAINT_HLT')

        # Check if mesh has vertex colors
        has_vertex_colors = False
        vertex_color_name = None
        if mesh_obj and mesh_obj.type == 'MESH' and mesh_obj.data:
            if mesh_obj.data.color_attributes:
                has_vertex_colors = True
                vertex_color_name = mesh_obj.data.color_attributes.active_color.name if mesh_obj.data.color_attributes.active_color else None

        # Check if vertex color node exists and get its layer name
        vc_node_exists = self.has_vertex_color_node(node_tree)
        vc_connected = self.is_vertex_color_connected(node_tree)
        vc_node_layer_name = self.get_vertex_color_node_layer_name(node_tree)

        # Check for name mismatch between mesh color attribute and material node
        names_mismatch = (has_vertex_colors and vc_node_layer_name and
                         vertex_color_name and vertex_color_name != vc_node_layer_name)

        col = vc_box.column()
        if has_vertex_colors:
            if names_mismatch:
                # Warning: names don't match
                row = col.row(align=True)
                row.label(text=f"Mesh: '{vertex_color_name}'", icon='ERROR')
                row.operator("mhs.disconnect_vertex_color", text="", icon='X')

                col.label(text=f"Material expects: '{vc_node_layer_name}'")

                row = col.row()
                row.operator("mhs.sync_vertex_color_name", text="Sync Names (rename mesh attribute)", icon='UV_SYNC_SELECT')
            else:
                # Normal case - names match or no node yet
                row = col.row(align=True)
                row.label(text=f"Using: {vertex_color_name}", icon='CHECKMARK')
                # Remove vertex color button (X)
                row.operator("mhs.disconnect_vertex_color", text="", icon='X')

                # Check if vertex color node is connected
                if not vc_connected:
                    row = col.row()
                    row.operator("mhs.connect_vertex_color", text="Connect Vertex Colors", icon='LINKED')
        else:
            # No vertex colors on mesh
            if vc_node_exists:
                # Warning: vertex color node exists but no vertex colors on mesh
                row = col.row(align=True)
                row.label(text="Vertex colors removed from mesh!", icon='ERROR')
                row.operator("mhs.disconnect_vertex_color", text="", icon='X')
                col.label(text="Node still connected (will cause issues)")

            # Add button to create vertex colors - styled like texture slots
            box = col.box()
            box.scale_y = 2.0
            row = box.row(align=True)
            row.label(text="No vertex colors")
            row.operator("mhs.add_color_attribute", text="Add Color Attribute", icon='ADD')

    def draw_texture_slot(self, layout, node_tree, display_name, export_name, color_space):
        """Draw a texture slot with preview and controls"""

        # Find existing texture node for this slot
        tex_node = None
        image = None
        if node_tree:
            # Look for texture node by name pattern
            for node in node_tree.nodes:
                if node.type == 'TEX_IMAGE' and display_name in node.name:
                    tex_node = node
                    image = node.image
                    break

        # Slot header
        row = layout.row(align=True)
        row.label(text=display_name + ":")

        # Color space indicator
        if image:
            cs_text = image.colorspace_settings.name
            if cs_text == color_space:
                row.label(text=f"[{cs_text}]", icon='CHECKMARK')
            else:
                row.label(text=f"[{cs_text}]", icon='ERROR')
        else:
            row.label(text=f"[{color_space}]")

        # Remove texture button (only show if texture node exists)
        if tex_node:
            op = row.operator("mhs.remove_texture", text="", icon='X')
            op.input_name = display_name

        # Texture preview and selector
        if tex_node:
            layout.template_ID_preview(tex_node, "image", open="image.open")
        else:
            # No texture node yet - show button to add one
            box = layout.box()
            box.scale_y = 2.0
            row = box.row(align=True)
            row.label(text="No texture assigned")
            op = row.operator("mhs.assign_texture", text="Add Texture", icon='ADD')
            op.input_name = display_name

    def is_vertex_color_connected(self, node_tree):
        """Check if a vertex color node is connected to the shader group"""
        if not node_tree:
            return False

        for node in node_tree.nodes:
            if node.type == 'VERTEX_COLOR':
                # Check if it's connected to anything
                for output in node.outputs:
                    if output.is_linked:
                        return True
        return False

    def has_vertex_color_node(self, node_tree):
        """Check if any vertex color node exists in the node tree"""
        if not node_tree:
            return False

        for node in node_tree.nodes:
            if node.type == 'VERTEX_COLOR':
                return True
        return False

    def get_vertex_color_node_layer_name(self, node_tree):
        """Get the layer name from the vertex color node, if it exists"""
        if not node_tree:
            return None

        for node in node_tree.nodes:
            if node.type == 'VERTEX_COLOR':
                return node.layer_name if node.layer_name else None
        return None

    def draw_isotropic_emissive_usd_ui(self, layout, mat, mesh_obj):
        """Draw the UI for Isotropic Emissive USD material format"""

        # Get the node tree to find texture nodes
        node_tree = mat.node_tree if mat.use_nodes else None

        # Find the MHS_IsotropicEmissiveUSD group node
        group_node = None
        if node_tree:
            for node in node_tree.nodes:
                if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_IsotropicEmissiveUSD':
                    group_node = node
                    break

        # ========================================
        # Shader Info Section
        # ========================================
        info_box = layout.box()
        row = info_box.row()
        row.separator(factor=0.5)
        row.label(text="MHS Shader Target:")
        row.label(text="isotropicEmissiveUsd.surface")

        # ========================================
        # Material Properties Section
        # ========================================
        props_box = layout.box()
        row = props_box.row()
        row.prop(mat.mhs, "show_texture_properties",
                icon="TRIA_DOWN" if mat.mhs.show_texture_properties else "TRIA_RIGHT",
                text="Material Properties", emboss=False)

        if mat.mhs.show_texture_properties:
            col = props_box.column()

            # Base Color texture
            self.draw_texture_slot(col, node_tree, "Base Color",
                                   "baseColorTex", "sRGB")

            col.separator()

            # MRO Texture
            self.draw_texture_slot(col, node_tree, "MRO Texture",
                                   "metalnessRoughnessOcclusionTex", "Non-Color")

            col.separator()

            # Emissive Texture
            self.draw_texture_slot(col, node_tree, "Emissive Texture",
                                   "emissiveTex", "sRGB")

            # UV Transform Settings
            col.separator()
            uv_box = col.box()
            uv_box.label(text="UV Transform", icon='UV')

            uv_transform_node = None
            for node in node_tree.nodes:
                if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_UVTransform':
                    uv_transform_node = node
                    break

            if uv_transform_node:
                uv_col = uv_box.column()

                if 'UV Scale' in uv_transform_node.inputs:
                    row = uv_col.row(align=True)
                    row.label(text="Scale:")
                    sub = row.row(align=True)
                    sub.prop(uv_transform_node.inputs['UV Scale'], "default_value", index=0, text="X")
                    sub.prop(uv_transform_node.inputs['UV Scale'], "default_value", index=1, text="Y")

                if 'UV Offset' in uv_transform_node.inputs:
                    row = uv_col.row(align=True)
                    row.label(text="Offset:")
                    sub = row.row(align=True)
                    sub.prop(uv_transform_node.inputs['UV Offset'], "default_value", index=0, text="X")
                    sub.prop(uv_transform_node.inputs['UV Offset'], "default_value", index=1, text="Y")
            else:
                uv_box.label(text="Add a texture to enable UV controls", icon='INFO')

            # Texture Wrap Settings
            col.separator()
            wrap_box = col.box()
            wrap_box.label(text="Texture Wrap", icon='MOD_UVPROJECT')
            wrap_col = wrap_box.column()
            wrap_col.prop(mat.mhs, "texture_wrap_s", text="U")
            wrap_col.prop(mat.mhs, "texture_wrap_t", text="V")

        # ========================================
        # Vertex Color Section
        # ========================================
        vc_box = layout.box()
        row = vc_box.row()
        row.label(text="Vertex Color:", icon='VPAINT_HLT')

        has_vertex_colors = False
        vertex_color_name = None
        if mesh_obj and mesh_obj.type == 'MESH' and mesh_obj.data:
            if mesh_obj.data.color_attributes:
                has_vertex_colors = True
                vertex_color_name = mesh_obj.data.color_attributes.active_color.name if mesh_obj.data.color_attributes.active_color else None

        vc_node_exists = self.has_vertex_color_node(node_tree)
        vc_connected = self.is_vertex_color_connected(node_tree)
        vc_node_layer_name = self.get_vertex_color_node_layer_name(node_tree)

        names_mismatch = (has_vertex_colors and vc_node_layer_name and
                         vertex_color_name and vertex_color_name != vc_node_layer_name)

        col = vc_box.column()
        if has_vertex_colors:
            if names_mismatch:
                row = col.row(align=True)
                row.label(text=f"Mesh: '{vertex_color_name}'", icon='ERROR')
                row.operator("mhs.disconnect_vertex_color", text="", icon='X')
                col.label(text=f"Material expects: '{vc_node_layer_name}'")
                row = col.row()
                row.operator("mhs.sync_vertex_color_name", text="Sync Names (rename mesh attribute)", icon='UV_SYNC_SELECT')
            else:
                row = col.row(align=True)
                row.label(text=f"Using: {vertex_color_name}", icon='CHECKMARK')
                row.operator("mhs.disconnect_vertex_color", text="", icon='X')

                if not vc_connected:
                    row = col.row()
                    row.operator("mhs.connect_vertex_color", text="Connect Vertex Colors", icon='LINKED')
        else:
            if vc_node_exists:
                row = col.row(align=True)
                row.label(text="Vertex colors removed from mesh!", icon='ERROR')
                row.operator("mhs.disconnect_vertex_color", text="", icon='X')
                col.label(text="Node still connected (will cause issues)")

            box = col.box()
            box.scale_y = 2.0
            row = box.row(align=True)
            row.label(text="No vertex colors")
            row.operator("mhs.add_color_attribute", text="Add Color Attribute", icon='ADD')

    def draw_isotropic_simple_usd_ui(self, layout, mat, mesh_obj):
        """Draw the UI for Isotropic Simple USD material format (constant properties, no textures)"""

        # Get the node tree to find the shader group
        node_tree = mat.node_tree if mat.use_nodes else None

        # Find the MHS_IsotropicSimpleUSD group node
        group_node = None
        if node_tree:
            for node in node_tree.nodes:
                if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_IsotropicSimpleUSD':
                    group_node = node
                    break

        # ========================================
        # Shader Info Section
        # ========================================
        info_box = layout.box()
        row = info_box.row()
        row.separator(factor=0.5)
        row.label(text="MHS Shader Target:")
        row.label(text="isotropicSimpleUsd.surface")

        row = info_box.row()
        row.label(text="Uses constant values (no textures)", icon='INFO')

        # ========================================
        # Material Properties Section
        # ========================================
        props_box = layout.box()
        row = props_box.row()
        row.prop(mat.mhs, "show_texture_properties",
                icon="TRIA_DOWN" if mat.mhs.show_texture_properties else "TRIA_RIGHT",
                text="Material Properties", emboss=False)

        if mat.mhs.show_texture_properties:
            col = props_box.column()

            if group_node:
                # Base Color
                if 'Base Color' in group_node.inputs:
                    row = col.row()
                    row.prop(group_node.inputs['Base Color'], "default_value", text="Base Color")

                col.separator()

                # Roughness
                if 'Roughness' in group_node.inputs:
                    row = col.row()
                    row.prop(group_node.inputs['Roughness'], "default_value", text="Roughness", slider=True)

                # Metalness
                if 'Metalness' in group_node.inputs:
                    row = col.row()
                    row.prop(group_node.inputs['Metalness'], "default_value", text="Metalness", slider=True)
            else:
                # Node group not found - show warning
                col.label(text="Shader node group not found!", icon='ERROR')
                col.label(text="Try changing material format to rebuild")

        # ========================================
        # Vertex Color Section
        # ========================================
        vc_box = layout.box()
        row = vc_box.row()
        row.label(text="Vertex Color:", icon='VPAINT_HLT')

        has_vertex_colors = False
        vertex_color_name = None
        if mesh_obj and mesh_obj.type == 'MESH' and mesh_obj.data:
            if mesh_obj.data.color_attributes:
                has_vertex_colors = True
                vertex_color_name = mesh_obj.data.color_attributes.active_color.name if mesh_obj.data.color_attributes.active_color else None

        vc_node_exists = self.has_vertex_color_node(node_tree)
        vc_connected = self.is_vertex_color_connected(node_tree)
        vc_node_layer_name = self.get_vertex_color_node_layer_name(node_tree)

        names_mismatch = (has_vertex_colors and vc_node_layer_name and
                         vertex_color_name and vertex_color_name != vc_node_layer_name)

        col = vc_box.column()
        if has_vertex_colors:
            if names_mismatch:
                row = col.row(align=True)
                row.label(text=f"Mesh: '{vertex_color_name}'", icon='ERROR')
                row.operator("mhs.disconnect_vertex_color", text="", icon='X')
                col.label(text=f"Material expects: '{vc_node_layer_name}'")
                row = col.row()
                row.operator("mhs.sync_vertex_color_name", text="Sync Names (rename mesh attribute)", icon='UV_SYNC_SELECT')
            else:
                row = col.row(align=True)
                row.label(text=f"Using: {vertex_color_name}", icon='CHECKMARK')
                row.operator("mhs.disconnect_vertex_color", text="", icon='X')

                if not vc_connected:
                    row = col.row()
                    row.operator("mhs.connect_vertex_color", text="Connect Vertex Colors", icon='LINKED')
        else:
            if vc_node_exists:
                row = col.row(align=True)
                row.label(text="Vertex colors removed from mesh!", icon='ERROR')
                row.operator("mhs.disconnect_vertex_color", text="", icon='X')
                col.label(text="Node still connected (will cause issues)")

            box = col.box()
            box.scale_y = 2.0
            row = box.row(align=True)
            row.label(text="No vertex colors")
            row.operator("mhs.add_color_attribute", text="Add Color Attribute", icon='ADD')

    def draw_unlit_ui(self, layout, mat, mesh_obj):
        """Draw the UI for Unlit material format"""

        node_tree = mat.node_tree if mat.use_nodes else None

        # ========================================
        # Shader Info Section
        # ========================================
        info_box = layout.box()
        row = info_box.row()
        row.separator(factor=0.5)
        row.label(text="MHS Shader Target:")
        row.label(text="unlit.surface")

        # ========================================
        # Material Properties Section
        # ========================================
        props_box = layout.box()
        row = props_box.row()
        row.prop(mat.mhs, "show_texture_properties",
                icon="TRIA_DOWN" if mat.mhs.show_texture_properties else "TRIA_RIGHT",
                text="Material Properties", emboss=False)

        if mat.mhs.show_texture_properties:
            col = props_box.column()

            # Base Color texture (RGB only)
            self.draw_texture_slot(col, node_tree, "Base Color",
                                   "baseColorTex", "sRGB")

            # UV Transform Settings
            col.separator()
            uv_box = col.box()
            uv_box.label(text="UV Transform", icon='UV')

            uv_transform_node = None
            if node_tree:
                for node in node_tree.nodes:
                    if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_UVTransform':
                        uv_transform_node = node
                        break

            if uv_transform_node:
                uv_col = uv_box.column()

                if 'UV Scale' in uv_transform_node.inputs:
                    row = uv_col.row(align=True)
                    row.label(text="Scale:")
                    sub = row.row(align=True)
                    sub.prop(uv_transform_node.inputs['UV Scale'], "default_value", index=0, text="X")
                    sub.prop(uv_transform_node.inputs['UV Scale'], "default_value", index=1, text="Y")

                if 'UV Offset' in uv_transform_node.inputs:
                    row = uv_col.row(align=True)
                    row.label(text="Offset:")
                    sub = row.row(align=True)
                    sub.prop(uv_transform_node.inputs['UV Offset'], "default_value", index=0, text="X")
                    sub.prop(uv_transform_node.inputs['UV Offset'], "default_value", index=1, text="Y")
            else:
                uv_box.label(text="Add a texture to enable UV controls", icon='INFO')

            # Texture Wrap Settings
            col.separator()
            wrap_box = col.box()
            wrap_box.label(text="Texture Wrap", icon='MOD_UVPROJECT')
            wrap_col = wrap_box.column()
            wrap_col.prop(mat.mhs, "texture_wrap_s", text="U")
            wrap_col.prop(mat.mhs, "texture_wrap_t", text="V")

    def draw_unlit_blend_ui(self, layout, mat, mesh_obj):
        """Draw the UI for Unlit Blend material format"""

        node_tree = mat.node_tree if mat.use_nodes else None

        # ========================================
        # Shader Info Section
        # ========================================
        info_box = layout.box()
        row = info_box.row()
        row.separator(factor=0.5)
        row.label(text="MHS Shader Target:")
        row.label(text="unlitBlend.surface")

        row = info_box.row()
        row.label(text="Uses alpha blending (translucent)", icon='INFO')

        # ========================================
        # Material Properties Section
        # ========================================
        props_box = layout.box()
        row = props_box.row()
        row.prop(mat.mhs, "show_texture_properties",
                icon="TRIA_DOWN" if mat.mhs.show_texture_properties else "TRIA_RIGHT",
                text="Material Properties", emboss=False)

        if mat.mhs.show_texture_properties:
            col = props_box.column()

            # Alpha channel note (above texture)
            col.label(text="Texture must have alpha channel", icon='INFO')

            # Base Color texture (RGBA - alpha required)
            self.draw_texture_slot(col, node_tree, "Base Color",
                                   "baseColorTex", "sRGB")

            # UV Transform Settings
            col.separator()
            uv_box = col.box()
            uv_box.label(text="UV Transform", icon='UV')

            uv_transform_node = None
            if node_tree:
                for node in node_tree.nodes:
                    if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_UVTransform':
                        uv_transform_node = node
                        break

            if uv_transform_node:
                uv_col = uv_box.column()

                if 'UV Scale' in uv_transform_node.inputs:
                    row = uv_col.row(align=True)
                    row.label(text="Scale:")
                    sub = row.row(align=True)
                    sub.prop(uv_transform_node.inputs['UV Scale'], "default_value", index=0, text="X")
                    sub.prop(uv_transform_node.inputs['UV Scale'], "default_value", index=1, text="Y")

                if 'UV Offset' in uv_transform_node.inputs:
                    row = uv_col.row(align=True)
                    row.label(text="Offset:")
                    sub = row.row(align=True)
                    sub.prop(uv_transform_node.inputs['UV Offset'], "default_value", index=0, text="X")
                    sub.prop(uv_transform_node.inputs['UV Offset'], "default_value", index=1, text="Y")
            else:
                uv_box.label(text="Add a texture to enable UV controls", icon='INFO')

            # Texture Wrap Settings
            col.separator()
            wrap_box = col.box()
            wrap_box.label(text="Texture Wrap", icon='MOD_UVPROJECT')
            wrap_col = wrap_box.column()
            wrap_col.prop(mat.mhs, "texture_wrap_s", text="U")
            wrap_col.prop(mat.mhs, "texture_wrap_t", text="V")

    def draw_unlit_masked_ui(self, layout, mat, mesh_obj):
        """Draw the UI for Unlit Masked material format"""

        node_tree = mat.node_tree if mat.use_nodes else None

        # ========================================
        # Shader Info Section
        # ========================================
        info_box = layout.box()
        row = info_box.row()
        row.separator(factor=0.5)
        row.label(text="MHS Shader Target:")
        row.label(text="unlitMasked.surface")

        row = info_box.row()
        row.label(text="Uses alpha masking (cutout)", icon='INFO')

        # ========================================
        # Material Properties Section
        # ========================================
        props_box = layout.box()
        row = props_box.row()
        row.prop(mat.mhs, "show_texture_properties",
                icon="TRIA_DOWN" if mat.mhs.show_texture_properties else "TRIA_RIGHT",
                text="Material Properties", emboss=False)

        if mat.mhs.show_texture_properties:
            col = props_box.column()

            # Info notes (above texture)
            col.label(text="Texture must have alpha channel", icon='INFO')
            col.label(text="Alpha threshold: 0.5 (pixels below are discarded)", icon='INFO')

            # Base Color texture (RGBA - alpha required)
            self.draw_texture_slot(col, node_tree, "Base Color",
                                   "baseColorTex", "sRGB")

            # UV Transform Settings
            col.separator()
            uv_box = col.box()
            uv_box.label(text="UV Transform", icon='UV')

            uv_transform_node = None
            if node_tree:
                for node in node_tree.nodes:
                    if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_UVTransform':
                        uv_transform_node = node
                        break

            if uv_transform_node:
                uv_col = uv_box.column()

                if 'UV Scale' in uv_transform_node.inputs:
                    row = uv_col.row(align=True)
                    row.label(text="Scale:")
                    sub = row.row(align=True)
                    sub.prop(uv_transform_node.inputs['UV Scale'], "default_value", index=0, text="X")
                    sub.prop(uv_transform_node.inputs['UV Scale'], "default_value", index=1, text="Y")

                if 'UV Offset' in uv_transform_node.inputs:
                    row = uv_col.row(align=True)
                    row.label(text="Offset:")
                    sub = row.row(align=True)
                    sub.prop(uv_transform_node.inputs['UV Offset'], "default_value", index=0, text="X")
                    sub.prop(uv_transform_node.inputs['UV Offset'], "default_value", index=1, text="Y")
            else:
                uv_box.label(text="Add a texture to enable UV controls", icon='INFO')

            # Texture Wrap Settings
            col.separator()
            wrap_box = col.box()
            wrap_box.label(text="Texture Wrap", icon='MOD_UVPROJECT')
            wrap_col = wrap_box.column()
            wrap_col.prop(mat.mhs, "texture_wrap_s", text="U")
            wrap_col.prop(mat.mhs, "texture_wrap_t", text="V")


# MHS_PT_lod_settings_panel has been removed - LOD settings are now shown inline
# in the Mesh Export and Animation Export panels when export_lods is enabled

def setup_PBR(mat, layout, box):
    texture_box = box.box()
    row = texture_box.row()
    row.prop(mat.mhs, "show_texture_properties", icon="TRIA_DOWN" if mat.mhs.show_texture_properties else "TRIA_RIGHT", icon_only=True, emboss=False)
    row.label(text="Texture Settings", icon="TEXTURE")

    if mat.mhs.show_texture_properties:
        col = texture_box.column()

        col.label(text="Base Color - B:")
        col.template_ID_preview(mat.mhs, "b_texture", open="image.open")
        # if mat.mhs.b_texture:
        #     col.template_preview(mat.mhs.b_texture, show_buttons=False)

        col.label(text="Utility - MRO:")
        col.template_ID_preview(mat.mhs, "mro_texture", open="image.open")
        # if mat.mhs.mro_texture:
        #     col.template_preview(mat.mhs.mro_texture, show_buttons=False)

        if mat.mhs.material_format == 'PBR-E':
            col.label(text="Emissive - E:")
            col.template_ID_preview(mat.mhs, "e_texture", open="image.open")
            # if mat.mhs.e_texture:
            #     col.template_preview(mat.mhs.e_texture, show_buttons=False)

        col.separator()
        col.prop(mat.mhs, "texture_wrap_s")
        col.prop(mat.mhs, "texture_wrap_t")

class MHS_UL_LightmapGroupList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)

            color_row = row.row()
            color_row.scale_x = 0.3
            color_row.prop(item, "color", text="")
            row.separator()

            # Add the object count to the group name
            object_count = len(item.objects)
            row.label(text=f"{item.name} ({object_count})")

            # Use operator instead of property
            op = row.operator("lightmap.toggle_uv", text="", icon='UV',
                            depress=item.get("show_lightmap_uv", False))
            op.group_name = item.name
            op.show_lightmap = not item.get("show_lightmap_uv", False)

            op = row.operator("usda.select_lightmap_group", text="",
                            icon='RESTRICT_SELECT_OFF', emboss=False)
            op.group_name = item.name

class MHS_PT_lightmapping_panel(Panel):
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "render"
    bl_category = "BlendMHS"
    bl_label = "Lightmapping"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Lightmap Groups
        lightmap_group_box = layout.box()
        row = lightmap_group_box.row(align=False)
        row.scale_y = 1.4
        row.scale_x = 2
        row.prop(scene.mhs, "show_lightmap_group_visualization", text="Show Group Visualization", toggle=True)
        row.scale_x = 1.2
        row.prop(scene.mhs, "lightmap_visualization_alpha", text = "Alpha")

        row = lightmap_group_box.row()
        row.prop(scene.mhs, "show_lightmap_group_properties", icon="TRIA_DOWN" if scene.mhs.show_lightmap_group_properties else "TRIA_RIGHT", icon_only=True, emboss=False)
        row.label(text="Lightmap Groups", icon='GROUP')

        if scene.mhs.show_lightmap_group_properties:
            # DISABLED: lightmap_groups property doesn't exist - causes AttributeError
            # row = lightmap_group_box.row()
            # row.template_list("MHS_UL_LightmapGroupList", "", scene.mhs, "lightmap_groups", scene.mhs, "lightmap_group_index")

            # col = row.column(align=True)
            # col.operator("usda.add_lightmap_group", icon='ADD', text="")
            # col.operator("usda.remove_lightmap_group", icon='REMOVE', text="")
            # col.operator("usda.clear_empty_lightmap_groups", icon='TRASH', text="")

            # if len(scene.mhs.lightmap_groups) > 0:
            #     group = scene.mhs.lightmap_groups[scene.mhs.lightmap_group_index]

            #     row = lightmap_group_box.row(align=True)
            #     row.operator("usda.add_to_lightmap_group", icon='ADD', text="Add Objects")
            #     row.operator("usda.remove_from_lightmap_group", icon='REMOVE', text="Remove Objects")

            #     col = lightmap_group_box.column()
            #     col.separator()
            #     col.scale_y = 1.5
            #     col.prop(group, "lightmap_resolution", text= "LM Resolution")
            #     col.separator()
            #     col = lightmap_group_box.column()
            #     # Show baked lightmap preview
            #     if group.baked_lightmap:
            #         col.template_ID_preview(group, "baked_lightmap", open="image.open", hide_buttons=True)
            #     else:
            #         col.label(text="No baked lightmap", icon='ERROR')
            #         col.label(text=f"Settings for {group.name}", icon='GROUP')

            #     col = lightmap_group_box.column(align=True)
            #     col.label(text=f"Objects in {group.name}:")
            #     col.separator()
            #     box = col.box()
            #     for obj_ref in group.objects:
            #         obj = bpy.data.objects.get(obj_ref.name)
            #         if obj:
            #             row = box.row()
            #             row.label(text=f"{obj.name} ({obj.mhs.lightmap_index})", icon="OBJECT_DATA")
            #         else:
            #             row = box.row()
            #             row.label(text=f"{obj_ref.name} (Not found)", icon="ERROR")

            # Show a message that lightmap groups are disabled
            box = lightmap_group_box.box()
            box.label(text="Lightmap Groups are currently disabled", icon='ERROR')
            box.label(text="(Due to Vulkan visualization errors)", icon='INFO')


        # Lightmap UV Generation
        lightmap_uv_box = layout.box()
        row = lightmap_uv_box.row()
        row.prop(scene.mhs, "show_lightmap_uv_properties", icon="TRIA_DOWN" if scene.mhs.show_lightmap_uv_properties else "TRIA_RIGHT", icon_only=True, emboss=False)
        row.label(text="Lightmap UV Generation", icon='UV')

        if scene.mhs.show_lightmap_uv_properties:
            col = lightmap_uv_box.column(align=True)
            col.prop(scene.mhs, "lightmap_angle_limit")
            col.prop(scene.mhs, "lightmap_island_margin")
            col.prop(scene.mhs, "lightmap_area_weight")

        col.operator("mhs.create_lightmap_uvs", text="Create Lightmap UVs")

        # Lightmap Baking
        bake_box = layout.box()
        row = bake_box.row()
        row.prop(scene.mhs, "show_lightmap_bake_properties", icon="TRIA_DOWN" if scene.mhs.show_lightmap_bake_properties else "TRIA_RIGHT", icon_only=True, emboss=False)
        row.label(text="Lightmap Baking", icon='RENDER_STILL')

        if scene.mhs.show_lightmap_bake_properties:
            col = bake_box.column(align=False)
            #col.prop(scene.mhs, "lightmap_bake_engine")
            #col.prop(scene.mhs, "lightmap_compute_device")
            col.prop(scene.mhs, "lightmap_resolution_modifier")
            col.prop(scene.mhs, "lightmap_bake_mode")

            # Denoising settings
            denoise_box = bake_box.box()
            col = denoise_box.column(align=False)
            col.prop(scene.mhs, "lightmap_use_denoising", text="Use Denoising")
            if scene.mhs.lightmap_use_denoising:
                sub = col.column(align=True)
                sub.prop(scene.mhs, "lightmap_denoise_strength")
                sub.prop(scene.mhs, "lightmap_denoise_color_strength")
                sub.prop(scene.mhs, "lightmap_denoise_space_strength")


            col = bake_box.column(align=False)
            col.scale_y = 1.5
            col.operator("mhs.bake_lightmap", text="Bake Selected Group").bake_all = False
            col.operator("mhs.bake_lightmap", text="Bake All Groups").bake_all = True

class LIGHTPROBE_UL_list(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if not item.object:
            return

        split = layout.split(factor=0.8)

        # Main row with probe name and collection info
        row = split.row(align=True)
        row.alignment = 'LEFT'

        # Add collection info to the display name
        collection_names = [c.name for c in bpy.data.collections if item.name in c.objects]
        display_name = f"{item.name} ({collection_names[0] if collection_names else 'Scene'})"

        # Make the row clickable
        op = row.operator("lightprobe.select_from_list", text=display_name, emboss=False)
        op.probe_name = item.name

        # Status and delete buttons
        buttons_row = split.row(align=True)
        buttons_row.alignment = 'RIGHT'

        # Status icon
        probe = item.object
        if probe and 'lightprobe' in probe:
            probe_properties = probe['lightprobe']
            if probe_properties:
                if probe_properties.get('baked_cubemap'):
                    if probe_properties.get('needs_rebake', True):
                        buttons_row.label(icon='ERROR')
                    else:
                        buttons_row.label(icon='CHECKMARK')
                else:
                    buttons_row.label(icon='DOT')

        # Delete button
        delete_op = buttons_row.operator("lightprobe.delete", text="", icon='X', emboss=False)
        delete_op.probe_name = item.name

    def filter_items(self, context, data, propname):
        # Get list of items
        helper_funcs = bpy.types.UI_UL_list
        items = getattr(data, propname)

        # Initialize with everything visible and in original order
        flags = [self.bitflag_filter_item] * len(items)
        order = []

        # Sort by name if items exist
        if items:
            # Create list of tuples (index, name) for sorting
            sorted_items = [(idx, item.name) for idx, item in enumerate(items)]
            # Sort by name
            sorted_items.sort(key=lambda x: x[1])
            # Extract sorted indices
            order = [item[0] for item in sorted_items]

        return flags, order

class LIGHTPROBE_PT_panel(Panel):
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "render"
    bl_category = "BlendMHS"
    bl_label = "Light Probes"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        # Probe creation tools
        box = layout.box()
        row = box.row(align=True)
        row.operator("lightprobe.add", icon='VOLUME_DATA', text="Add Probe")
        row.operator("lightprobe.add_grid", icon='GRID', text="Add Grid")

        # Probe list with Clear All button
        box = layout.box()
        row = box.row()
        split = row.split(factor=0.7)
        split.label(text="Scene Probes", icon='OUTLINER_OB_LIGHTPROBE')
        button_row = split.row()
        button_row.alignment = 'RIGHT'
        button_row.scale_x = 1
        button_row.operator("lightprobe.clear_all", icon='X', text="Clear All")

        # Draw the list
        # DISABLED: probe_list property doesn't exist - causes AttributeError
        # row = box.row()
        # row.template_list(
        #     "LIGHTPROBE_UL_list", "",
        #     context.scene.mhs, "probe_list",
        #     context.scene.mhs, "active_lightprobe_index",
        #     rows=5
        # )

        # Show a message that light probes are disabled
        row = box.row()
        box_disabled = row.box()
        box_disabled.label(text="Light Probes are currently disabled", icon='ERROR')
        box_disabled.label(text="(Due to Vulkan visualization errors)", icon='INFO')

        # Selected probe settings
        active_probe = context.active_object
        if active_probe and active_probe.type == 'EMPTY' and active_probe.lightprobe:
            probe_properties = active_probe.lightprobe

            box = layout.box()
            col = box.column()

            # Core settings
            row = col.row()
            row.prop(active_probe.lightprobe, "samples", text="Samples")

            # Baked status
            status_row = col.row()
            if probe_properties.baked_cubemap:
                if probe_properties.needs_rebake:
                        status_row.label(text="Needs Rebake", icon='ERROR')
                else:
                    status_row.label(text="Baked", icon='CHECKMARK')
                box.template_ID_preview(probe_properties, "baked_cubemap",
                                     open="image.open", hide_buttons=True)
            else:
                status_row.label(text="Not Baked", icon='DOT')

        # Bake buttons
        col = layout.column(align=True)
        col.scale_y = 1.5
        row = col.row()
        row.operator("lightprobe.bake", text="Bake Selected").bake_all = False
        row.operator("lightprobe.bake", text="Bake All").bake_all = True

        # Export button
        # col.operator("lightprobe.export", icon='EXPORT')  # DISABLED: Lightmap export

# ═══════════════════════════════════════════════════════════════════════════════
# Frame Rate Presets Menu (wraps Blender's built-in with Custom option)
# ═══════════════════════════════════════════════════════════════════════════════

class MHS_OT_set_framerate_preset(Operator):
    """Set a frame rate preset and hide custom fields"""
    bl_idname = "mhs.set_framerate_preset"
    bl_label = "Set Frame Rate Preset"
    bl_options = {'REGISTER', 'UNDO'}

    fps: IntProperty(name="FPS", default=30)
    fps_base: bpy.props.FloatProperty(name="FPS Base", default=1.0)

    def execute(self, context):
        context.scene.render.fps = self.fps
        context.scene.render.fps_base = self.fps_base
        context.scene.mhs.use_custom_framerate = False
        return {'FINISHED'}


class MHS_OT_set_custom_framerate(Operator):
    """Enable custom frame rate fields"""
    bl_idname = "mhs.set_custom_framerate"
    bl_label = "Custom"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.mhs.use_custom_framerate = True
        return {'FINISHED'}


class MHS_MT_framerate_presets(Menu):
    """Frame rate presets menu with Custom option"""
    bl_idname = "MHS_MT_framerate_presets"
    bl_label = "Frame Rate Presets"

    def draw(self, context):
        layout = self.layout

        # Standard frame rate presets
        presets = [
            (24, 1.001, "23.98 fps"),
            (24, 1.0, "24 fps"),
            (25, 1.0, "25 fps"),
            (30, 1.001, "29.97 fps"),
            (30, 1.0, "30 fps"),
            (50, 1.0, "50 fps"),
            (60, 1.001, "59.94 fps"),
            (60, 1.0, "60 fps"),
            (120, 1.0, "120 fps"),
            (240, 1.0, "240 fps"),
        ]

        for fps, fps_base, label in presets:
            op = layout.operator("mhs.set_framerate_preset", text=label)
            op.fps = fps
            op.fps_base = fps_base

        layout.separator()

        # Custom option
        layout.operator("mhs.set_custom_framerate", text="Custom")


# ═══════════════════════════════════════════════════════════════════════════════
# Animation Action Extras Menu (Phase 4 of Action Loader Enhancement)
# ═══════════════════════════════════════════════════════════════════════════════

class MHS_MT_action_extras_menu(Menu):
    """Extras menu for animation action list with batch operations"""
    bl_idname = "MHS_MT_action_extras_menu"
    bl_label = "Action Menu"

    def draw(self, context):
        layout = self.layout

        # Selection operations
        layout.operator("mhs.select_all_animation_actions", text="Select All", icon='CHECKBOX_HLT')
        layout.operator("mhs.deselect_all_animation_actions", text="Deselect All", icon='CHECKBOX_DEHLT')

        layout.separator()

        # Batch operations
        layout.operator("mhs.batch_enable_actions", text="Enable Filtered").enable = True
        layout.operator("mhs.batch_enable_actions", text="Disable Filtered").enable = False
        layout.operator("mhs.batch_tag_actions", text="Tag Actions...", icon='BOOKMARKS')

        layout.separator()

        # Organization
        layout.operator("mhs.add_action_label", text="Add Label", icon='FONT_DATA')
        layout.operator("mhs.clean_action_list", text="Clean Invalid", icon='BRUSH_DATA')

        layout.separator()

        # Import/Load operations
        layout.operator("mhs.load_all_actions", text="Load All Compatible", icon='FILE_REFRESH')
        layout.operator("mhs.append_action_from_file", text="Import from .blend...", icon='FILE_BLEND')

        layout.separator()

        # Playback
        layout.operator("mhs.play_action", text="Play Selected", icon='PLAY')


# ═══════════════════════════════════════════════════════════════════════════════
# Animation Setup Panel for Animation Editors (Dope Sheet, Graph Editor, NLA)
# ═══════════════════════════════════════════════════════════════════════════════

class MHS_AnimationPanelMixin:
    """Mixin class containing shared animation panel functionality for animation editors"""

    bl_label = "MHS Actions"
    bl_category = "BlendMHS"
    bl_region_type = 'UI'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        """Check if we should show the panel - requires armature with actions"""
        obj = context.active_object
        if not obj:
            return False

        # Get the armature
        armature = None
        if obj.type == 'ARMATURE':
            armature = obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    armature = modifier.object
                    break

        if not armature:
            return False

        # Check if armature has MHS properties
        if not hasattr(armature, 'mhs'):
            return False

        return True

    def get_armature(self, context):
        """Get the armature from context"""
        obj = context.active_object
        if not obj:
            return None

        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def draw(self, context):
        layout = self.layout
        armature = self.get_armature(context)

        if not armature:
            layout.label(text="No armature selected", icon='INFO')
            return

        # Armature name header
        armature_row = layout.row()
        armature_row.label(text=armature.name, icon='ARMATURE_DATA')

        # Actions count
        total_actions = len(armature.mhs.animation_export_actions)
        header_row = layout.row()
        header_row.label(text=f"{total_actions} Actions Loaded", icon='ACTION')

        # Check if active action is not in the list
        if armature.animation_data and armature.animation_data.action:
            active_action = armature.animation_data.action
            action_in_list = any(item.action == active_action for item in armature.mhs.animation_export_actions)
            if not action_in_list:
                row = layout.row()
                row.scale_y = 1.3
                row.operator("mhs.add_active_action", text=f"Load Active: {active_action.name}", icon='ACTION')

        # New / Load / Dropdown Menu
        button_row = layout.row(align=True)
        button_row.operator("mhs.new_action", text="New", icon='ADD')
        button_row.operator("mhs.load_all_actions", text="Load")
        button_row.menu("MHS_MT_action_extras_menu", text="", icon='DOWNARROW_HLT')

        # Actions list
        if total_actions > 0:
            layout.template_list(
                "MHS_UL_animation_actions", "",
                armature.mhs, "animation_export_actions",
                armature.mhs, "active_animation_action_index",
                rows=5
            )

            # Selected Action Detail
            idx = armature.mhs.active_animation_action_index
            if 0 <= idx < total_actions:
                active_item = armature.mhs.animation_export_actions[idx]
                if active_item.action:
                    action = active_item.action

                    # Action detail foldout
                    detail_box = layout.box()
                    header_row = detail_box.row(align=True)

                    # Foldout toggle
                    icon = "TRIA_DOWN" if armature.mhs.show_action_detail else "TRIA_RIGHT"
                    header_row.prop(armature.mhs, "show_action_detail", text="", icon=icon, emboss=False)

                    # Action name
                    header_row.prop(action, "name", text="")

                    # Duplicate button
                    header_row.operator("mhs.duplicate_action", text="", icon='DUPLICATE')

                    # Enabled checkbox
                    icon_enabled = 'CHECKBOX_HLT' if active_item.enabled else 'CHECKBOX_DEHLT'
                    header_row.prop(active_item, "enabled", text="", icon=icon_enabled, emboss=True)

                    # Remove button
                    op = header_row.operator("mhs.remove_animation_action", text="", icon='X')
                    op.action_index = idx

                    # Show detail contents if expanded
                    if armature.mhs.show_action_detail:
                        # Action Slot
                        row = detail_box.row(align=True)
                        row.label(text="Action Slot:")
                        if hasattr(action, 'slots') and len(action.slots) > 0:
                            row.prop_search(active_item, "action_slot", action, "slots", text="")
                        else:
                            row.label(text=armature.name, icon='ARMATURE_DATA')

                        # Frame Range
                        row = detail_box.row(align=True)
                        if action.use_frame_range:
                            row.prop(action, "frame_start", text="Start")
                            row.prop(action, "frame_end", text="End")
                        else:
                            row.prop(action, "curve_frame_range", text="Start", index=0)
                            row.prop(action, "curve_frame_range", text="End", index=1)

                        # Is Loop
                        detail_box.prop(active_item, "is_loop", text="Is Loop")

                        # Manual Frame Range
                        detail_box.prop(action, "use_frame_range", text="Manual Frame Range")

                        # Use Cyclic
                        detail_box.prop(action, "use_cyclic", text="Use Cyclic")

                        # Tags
                        detail_box.prop(active_item, "tags", text="Tags")

            # Action Box (operations)
            action_ops_box = layout.box()
            row = action_ops_box.row()
            row.prop(armature.mhs, "show_action_box",
                    icon="TRIA_DOWN" if armature.mhs.show_action_box else "TRIA_RIGHT",
                    text="Action Box", emboss=False)

            if armature.mhs.show_action_box:
                col = action_ops_box.column(align=True)

                row = col.row()
                row.scale_y = 1.3
                row.operator("mhs.play_action", text="Play", icon='PLAY')

                row = col.row()
                row.scale_y = 1.3
                row.operator("mhs.flip_action", text="Flip Action", icon='MOD_MIRROR')

                row = col.row()
                row.scale_y = 1.3
                row.operator("mhs.bake_action", text="Bake This Action", icon='KEYTYPE_KEYFRAME_VEC')

                row = col.row()
                row.scale_y = 1.3
                row.operator("mhs.push_action_to_nla", text="Push To NLA", icon='NLA_PUSHDOWN')

                row = col.row()
                row.scale_y = 1.3
                row.operator("mhs.duplicate_action", text="Duplicate", icon='DUPLICATE')


class MHS_PT_animation_dopesheet_panel(MHS_AnimationPanelMixin, Panel):
    """Animation Setup panel for Dope Sheet / Action Editor"""
    bl_idname = "MHS_PT_animation_dopesheet_panel"
    bl_space_type = 'DOPESHEET_EDITOR'


class MHS_PT_animation_graph_panel(MHS_AnimationPanelMixin, Panel):
    """Animation Setup panel for Graph Editor"""
    bl_idname = "MHS_PT_animation_graph_panel"
    bl_space_type = 'GRAPH_EDITOR'


class MHS_PT_animation_nla_panel(MHS_AnimationPanelMixin, Panel):
    """Animation Setup panel for NLA Editor"""
    bl_idname = "MHS_PT_animation_nla_panel"
    bl_space_type = 'NLA_EDITOR'


def register():
    bpy.utils.register_class(MHS_OT_open_documentation)
    bpy.utils.register_class(MHS_OT_dismiss_layout_hint)
    bpy.utils.register_class(MHS_OT_open_layout_setup)
    bpy.utils.register_class(MHS_UL_LOD_list)
    bpy.utils.register_class(MHS_UL_layout_exports)
    bpy.utils.register_class(MHS_UL_layout_collections)
    bpy.utils.register_class(MHS_UL_animation_actions)
    bpy.utils.register_class(MHS_UL_animated_objects)
    bpy.utils.register_class(MHS_OT_refresh_animated_objects)
    bpy.utils.register_class(MHS_OT_select_animated_object)
    bpy.utils.register_class(MHS_OT_refresh_animation_actions)
    bpy.utils.register_class(MHS_OT_select_all_animation_actions)
    bpy.utils.register_class(MHS_OT_deselect_all_animation_actions)
    bpy.utils.register_class(MHS_OT_remove_animation_action)
    bpy.utils.register_class(MHS_MT_move_to_collection)
    bpy.utils.register_class(MHS_MT_action_extras_menu)
    bpy.utils.register_class(MHS_OT_set_framerate_preset)
    bpy.utils.register_class(MHS_OT_set_custom_framerate)
    bpy.utils.register_class(MHS_MT_framerate_presets)
    # NOTE: MHS_MT_quick_export_pie is now registered dynamically via the activation system
    # in registration.py based on the activate_quick_export_pie preference
    bpy.utils.register_class(MHS_PT_base_panel)
    bpy.utils.register_class(MHS_PT_project_management_panel)
    bpy.utils.register_class(MHS_PT_quick_export_panel)
    bpy.utils.register_class(MHS_PT_layout_panel)
    bpy.utils.register_class(MHS_PT_export_panel)
    bpy.utils.register_class(MHS_PT_animation_export_panel)
    bpy.utils.register_class(MHS_PT_material_settings_panel)
    # bpy.utils.register_class(MHS_UL_LightmapGroupList)  # DISABLED: Causes Vulkan visualization errors
    # bpy.utils.register_class(MHS_PT_lightmapping_panel)  # DISABLED: Causes Vulkan visualization errors
    # bpy.utils.register_class(LIGHTPROBE_UL_list)  # DISABLED: Causes Vulkan visualization errors
    # bpy.utils.register_class(LIGHTPROBE_PT_panel)  # DISABLED: Causes Vulkan visualization errors

    # Animation panels for animation editors (Dope Sheet, Graph Editor, NLA)
    bpy.utils.register_class(MHS_PT_animation_dopesheet_panel)
    bpy.utils.register_class(MHS_PT_animation_graph_panel)
    bpy.utils.register_class(MHS_PT_animation_nla_panel)

    # NOTE: Keymaps for Quick Export pie menu are now registered dynamically
    # via the new registration system in utils/registration.py

def unregister():
    # NOTE: MHS_MT_quick_export_pie and its keymaps are now unregistered dynamically
    # via the activation system in __init__.py and registration.py

    # Animation panels for animation editors (Dope Sheet, Graph Editor, NLA)
    bpy.utils.unregister_class(MHS_PT_animation_nla_panel)
    bpy.utils.unregister_class(MHS_PT_animation_graph_panel)
    bpy.utils.unregister_class(MHS_PT_animation_dopesheet_panel)

    # bpy.utils.unregister_class(LIGHTPROBE_PT_panel)  # DISABLED: Causes Vulkan visualization errors
    # bpy.utils.unregister_class(LIGHTPROBE_UL_list)  # DISABLED: Causes Vulkan visualization errors
    # bpy.utils.unregister_class(MHS_PT_lightmapping_panel)  # DISABLED: Causes Vulkan visualization errors
    # bpy.utils.unregister_class(MHS_UL_LightmapGroupList)  # DISABLED: Causes Vulkan visualization errors
    bpy.utils.unregister_class(MHS_PT_material_settings_panel)
    bpy.utils.unregister_class(MHS_PT_animation_export_panel)
    bpy.utils.unregister_class(MHS_PT_export_panel)
    bpy.utils.unregister_class(MHS_PT_layout_panel)
    bpy.utils.unregister_class(MHS_PT_quick_export_panel)
    bpy.utils.unregister_class(MHS_PT_project_management_panel)
    bpy.utils.unregister_class(MHS_PT_base_panel)
    # NOTE: MHS_MT_quick_export_pie is now unregistered dynamically via the activation system
    bpy.utils.unregister_class(MHS_MT_framerate_presets)
    bpy.utils.unregister_class(MHS_OT_set_custom_framerate)
    bpy.utils.unregister_class(MHS_OT_set_framerate_preset)
    bpy.utils.unregister_class(MHS_MT_action_extras_menu)
    bpy.utils.unregister_class(MHS_MT_move_to_collection)
    bpy.utils.unregister_class(MHS_OT_remove_animation_action)
    bpy.utils.unregister_class(MHS_OT_deselect_all_animation_actions)
    bpy.utils.unregister_class(MHS_OT_select_all_animation_actions)
    bpy.utils.unregister_class(MHS_OT_refresh_animation_actions)
    bpy.utils.unregister_class(MHS_OT_select_animated_object)
    bpy.utils.unregister_class(MHS_OT_refresh_animated_objects)
    bpy.utils.unregister_class(MHS_UL_animated_objects)
    bpy.utils.unregister_class(MHS_UL_animation_actions)
    bpy.utils.unregister_class(MHS_UL_layout_collections)
    bpy.utils.unregister_class(MHS_UL_layout_exports)
    bpy.utils.unregister_class(MHS_UL_LOD_list)
    bpy.utils.unregister_class(MHS_OT_open_layout_setup)
    bpy.utils.unregister_class(MHS_OT_dismiss_layout_hint)
    bpy.utils.unregister_class(MHS_OT_open_documentation)
