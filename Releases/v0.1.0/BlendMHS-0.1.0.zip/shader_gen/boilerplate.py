"""
Shader Boilerplate Generator

This module generates MHS-compliant .surface shader files from Blender node groups.
The generated shaders follow the MHS surface shader format with:
- Description block
- Options block (template selection)
- Properties block (shader parameters)
- Surface function block (shader logic)
"""

import os
from typing import Optional

from .templates import get_template_name, infer_template_from_name

# Try to import Blender modules (may not be available in tests)
try:
    import bpy
except ImportError:
    bpy = None

# Import from sibling module
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from material_map.introspection import ShaderDefinition, ShaderProperty


class ShaderBoilerplateGenerator:
    """Generates MHS surface shader boilerplate from Blender node groups."""

    def __init__(self, output_directory: str = ""):
        """
        Initialize the generator.

        Args:
            output_directory: Directory to write generated shader files
        """
        self.output_directory = output_directory

    def generate_surface_shader(
        self,
        shader_def: ShaderDefinition,
        template: str = None
    ) -> str:
        """
        Generate a complete .surface shader file.

        Args:
            shader_def: ShaderDefinition containing property metadata
            template: Optional template key (e.g., 'Lit', 'LitSkinned').
                      If not provided, uses shader_def.template

        Returns:
            Complete shader file content as string
        """
        # Use shader definition's template if none provided
        if template is None:
            template = getattr(shader_def, 'template', 'Lit')

        template_name = get_template_name(template)

        lines = [
            "// (c) Meta Platforms, Inc. and affiliates. Confidential and proprietary.",
            "",
            "BEGIN_DESCRIPTION",
            f"{shader_def.description}",
            "END_DESCRIPTION",
            "",
            "BEGIN_OPTIONS",
            f'  Template "{template_name}"',
            "END_OPTIONS",
            "",
            "BEGIN_PROPERTIES",
        ]

        # Generate properties
        for prop in shader_def.properties:
            lines.extend(self._generate_property(prop))

        lines.extend([
            "END_PROPERTIES",
            "",
            "BEGIN_SURFACE",
            "void surfaceFunction(inout Surface s, SurfaceData sd) {",
        ])

        # Generate surface function body
        lines.extend(self._generate_surface_body(shader_def))

        lines.extend([
            "}",
            "END_SURFACE",
        ])

        return "\n".join(lines)

    def _generate_property(self, prop: ShaderProperty) -> list[str]:
        """Generate BEGIN_PROPERTIES content for a single property."""
        lines = []

        # Skip internal properties (starting with _)
        if prop.name.startswith('_'):
            return lines

        # Get USD attribute - check explicit mapping first, then infer
        usd_attr = prop.usd_attribute_name
        if not usd_attr:
            from material_map.introspection import infer_usd_attribute
            usd_attr = infer_usd_attribute(prop.name, prop.is_texture)

        # Only include properties that have a USD attribute mapping
        if not usd_attr:
            return lines

        # Add help attribute
        lines.append(f'  [Help("{prop.name}")]')

        # Add range/slider for floats with min/max
        if prop.property_type == 'float':
            min_val = prop.min_value if prop.min_value is not None else 0.0
            max_val = prop.max_value if prop.max_value is not None else 1.0
            # Calculate reasonable step size
            range_size = max_val - min_val
            if range_size > 0:
                step = range_size / 100.0  # 100 steps across the range
            else:
                step = 0.01
            lines.append(f'  [Slider({min_val:.6g}, {max_val:.6g}, {step:.6g})]')

        # Format default value and type
        default_value = self._format_default_value(prop)
        type_name = self._get_type_name(prop.property_type)

        lines.append(f'  {prop.name}("{prop.name}", {type_name}) = {default_value}')
        lines.append("")

        return lines

    def _get_type_name(self, property_type: str) -> str:
        """Get MHS type name for property type."""
        type_map = {
            'float': 'Float',
            'color': 'Color',
            'vector': 'Vector4',
            'texture': '2D',
            'bool': 'Float',
        }
        return type_map.get(property_type, 'Float')

    def _format_default_value(self, prop: ShaderProperty) -> str:
        """Format the default value for a property with proper precision."""
        if prop.property_type == 'float':
            val = prop.default_value if prop.default_value is not None else 0.5
            return f"{val:.6g}"

        elif prop.property_type == 'color':
            if prop.default_value and len(prop.default_value) >= 4:
                r, g, b, a = prop.default_value[:4]
                return f"({r:.6g}, {g:.6g}, {b:.6g}, {a:.6g})"
            return "(1.0, 1.0, 1.0, 1.0)"

        elif prop.property_type == 'vector':
            if prop.default_value and len(prop.default_value) >= 3:
                x, y, z = prop.default_value[:3]
                w = prop.default_value[3] if len(prop.default_value) > 3 else 0.0
                return f"({x:.6g}, {y:.6g}, {z:.6g}, {w:.6g})"
            return "(0.0, 0.0, 0.0, 0.0)"

        elif prop.property_type == 'texture':
            return '"white"'

        elif prop.property_type == 'bool':
            val = 1.0 if prop.default_value else 0.0
            return f"{val:.6g}"

        return "0.0"

    def _generate_surface_body(self, shader_def: ShaderDefinition) -> list[str]:
        """Generate the body of the surfaceFunction using shader properties."""
        lines = []

        # Track what we've assigned
        assigned = {
            'baseColor': False,
            'roughness': False,
            'metallic': False,
            'normal': False,
            'emissive': False,
            'occlusion': False,
            'opacity': False,
        }

        # Process all properties and map them based on USD attribute
        for prop in shader_def.properties:
            # Get USD attribute - check explicit mapping first, then infer
            usd_attr = prop.usd_attribute_name
            if not usd_attr:
                # Try to infer from name
                from material_map.introspection import infer_usd_attribute
                usd_attr = infer_usd_attribute(prop.name, prop.is_texture)

            if not usd_attr:
                continue

            attr_lower = usd_attr.lower()

            if attr_lower == 'diffusecolor' and not assigned['baseColor']:
                if prop.is_texture:
                    lines.append(f"  s.baseColor = TEX({prop.name}).rgb * sd.vertexColor0.rgb;")
                else:
                    lines.append(f"  s.baseColor = matParams.{prop.name}.rgb * sd.vertexColor0.rgb;")
                assigned['baseColor'] = True

            elif attr_lower == 'roughness' and not assigned['roughness']:
                if prop.is_texture:
                    lines.append(f"  s.roughness = TEX({prop.name}).r;")
                else:
                    lines.append(f"  s.roughness = matParams.{prop.name};")
                assigned['roughness'] = True

            elif attr_lower == 'metallic' and not assigned['metallic']:
                if prop.is_texture:
                    lines.append(f"  s.metallic = TEX({prop.name}).r;")
                else:
                    lines.append(f"  s.metallic = matParams.{prop.name};")
                assigned['metallic'] = True

            elif attr_lower == 'emissivecolor' and not assigned['emissive']:
                if prop.is_texture:
                    lines.append(f"  s.emissive = TEX({prop.name}).rgb;")
                else:
                    lines.append(f"  s.emissive = matParams.{prop.name}.rgb;")
                assigned['emissive'] = True

            elif attr_lower == 'normal' and not assigned['normal']:
                if prop.is_texture:
                    lines.append(f"  s.normal = normalize(TEX({prop.name}).xyz * 2.0 - 1.0);")
                assigned['normal'] = True

            elif attr_lower == 'occlusion' and not assigned['occlusion']:
                if prop.is_texture:
                    lines.append(f"  s.occlusion = TEX({prop.name}).r;")
                else:
                    lines.append(f"  s.occlusion = matParams.{prop.name};")
                assigned['occlusion'] = True

            elif attr_lower == 'opacity' and not assigned['opacity']:
                if prop.is_texture:
                    lines.append(f"  s.alpha = TEX({prop.name}).a;")
                else:
                    lines.append(f"  s.alpha = matParams.{prop.name};")
                assigned['opacity'] = True

        # Add sensible defaults for unassigned core properties
        if not assigned['baseColor']:
            lines.append("  s.baseColor = sd.vertexColor0.rgb;")

        if not assigned['roughness']:
            lines.append("  s.roughness = 0.5;")

        if not assigned['metallic']:
            lines.append("  s.metallic = 0.0;")

        return lines

    def export_shader(
        self,
        shader_def: ShaderDefinition,
        template: str = "Lit",
        filename: Optional[str] = None
    ) -> str:
        """
        Generate and save a shader file.

        Args:
            shader_def: ShaderDefinition containing property metadata
            template: Template key
            filename: Output filename (without extension). Uses shader_def.name if not provided.

        Returns:
            Path to the generated file
        """
        content = self.generate_surface_shader(shader_def, template)

        # Determine filename
        if filename is None:
            filename = shader_def.name.replace("HSR_", "").lower()

        # Ensure .surface extension
        if not filename.endswith('.surface'):
            filename = f"{filename}.surface"

        # Build full path
        if self.output_directory:
            # Resolve relative paths
            if bpy and self.output_directory.startswith("//"):
                output_dir = bpy.path.abspath(self.output_directory)
            else:
                output_dir = self.output_directory

            # Ensure directory exists
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)

            filepath = os.path.join(output_dir, filename)
        else:
            filepath = filename

        # Write file
        with open(filepath, 'w') as f:
            f.write(content)

        print(f"Generated shader: {filepath}")
        return filepath


def generate_surface_shader(
    shader_def: ShaderDefinition,
    template: str = "Lit"
) -> str:
    """
    Convenience function to generate a surface shader.

    Args:
        shader_def: ShaderDefinition containing property metadata
        template: Template key

    Returns:
        Shader file content as string
    """
    generator = ShaderBoilerplateGenerator()
    return generator.generate_surface_shader(shader_def, template)


def generate_shader_from_node_group(node_group, template: str = None) -> str:
    """
    Generate a surface shader from a Blender node group.

    Args:
        node_group: Blender node group to introspect
        template: Optional template key. If not provided, infers from name.

    Returns:
        Shader file content as string
    """
    from material_map.introspection import introspect_node_group

    shader_def = introspect_node_group(node_group)

    if template is None:
        template = infer_template_from_name(shader_def.name)

    generator = ShaderBoilerplateGenerator()
    return generator.generate_surface_shader(shader_def, template)
