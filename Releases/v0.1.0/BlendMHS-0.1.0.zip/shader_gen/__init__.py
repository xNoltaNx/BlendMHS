"""
Shader Generator Module

This module handles the generation of MHS surface shader boilerplate code
from Blender node groups.

Submodules:
- boilerplate: Surface shader boilerplate generator
- templates: Shader templates for different material types
"""

from .boilerplate import (
    ShaderBoilerplateGenerator,
    generate_surface_shader,
)
from .templates import (
    SHADER_TEMPLATES,
    get_template_name,
)

__all__ = [
    'ShaderBoilerplateGenerator',
    'generate_surface_shader',
    'SHADER_TEMPLATES',
    'get_template_name',
]
