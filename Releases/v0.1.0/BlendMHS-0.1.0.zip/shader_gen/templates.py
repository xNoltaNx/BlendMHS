"""
Shader Templates

This module contains template definitions for different MHS shader types.
Templates are used when generating .surface shader boilerplate.
"""

# Map from template enum values to MHS template names
SHADER_TEMPLATES = {
    'Lit': 'lit',
    'Unlit': 'unlit',
    'LitSkinned': 'litSkinned',
    'UnlitSkinned': 'unlitSkinned',
    'Line': 'line',
    'Compute': 'compute',
}

# Default template options based on usage
TEMPLATE_DEFAULTS = {
    'Lit': {
        'description': 'Standard lit PBR material',
        'has_skinning': False,
        'supports_transparency': True,
    },
    'Unlit': {
        'description': 'Unlit/emissive material',
        'has_skinning': False,
        'supports_transparency': True,
    },
    'LitSkinned': {
        'description': 'Lit material with skeletal animation support',
        'has_skinning': True,
        'supports_transparency': True,
    },
    'UnlitSkinned': {
        'description': 'Unlit material with skeletal animation',
        'has_skinning': True,
        'supports_transparency': True,
    },
    'Line': {
        'description': 'Line rendering',
        'has_skinning': False,
        'supports_transparency': True,
    },
    'Compute': {
        'description': 'Compute shader',
        'has_skinning': False,
        'supports_transparency': False,
    },
}


def get_template_name(template_key: str) -> str:
    """
    Get the MHS template name for a given template key.

    Args:
        template_key: Template key (e.g., 'Lit', 'LitSkinned')

    Returns:
        Template name (e.g., 'lit', 'litSkinned')
    """
    return SHADER_TEMPLATES.get(template_key, 'lit')


def get_template_defaults(template_key: str) -> dict:
    """
    Get default settings for a given template.

    Args:
        template_key: Template key

    Returns:
        Dictionary of default settings
    """
    return TEMPLATE_DEFAULTS.get(template_key, TEMPLATE_DEFAULTS['Lit'])


def infer_template_from_name(shader_name: str) -> str:
    """
    Infer the appropriate template from a shader name.

    Args:
        shader_name: Name of the shader

    Returns:
        Template key (e.g., 'Lit', 'LitSkinned')
    """
    name_lower = shader_name.lower()

    # Check for skinned variants first
    if 'skinned' in name_lower:
        if 'unlit' in name_lower:
            return 'UnlitSkinned'
        return 'LitSkinned'

    # Check for specific types
    if 'unlit' in name_lower or 'emissive' in name_lower:
        return 'Unlit'

    if 'line' in name_lower:
        return 'Line'

    if 'compute' in name_lower:
        return 'Compute'

    # Default to Lit
    return 'Lit'
