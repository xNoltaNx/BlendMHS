import numpy as np
import math
from mathutils import Vector, Matrix
import json

def compute_sh_basis(direction):
    """
    Compute spherical harmonics basis functions for a given direction vector.
    Note: direction should be in RUF coordinate system.
    """
    # Transform direction to RUF
    direction_ruf = transform_vector_to_ruf(direction)
    x, y, z = direction_ruf
    
    # Normalization constants
    k0 = 0.282094791773878  # 1/(2*sqrt(pi))
    k1 = 0.488602511902920  # sqrt(3/(4*pi))
    k2 = 1.092548430592079  # sqrt(15/(4*pi))
    k3 = 0.315391565252520  # sqrt(5/(16*pi))
    k4 = 0.546274215296039  # sqrt(15/(16*pi))
    
    basis = np.zeros(9)
    
    # Band L = 0
    basis[0] = k0  # Y00
    
    # Band L = 1
    basis[1] = k1 * y    # Y1,-1
    basis[2] = k1 * z    # Y1,0
    basis[3] = k1 * x    # Y1,1
    
    # Band L = 2
    basis[4] = k2 * x * y            # Y2,-2
    basis[5] = k2 * y * z            # Y2,-1
    basis[6] = k3 * (3*z*z - 1)      # Y2,0
    basis[7] = k2 * x * z            # Y2,1
    basis[8] = k4 * (x*x - y*y)      # Y2,2
    
    return basis

def sample_sphere(num_samples=1000):
    """
    Generate uniform sample points on a sphere using fibonacci spiral.
    """
    points = []
    phi = math.pi * (3. - math.sqrt(5.))  # golden angle in radians

    for i in range(num_samples):
        y = 1 - (i / float(num_samples - 1)) * 2  # y goes from 1 to -1
        radius = math.sqrt(1 - y * y)  # radius at y

        theta = phi * i  # golden angle increment

        x = math.cos(theta) * radius
        z = math.sin(theta) * radius

        points.append(Vector((x, y, z)))

    return points

def compute_sh_for_cubemap(cubemap_image):
    """
    Compute spherical harmonics coefficients from a cubemap image.
    Returns coefficients in RUF orientation.
    """
    # Sample points on the sphere
    sample_points = sample_sphere()
    
    # Initialize coefficients array (9 coefficients, each with RGB)
    coefficients = np.zeros((9, 3))
    
    # For each sample point
    for direction in sample_points:
        # Get the color from the cubemap for this direction
        color = sample_cubemap(cubemap_image, direction)
        
        # Compute SH basis for this direction (will be transformed to RUF internally)
        basis = compute_sh_basis(direction)
        
        # Accumulate weighted coefficients
        for i in range(9):
            coefficients[i] += color * basis[i]
    
    # Normalize coefficients
    coefficients /= len(sample_points)
    
    # No need to transform coefficients here as they're already computed in RUF space
    return coefficients

def sample_cubemap(image, direction):
    """
    Sample a color from a cubemap given a direction vector.
    This is a placeholder implementation - you'll need to implement proper cubemap sampling.
    """
    # For now, return a placeholder color
    return Vector((1.0, 1.0, 1.0))

def export_light_probes_sh(context, filepath):
    """
    Export light probe spherical harmonics data to JSON in RUF orientation.
    Coefficients are ordered: L00, L11, L10, L1_1, L21, L2_1, L2_2, L20, L22
    """
    scene = context.scene
    data = {
        "lightprobes": []
    }
    
    for probe in scene.mhs.light_probes:
        # Transform probe location to RUF
        location_ruf = transform_vector_to_ruf(probe.location)
        
        # Get coefficients as numpy array for transformation
        coefficients = sh_props_to_numpy(probe.sh_coefficients)
        
        # Transform coefficients to RUF orientation
        coefficients_ruf = transform_sh_to_ruf(coefficients)
        
        # Create probe data with reordered coefficients
        probe_data = {
            "location": {
                "x": location_ruf.x,
                "y": location_ruf.y,
                "z": location_ruf.z
            },
            "coefficients": {
                # Reordered according to specified sequence
                "L00": vector_to_dict(coefficients_ruf[0]),  # L00
                "L11": vector_to_dict(coefficients_ruf[3]),  # L11
                "L10": vector_to_dict(coefficients_ruf[2]),  # L10
                "L1_1": vector_to_dict(coefficients_ruf[1]), # L1_1
                "L21": vector_to_dict(coefficients_ruf[7]),  # L21
                "L2_1": vector_to_dict(coefficients_ruf[5]), # L2_1
                "L2_2": vector_to_dict(coefficients_ruf[4]), # L2_2
                "L20": vector_to_dict(coefficients_ruf[6]),  # L20
                "L22": vector_to_dict(coefficients_ruf[8])   # L22
            }
        }
        data["lightprobes"].append(probe_data)
    
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2)

def sh_props_to_numpy(sh_props):
    """
    Convert SH property group to numpy array for transformation.
    Internal order: L00, L1_1, L10, L11, L2_2, L2_1, L20, L21, L22
    """
    coefficients = np.zeros((9, 3))
    coefficients[0] = np.array(sh_props.L00)   # L00
    coefficients[1] = np.array(sh_props.L1_1)  # L1_1
    coefficients[2] = np.array(sh_props.L10)   # L10
    coefficients[3] = np.array(sh_props.L11)   # L11
    coefficients[4] = np.array(sh_props.L2_2)  # L2_2
    coefficients[5] = np.array(sh_props.L2_1)  # L2_1
    coefficients[6] = np.array(sh_props.L20)   # L20
    coefficients[7] = np.array(sh_props.L21)   # L21
    coefficients[8] = np.array(sh_props.L22)   # L22
    return coefficients

def vector_to_dict(vec):
    """Convert a vector to a dictionary with x, y, z components."""
    return {
        "x": vec[0],
        "y": vec[1],
        "z": vec[2]
    }
    
def blender_to_ruf_matrix():
    """
    Create transformation matrix from Blender (Y-up) to RUF coordinate system.
    Blender: Right = X, Up = Z, Forward = -Y
    RUF: Right = X, Up = Y, Forward = Z
    """
    return Matrix((
        ( 1.0,  0.0,  0.0,  0.0),
        ( 0.0,  0.0,  1.0,  0.0),
        ( 0.0, -1.0,  0.0,  0.0),
        ( 0.0,  0.0,  0.0,  1.0)
    ))

def transform_vector_to_ruf(vec):
    """Transform a vector from Blender to RUF coordinate system."""
    transform = blender_to_ruf_matrix()
    transformed = transform @ Vector((vec[0], vec[1], vec[2], 1.0))
    return Vector((transformed.x, transformed.y, transformed.z))

def transform_sh_to_ruf(coefficients):
    """
    Transform spherical harmonics coefficients from Blender to RUF coordinate system.
    This involves rotating the basis functions according to the coordinate transform.
    """
    # Get the rotation matrix for the coordinate transform
    transform = blender_to_ruf_matrix().to_3x3()
    
    # Create rotation matrix in SH space (for each band)
    # This is a simplified version - for complete accuracy, you'd need to properly
    # rotate each SH band according to the Wigner D-matrices
    
    result = np.zeros_like(coefficients)
    
    # L0 band (coefficients[0]) doesn't change under rotation
    result[0] = coefficients[0]
    
    # L1 band transformation
    l1_indices = [1, 2, 3]  # indices for L1,-1, L1,0, L1,1
    for i in l1_indices:
        vec = Vector((coefficients[i][0], coefficients[i][1], coefficients[i][2]))
        rotated = transform @ vec
        result[i] = np.array([rotated.x, rotated.y, rotated.z])
    
    # L2 band transformation
    l2_indices = [4, 5, 6, 7, 8]  # indices for L2 coefficients
    for i in l2_indices:
        vec = Vector((coefficients[i][0], coefficients[i][1], coefficients[i][2]))
        rotated = transform @ vec
        result[i] = np.array([rotated.x, rotated.y, rotated.z])
    
    return result

def store_sh_coefficients(sh_props, coefficients):
    """
    Store computed SH coefficients in the probe properties.
    Maintains internal order: L00, L1_1, L10, L11, L2_2, L2_1, L20, L21, L22
    """
    sh_props.L00 = coefficients[0]   # L00
    sh_props.L1_1 = coefficients[1]  # L1_1
    sh_props.L10 = coefficients[2]   # L10
    sh_props.L11 = coefficients[3]   # L11
    sh_props.L2_2 = coefficients[4]  # L2_2
    sh_props.L2_1 = coefficients[5]  # L2_1
    sh_props.L20 = coefficients[6]   # L20
    sh_props.L21 = coefficients[7]   # L21
    sh_props.L22 = coefficients[8]   # L22
