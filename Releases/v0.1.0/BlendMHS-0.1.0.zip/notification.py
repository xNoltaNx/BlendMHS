"""
Mouse-following notification system for BlendMHS export results.
Provides compact, non-intrusive feedback for auto-export operations.
"""

import time
from enum import Enum
from dataclasses import dataclass
from typing import Optional, Tuple

import bpy
import blf
import gpu
from gpu_extras.batch import batch_for_shader


class NotificationType(Enum):
    """Types of notification with associated colors."""
    SUCCESS = "SUCCESS"
    WARNING = "WARNING"
    ERROR = "ERROR"


# Color constants for notification types (RGB, 0-1 range)
NOTIFICATION_COLORS = {
    NotificationType.SUCCESS: (0.3, 0.85, 0.3),   # Green
    NotificationType.WARNING: (1.0, 0.7, 0.2),    # Yellow/Orange
    NotificationType.ERROR: (0.9, 0.3, 0.3),      # Red
}

# Unicode icons for notification types
NOTIFICATION_ICONS = {
    NotificationType.SUCCESS: "✓",
    NotificationType.WARNING: "⚠",
    NotificationType.ERROR: "✕",
}

# Text color
TEXT_COLOR = (1.0, 1.0, 1.0)  # White

# Shadow color
SHADOW_COLOR = (0.0, 0.0, 0.0)  # Black


@dataclass
class NotificationState:
    """Store notification state for the modal operator."""
    message: str
    notification_type: NotificationType
    start_time: float
    duration: float
    fade_duration: float
    last_mouse_pos: Tuple[int, int]

    @property
    def elapsed(self) -> float:
        """Get elapsed time since notification started."""
        return time.time() - self.start_time

    @property
    def alpha(self) -> float:
        """Calculate current alpha based on elapsed time."""
        elapsed = self.elapsed
        if elapsed < self.duration:
            return 1.0
        else:
            fade_progress = (elapsed - self.duration) / self.fade_duration
            return max(0.0, 1.0 - fade_progress)

    @property
    def is_finished(self) -> bool:
        """Check if notification has completed (fully faded)."""
        return self.elapsed > (self.duration + self.fade_duration)

    @property
    def color(self) -> Tuple[float, float, float]:
        """Get the color for this notification type."""
        return NOTIFICATION_COLORS.get(self.notification_type, NOTIFICATION_COLORS[NotificationType.SUCCESS])

    @property
    def icon(self) -> str:
        """Get the unicode icon for this notification type."""
        return NOTIFICATION_ICONS.get(self.notification_type, NOTIFICATION_ICONS[NotificationType.SUCCESS])


def get_ui_scale(context) -> float:
    """Get the current UI scale factor from preferences."""
    try:
        return context.preferences.system.ui_scale
    except Exception:
        return 1.0


def draw_notification_text(
    text: str,
    x: int,
    y: int,
    color: Tuple[float, float, float] = TEXT_COLOR,
    alpha: float = 1.0,
    size: int = 14,
    shadow: bool = True,
    shadow_offset: int = 2,
    context: Optional[bpy.types.Context] = None
) -> Tuple[int, int]:
    """
    Draw text at screen coordinates with optional shadow for visibility.

    Args:
        text: The text to draw
        x: X screen coordinate
        y: Y screen coordinate
        color: RGB color tuple (0-1 range)
        alpha: Transparency (0-1)
        size: Font size in pixels
        shadow: Whether to draw a shadow behind the text
        shadow_offset: Pixel offset for shadow
        context: Blender context for UI scale

    Returns:
        Tuple of (width, height) of drawn text
    """
    # Scale font size with UI preferences
    if context:
        ui_scale = get_ui_scale(context)
        size = int(size * ui_scale)

    font_id = 0  # Default font

    # Set font size
    blf.size(font_id, size)

    # Get text dimensions
    text_width, text_height = blf.dimensions(font_id, text)

    # Draw shadow first (if enabled)
    if shadow and alpha > 0.1:
        blf.enable(font_id, blf.SHADOW)
        blf.shadow(font_id, 5, 0.0, 0.0, 0.0, min(alpha * 0.8, 0.7))
        blf.shadow_offset(font_id, shadow_offset, -shadow_offset)

    # Set position and color
    blf.position(font_id, x, y, 0)
    blf.color(font_id, color[0], color[1], color[2], alpha)

    # Draw the text
    blf.draw(font_id, text)

    # Disable shadow
    if shadow:
        blf.disable(font_id, blf.SHADOW)

    return int(text_width), int(text_height)


def draw_notification_background(
    x: int,
    y: int,
    width: int,
    height: int,
    alpha: float = 0.7,
    corner_radius: int = 4,
    padding: int = 8
) -> None:
    """
    Draw a rounded rectangle background for the notification.

    Args:
        x: X screen coordinate (left edge)
        y: Y screen coordinate (bottom edge)
        width: Width of the background
        height: Height of the background
        alpha: Transparency (0-1)
        corner_radius: Radius for rounded corners (not implemented, uses rectangle)
        padding: Additional padding around content
    """
    # Adjust for padding
    x -= padding
    y -= padding // 2
    width += padding * 2
    height += padding

    # Create shader for drawing
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')

    # Define vertices for rectangle
    vertices = [
        (x, y),
        (x + width, y),
        (x + width, y + height),
        (x, y + height),
    ]

    indices = [(0, 1, 2), (0, 2, 3)]

    batch = batch_for_shader(shader, 'TRIS', {"pos": vertices}, indices=indices)

    # Enable blending
    gpu.state.blend_set('ALPHA')

    shader.bind()
    shader.uniform_float("color", (0.15, 0.15, 0.15, alpha * 0.85))
    batch.draw(shader)

    # Restore blend state
    gpu.state.blend_set('NONE')


def format_export_notification(scene) -> Tuple[str, NotificationType]:
    """
    Format export results into a concise notification message.

    Args:
        scene: The Blender scene with mhs properties

    Returns:
        Tuple of (message string, notification type)
    """
    stats = scene.mhs
    exported = stats.last_export_exported
    cached = stats.last_export_skipped
    total_time = stats.last_export_total_time

    # Determine notification type based on results
    notification_type = NotificationType.SUCCESS

    # Build message
    if exported == 0 and cached > 0:
        # All cached - very fast
        message = f"Export: {cached} cached ({total_time:.1f}s)"
    elif exported > 0 and cached > 0:
        message = f"Exported {exported}, {cached} cached ({total_time:.1f}s)"
    elif exported > 0:
        message = f"Exported {exported} files ({total_time:.1f}s)"
    else:
        message = f"Export complete ({total_time:.1f}s)"

    return message, notification_type
