import os
import bpy

# ============================================================================
# BlendMHS Extension
# ============================================================================
# Blender 4.2+ has built-in USD/pxr support - no usd-core wheel needed.
# Only opencv-python is bundled as a wheel for texture processing.
# ============================================================================


def setup_usd():
    """Configure USD environment variables for plugin discovery."""
    addon_dir = os.path.dirname(__file__)

    # Set USD plugin path for USD schema/plugin discovery (if using custom schemas)
    usd_plugin_path = os.path.join(addon_dir, "pxr")
    if os.path.exists(usd_plugin_path):
        os.environ["PXR_PLUGINPATH_NAME"] = usd_plugin_path


def register():
    # Import modules (dependencies available from bundled wheels)
    from . import prefs, props, ui, operators, material_system
    # NOTE: Shader Creator and MaterialMap Export are disabled for initial release
    # from . import shader_creator, material_map_export
    from .core.registration import register_keymaps
    from .registration import get_quick_export_pie, get_layout_setup_pie

    setup_usd()
    print("BlendMHS Extension Registered")
    props.register()

    # NOTE: Shader Creator and MaterialMap Export are disabled for initial release
    # These features will be re-enabled when the shader export workflow is complete.
    #
    # # Register shader creator PropertyGroups (but not panels yet)
    # shader_creator.register_property_groups()
    #
    # # Register material map export PropertyGroups (but not panels yet)
    # material_map_export.register_property_groups()
    #
    # # Add shader_definition and material_map_settings to MHS_SceneProperties
    # # These are added here to avoid circular import issues
    # from bpy.props import PointerProperty
    # props.MHS_SceneProperties.shader_definition = PointerProperty(
    #     type=shader_creator.MHS_ShaderDefinition
    # )
    # props.MHS_SceneProperties.material_map_settings = PointerProperty(
    #     type=material_map_export.MHS_MaterialMapSettings
    # )
    #
    # # Add shader export settings directly to Scene (for dialog access)
    # bpy.types.Scene.mhs_shader_export = PointerProperty(
    #     type=material_map_export.MHS_ShaderExportSettings
    # )

    # Register operators BEFORE UI panels (so operators are available when UI draws)
    operators.register()

    # Register UI (includes MHS_PT_base_panel which is needed by child panels)
    # Note: ui.register() now excludes MHS_MT_quick_export_pie as it's controlled
    # by the activation system
    ui.register()

    # NOTE: Shader Creator and MaterialMap Export panels are disabled for initial release
    # # NOW register the panels that depend on MHS_PT_base_panel
    # shader_creator.register_panels()
    # material_map_export.register_panels()

    # Register preferences (this enables the new tabbed preferences UI)
    prefs.register()

    # Register activated tools & pies based on preferences (on first load)
    # Note: The update callback won't fire on registration, so we need to
    # manually register if the default is True
    try:
        prefs_obj = bpy.context.preferences.addons[__name__].preferences

        # Register Quick Export Pie if enabled
        if prefs_obj.activate_quick_export_pie:
            # Register pie menu and keymaps
            classes, keymap_defs, _ = get_quick_export_pie()
            from .core.registration import register_classes, get_addon_keymaps
            register_classes(classes)
            registered_keys = register_keymaps(keymap_defs)
            addon_keymaps = get_addon_keymaps()
            addon_keymaps.extend(registered_keys)

        # Register Layout Setup Pie if enabled
        if prefs_obj.activate_layout_setup_pie:
            classes, keymap_defs, _ = get_layout_setup_pie()
            from .core.registration import register_classes, get_addon_keymaps
            register_classes(classes)
            registered_keys = register_keymaps(keymap_defs)
            addon_keymaps = get_addon_keymaps()
            addon_keymaps.extend(registered_keys)

    except (KeyError, AttributeError):
        # Preferences not available yet (first-time registration)
        # Register with defaults (pie menus on by default)
        from .core.registration import register_classes, get_addon_keymaps

        # Quick Export Pie
        classes, keymap_defs, _ = get_quick_export_pie()
        register_classes(classes)
        registered_keys = register_keymaps(keymap_defs)
        addon_keymaps = get_addon_keymaps()
        addon_keymaps.extend(registered_keys)

        # Layout Setup Pie
        classes, keymap_defs, _ = get_layout_setup_pie()
        register_classes(classes)
        registered_keys = register_keymaps(keymap_defs)
        addon_keymaps.extend(registered_keys)

    material_system.register()


def unregister():
    from . import prefs, props, ui, operators, material_system
    # NOTE: Shader Creator and MaterialMap Export are disabled for initial release
    # from . import shader_creator, material_map_export
    from .core.registration import clear_addon_keymaps, unregister_classes
    from .registration import get_quick_export_pie, get_layout_setup_pie

    print("BlendMHS Extension Unregistered")
    material_system.unregister()

    # Unregister all addon keymaps first
    clear_addon_keymaps()

    # Unregister pie menu class if it was registered
    try:
        classes, _, _ = get_quick_export_pie()
        unregister_classes(classes)
    except Exception:
        pass  # Already unregistered

    try:
        classes, _, _ = get_layout_setup_pie()
        unregister_classes(classes)
    except Exception:
        pass  # Already unregistered

    prefs.unregister()

    # NOTE: Shader Creator and MaterialMap Export are disabled for initial release
    # # Unregister panels that depend on MHS_PT_base_panel first
    # material_map_export.unregister()
    # shader_creator.unregister()

    # Unregister UI (includes MHS_PT_base_panel)
    ui.unregister()

    # Unregister operators AFTER UI panels
    operators.unregister()

    # NOTE: Shader Creator and MaterialMap Export are disabled for initial release
    # # Remove the added PointerProperties
    # del props.MHS_SceneProperties.material_map_settings
    # del props.MHS_SceneProperties.shader_definition
    # del bpy.types.Scene.mhs_shader_export

    props.unregister()


if __name__ == "__main__":
    register()
