"""
Shader Creator Module

Provides artist-driven shader creation with dropdown selection for existing
MHS_ node groups or creating new ones.
"""

import bpy
import os
from bpy.props import (
    StringProperty, BoolProperty, EnumProperty, FloatProperty,
    FloatVectorProperty, IntProperty, CollectionProperty
)
from bpy.types import PropertyGroup, Operator, Panel, UIList


def get_mhs_node_groups(self, context):
    """Get list of shader node groups for dropdown"""
    items = [('__NEW__', "Create New...", "Create a new shader node group")]
    for ng in bpy.data.node_groups:
        if ng.type == 'SHADER':
            items.append((ng.name, ng.name, f"Edit shader: {ng.name}"))
    return items


def get_mapping_value(mapping, key, default=''):
    """Safely get a value from a mapping that may be an IDPropertyGroup or dict"""
    try:
        if hasattr(mapping, 'to_dict'):
            mapping = mapping.to_dict()
        value = mapping.get(key, default)
        # Handle nested IDPropertyGroup
        if hasattr(value, 'to_dict'):
            return value.to_dict()
        return value
    except (AttributeError, TypeError):
        return default


def load_properties_from_node_group(shader_def, node_group):
    """Load properties from an existing node group"""
    import json

    shader_def.properties.clear()
    shader_def.name = node_group.name
    shader_def.description = f"Shader: {node_group.name}"

    # Load USD mappings from node group custom properties if they exist
    # Try JSON string first (more reliable), then fall back to dict
    usd_mappings = {}
    if 'mhs_usd_mappings_json' in node_group:
        try:
            usd_mappings = json.loads(node_group['mhs_usd_mappings_json'])
        except (json.JSONDecodeError, TypeError):
            pass

    if not usd_mappings and 'mhs_usd_mappings' in node_group:
        raw = node_group['mhs_usd_mappings']
        if hasattr(raw, 'to_dict'):
            usd_mappings = raw.to_dict()
        elif isinstance(raw, dict):
            usd_mappings = dict(raw)

    # Load shader settings (template, etc.)
    if 'mhs_shader_settings_json' in node_group:
        try:
            shader_settings = json.loads(node_group['mhs_shader_settings_json'])
            shader_def.template = shader_settings.get('template', 'Lit')
            shader_def.is_dynamic = shader_settings.get('is_dynamic', True)
            shader_def.is_masked = shader_settings.get('is_masked', False)
            shader_def.is_translucent = shader_settings.get('is_translucent', False)
        except (json.JSONDecodeError, TypeError):
            pass

    # STRATEGY: If we have saved USD mappings JSON, use that as the primary source.
    # This avoids iterating over potentially buggy interface.items_tree in Blender 4.5.x.
    # Only fall back to interface iteration if no saved mappings exist.

    if usd_mappings:
        # Load properties from saved JSON mappings (preferred - avoids Blender bugs)
        for prop_name, mapping in usd_mappings.items():
            if prop_name.startswith('_'):
                continue

            prop = shader_def.properties.add()
            prop.name = prop_name

            # Convert IDPropertyGroup to dict if needed
            if hasattr(mapping, 'to_dict'):
                mapping = mapping.to_dict()

            if isinstance(mapping, dict):
                # Property type
                if 'property_type' in mapping:
                    prop.property_type = str(mapping['property_type'])

                # Texture source type settings
                if 'texture_source_type' in mapping:
                    prop.texture_source_type = str(mapping['texture_source_type'])
                if 'texture_string_pattern' in mapping:
                    prop.texture_string_pattern = str(mapping['texture_string_pattern'])
                if 'texture_target_path' in mapping:
                    prop.texture_target_path = str(mapping['texture_target_path'])

                # USD attributes
                if 'usd_attribute' in mapping:
                    prop.usd_attribute = str(mapping['usd_attribute'])
                if 'usd_attribute_custom' in mapping:
                    prop.usd_attribute_custom = str(mapping['usd_attribute_custom'])
                if 'use_channel_mapping' in mapping:
                    prop.use_channel_mapping = bool(mapping['use_channel_mapping'])
                if 'texture_rgb_attribute' in mapping:
                    prop.texture_rgb_attribute = str(mapping['texture_rgb_attribute'])
                if 'texture_rgb_custom' in mapping:
                    prop.texture_rgb_custom = str(mapping['texture_rgb_custom'])
                if 'texture_r_attribute' in mapping:
                    prop.texture_r_attribute = str(mapping['texture_r_attribute'])
                if 'texture_r_custom' in mapping:
                    prop.texture_r_custom = str(mapping['texture_r_custom'])
                if 'texture_g_attribute' in mapping:
                    prop.texture_g_attribute = str(mapping['texture_g_attribute'])
                if 'texture_g_custom' in mapping:
                    prop.texture_g_custom = str(mapping['texture_g_custom'])
                if 'texture_b_attribute' in mapping:
                    prop.texture_b_attribute = str(mapping['texture_b_attribute'])
                if 'texture_b_custom' in mapping:
                    prop.texture_b_custom = str(mapping['texture_b_custom'])
                if 'texture_a_attribute' in mapping:
                    prop.texture_a_attribute = str(mapping['texture_a_attribute'])
                if 'texture_a_custom' in mapping:
                    prop.texture_a_custom = str(mapping['texture_a_custom'])

                # Property values
                if 'default_float' in mapping:
                    prop.default_float = float(mapping['default_float'])
                if 'min_float' in mapping:
                    prop.min_float = float(mapping['min_float'])
                if 'max_float' in mapping:
                    prop.max_float = float(mapping['max_float'])
                if 'default_color' in mapping:
                    color = mapping['default_color']
                    if isinstance(color, (list, tuple)) and len(color) >= 4:
                        prop.default_color = tuple(color[:4])
                if 'default_vector' in mapping:
                    vec = mapping['default_vector']
                    if isinstance(vec, (list, tuple)) and len(vec) >= 3:
                        prop.default_vector = tuple(vec[:3])
                if 'default_bool' in mapping:
                    prop.default_bool = bool(mapping['default_bool'])
                # Load panel assignment
                if 'panel_name' in mapping:
                    prop.panel_name = str(mapping['panel_name'])
    else:
        # Fallback: No saved mappings, need to iterate interface
        # This path is only used for node groups that were created outside this addon
        # or before the JSON mapping system was implemented
        _load_properties_from_interface_fallback(shader_def, node_group)


def _load_properties_from_interface_fallback(shader_def, node_group):
    """
    Fallback function to load properties by iterating node group interface.
    Used only when no saved JSON mappings exist.

    NOTE: This function may crash on Blender 4.5.x due to bugs in the interface API.
    We minimize its use by preferring saved JSON mappings.
    """
    # Get list of items first, then process to minimize time spent in buggy API
    items_to_process = []

    try:
        for item in node_group.interface.items_tree:
            try:
                # Quickly get the essential info and move on
                if item.item_type != 'SOCKET' or item.in_out != 'INPUT':
                    continue

                item_name = item.name
                if item_name.startswith('_'):
                    continue

                socket_class = item.__class__.__name__
                items_to_process.append((item_name, socket_class))
            except Exception:
                # Skip any items that cause issues
                continue
    except Exception:
        # If even iterating fails, we can't load anything
        return

    # Now create properties from the safely gathered info
    for item_name, socket_class in items_to_process:
        prop = shader_def.properties.add()
        prop.name = item_name

        # Infer type from socket class name
        if 'Float' in socket_class:
            prop.property_type = 'FLOAT'
        elif 'Color' in socket_class:
            name_lower = item_name.lower()
            if any(x in name_lower for x in ['tex', 'texture', 'map']):
                prop.property_type = 'TEXTURE'
            else:
                prop.property_type = 'COLOR'
        elif 'Vector' in socket_class:
            prop.property_type = 'VECTOR'
        elif 'Bool' in socket_class:
            prop.property_type = 'BOOL'
        else:
            prop.property_type = 'FLOAT'


def sync_property_to_node_group(shader_def, prop, action='update'):
    """
    Sync a single property change to the node group.
    action: 'add', 'remove', or 'update'
    """
    group_name = shader_def.name

    if group_name not in bpy.data.node_groups:
        return  # Node group doesn't exist yet

    node_group = bpy.data.node_groups[group_name]

    if action == 'add':
        # Add new socket (no parent panel - sockets are at root level)
        socket_types = {
            'FLOAT': 'NodeSocketFloat', 'COLOR': 'NodeSocketColor',
            'VECTOR': 'NodeSocketVector', 'TEXTURE': 'NodeSocketColor',
            'BOOL': 'NodeSocketFloat',
        }
        socket = node_group.interface.new_socket(
            name=prop.name, in_out='INPUT',
            socket_type=socket_types.get(prop.property_type, 'NodeSocketFloat')
        )
        _apply_property_to_socket(socket, prop)

    elif action == 'remove':
        # Find and remove socket
        for item in node_group.interface.items_tree:
            if hasattr(item, 'in_out') and item.in_out == 'INPUT' and item.name == prop.name:
                node_group.interface.remove(item)
                break

    elif action == 'update':
        # Find and update socket
        for item in node_group.interface.items_tree:
            if hasattr(item, 'in_out') and item.in_out == 'INPUT' and item.name == prop.name:
                _apply_property_to_socket(item, prop)
                break


def _apply_property_to_socket(socket, prop):
    """Apply property values to a socket"""
    if prop.property_type == 'FLOAT':
        if hasattr(socket, 'default_value'):
            socket.default_value = prop.default_float
        if hasattr(socket, 'min_value'):
            socket.min_value = prop.min_float
        if hasattr(socket, 'max_value'):
            socket.max_value = prop.max_float
    elif prop.property_type == 'COLOR':
        if hasattr(socket, 'default_value'):
            socket.default_value = prop.default_color
    elif prop.property_type == 'TEXTURE':
        if hasattr(socket, 'default_value'):
            socket.default_value = (1.0, 1.0, 1.0, 1.0)
    elif prop.property_type == 'VECTOR':
        if hasattr(socket, 'default_value'):
            socket.default_value = prop.default_vector
    elif prop.property_type == 'BOOL':
        if hasattr(socket, 'default_value'):
            socket.default_value = 1.0 if prop.default_bool else 0.0


def sync_all_properties_to_node_group(context):
    """Sync all properties to the node group (for reordering)"""
    shader_def = context.scene.mhs.shader_definition
    group_name = shader_def.name

    if group_name not in bpy.data.node_groups:
        return

    node_group = bpy.data.node_groups[group_name]

    # For now, just update USD mappings - socket order changes are complex
    save_usd_mappings_to_node_group(shader_def, node_group)


def sync_property_removal_to_node_group(shader_def, prop_name):
    """Remove a property socket from the node group"""
    group_name = shader_def.name

    if group_name not in bpy.data.node_groups:
        return

    node_group = bpy.data.node_groups[group_name]

    # Find and remove the socket
    for item in node_group.interface.items_tree:
        if hasattr(item, 'in_out') and item.in_out == 'INPUT' and item.name == prop_name:
            node_group.interface.remove(item)
            break


def save_usd_mappings_to_node_group_if_exists(shader_def):
    """Save USD mappings to node group if it exists"""
    group_name = shader_def.name

    if group_name in bpy.data.node_groups:
        node_group = bpy.data.node_groups[group_name]
        save_usd_mappings_to_node_group(shader_def, node_group)


def save_usd_mappings_to_node_group(shader_def, node_group):
    """Save USD attribute mappings and property settings to node group custom properties"""
    import json

    usd_mappings = {}

    for prop in shader_def.properties:
        mapping = {
            'usd_attribute': prop.usd_attribute,
            'usd_attribute_custom': prop.usd_attribute_custom,
            'use_channel_mapping': prop.use_channel_mapping,
            'texture_rgb_attribute': prop.texture_rgb_attribute,
            'texture_rgb_custom': prop.texture_rgb_custom,
            'texture_r_attribute': prop.texture_r_attribute,
            'texture_r_custom': prop.texture_r_custom,
            'texture_g_attribute': prop.texture_g_attribute,
            'texture_g_custom': prop.texture_g_custom,
            'texture_b_attribute': prop.texture_b_attribute,
            'texture_b_custom': prop.texture_b_custom,
            'texture_a_attribute': prop.texture_a_attribute,
            'texture_a_custom': prop.texture_a_custom,
            # Texture source type settings
            'texture_source_type': prop.texture_source_type,
            'texture_string_pattern': prop.texture_string_pattern,
            'texture_target_path': prop.texture_target_path,
            # Save property values
            'property_type': prop.property_type,
            'default_float': prop.default_float,
            'min_float': prop.min_float,
            'max_float': prop.max_float,
            'default_color': list(prop.default_color),
            'default_vector': list(prop.default_vector),
            'default_bool': prop.default_bool,
            # Save panel assignment
            'panel_name': prop.panel_name,
        }
        usd_mappings[prop.name] = mapping

    # Save shader settings
    shader_settings = {
        'template': shader_def.template,
        'is_dynamic': shader_def.is_dynamic,
        'is_masked': shader_def.is_masked,
        'is_translucent': shader_def.is_translucent,
    }

    # Save as JSON string - more reliable than nested dict custom properties
    node_group['mhs_usd_mappings_json'] = json.dumps(usd_mappings)
    node_group['mhs_shader_settings_json'] = json.dumps(shader_settings)
    # Also keep dict version for backwards compatibility
    node_group['mhs_usd_mappings'] = usd_mappings


def on_shader_name_update(self, context):
    """Called when the shader name is changed - renames the node group and material"""
    # Skip if we're creating a new shader (no existing node group)
    if self.selected_node_group == '__NEW__':
        return

    old_name = self.selected_node_group
    new_name = self.name

    # Skip if the name hasn't actually changed
    if old_name == new_name:
        return

    # Skip if the new name is empty
    if not new_name.strip():
        return

    # Check if old node group exists
    if old_name not in bpy.data.node_groups:
        return

    # Check if new name already exists (can't rename to existing name)
    if new_name in bpy.data.node_groups:
        # Revert the name change in the UI
        self['name'] = old_name
        return

    # Rename the node group
    node_group = bpy.data.node_groups[old_name]
    node_group.name = new_name

    # Rename the associated material if it exists
    if old_name in bpy.data.materials:
        material = bpy.data.materials[old_name]
        material.name = new_name

    # Update the selection to point to the renamed node group
    # Note: We need to use property_unset and then set to avoid triggering
    # on_selected_node_group_update which would reload properties
    # Since EnumProperty items are dynamic, setting the string value directly works
    # when going through the property system (not dictionary access)

    # Use a flag to prevent on_selected_node_group_update from reloading
    self._renaming_in_progress = True
    try:
        self.selected_node_group = new_name
    finally:
        self._renaming_in_progress = False


def on_selected_node_group_update(self, context):
    """Called when the selected node group changes"""
    # Skip if we're in the middle of a rename operation
    if getattr(self, '_renaming_in_progress', False):
        return

    if self.selected_node_group == '__NEW__':
        self.properties.clear()
        self.name = "NewShader"
        self.description = "Custom artist shader"
    else:
        node_group = bpy.data.node_groups.get(self.selected_node_group)
        if node_group:
            load_properties_from_node_group(self, node_group)


def update_node_group_interface(node_group, shader_def):
    """
    Update node group interface - sockets and panels.
    Shared function used by both auto-save and operators.
    """
    socket_types = {
        'FLOAT': 'NodeSocketFloat',
        'COLOR': 'NodeSocketColor',
        'VECTOR': 'NodeSocketVector',
        'TEXTURE': 'NodeSocketColor',
        'BOOL': 'NodeSocketFloat',
    }

    # Get new property names
    new_prop_names = {prop.name for prop in shader_def.properties}

    # Remove sockets that no longer exist in properties
    for item in list(node_group.interface.items_tree):
        if hasattr(item, 'in_out') and item.in_out == 'INPUT':
            if item.name not in new_prop_names:
                node_group.interface.remove(item)

    # Collect existing panels
    panels = {}
    for item in node_group.interface.items_tree:
        if item.item_type == 'PANEL':
            panels[item.name] = item

    # Create panels for properties that have panel assignments
    for prop in shader_def.properties:
        pname = prop.panel_name.strip()
        if pname and pname not in panels:
            panels[pname] = node_group.interface.new_panel(name=pname)

    # Remove ALL existing input sockets and recreate them with proper panel assignment
    for item in list(node_group.interface.items_tree):
        if hasattr(item, 'in_out') and item.in_out == 'INPUT':
            node_group.interface.remove(item)

    # Recreate sockets with proper panel assignment
    for prop in shader_def.properties:
        expected_type = socket_types.get(prop.property_type, 'NodeSocketFloat')
        panel_name = prop.panel_name.strip()
        parent_panel = panels.get(panel_name) if panel_name else None

        new_socket = node_group.interface.new_socket(
            name=prop.name, in_out='INPUT',
            socket_type=expected_type, parent=parent_panel
        )
        _apply_socket_values(new_socket, prop)

    # Remove empty panels
    cleanup_empty_panels(node_group)


def _apply_socket_values(socket, prop):
    """Apply property values to a socket"""
    try:
        if prop.property_type == 'FLOAT':
            if hasattr(socket, 'default_value'):
                socket.default_value = prop.default_float
            if hasattr(socket, 'min_value'):
                socket.min_value = prop.min_float
            if hasattr(socket, 'max_value'):
                socket.max_value = prop.max_float
        elif prop.property_type == 'COLOR':
            if hasattr(socket, 'default_value'):
                socket.default_value = prop.default_color
        elif prop.property_type == 'TEXTURE':
            if hasattr(socket, 'default_value'):
                socket.default_value = (1.0, 1.0, 1.0, 1.0)
        elif prop.property_type == 'VECTOR':
            if hasattr(socket, 'default_value'):
                socket.default_value = prop.default_vector
        elif prop.property_type == 'BOOL':
            if hasattr(socket, 'default_value'):
                socket.default_value = 1.0 if prop.default_bool else 0.0
    except (TypeError, AttributeError):
        pass


def cleanup_empty_panels(node_group):
    """Remove panels that have no child sockets"""
    all_panels = []
    for item in node_group.interface.items_tree:
        if item.item_type == 'PANEL':
            all_panels.append(item)

    panels_to_remove = []
    for panel in all_panels:
        has_children = False
        for item in node_group.interface.items_tree:
            if hasattr(item, 'parent') and item.parent == panel:
                has_children = True
                break
        if not has_children:
            panels_to_remove.append(panel)

    for panel in panels_to_remove:
        node_group.interface.remove(panel)


def auto_save_to_node_group(self, context):
    """
    Auto-save property changes to node group when user modifies values.
    This runs during property update callbacks, which ARE included in Blender's undo system.
    """
    shader_def = context.scene.mhs.shader_definition

    # Skip if creating new shader (no node group yet)
    if shader_def.selected_node_group == '__NEW__':
        return

    group_name = shader_def.name

    if group_name not in bpy.data.node_groups:
        return

    node_group = bpy.data.node_groups[group_name]

    # Save USD mappings (this includes all property values)
    save_usd_mappings_to_node_group(shader_def, node_group)

    # Update node group interface (sockets and panels)
    update_node_group_interface(node_group, shader_def)


class MHS_ShaderPropertyItem(PropertyGroup):
    """Single shader property with USD mapping configuration"""
    name: StringProperty(name="Name", default="Property", update=auto_save_to_node_group)
    property_type: EnumProperty(
        name="Type",
        items=[
            ('FLOAT', "Float", "Single float value"),
            ('COLOR', "Color", "RGBA color"),
            ('VECTOR', "Vector", "3D vector"),
            ('TEXTURE', "Texture", "Texture input"),
            ('BOOL', "Boolean", "True/False toggle"),
        ],
        default='FLOAT',
        update=auto_save_to_node_group
    )

    # Panel assignment for organization
    panel_name: StringProperty(
        name="Panel",
        description="Panel name for grouping (leave empty for default 'Material Properties')",
        default="",
        update=auto_save_to_node_group
    )

    # Texture source type - determines how texture is resolved in materialMap
    texture_source_type: EnumProperty(
        name="Source Type",
        description="How the texture path is resolved in the materialMap",
        items=[
            ('ATTRIBUTE', "USD Attribute", "Map from USD material attributes using channel mapping (assetIdFromAttribute)"),
            ('STRING_PATTERN', "String Pattern", "Build texture path from pattern with %MaterialName% replacement (assetIdFromString)"),
            ('TARGET_PATH', "Target Path", "Direct reference to a specific asset path (assetIdFromTargetPath)"),
        ],
        default='ATTRIBUTE',
        update=auto_save_to_node_group
    )

    # For STRING_PATTERN source type
    texture_string_pattern: StringProperty(
        name="Pattern",
        description="Texture path pattern. Use %MaterialName% for material name substitution (e.g., %MaterialName%_BR.png)",
        default="%MaterialName%.png",
        update=auto_save_to_node_group
    )

    # For TARGET_PATH source type
    texture_target_path: StringProperty(
        name="Target Path",
        description="Direct asset target path (e.g., meta/renderer_module@textures/missing.png:tex)",
        default="",
        update=auto_save_to_node_group
    )
    default_float: FloatProperty(
        name="Default", default=0.5,
        soft_min=0.0, soft_max=1.0,
        update=auto_save_to_node_group
    )
    min_float: FloatProperty(
        name="Min", default=0.0,
        soft_min=-100.0, soft_max=100.0,
        update=auto_save_to_node_group
    )
    max_float: FloatProperty(
        name="Max", default=1.0,
        soft_min=-100.0, soft_max=100.0,
        update=auto_save_to_node_group
    )
    default_color: FloatVectorProperty(
        name="Default Color", size=4, subtype='COLOR',
        default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0,
        update=auto_save_to_node_group
    )
    default_vector: FloatVectorProperty(
        name="Default Vector", size=3, default=(0.0, 0.0, 0.0),
        update=auto_save_to_node_group
    )
    default_bool: BoolProperty(name="Default", default=False, update=auto_save_to_node_group)

    usd_attribute: EnumProperty(
        name="USD Attribute",
        items=[
            ('NONE', "None", "No USD mapping"),
            ('diffuseColor', "Diffuse Color", ""),
            ('roughness', "Roughness", ""),
            ('metallic', "Metallic", ""),
            ('emissiveColor', "Emissive", ""),
            ('occlusion', "Occlusion", ""),
            ('normal', "Normal", ""),
            ('opacity', "Opacity", ""),
            ('CUSTOM', "Custom", "Custom attribute name"),
        ],
        default='NONE',
        update=auto_save_to_node_group
    )
    usd_attribute_custom: StringProperty(
        name="Custom USD Attr", default="",
        update=auto_save_to_node_group
    )

    use_channel_mapping: BoolProperty(
        name="Per-Channel Mapping", default=False,
        update=auto_save_to_node_group
    )
    texture_rgb_attribute: EnumProperty(
        name="RGB Channel",
        items=[
            ('NONE', "None", ""), ('diffuseColor', "Diffuse Color", ""),
            ('emissiveColor', "Emissive Color", ""), ('normal', "Normal", ""),
            ('CUSTOM', "Custom", ""),
        ],
        default='diffuseColor',
        update=auto_save_to_node_group
    )
    texture_rgb_custom: StringProperty(
        name="Custom RGB Attr", default="",
        update=auto_save_to_node_group
    )
    texture_r_attribute: EnumProperty(
        name="R Channel",
        items=[
            ('NONE', "None", ""), ('metallic', "Metallic", ""),
            ('roughness', "Roughness", ""), ('occlusion', "Occlusion", ""),
            ('opacity', "Opacity", ""), ('CUSTOM', "Custom", ""),
        ],
        default='NONE',
        update=auto_save_to_node_group
    )
    texture_r_custom: StringProperty(
        name="Custom R Attr", default="",
        update=auto_save_to_node_group
    )
    texture_g_attribute: EnumProperty(
        name="G Channel",
        items=[
            ('NONE', "None", ""), ('metallic', "Metallic", ""),
            ('roughness', "Roughness", ""), ('occlusion', "Occlusion", ""),
            ('opacity', "Opacity", ""), ('CUSTOM', "Custom", ""),
        ],
        default='NONE',
        update=auto_save_to_node_group
    )
    texture_g_custom: StringProperty(
        name="Custom G Attr", default="",
        update=auto_save_to_node_group
    )
    texture_b_attribute: EnumProperty(
        name="B Channel",
        items=[
            ('NONE', "None", ""), ('metallic', "Metallic", ""),
            ('roughness', "Roughness", ""), ('occlusion', "Occlusion", ""),
            ('opacity', "Opacity", ""), ('CUSTOM', "Custom", ""),
        ],
        default='NONE',
        update=auto_save_to_node_group
    )
    texture_b_custom: StringProperty(
        name="Custom B Attr", default="",
        update=auto_save_to_node_group
    )
    texture_a_attribute: EnumProperty(
        name="A Channel",
        items=[
            ('NONE', "None", ""), ('opacity', "Opacity", ""),
            ('roughness', "Roughness", ""), ('metallic', "Metallic", ""),
            ('CUSTOM', "Custom", ""),
        ],
        default='NONE',
        update=auto_save_to_node_group
    )
    texture_a_custom: StringProperty(
        name="Custom A Attr", default="",
        update=auto_save_to_node_group
    )


def on_masked_update(self, context):
    """When masked is enabled, disable translucent"""
    if self.is_masked:
        self.is_translucent = False


def on_translucent_update(self, context):
    """When translucent is enabled, disable masked"""
    if self.is_translucent:
        self.is_masked = False


def auto_save_shader_settings(self, context):
    """
    Note: This callback is kept for mutual exclusivity logic but does NOT auto-save
    to preserve undo functionality. Saving happens during explicit operator actions.
    """
    pass  # Intentionally empty - saves happen in operators now


class MHS_ShaderDefinition(PropertyGroup):
    """Complete shader definition"""
    selected_node_group: EnumProperty(
        name="Shader",
        description="Select existing shader or create new",
        items=get_mhs_node_groups,
        update=on_selected_node_group_update
    )
    name: StringProperty(
        name="Shader Name",
        default="CustomShader",
        update=on_shader_name_update
    )
    description: StringProperty(name="Description", default="Custom artist shader")
    template: EnumProperty(
        name="Template",
        items=[
            ('Lit', "Lit", "Standard lit PBR material"),
            ('Unlit', "Unlit", "Unlit/emissive material"),
            ('LitSkinned', "Lit Skinned", "Lit with skeletal animation"),
            ('UnlitSkinned', "Unlit Skinned", "Unlit with skeletal animation"),
        ],
        default='Lit'
    )
    is_dynamic: BoolProperty(name="Dynamic", default=True, update=auto_save_shader_settings)
    is_masked: BoolProperty(name="Masked", default=False, update=on_masked_update)
    is_translucent: BoolProperty(name="Translucent", default=False, update=on_translucent_update)
    properties: CollectionProperty(type=MHS_ShaderPropertyItem)
    active_property_index: IntProperty(default=0)


class MHS_OT_add_shader_property(Operator):
    """Add a new shader property"""
    bl_idname = "mhs.add_shader_property"
    bl_label = "Add Property"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        shader_def = context.scene.mhs.shader_definition
        prop = shader_def.properties.add()
        prop.name = f"Property{len(shader_def.properties)}"
        shader_def.active_property_index = len(shader_def.properties) - 1

        # Auto-save to node group (if it exists)
        auto_save_to_node_group(prop, context)

        return {'FINISHED'}


class MHS_OT_remove_shader_property(Operator):
    """Remove selected shader property"""
    bl_idname = "mhs.remove_shader_property"
    bl_label = "Remove Property"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        shader_def = context.scene.mhs.shader_definition
        return len(shader_def.properties) > 0

    def execute(self, context):
        shader_def = context.scene.mhs.shader_definition
        idx = shader_def.active_property_index

        if 0 <= idx < len(shader_def.properties):
            shader_def.properties.remove(idx)
            if shader_def.active_property_index >= len(shader_def.properties):
                shader_def.active_property_index = max(0, len(shader_def.properties) - 1)

        # Auto-save to node group (if it exists)
        # Pass None for self since we're not in a property callback
        auto_save_to_node_group(None, context)

        return {'FINISHED'}


class MHS_OT_move_shader_property(Operator):
    """Move shader property up or down"""
    bl_idname = "mhs.move_shader_property"
    bl_label = "Move Property"
    bl_options = {'REGISTER', 'UNDO'}

    direction: EnumProperty(items=[('UP', "Up", ""), ('DOWN', "Down", "")])

    @classmethod
    def poll(cls, context):
        shader_def = context.scene.mhs.shader_definition
        return len(shader_def.properties) > 1

    def execute(self, context):
        shader_def = context.scene.mhs.shader_definition
        idx = shader_def.active_property_index

        if self.direction == 'UP' and idx > 0:
            shader_def.properties.move(idx, idx - 1)
            shader_def.active_property_index = idx - 1
        elif self.direction == 'DOWN' and idx < len(shader_def.properties) - 1:
            shader_def.properties.move(idx, idx + 1)
            shader_def.active_property_index = idx + 1

        # Auto-save to node group (if it exists)
        auto_save_to_node_group(None, context)

        return {'FINISHED'}

class MHS_OT_save_shader_changes(Operator):
    """Save all property changes to the node group (USD mappings and interface updates)"""
    bl_idname = "mhs.save_shader_changes"
    bl_label = "Save Changes"
    @classmethod
    def poll(cls, context):
        shader_def = context.scene.mhs.shader_definition
        group_name = shader_def.name
        return group_name in bpy.data.node_groups

    def execute(self, context):
        shader_def = context.scene.mhs.shader_definition
        group_name = shader_def.name

        if group_name not in bpy.data.node_groups:
            self.report({'ERROR'}, f"Node group '{group_name}' not found")
            return {'CANCELLED'}

        node_group = bpy.data.node_groups[group_name]

        # Update the node group interface carefully to preserve links
        self.update_node_group_interface(node_group, shader_def)

        # Save USD mappings and shader settings
        save_usd_mappings_to_node_group(shader_def, node_group)

        self.report({'INFO'}, f"Saved changes to '{group_name}'")
        return {'FINISHED'}

    def update_node_group_interface(self, node_group, shader_def):
        """Update node group interface carefully to preserve links"""
        socket_types = {
            'FLOAT': 'NodeSocketFloat',
            'COLOR': 'NodeSocketColor',
            'VECTOR': 'NodeSocketVector',
            'TEXTURE': 'NodeSocketColor',
            'BOOL': 'NodeSocketFloat',
        }

        # Get existing input sockets
        existing_sockets = {}
        for item in node_group.interface.items_tree:
            if hasattr(item, 'in_out') and item.in_out == 'INPUT':
                existing_sockets[item.name] = item

        # Get new property names
        new_prop_names = {prop.name for prop in shader_def.properties}

        # Remove sockets that no longer exist in properties
        sockets_to_remove = []
        for socket_name in existing_sockets:
            if socket_name not in new_prop_names:
                sockets_to_remove.append(existing_sockets[socket_name])

        for socket in sockets_to_remove:
            node_group.interface.remove(socket)

        # Collect existing panels
        panels = {}
        for item in node_group.interface.items_tree:
            if item.item_type == 'PANEL':
                panels[item.name] = item

        # Create panels for properties that have panel assignments
        for prop in shader_def.properties:
            pname = prop.panel_name.strip()
            if pname and pname not in panels:
                panels[pname] = node_group.interface.new_panel(name=pname)

        # Remove ALL existing input sockets and recreate them with proper panel assignment
        # This ensures sockets are properly parented to their panels
        # NOTE: We don't read default_value from interface sockets due to Blender 4.5.x
        # crash bugs. We use saved property values from shader_def instead.
        for item in list(node_group.interface.items_tree):
            if hasattr(item, 'in_out') and item.in_out == 'INPUT':
                node_group.interface.remove(item)

        # Recreate sockets with proper panel assignment
        for prop in shader_def.properties:
            expected_type = socket_types.get(prop.property_type, 'NodeSocketFloat')
            panel_name = prop.panel_name.strip()
            parent_panel = panels.get(panel_name) if panel_name else None

            new_socket = node_group.interface.new_socket(
                name=prop.name, in_out='INPUT',
                socket_type=expected_type, parent=parent_panel
            )
            self.update_socket_values(new_socket, prop)

        # Remove empty panels
        self.cleanup_empty_panels(node_group)

    def cleanup_empty_panels(self, node_group):
        """Remove panels that have no child sockets"""
        # Get all panels
        all_panels = []
        for item in node_group.interface.items_tree:
            if item.item_type == 'PANEL':
                all_panels.append(item)

        # For each panel, check if any socket has it as parent
        panels_to_remove = []
        for panel in all_panels:
            has_children = False
            for item in node_group.interface.items_tree:
                if hasattr(item, 'parent') and item.parent == panel:
                    has_children = True
                    break

            if not has_children:
                panels_to_remove.append(panel)

        for panel in panels_to_remove:
            node_group.interface.remove(panel)

    def update_socket_values(self, socket, prop):
        """Update socket default values without changing the socket type"""
        try:
            if prop.property_type == 'FLOAT':
                if hasattr(socket, 'default_value'):
                    socket.default_value = prop.default_float
                if hasattr(socket, 'min_value'):
                    socket.min_value = prop.min_float
                if hasattr(socket, 'max_value'):
                    socket.max_value = prop.max_float
            elif prop.property_type == 'COLOR':
                if hasattr(socket, 'default_value'):
                    socket.default_value = prop.default_color
            elif prop.property_type == 'TEXTURE':
                if hasattr(socket, 'default_value'):
                    socket.default_value = (1.0, 1.0, 1.0, 1.0)
            elif prop.property_type == 'VECTOR':
                if hasattr(socket, 'default_value'):
                    socket.default_value = prop.default_vector
            elif prop.property_type == 'BOOL':
                if hasattr(socket, 'default_value'):
                    socket.default_value = 1.0 if prop.default_bool else 0.0
        except (TypeError, AttributeError):
            pass  # Skip if type mismatch


class MHS_OT_select_property(Operator):
    """Select a shader property"""
    bl_idname = "mhs.select_property"
    bl_label = "Select Property"
    bl_options = {'INTERNAL'}

    index: IntProperty()

    def execute(self, context):
        shader_def = context.scene.mhs.shader_definition
        shader_def.active_property_index = self.index
        return {'FINISHED'}


class MHS_OT_refresh_shader_list(Operator):
    """Refresh the shader list"""
    bl_idname = "mhs.refresh_shader_list"
    bl_label = "Refresh Shader List"

    def execute(self, context):
        # Force re-evaluation of the enum
        shader_def = context.scene.mhs.shader_definition
        # Trigger update by temporarily changing selection
        current = shader_def.selected_node_group
        shader_def.selected_node_group = '__NEW__'
        shader_def.selected_node_group = current
        return {'FINISHED'}


class MHS_OT_remove_shader_node_group(Operator):
    """Remove the selected shader node group and its associated material"""
    bl_idname = "mhs.remove_shader_node_group"
    bl_label = "Remove Shader Node Group"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        shader_def = context.scene.mhs.shader_definition
        # Can only remove if an existing node group is selected (not __NEW__)
        return (shader_def.selected_node_group and
                shader_def.selected_node_group != '__NEW__' and
                shader_def.selected_node_group in bpy.data.node_groups)

    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        shader_def = context.scene.mhs.shader_definition
        node_group_name = shader_def.selected_node_group

        if node_group_name not in bpy.data.node_groups:
            self.report({'ERROR'}, f"Node group '{node_group_name}' not found")
            return {'CANCELLED'}

        node_group = bpy.data.node_groups[node_group_name]

        # Find and remove the associated material (same name as node group)
        removed_material = False
        if node_group_name in bpy.data.materials:
            material = bpy.data.materials[node_group_name]
            bpy.data.materials.remove(material)
            removed_material = True

        # Remove the node group
        bpy.data.node_groups.remove(node_group)

        # Reset selection to __NEW__
        shader_def.selected_node_group = '__NEW__'
        shader_def.properties.clear()
        shader_def.name = ""
        shader_def.description = ""

        if removed_material:
            self.report({'INFO'}, f"Removed shader '{node_group_name}' and its material")
        else:
            self.report({'INFO'}, f"Removed shader node group: {node_group_name}")
        return {'FINISHED'}


class MHS_OT_create_shader_node_group(Operator):
    """Create or update shader node group"""
    bl_idname = "mhs.create_shader_node_group"
    bl_label = "Create Shader Node Group"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        shader_def = context.scene.mhs.shader_definition
        return shader_def.name and len(shader_def.properties) > 0

    def execute(self, context):
        shader_def = context.scene.mhs.shader_definition
        group_name = shader_def.name

        is_update = group_name in bpy.data.node_groups

        if is_update:
            # Update existing node group in-place to preserve material references
            node_group = bpy.data.node_groups[group_name]
            self.update_node_group(node_group, shader_def)
        else:
            # Create new node group
            node_group = bpy.data.node_groups.new(name=group_name, type='ShaderNodeTree')
            self.setup_new_node_group(node_group, shader_def)
            self.create_material(group_name, node_group)

        # Save USD mappings to node group custom properties
        save_usd_mappings_to_node_group(shader_def, node_group)

        # Update shader factory mapping (use importlib for robust import)
        import importlib
        try:
            shader_factory = importlib.import_module('.shader_factory', package=__package__)
            if group_name not in shader_factory.NODE_GROUP_MAPPING:
                shader_factory.NODE_GROUP_MAPPING[group_name] = group_name
        except (ImportError, AttributeError):
            pass  # shader_factory not available or NODE_GROUP_MAPPING not present

        # Switch selection to the newly created/updated shader
        # This prevents a broken state where we're on __NEW__ but the node group exists
        shader_def.selected_node_group = group_name

        if is_update:
            self.report({'INFO'}, f"Updated '{group_name}'")
        else:
            self.report({'INFO'}, f"Created '{group_name}' and material")

        return {'FINISHED'}

    def setup_new_node_group(self, node_group, shader_def):
        """Setup a new node group from scratch"""
        input_node = node_group.nodes.new('NodeGroupInput')
        input_node.location = (-300, 0)
        output_node = node_group.nodes.new('NodeGroupOutput')
        output_node.location = (300, 0)

        node_group.interface.new_socket(name='BSDF', in_out='OUTPUT', socket_type='NodeSocketShader')

        # Create panels for properties that have panel assignments
        panels = {}
        for prop in shader_def.properties:
            pname = prop.panel_name.strip()
            if pname and pname not in panels:
                panels[pname] = node_group.interface.new_panel(name=pname)

        # Create sockets with proper panel assignment
        for prop in shader_def.properties:
            panel_name = prop.panel_name.strip()
            parent_panel = panels.get(panel_name) if panel_name else None
            self.create_socket(node_group, prop, parent_panel)

        bsdf = node_group.nodes.new('ShaderNodeBsdfPrincipled')
        bsdf.location = (0, 0)
        node_group.links.new(bsdf.outputs['BSDF'], output_node.inputs['BSDF'])

    def update_node_group(self, node_group, shader_def):
        """Update an existing node group in-place, preserving material references"""
        socket_types = {
            'FLOAT': 'NodeSocketFloat',
            'COLOR': 'NodeSocketColor',
            'VECTOR': 'NodeSocketVector',
            'TEXTURE': 'NodeSocketColor',
            'BOOL': 'NodeSocketFloat',
        }

        # Get new property names
        new_prop_names = {prop.name for prop in shader_def.properties}

        # Remove sockets that no longer exist in the definition
        sockets_to_remove = []
        for item in node_group.interface.items_tree:
            if hasattr(item, 'in_out') and item.in_out == 'INPUT':
                if item.name not in new_prop_names:
                    sockets_to_remove.append(item)

        for socket in sockets_to_remove:
            node_group.interface.remove(socket)

        # Collect existing panels and create new ones as needed
        panels = {}
        for item in node_group.interface.items_tree:
            if item.item_type == 'PANEL':
                panels[item.name] = item

        # Create panels for properties that have panel assignments
        for prop in shader_def.properties:
            pname = prop.panel_name.strip()
            if pname and pname not in panels:
                panels[pname] = node_group.interface.new_panel(name=pname)

        # Remove ALL remaining input sockets and recreate them with proper panel assignment
        for item in list(node_group.interface.items_tree):
            if hasattr(item, 'in_out') and item.in_out == 'INPUT':
                node_group.interface.remove(item)

        # Recreate sockets with proper panel assignment
        for prop in shader_def.properties:
            panel_name = prop.panel_name.strip()
            parent_panel = panels.get(panel_name) if panel_name else None
            self.create_socket(node_group, prop, parent_panel)

        # Remove empty panels
        self.cleanup_empty_panels(node_group)

    def cleanup_empty_panels(self, node_group):
        """Remove panels that have no child sockets"""
        # Get all panels
        all_panels = []
        for item in node_group.interface.items_tree:
            if item.item_type == 'PANEL':
                all_panels.append(item)

        # For each panel, check if any socket has it as parent
        panels_to_remove = []
        for panel in all_panels:
            has_children = False
            for item in node_group.interface.items_tree:
                if hasattr(item, 'parent') and item.parent == panel:
                    has_children = True
                    break

            if not has_children:
                panels_to_remove.append(panel)

        for panel in panels_to_remove:
            node_group.interface.remove(panel)

    def update_socket(self, socket, prop):
        """Update an existing socket with new property values"""
        if prop.property_type == 'FLOAT':
            if hasattr(socket, 'default_value'):
                socket.default_value = prop.default_float
            if hasattr(socket, 'min_value'):
                socket.min_value = prop.min_float
            if hasattr(socket, 'max_value'):
                socket.max_value = prop.max_float
        elif prop.property_type == 'COLOR':
            if hasattr(socket, 'default_value'):
                socket.default_value = prop.default_color
        elif prop.property_type == 'VECTOR':
            if hasattr(socket, 'default_value'):
                socket.default_value = prop.default_vector
        elif prop.property_type == 'BOOL':
            if hasattr(socket, 'default_value'):
                socket.default_value = 1.0 if prop.default_bool else 0.0

    def create_socket(self, node_group, prop, panel):
        socket_types = {
            'FLOAT': 'NodeSocketFloat', 'COLOR': 'NodeSocketColor',
            'VECTOR': 'NodeSocketVector', 'TEXTURE': 'NodeSocketColor',
            'BOOL': 'NodeSocketFloat',
        }
        socket = node_group.interface.new_socket(
            name=prop.name, in_out='INPUT',
            socket_type=socket_types[prop.property_type], parent=panel
        )
        if prop.property_type == 'FLOAT':
            socket.default_value = prop.default_float
            socket.min_value = prop.min_float
            socket.max_value = prop.max_float
        elif prop.property_type == 'COLOR':
            socket.default_value = prop.default_color
        elif prop.property_type == 'VECTOR':
            socket.default_value = prop.default_vector
        elif prop.property_type == 'BOOL':
            socket.default_value = 1.0 if prop.default_bool else 0.0

    def create_material(self, group_name, node_group):
        mat = bpy.data.materials.new(name=group_name)
        mat.use_nodes = True
        mat.node_tree.nodes.clear()

        output = mat.node_tree.nodes.new('ShaderNodeOutputMaterial')
        output.location = (300, 0)
        group = mat.node_tree.nodes.new('ShaderNodeGroup')
        group.node_tree = node_group
        group.location = (0, 0)

        if 'BSDF' in group.outputs:
            mat.node_tree.links.new(group.outputs['BSDF'], output.inputs['Surface'])
        return mat


def get_shader_output_path(context):
    """Get the full path for shader output directory"""
    project_path = context.scene.mhs.project_path
    if project_path:
        project_path = bpy.path.abspath(project_path)
        if hasattr(context.scene.mhs, 'material_map_settings'):
            settings = context.scene.mhs.material_map_settings
            if settings.shader_subfolder:
                return os.path.join(project_path, settings.shader_subfolder)
        return project_path
    return ""


class MHS_OT_generate_shader_boilerplate(Operator):
    """Generate .surface shader boilerplate for the current shader"""
    bl_idname = "mhs.generate_shader_boilerplate"
    bl_label = "Generate Shader Boilerplate"
    bl_options = {'REGISTER'}

    force_overwrite: bpy.props.BoolProperty(
        name="Force Overwrite",
        description="Overwrite existing shader file without confirmation",
        default=False
    )

    existing_file: bpy.props.StringProperty(default="")

    @classmethod
    def poll(cls, context):
        shader_def = context.scene.mhs.shader_definition
        project_path = context.scene.mhs.project_path
        # Must have project path set
        if not project_path:
            return False
        # Must have a shader with properties
        if shader_def.selected_node_group == '__NEW__':
            return shader_def.name and len(shader_def.properties) > 0
        else:
            return shader_def.selected_node_group and shader_def.selected_node_group in bpy.data.node_groups

    def invoke(self, context, event):
        shader_def = context.scene.mhs.shader_definition
        shader_output_dir = get_shader_output_path(context)

        # Get shader name
        shader_name = shader_def.name

        filename = shader_name.lower() + ".surface"
        filepath = os.path.join(shader_output_dir, filename)
        self.existing_file = filename

        if os.path.exists(filepath) and not self.force_overwrite:
            # Show confirmation dialog
            return context.window_manager.invoke_props_dialog(self, width=400)

        return self.execute(context)

    def draw(self, context):
        layout = self.layout

        layout.label(text="⚠️ Shader file already exists!", icon='ERROR')
        layout.label(text=f"File: {self.existing_file}")
        layout.separator()
        layout.label(text="Overwriting may break existing shader customizations.")
        layout.label(text="This action cannot be undone.")
        layout.separator()
        layout.label(text="Click OK to overwrite, or Cancel to abort.")

    def execute(self, context):
        from .material_map.introspection import introspect_node_group
        from .shader_gen import ShaderBoilerplateGenerator

        shader_def = context.scene.mhs.shader_definition
        shader_output_dir = get_shader_output_path(context)

        # Ensure directory exists
        if not os.path.exists(shader_output_dir):
            os.makedirs(shader_output_dir)

        # Get the node group to introspect
        shader_name = shader_def.name

        node_group = bpy.data.node_groups.get(shader_name)
        if not node_group:
            self.report({'ERROR'}, f"Node group '{shader_name}' not found")
            return {'CANCELLED'}

        # Introspect the node group
        introspected_def = introspect_node_group(node_group)
        if not introspected_def:
            self.report({'ERROR'}, "Could not introspect shader")
            return {'CANCELLED'}

        shader_gen = ShaderBoilerplateGenerator(output_directory=shader_output_dir)

        try:
            filepath = shader_gen.export_shader(introspected_def)
            self.report({'INFO'}, f"Generated shader: {filepath}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to generate shader: {e}")
            return {'CANCELLED'}


class MHS_UL_shader_properties(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        icons = {'FLOAT': 'FORCE_CHARGE', 'COLOR': 'COLOR', 'VECTOR': 'EMPTY_AXIS',
                 'TEXTURE': 'TEXTURE', 'BOOL': 'CHECKBOX_HLT'}

        # Format as "PanelName | PropertyName" only if panel is assigned
        panel_name = item.panel_name.strip()
        if panel_name:
            display_name = f"{panel_name} | {item.name}"
        else:
            display_name = item.name

        row = layout.row(align=True)
        row.label(text="", icon=icons.get(item.property_type, 'DOT'))
        row.label(text=display_name)
        # Show type on the right side
        row.label(text=item.property_type)


def ensure_properties_loaded(context):
    """
    Check if properties need to be loaded from node group (for file reload scenarios).

    NOTE: This function is called from draw() context, so it cannot modify data.
    It only checks and flags - actual loading must happen via operators or update callbacks.
    """
    # This function is now a no-op during draw to avoid "Writing to ID classes" errors.
    # Property loading happens in on_selected_node_group_update() when user selects a shader.
    pass


def has_unsaved_changes(context) -> bool:
    """Check if there are unsaved changes between UI properties and saved JSON mappings"""
    import json

    shader_def = context.scene.mhs.shader_definition

    # Skip check for new shaders
    if shader_def.selected_node_group == '__NEW__':
        return False

    group_name = shader_def.name

    if group_name not in bpy.data.node_groups:
        return False  # No node group to compare against

    node_group = bpy.data.node_groups[group_name]

    # Load saved USD mappings from JSON
    saved_mappings = {}
    if 'mhs_usd_mappings_json' in node_group:
        try:
            saved_mappings = json.loads(node_group['mhs_usd_mappings_json'])
        except (json.JSONDecodeError, TypeError):
            pass

    # If no saved mappings, check if we have any properties
    if not saved_mappings:
        return len(shader_def.properties) > 0

    # Build current state as we would save it
    current_mappings = {}
    for prop in shader_def.properties:
        mapping = {
            'usd_attribute': prop.usd_attribute,
            'usd_attribute_custom': prop.usd_attribute_custom,
            'use_channel_mapping': prop.use_channel_mapping,
            'texture_rgb_attribute': prop.texture_rgb_attribute,
            'texture_rgb_custom': prop.texture_rgb_custom,
            'texture_r_attribute': prop.texture_r_attribute,
            'texture_r_custom': prop.texture_r_custom,
            'texture_g_attribute': prop.texture_g_attribute,
            'texture_g_custom': prop.texture_g_custom,
            'texture_b_attribute': prop.texture_b_attribute,
            'texture_b_custom': prop.texture_b_custom,
            'texture_a_attribute': prop.texture_a_attribute,
            'texture_a_custom': prop.texture_a_custom,
            'property_type': prop.property_type,
            'default_float': prop.default_float,
            'min_float': prop.min_float,
            'max_float': prop.max_float,
            'default_color': list(prop.default_color),
            'default_vector': list(prop.default_vector),
            'default_bool': prop.default_bool,
            'panel_name': prop.panel_name,
        }
        current_mappings[prop.name] = mapping

    # Compare property names and order
    current_names = list(current_mappings.keys())
    saved_names = list(saved_mappings.keys())

    if current_names != saved_names:
        return True

    # Compare each property's values
    for prop_name in current_names:
        current = current_mappings[prop_name]
        saved = saved_mappings.get(prop_name, {})

        # Compare key fields
        for key in ['property_type', 'panel_name', 'usd_attribute', 'usd_attribute_custom',
                    'use_channel_mapping', 'texture_rgb_attribute', 'texture_r_attribute',
                    'texture_g_attribute', 'texture_b_attribute', 'texture_a_attribute']:
            if key in current and key in saved:
                if current[key] != saved[key]:
                    return True

        # Compare float values with tolerance
        for key in ['default_float', 'min_float', 'max_float']:
            if key in current and key in saved:
                if abs(current[key] - saved[key]) > 0.0001:
                    return True

        # Compare color values with tolerance
        if 'default_color' in current and 'default_color' in saved:
            for i in range(min(len(current['default_color']), len(saved['default_color']))):
                if abs(current['default_color'][i] - saved['default_color'][i]) > 0.0001:
                    return True

        # Compare vector values with tolerance
        if 'default_vector' in current and 'default_vector' in saved:
            for i in range(min(len(current['default_vector']), len(saved['default_vector']))):
                if abs(current['default_vector'][i] - saved['default_vector'][i]) > 0.0001:
                    return True

        # Compare bool
        if 'default_bool' in current and 'default_bool' in saved:
            if current['default_bool'] != saved['default_bool']:
                return True

    return False

class MHS_PT_shader_creator_panel(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BlendMHS"
    bl_label = "Shader Creator"
    bl_parent_id = "MHS_PT_base_panel"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        prefs = context.preferences.addons.get('BlendMHS')
        if prefs is None:
            return False
        return prefs.preferences.advanced_mode

    def draw_header(self, context):
        self.layout.label(icon='NODE_MATERIAL')

    def draw(self, context):
        layout = self.layout
        shader_def = context.scene.mhs.shader_definition
        is_new = shader_def.selected_node_group == '__NEW__'

        # Ensure properties are loaded (handles file reload scenarios)
        ensure_properties_loaded(context)

        # Shader selection
        box = layout.box()
        box.label(text="Shader Selection", icon='NODE_MATERIAL')
        row = box.row(align=True)
        row.prop(shader_def, "selected_node_group", text="")
        row.operator("mhs.refresh_shader_list", icon='FILE_REFRESH', text="")
        sub = row.row(align=True)
        sub.enabled = shader_def.selected_node_group != '__NEW__'
        sub.operator("mhs.remove_shader_node_group", icon='TRASH', text="")

        # Shader Properties section

        is_new = shader_def.selected_node_group == '__NEW__'

        # Name/description
        box = layout.box()
        box.label(text="New Shader" if is_new else "Edit Shader", icon='ADD' if is_new else 'GREASEPENCIL')
        box.prop(shader_def, "name")
        box.prop(shader_def, "description")

        # Template
        box = layout.box()
        box.label(text="Shader Template", icon='FILE_SCRIPT')
        box.prop(shader_def, "template")
        box.label(text="Technique Properties:")
        row = box.row(align=True)
        row.prop(shader_def, "is_dynamic", toggle=True)
        row = box.row(align=True)
        row.prop(shader_def, "is_masked", toggle=True)
        row.prop(shader_def, "is_translucent", toggle=True)

        # Shader Properties section
        box = layout.box()
        box.label(text="Shader Properties", icon='PROPERTIES')

        row = box.row()

        # Left side: scrollable template_list
        list_col = row.column()
        list_col.template_list(
            "MHS_UL_shader_properties", "",
            shader_def, "properties",
            shader_def, "active_property_index",
            rows=5, maxrows=10
        )

        # Right side: +/- and up/down buttons
        btn_col = row.column(align=True)
        btn_col.operator("mhs.add_shader_property", icon='ADD', text="")
        btn_col.operator("mhs.remove_shader_property", icon='REMOVE', text="")
        btn_col.separator()
        btn_col.operator("mhs.move_shader_property", icon='TRIA_UP', text="").direction = 'UP'
        btn_col.operator("mhs.move_shader_property", icon='TRIA_DOWN', text="").direction = 'DOWN'

        # Property configuration (only show if there are properties)
        if shader_def.properties and shader_def.active_property_index < len(shader_def.properties):
            prop = shader_def.properties[shader_def.active_property_index]
            config_box = box.box()
            config_box.label(text="Configure", icon='SETTINGS')
            col = config_box.column()

            col.prop(prop, "name")
            col.prop(prop, "panel_name", text="Panel")
            col.prop(prop, "property_type")

            if prop.property_type == 'FLOAT':
                # Draw default with slider
                row = col.row()
                row.prop(prop, "default_float", text="Default", slider=True)
                row = col.row(align=True)
                row.prop(prop, "min_float", text="Min")
                row.prop(prop, "max_float", text="Max")
            elif prop.property_type == 'COLOR':
                col.prop(prop, "default_color", text="Default")
            elif prop.property_type == 'VECTOR':
                col.prop(prop, "default_vector", text="Default")
            elif prop.property_type == 'BOOL':
                col.prop(prop, "default_bool", text="Default")
            elif prop.property_type == 'TEXTURE':
                col.separator()
                col.label(text="Texture Source:", icon='IMAGE_DATA')
                col.prop(prop, "texture_source_type", text="")

                if prop.texture_source_type == 'ATTRIBUTE':
                    # USD Attribute mapping (assetIdFromAttribute)
                    col.separator()
                    col.label(text="USD Channel Mapping:", icon='IMAGE_RGB')
                    col.prop(prop, "use_channel_mapping")
                    if not prop.use_channel_mapping:
                        col.prop(prop, "texture_rgb_attribute", text="RGB →")
                        if prop.texture_rgb_attribute == 'CUSTOM':
                            col.prop(prop, "texture_rgb_custom", text="Custom")
                    else:
                        ch_box = col.box()
                        for ch, attr, custom_attr in [
                            ('R', 'texture_r_attribute', 'texture_r_custom'),
                            ('G', 'texture_g_attribute', 'texture_g_custom'),
                            ('B', 'texture_b_attribute', 'texture_b_custom'),
                            ('A', 'texture_a_attribute', 'texture_a_custom')
                        ]:
                            row = ch_box.row(align=True)
                            row.label(text=f"{ch} →")
                            row.prop(prop, attr, text="")
                            if getattr(prop, attr) == 'CUSTOM':
                                row = ch_box.row(align=True)
                                row.label(text="")
                                row.prop(prop, custom_attr, text="Custom")

                elif prop.texture_source_type == 'STRING_PATTERN':
                    # String pattern mapping (assetIdFromString)
                    col.separator()
                    col.label(text="Use %MaterialName% for substitution")
                    col.prop(prop, "texture_string_pattern", text="")

                elif prop.texture_source_type == 'TARGET_PATH':
                    # Direct target path (assetIdFromTargetPath)
                    col.separator()
                    col.label(text="Direct Asset Path:")
                    col.prop(prop, "texture_target_path", text="")

            if prop.property_type != 'TEXTURE':
                col.separator()
                col.prop(prop, "usd_attribute")
                if prop.usd_attribute == 'CUSTOM':
                    col.prop(prop, "usd_attribute_custom")

        # Create button - only show for new shaders (node group doesn't exist yet)
        layout.separator()
        group_name = shader_def.name

        if group_name not in bpy.data.node_groups:
            row = layout.row()
            row.scale_y = 2.0
            row.operator("mhs.create_shader_node_group", icon='NODE_MATERIAL', text="Create Shader Node Group")

        # Generate boilerplate shader button
        row = layout.row()
        row.scale_y = 1.5
        row.operator("mhs.generate_shader_boilerplate", icon='FILE_SCRIPT', text="Generate Boilerplate Shader")


# Registration
property_classes = [
    MHS_ShaderPropertyItem,
    MHS_ShaderDefinition,
    MHS_OT_add_shader_property,
    MHS_OT_remove_shader_property,
    MHS_OT_move_shader_property,
    MHS_OT_select_property,
    MHS_OT_save_shader_changes,
    MHS_OT_refresh_shader_list,
    MHS_OT_remove_shader_node_group,
    MHS_OT_create_shader_node_group,
    MHS_OT_generate_shader_boilerplate,
]

panel_classes = [
    MHS_UL_shader_properties,
    MHS_PT_shader_creator_panel,
]


def register_property_groups():
    for cls in property_classes:
        bpy.utils.register_class(cls)


def register_panels():
    for cls in panel_classes:
        bpy.utils.register_class(cls)


def register():
    register_property_groups()
    register_panels()


def unregister():
    for cls in reversed(panel_classes):
        bpy.utils.unregister_class(cls)
    for cls in reversed(property_classes):
        bpy.utils.unregister_class(cls)
