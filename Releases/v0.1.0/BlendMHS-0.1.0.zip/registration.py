"""
Master class and keymap registry for BlendMHS addon.
Defines all tool classes and their associated keymaps in a declarative format.
"""

# ═══════════════════════════════════════════════════════════════════════════════
# Keymap Definitions
# ═══════════════════════════════════════════════════════════════════════════════

keys = {
    'QUICK_EXPORT_PIE': [
        {
            'label': 'Quick Export Pie',
            'keymap': '3D View',
            'space_type': 'VIEW_3D',
            'idname': 'wm.call_menu_pie',
            'type': 'E',
            'value': 'PRESS',
            'ctrl': True,
            'shift': True,
            'alt': False,
            'properties': [('name', 'MHS_MT_quick_export_pie')],
        }
    ],
    'LAYOUT_SETUP_PIE': [
        {
            'label': 'Layout Setup Popup',
            'keymap': '3D View',
            'space_type': 'VIEW_3D',
            'idname': 'mhs.layout_setup_popup',
            'type': 'C',
            'value': 'PRESS',
            'ctrl': True,
            'shift': True,
            'alt': False,
            'properties': [],
        }
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# Getter Functions for Tool Groups
# ═══════════════════════════════════════════════════════════════════════════════

def get_quick_export_pie():
    """
    Get classes and keymaps for the Quick Export Pie menu.

    Returns:
        tuple: (classes, keymap_defs, module_name)
    """
    from .ui import MHS_MT_quick_export_pie

    classes = [MHS_MT_quick_export_pie]
    keymap_defs = keys['QUICK_EXPORT_PIE']

    return classes, keymap_defs, 'quick_export_pie'


def get_layout_setup_pie():
    """
    Get classes and keymaps for the Layout Setup Popup.

    Returns:
        tuple: (classes, keymap_defs, module_name)
    """
    from .ui import MHS_OT_layout_setup_popup

    classes = [MHS_OT_layout_setup_popup]
    keymap_defs = keys['LAYOUT_SETUP_PIE']

    return classes, keymap_defs, 'layout_setup_popup'


# ═══════════════════════════════════════════════════════════════════════════════
# Tool Activation Update Functions
# ═══════════════════════════════════════════════════════════════════════════════

def update_activate_quick_export_pie(self, context):
    """
    Update function called when activate_quick_export_pie preference changes.
    Dynamically registers/unregisters the pie menu and its keymap.
    """
    from .core.registration import register_classes, unregister_classes
    from .core.registration import register_keymaps, unregister_keymaps
    from .core.registration import get_addon_keymaps

    classes, keymap_defs, _ = get_quick_export_pie()

    # Get the keymaps module-level list for tracking
    addon_keymaps = get_addon_keymaps()

    if self.activate_quick_export_pie:
        # Register
        register_classes(classes)
        new_keymaps = register_keymaps(keymap_defs)
        addon_keymaps.extend(new_keymaps)
        print("BlendMHS: Quick Export Pie menu enabled")
    else:
        # Unregister
        # Find and remove our keymaps
        pie_idname = 'wm.call_menu_pie'
        keymaps_to_keep = []
        keymaps_to_remove = []

        for km, kmi in addon_keymaps:
            if kmi.idname == pie_idname and hasattr(kmi.properties, 'name'):
                if kmi.properties.name == 'MHS_MT_quick_export_pie':
                    keymaps_to_remove.append((km, kmi))
                    continue
            keymaps_to_keep.append((km, kmi))

        unregister_keymaps(keymaps_to_remove)

        # Update the global list
        addon_keymaps.clear()
        addon_keymaps.extend(keymaps_to_keep)

        unregister_classes(classes)
        print("BlendMHS: Quick Export Pie menu disabled")


def update_activate_layout_setup_pie(self, context):
    """
    Update function called when activate_layout_setup_pie preference changes.
    Dynamically registers/unregisters the popup operator and its keymap.
    """
    from .core.registration import register_classes, unregister_classes
    from .core.registration import register_keymaps, unregister_keymaps
    from .core.registration import get_addon_keymaps

    classes, keymap_defs, _ = get_layout_setup_pie()

    # Get the keymaps module-level list for tracking
    addon_keymaps = get_addon_keymaps()

    if self.activate_layout_setup_pie:
        # Register
        register_classes(classes)
        new_keymaps = register_keymaps(keymap_defs)
        addon_keymaps.extend(new_keymaps)
        print("BlendMHS: Layout Setup Popup enabled")
    else:
        # Unregister
        # Find and remove our keymaps
        popup_idname = 'mhs.layout_setup_popup'
        keymaps_to_keep = []
        keymaps_to_remove = []

        for km, kmi in addon_keymaps:
            if kmi.idname == popup_idname:
                keymaps_to_remove.append((km, kmi))
                continue
            keymaps_to_keep.append((km, kmi))

        unregister_keymaps(keymaps_to_remove)

        # Update the global list
        addon_keymaps.clear()
        addon_keymaps.extend(keymaps_to_keep)

        unregister_classes(classes)
        print("BlendMHS: Layout Setup Popup disabled")
