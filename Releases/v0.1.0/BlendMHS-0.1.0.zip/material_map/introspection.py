"""
Node Group Introspection

This module inspects Blender node group interfaces to extract material property
metadata for both UI generation and materialMap generation.

It handles:
- Property names, types, and default values
- Min/max ranges for float properties
- Panel organization
- Texture slot naming conventions
- USD attribute mapping inference
"""

from dataclasses import dataclass, field
from typing import Any, Optional
import re


# Property-to-USD Mapping Rules
# Maps Blender property name patterns to USD attribute names
USD_ATTRIBUTE_MAPPINGS = {
    # Base color patterns - match common naming conventions
    r'(?i)^basecolor$': 'diffuseColor',
    r'(?i)^base_color$': 'diffuseColor',
    r'(?i)^diffusecolor$': 'diffuseColor',
    r'(?i)^diffuse_color$': 'diffuseColor',
    r'(?i)^diffuse$': 'diffuseColor',
    r'(?i)^albedo$': 'diffuseColor',
    r'(?i)^color$': 'diffuseColor',

    # PBR properties
    r'(?i)^roughness$': 'roughness',
    r'(?i)^metallic$': 'metallic',
    r'(?i)^metalness$': 'metallic',

    # Emissive
    r'(?i)^emissive$': 'emissiveColor',
    r'(?i)^emissivecolor$': 'emissiveColor',
    r'(?i)^emissive_color$': 'emissiveColor',
    r'(?i)^emission$': 'emissiveColor',

    # Normal
    r'(?i)^normal$': 'normal',
    r'(?i)^normalmap$': 'normal',
    r'(?i)^normal_map$': 'normal',

    # Occlusion
    r'(?i)^occlusion$': 'occlusion',
    r'(?i)^ao$': 'occlusion',
    r'(?i)^ambientocclusion$': 'occlusion',
    r'(?i)^ambient_occlusion$': 'occlusion',

    # Opacity/Alpha
    r'(?i)^opacity$': 'opacity',
    r'(?i)^alpha$': 'opacity',

    # Texture variants - with _tex or Tex suffix
    r'(?i)^basecolor_tex$': 'diffuseColor',
    r'(?i)^basecolortex$': 'diffuseColor',
    r'(?i)^diffuse_tex$': 'diffuseColor',
    r'(?i)^diffusetex$': 'diffuseColor',
    r'(?i)^albedo_tex$': 'diffuseColor',
    r'(?i)^albedotex$': 'diffuseColor',
    r'(?i)^b_texture$': 'diffuseColor',

    r'(?i)^normal_tex$': 'normal',
    r'(?i)^normaltex$': 'normal',
    r'(?i)^n_texture$': 'normal',

    r'(?i)^roughness_tex$': 'roughness',
    r'(?i)^roughnesstex$': 'roughness',

    r'(?i)^metallic_tex$': 'metallic',
    r'(?i)^metallictex$': 'metallic',

    r'(?i)^emissive_tex$': 'emissiveColor',
    r'(?i)^emissivetex$': 'emissiveColor',
    r'(?i)^e_texture$': 'emissiveColor',

    r'(?i)^occlusion_tex$': 'occlusion',
    r'(?i)^occlusiontex$': 'occlusion',
    r'(?i)^ao_tex$': 'occlusion',
    r'(?i)^aotex$': 'occlusion',

    # MRO texture (metallic/roughness/occlusion packed)
    r'(?i)^mro_texture$': 'metallic',  # Primary channel
    r'(?i)^mrotex$': 'metallic',
}

# Texture property patterns
TEXTURE_PATTERNS = [
    r'_tex$',
    r'_texture$',
    r'Tex$',
    r'Texture$',
    r'_map$',
    r'Map$',
]


@dataclass
class ShaderProperty:
    """
    Represents a single shader property extracted from a node group.
    """
    name: str
    property_type: str  # 'float', 'color', 'vector', 'texture', 'bool'
    default_value: Any
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    panel_name: Optional[str] = None
    is_texture: bool = False
    usd_attribute_name: Optional[str] = None  # e.g., "diffuseColor", "roughness"

    # Source channel mapping for textures
    source_channels: Optional[dict] = None

    # Texture source type settings
    texture_source_type: str = 'ATTRIBUTE'  # 'ATTRIBUTE', 'STRING_PATTERN', 'TARGET_PATH'
    texture_string_pattern: str = '%MaterialName%.png'
    texture_target_path: str = ''

    def __post_init__(self):
        """Infer USD attribute name if not provided"""
        if self.usd_attribute_name is None:
            self.usd_attribute_name = infer_usd_attribute(self.name, self.is_texture)


@dataclass
class ShaderDefinition:
    """
    Complete shader definition extracted from a Blender node group.
    """
    name: str
    description: str
    properties: list[ShaderProperty] = field(default_factory=list)
    panels: list[str] = field(default_factory=list)
    has_skinning: bool = False
    technique_properties: list[str] = field(default_factory=list)
    template: str = "Lit"  # Shader template (Lit, Unlit, LitSkinned, UnlitSkinned)
    is_dynamic: bool = True
    is_masked: bool = False
    is_translucent: bool = False

    def get_texture_properties(self) -> list[ShaderProperty]:
        """Get all texture properties"""
        return [p for p in self.properties if p.is_texture]

    def get_constant_properties(self) -> list[ShaderProperty]:
        """Get all non-texture properties"""
        return [p for p in self.properties if not p.is_texture]

    def get_properties_by_panel(self, panel_name: str) -> list[ShaderProperty]:
        """Get properties belonging to a specific panel"""
        return [p for p in self.properties if p.panel_name == panel_name]

    def get_technique_properties(self) -> list[str]:
        """Get technique properties based on shader settings"""
        props = []
        if self.is_dynamic:
            props.append("dynamic")
        if self.is_masked:
            props.append("masked")
        if self.is_translucent:
            props.append("translucent")
        return props


def is_texture_property(name: str) -> bool:
    """Check if a property name indicates a texture input"""
    for pattern in TEXTURE_PATTERNS:
        if re.search(pattern, name):
            return True
    return False


def infer_usd_attribute(name: str, is_texture: bool = False) -> Optional[str]:
    """
    Infer the USD attribute name from a Blender property name.

    Args:
        name: The property name from Blender
        is_texture: Whether this is a texture property

    Returns:
        The inferred USD attribute name, or None if no mapping found
    """
    # Check against known patterns
    for pattern, usd_attr in USD_ATTRIBUTE_MAPPINGS.items():
        if re.match(pattern, name):
            return usd_attr

    # Fallback: try partial matching for common terms
    name_lower = name.lower()

    # Base color variants
    if any(term in name_lower for term in ['basecolor', 'diffuse', 'albedo']):
        if 'emissive' not in name_lower:  # Don't confuse with emissive
            return 'diffuseColor'

    # Roughness
    if 'roughness' in name_lower:
        return 'roughness'

    # Metallic
    if 'metallic' in name_lower or 'metalness' in name_lower:
        return 'metallic'

    # Emissive
    if 'emissive' in name_lower or 'emission' in name_lower:
        return 'emissiveColor'

    # Normal
    if 'normal' in name_lower:
        return 'normal'

    # Occlusion
    if 'occlusion' in name_lower or name_lower == 'ao':
        return 'occlusion'

    # Opacity
    if 'opacity' in name_lower or 'alpha' in name_lower:
        return 'opacity'

    return None


def get_socket_type(socket) -> str:
    """
    Determine the property type from a Blender node interface socket.

    Args:
        socket: A Blender NodeTreeInterfaceSocket item

    Returns:
        Property type string: 'float', 'color', 'vector', 'texture', or 'bool'
    """
    # In Blender 4.x, interface items have socket_type attribute, not type
    # Get the socket type from the class name or socket_type attribute
    socket_class = socket.__class__.__name__

    # Check class name for socket type
    if 'Float' in socket_class or socket_class == 'NodeTreeInterfaceSocketFloat':
        return 'float'
    elif 'Color' in socket_class or socket_class == 'NodeTreeInterfaceSocketColor':
        # Check if this is likely a texture input
        if is_texture_property(socket.name):
            return 'texture'
        return 'color'
    elif 'Vector' in socket_class or socket_class == 'NodeTreeInterfaceSocketVector':
        return 'vector'
    elif 'Bool' in socket_class or socket_class == 'NodeTreeInterfaceSocketBool':
        return 'bool'
    elif 'Shader' in socket_class:
        return 'shader'

    # Fallback: try to get socket_type attribute if available
    if hasattr(socket, 'socket_type'):
        socket_type = socket.socket_type
        if socket_type == 'NodeSocketFloat':
            return 'float'
        elif socket_type == 'NodeSocketColor':
            if is_texture_property(socket.name):
                return 'texture'
            return 'color'
        elif socket_type == 'NodeSocketVector':
            return 'vector'
        elif socket_type == 'NodeSocketBool':
            return 'bool'

    # Default to float for unknown types
    return 'float'


def get_default_value(socket, property_type: str) -> Any:
    """
    Get the default value from a socket.

    Args:
        socket: A Blender node interface socket item
        property_type: The determined property type

    Returns:
        The default value appropriate for the property type
    """
    try:
        if property_type == 'float':
            if hasattr(socket, 'default_value'):
                return socket.default_value
            return 0.5
        elif property_type == 'color':
            if hasattr(socket, 'default_value'):
                return tuple(socket.default_value)
            return (1.0, 1.0, 1.0, 1.0)
        elif property_type == 'vector':
            if hasattr(socket, 'default_value'):
                return tuple(socket.default_value)
            return (0.0, 0.0, 0.0)
        elif property_type == 'bool':
            if hasattr(socket, 'default_value'):
                return bool(socket.default_value)
            return False
        elif property_type == 'texture':
            return None
        else:
            if hasattr(socket, 'default_value'):
                return socket.default_value
            return None
    except (AttributeError, TypeError):
        return None


def get_min_max_values(socket) -> tuple:
    """
    Get the min and max values from a socket interface item.

    Args:
        socket: A Blender node interface socket item

    Returns:
        Tuple of (min_value, max_value) or (None, None) if not available
    """
    min_val = None
    max_val = None

    if hasattr(socket, 'min_value'):
        min_val = socket.min_value
    if hasattr(socket, 'max_value'):
        max_val = socket.max_value

    return min_val, max_val


def introspect_node_group(node_group) -> ShaderDefinition:
    """
    Extract shader definition from Blender node group interface.

    Args:
        node_group: A Blender ShaderNodeTree (node group)

    Returns:
        A ShaderDefinition containing all extracted property metadata
    """
    if node_group is None:
        return ShaderDefinition(
            name="Unknown",
            description="No node group provided"
        )

    shader_def = ShaderDefinition(
        name=node_group.name,
        description=f"Shader extracted from {node_group.name}"
    )

    current_panel = None

    # Load USD mappings from node group custom properties if they exist
    # Try JSON string first (more reliable), then fall back to dict
    # Check for both MHS_ (new) and HSR_ (legacy) prefixed keys
    import json
    usd_mappings = {}

    # Try MHS keys first (new format), then fall back to MHS (legacy)
    for prefix in ['mhs', 'mhs']:
        json_key = f'{prefix}_usd_mappings_json'
        dict_key = f'{prefix}_usd_mappings'

        if json_key in node_group:
            try:
                usd_mappings = json.loads(node_group[json_key])
                break
            except (json.JSONDecodeError, TypeError):
                pass

        if not usd_mappings and dict_key in node_group:
            raw = node_group.get(dict_key, {})
            if hasattr(raw, 'to_dict'):
                usd_mappings = raw.to_dict()
            elif isinstance(raw, dict):
                usd_mappings = dict(raw)
            if usd_mappings:
                break

    # Load shader settings (template, etc.) from node group custom properties
    # Check for both MHS_ (new) and HSR_ (legacy) prefixed keys
    for prefix in ['mhs', 'mhs']:
        json_key = f'{prefix}_shader_settings_json'
        if json_key in node_group:
            try:
                shader_settings = json.loads(node_group[json_key])
                shader_def.template = shader_settings.get('template', 'Lit')
                shader_def.is_dynamic = shader_settings.get('is_dynamic', True)
                shader_def.is_masked = shader_settings.get('is_masked', False)
                shader_def.is_translucent = shader_settings.get('is_translucent', False)
                # Store MHS shader name if available
                if 'mhs_shader' in shader_settings:
                    shader_def.description = f"MHS shader: {shader_settings['mhs_shader']}"
                break
            except (json.JSONDecodeError, TypeError):
                pass

    # Iterate through the node group interface
    for item in node_group.interface.items_tree:
        if item.item_type == 'PANEL':
            # Track panel for organization
            if item.name != "Output":
                current_panel = item.name
                if current_panel not in shader_def.panels:
                    shader_def.panels.append(current_panel)

        elif item.item_type == 'SOCKET':
            # Only process input sockets that don't start with underscore
            if item.in_out == 'INPUT' and not item.name.startswith('_'):
                socket_type = get_socket_type(item)
                is_texture = socket_type == 'texture' or is_texture_property(item.name)

                # Determine actual property type
                if is_texture:
                    property_type = 'texture'
                else:
                    property_type = socket_type

                # Get min/max for floats
                min_val, max_val = get_min_max_values(item)

                # Get default value
                default_val = get_default_value(item, property_type)

                # Get USD attribute - first check stored mappings, then infer
                usd_attr = None
                source_channels = None

                if item.name in usd_mappings:
                    mapping = usd_mappings[item.name]
                    if isinstance(mapping, dict):
                        stored_attr = mapping.get('usd_attribute', 'NONE')
                        if stored_attr == 'CUSTOM':
                            usd_attr = mapping.get('usd_attribute_custom', '')
                        elif stored_attr != 'NONE':
                            usd_attr = stored_attr

                        # Load saved property values (override socket values)
                        if 'default_float' in mapping and property_type == 'float':
                            default_val = float(mapping.get('default_float', default_val))
                        if 'min_float' in mapping:
                            min_val = float(mapping.get('min_float', min_val))
                        if 'max_float' in mapping:
                            max_val = float(mapping.get('max_float', max_val))
                        if 'default_color' in mapping and property_type == 'color':
                            saved_color = mapping.get('default_color')
                            if isinstance(saved_color, (list, tuple)) and len(saved_color) >= 4:
                                default_val = tuple(saved_color[:4])
                        if 'default_vector' in mapping and property_type == 'vector':
                            saved_vec = mapping.get('default_vector')
                            if isinstance(saved_vec, (list, tuple)) and len(saved_vec) >= 3:
                                default_val = tuple(saved_vec[:3])
                        if 'default_bool' in mapping and property_type == 'bool':
                            default_val = bool(mapping.get('default_bool', default_val))

                        # Handle texture channel mappings
                        if is_texture:
                            use_channel_mapping = mapping.get('use_channel_mapping', False)
                            if use_channel_mapping:
                                source_channels = {}
                                for ch in ['r', 'g', 'b', 'a']:
                                    ch_attr = mapping.get(f'texture_{ch}_attribute', 'NONE')
                                    if ch_attr == 'CUSTOM':
                                        ch_val = mapping.get(f'texture_{ch}_custom', '')
                                    elif ch_attr != 'NONE':
                                        ch_val = ch_attr
                                    else:
                                        ch_val = None
                                    if ch_val:
                                        source_channels[ch] = ch_val
                                # For per-channel, use the first valid channel as usd_attr if not set
                                if not usd_attr and source_channels:
                                    for ch in ['r', 'g', 'b']:
                                        if ch in source_channels:
                                            usd_attr = source_channels[ch]
                                            break
                            else:
                                rgb_attr = mapping.get('texture_rgb_attribute', 'NONE')
                                if rgb_attr == 'CUSTOM':
                                    rgb_val = mapping.get('texture_rgb_custom', '')
                                elif rgb_attr != 'NONE':
                                    rgb_val = rgb_attr
                                else:
                                    rgb_val = None
                                if rgb_val:
                                    source_channels = {'rgb': rgb_val}
                                    # Use RGB attribute as the usd_attr for this texture
                                    if not usd_attr:
                                        usd_attr = rgb_val

                # Fallback to inference if no stored mapping
                if not usd_attr:
                    usd_attr = infer_usd_attribute(item.name, is_texture)

                # Create the property
                prop = ShaderProperty(
                    name=item.name,
                    property_type=property_type,
                    default_value=default_val,
                    min_value=min_val,
                    max_value=max_val,
                    panel_name=current_panel,
                    is_texture=is_texture,
                    usd_attribute_name=usd_attr,
                    source_channels=source_channels,
                )

                # Load texture source type settings from stored mappings
                if is_texture and item.name in usd_mappings:
                    mapping = usd_mappings[item.name]
                    if isinstance(mapping, dict):
                        prop.texture_source_type = mapping.get('texture_source_type', 'ATTRIBUTE')
                        prop.texture_string_pattern = mapping.get('texture_string_pattern', '%MaterialName%.png')
                        prop.texture_target_path = mapping.get('texture_target_path', '')

                shader_def.properties.append(prop)

    # Determine if this shader has skinning support
    shader_def.has_skinning = 'skinned' in node_group.name.lower()

    return shader_def


def introspect_material(material) -> Optional[ShaderDefinition]:
    """
    Extract shader definition from a Blender material.

    Finds the main MHS/MHS node group in the material and introspects it.

    Args:
        material: A Blender Material object

    Returns:
        A ShaderDefinition, or None if no MHS/MHS group found
    """
    if not material or not material.node_tree:
        return None

    # Find the main MHS or MHS node group
    for node in material.node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree:
            # Check for both HSR_ (legacy) and MHS_ (new) prefixes
            if node.node_tree.name.startswith('HSR_') or node.node_tree.name.startswith('MHS_'):
                return introspect_node_group(node.node_tree)

    return None


def get_property_mappings_from_shader_definition(
    shader_def: ShaderDefinition
) -> tuple[dict, dict]:
    """
    Generate constant and texture mappings from a shader definition.

    Args:
        shader_def: A ShaderDefinition object

    Returns:
        Tuple of (constant_mappings, texture_mappings) dictionaries
    """
    from .schema import SourceType, ConstantMapping, TextureMapping, SourceChannels

    constant_mappings = {}
    texture_mappings = {}

    for prop in shader_def.properties:
        # Get USD attribute - either explicit or inferred
        usd_attr = prop.usd_attribute_name
        if not usd_attr:
            usd_attr = infer_usd_attribute(prop.name, prop.is_texture)

        if prop.is_texture:
            # Handle different texture source types
            texture_source_type = getattr(prop, 'texture_source_type', 'ATTRIBUTE')

            if texture_source_type == 'STRING_PATTERN':
                # assetIdFromString - uses %MaterialName% pattern
                pattern = getattr(prop, 'texture_string_pattern', '%MaterialName%.png')
                texture_mappings[prop.name] = TextureMapping(
                    source_type=SourceType.ASSET_ID_FROM_STRING,
                    source=pattern
                )
            elif texture_source_type == 'TARGET_PATH':
                # assetIdFromTargetPath - direct asset path
                target_path = getattr(prop, 'texture_target_path', '')
                if target_path:
                    texture_mappings[prop.name] = TextureMapping(
                        source_type=SourceType.ASSET_ID_FROM_TARGET_PATH,
                        source=target_path
                    )
            else:
                # Default: ATTRIBUTE - assetIdFromAttribute with channel mapping
                if not usd_attr:
                    continue  # Skip textures without USD mapping

                source_channels = None
                if prop.source_channels:
                    source_channels = SourceChannels(**prop.source_channels)
                else:
                    # Default to RGB mapping for the attribute
                    source_channels = SourceChannels(rgb=usd_attr)

                texture_mappings[prop.name] = TextureMapping(
                    source_type=SourceType.ASSET_ID_FROM_ATTRIBUTE,
                    source_channels=source_channels
                )
        else:
            if not usd_attr:
                continue  # Skip properties without USD mapping

            # Create constant mapping
            constant_mappings[f"matParams.{prop.name}"] = ConstantMapping(
                source_type=SourceType.ATTRIBUTE,
                source=usd_attr
            )

    return constant_mappings, texture_mappings
