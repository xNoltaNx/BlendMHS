"""
MaterialMap Schema

This module defines dataclasses that mirror the materialMap.json schema
for type-safe generation.

Example materialMap.json structure:
{
    "entries": [
        {
            "name": "usd-mhs-default",
            "materialType": "usd",
            "materialNameMatch": ".*HSR_Default.*",
            "shaderTargetPath": "shaders/default.surface:shader",
            "constantMappings": {
                "matParams.baseColor": {
                    "sourceType": "attribute",
                    "source": "diffuseColor"
                }
            },
            "textureMappings": {
                "baseColorTex": {
                    "sourceType": "assetIdFromAttribute",
                    "sourceChannels": { "rgb": "diffuseColor" }
                }
            },
            "techniqueProperties": ["dynamic"]
        }
    ],
    "imports": ["meta/renderer_module@materialMap.json"]
}
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Any
import json


class SourceType(Enum):
    """Source types for materialMap mappings"""
    ATTRIBUTE = "attribute"
    ATTRIBUTE_2F = "attribute2f"
    ATTRIBUTE_3F = "attribute3f"
    CONSTANT = "constant"
    ASSET_ID_FROM_STRING = "assetIdFromString"
    ASSET_ID_FROM_ATTRIBUTE = "assetIdFromAttribute"
    ASSET_ID_FROM_TARGET_PATH = "assetIdFromTargetPath"


@dataclass
class SourceChannels:
    """
    Channel mappings for texture sources.

    Can use either:
    - Simple mapping: rgb="diffuseColor"
    - Per-channel mapping: r="metallic", g="roughness", b="occlusion"
    """
    r: Optional[str] = None
    g: Optional[str] = None
    b: Optional[str] = None
    a: Optional[str] = None
    rgb: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary, excluding None values"""
        result = {}
        if self.rgb is not None:
            result['rgb'] = self.rgb
        else:
            if self.r is not None:
                result['r'] = self.r
            if self.g is not None:
                result['g'] = self.g
            if self.b is not None:
                result['b'] = self.b
            if self.a is not None:
                result['a'] = self.a
        return result

    @classmethod
    def from_dict(cls, data: dict) -> 'SourceChannels':
        """Create from dictionary"""
        return cls(
            r=data.get('r'),
            g=data.get('g'),
            b=data.get('b'),
            a=data.get('a'),
            rgb=data.get('rgb'),
        )


@dataclass
class ConstantMapping:
    """
    Mapping for constant/attribute values.

    Used for scalar, color, and vector properties.
    """
    source_type: SourceType
    source: str

    def to_dict(self) -> dict:
        """Convert to dictionary"""
        return {
            "sourceType": self.source_type.value,
            "source": self.source
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'ConstantMapping':
        """Create from dictionary"""
        return cls(
            source_type=SourceType(data['sourceType']),
            source=data['source']
        )


@dataclass
class TextureMapping:
    """
    Mapping for texture inputs.

    Can use assetIdFromAttribute, assetIdFromString, etc.
    """
    source_type: SourceType
    source: Optional[str] = None
    source_channels: Optional[SourceChannels] = None

    def to_dict(self) -> dict:
        """Convert to dictionary"""
        result = {
            "sourceType": self.source_type.value
        }
        if self.source is not None:
            result["source"] = self.source
        if self.source_channels is not None:
            channels_dict = self.source_channels.to_dict()
            if channels_dict:
                result["sourceChannels"] = channels_dict
        return result

    @classmethod
    def from_dict(cls, data: dict) -> 'TextureMapping':
        """Create from dictionary"""
        source_channels = None
        if 'sourceChannels' in data:
            source_channels = SourceChannels.from_dict(data['sourceChannels'])

        return cls(
            source_type=SourceType(data['sourceType']),
            source=data.get('source'),
            source_channels=source_channels
        )


@dataclass
class MaterialMapEntry:
    """
    A single entry in the materialMap.

    Defines how a specific material type should be mapped to an MHS shader.
    """
    name: str
    material_type: str  # "usd" or "assimp"
    shader_target_path: str
    material_name_match: Optional[str] = None
    match_mappings: bool = False
    constant_mappings: dict[str, ConstantMapping] = field(default_factory=dict)
    texture_mappings: dict[str, TextureMapping] = field(default_factory=dict)
    technique_properties: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        result = {
            "name": self.name,
            "materialType": self.material_type,
            "shaderTargetPath": self.shader_target_path
        }

        if self.material_name_match is not None:
            result["materialNameMatch"] = self.material_name_match

        if self.match_mappings:
            result["matchMappings"] = self.match_mappings

        if self.constant_mappings:
            result["constantMappings"] = {
                k: v.to_dict() for k, v in self.constant_mappings.items()
            }

        if self.texture_mappings:
            result["textureMappings"] = {
                k: v.to_dict() for k, v in self.texture_mappings.items()
            }

        if self.technique_properties:
            result["techniqueProperties"] = self.technique_properties

        return result

    @classmethod
    def from_dict(cls, data: dict) -> 'MaterialMapEntry':
        """Create from dictionary"""
        constant_mappings = {}
        if 'constantMappings' in data:
            for k, v in data['constantMappings'].items():
                constant_mappings[k] = ConstantMapping.from_dict(v)

        texture_mappings = {}
        if 'textureMappings' in data:
            for k, v in data['textureMappings'].items():
                texture_mappings[k] = TextureMapping.from_dict(v)

        return cls(
            name=data['name'],
            material_type=data['materialType'],
            shader_target_path=data['shaderTargetPath'],
            material_name_match=data.get('materialNameMatch'),
            match_mappings=data.get('matchMappings', False),
            constant_mappings=constant_mappings,
            texture_mappings=texture_mappings,
            technique_properties=data.get('techniqueProperties', [])
        )


@dataclass
class MaterialMap:
    """
    Complete materialMap.json structure.

    Contains a list of entries and optional imports.
    """
    entries: list[MaterialMapEntry] = field(default_factory=list)
    default_entry: Optional[MaterialMapEntry] = None
    imports: list[str] = field(default_factory=list)

    # Default import that's almost always needed
    DEFAULT_IMPORT = "meta/renderer_module@materialMap.json"

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        result = {}

        if self.entries:
            result["entries"] = [e.to_dict() for e in self.entries]

        if self.default_entry is not None:
            result["defaultEntry"] = self.default_entry.to_dict()

        if self.imports:
            result["imports"] = self.imports

        return result

    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict(), indent=indent)

    def save(self, path: str) -> None:
        """Save to a JSON file"""
        with open(path, 'w') as f:
            f.write(self.to_json())

    @classmethod
    def from_dict(cls, data: dict) -> 'MaterialMap':
        """Create from dictionary"""
        entries = []
        if 'entries' in data:
            entries = [MaterialMapEntry.from_dict(e) for e in data['entries']]

        default_entry = None
        if 'defaultEntry' in data:
            default_entry = MaterialMapEntry.from_dict(data['defaultEntry'])

        return cls(
            entries=entries,
            default_entry=default_entry,
            imports=data.get('imports', [])
        )

    @classmethod
    def load(cls, path: str) -> 'MaterialMap':
        """Load from a JSON file"""
        with open(path, 'r') as f:
            data = json.load(f)
        return cls.from_dict(data)

    def add_default_import(self) -> None:
        """Add the default renderer module import if not already present"""
        if self.DEFAULT_IMPORT not in self.imports:
            self.imports.insert(0, self.DEFAULT_IMPORT)

    def add_entry(self, entry: MaterialMapEntry) -> None:
        """Add an entry to the material map"""
        self.entries.append(entry)

    def find_entry(self, name: str) -> Optional[MaterialMapEntry]:
        """Find an entry by name"""
        for entry in self.entries:
            if entry.name == name:
                return entry
        return None

    def remove_entry(self, name: str) -> bool:
        """Remove an entry by name, returns True if found and removed"""
        for i, entry in enumerate(self.entries):
            if entry.name == name:
                self.entries.pop(i)
                return True
        return False
