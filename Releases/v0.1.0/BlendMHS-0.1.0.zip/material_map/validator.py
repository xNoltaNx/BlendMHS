"""
MaterialMap Validator

This module provides validation utilities for materialMap generation.
It checks for:
- Valid shader paths
- Proper property naming conventions (camelCase)
- Valid texture source channels
- No duplicate material name matches
"""

import re
from typing import Optional
from dataclasses import dataclass, field

from .schema import MaterialMap, MaterialMapEntry


@dataclass
class ValidationIssue:
    """Represents a single validation issue"""
    level: str  # 'error', 'warning', 'info'
    message: str
    entry_name: Optional[str] = None
    property_name: Optional[str] = None


@dataclass
class ValidationResult:
    """Result of validating a MaterialMap"""
    is_valid: bool = True
    issues: list[ValidationIssue] = field(default_factory=list)

    def add_error(self, message: str, entry_name: str = None, property_name: str = None):
        """Add an error issue"""
        self.issues.append(ValidationIssue('error', message, entry_name, property_name))
        self.is_valid = False

    def add_warning(self, message: str, entry_name: str = None, property_name: str = None):
        """Add a warning issue"""
        self.issues.append(ValidationIssue('warning', message, entry_name, property_name))

    def add_info(self, message: str, entry_name: str = None, property_name: str = None):
        """Add an info issue"""
        self.issues.append(ValidationIssue('info', message, entry_name, property_name))

    def get_errors(self) -> list[ValidationIssue]:
        """Get all error-level issues"""
        return [i for i in self.issues if i.level == 'error']

    def get_warnings(self) -> list[ValidationIssue]:
        """Get all warning-level issues"""
        return [i for i in self.issues if i.level == 'warning']


def is_camel_case(name: str) -> bool:
    """
    Check if a name follows camelCase convention.

    Args:
        name: The name to check

    Returns:
        True if the name is valid camelCase
    """
    # Allow names starting with lowercase or uppercase letter
    # Should not contain underscores (except leading underscore for internal)
    if name.startswith('_'):
        name = name[1:]  # Remove leading underscore for internal properties

    # Empty string after removing underscore is invalid
    if not name:
        return False

    # Check for snake_case (has underscore in middle)
    if '_' in name:
        return False

    # First character should be lowercase for true camelCase
    # But we allow PascalCase too
    return name[0].isalpha()


def validate_property_name(name: str) -> list[str]:
    """
    Validate a property name and return list of issues.

    Args:
        name: The property name to validate

    Returns:
        List of issue messages (empty if valid)
    """
    issues = []

    if not name:
        issues.append("Property name cannot be empty")
        return issues

    # Check for snake_case
    if '_' in name and not name.startswith('_'):
        issues.append(f"Property '{name}' uses snake_case. MHS expects camelCase.")

    # Check for spaces
    if ' ' in name:
        issues.append(f"Property '{name}' contains spaces. Use camelCase instead.")

    # Check for special characters
    if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', name):
        issues.append(f"Property '{name}' contains invalid characters.")

    return issues


def validate_shader_path(path: str) -> list[str]:
    """
    Validate a shader target path.

    Args:
        path: The shader target path

    Returns:
        List of issue messages (empty if valid)
    """
    issues = []

    if not path:
        issues.append("Shader target path cannot be empty")
        return issues

    # Check for .surface extension
    if ':shader' not in path:
        issues.append(f"Shader path '{path}' should end with ':shader'")

    # Check for valid characters
    if not re.match(r'^[a-zA-Z0-9_/.-]+$', path):
        issues.append(f"Shader path '{path}' contains invalid characters")

    return issues


def validate_entry(entry: MaterialMapEntry) -> ValidationResult:
    """
    Validate a single MaterialMap entry.

    Args:
        entry: The entry to validate

    Returns:
        ValidationResult with any issues found
    """
    result = ValidationResult()

    # Validate entry name
    if not entry.name:
        result.add_error("Entry name cannot be empty", entry.name)

    # Validate shader target path
    for issue in validate_shader_path(entry.shader_target_path):
        result.add_error(issue, entry.name)

    # Validate constant mappings
    for param_name in entry.constant_mappings.keys():
        # Check if param_name starts with matParams.
        if not param_name.startswith('matParams.'):
            result.add_warning(
                f"Constant mapping '{param_name}' should start with 'matParams.'",
                entry.name, param_name
            )

        # Check the actual property name (after matParams.)
        prop_name = param_name.replace('matParams.', '')
        for issue in validate_property_name(prop_name):
            result.add_warning(issue, entry.name, param_name)

    # Validate texture mappings
    for tex_name in entry.texture_mappings.keys():
        for issue in validate_property_name(tex_name):
            result.add_warning(issue, entry.name, tex_name)

        # Check source channels
        mapping = entry.texture_mappings[tex_name]
        if mapping.source_channels:
            channels = mapping.source_channels.to_dict()
            if not channels:
                result.add_warning(
                    f"Texture mapping '{tex_name}' has empty source channels",
                    entry.name, tex_name
                )

    return result


def validate_material_map(material_map: MaterialMap) -> ValidationResult:
    """
    Validate a complete MaterialMap.

    Args:
        material_map: The MaterialMap to validate

    Returns:
        ValidationResult with all issues found
    """
    result = ValidationResult()

    if not material_map.entries and material_map.default_entry is None:
        result.add_warning("MaterialMap has no entries")
        return result

    # Check for duplicate entry names
    entry_names = set()
    for entry in material_map.entries:
        if entry.name in entry_names:
            result.add_error(f"Duplicate entry name: '{entry.name}'", entry.name)
        entry_names.add(entry.name)

    # Check for duplicate material name matches
    name_matches = set()
    for entry in material_map.entries:
        if entry.material_name_match:
            if entry.material_name_match in name_matches:
                result.add_warning(
                    f"Duplicate materialNameMatch pattern: '{entry.material_name_match}'",
                    entry.name
                )
            name_matches.add(entry.material_name_match)

    # Validate each entry
    for entry in material_map.entries:
        entry_result = validate_entry(entry)
        result.issues.extend(entry_result.issues)
        if not entry_result.is_valid:
            result.is_valid = False

    # Validate default entry if present
    if material_map.default_entry:
        entry_result = validate_entry(material_map.default_entry)
        result.issues.extend(entry_result.issues)
        if not entry_result.is_valid:
            result.is_valid = False

    # Check imports
    if not material_map.imports:
        result.add_info("MaterialMap has no imports. Consider adding 'meta/renderer_module@materialMap.json'")

    return result


def format_validation_result(result: ValidationResult) -> str:
    """
    Format a validation result for display.

    Args:
        result: The ValidationResult to format

    Returns:
        Formatted string
    """
    lines = []

    if result.is_valid:
        lines.append("✓ MaterialMap validation passed")
    else:
        lines.append("✗ MaterialMap validation failed")

    # Group issues by level
    errors = result.get_errors()
    warnings = result.get_warnings()

    if errors:
        lines.append(f"\nErrors ({len(errors)}):")
        for issue in errors:
            prefix = f"  [{issue.entry_name}]" if issue.entry_name else "  "
            lines.append(f"{prefix} {issue.message}")

    if warnings:
        lines.append(f"\nWarnings ({len(warnings)}):")
        for issue in warnings:
            prefix = f"  [{issue.entry_name}]" if issue.entry_name else "  "
            lines.append(f"{prefix} {issue.message}")

    return "\n".join(lines)
