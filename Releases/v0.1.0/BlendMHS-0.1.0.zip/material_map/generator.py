"""
MaterialMap Generator

This module generates materialMap.json files from Blender materials and shaders.
It handles:
- Extracting material properties from Blender materials
- Generating materialMap entries from shader definitions
- Export to JSON format with proper formatting
"""

import bpy
import os
from typing import Optional

from .schema import (
    SourceType,
    SourceChannels,
    ConstantMapping,
    TextureMapping,
    MaterialMapEntry,
    MaterialMap,
)
from .introspection import (
    ShaderDefinition,
    introspect_node_group,
    introspect_material,
    get_property_mappings_from_shader_definition,
)


class MaterialMapGenerator:
    """
    Generates materialMap.json from Blender materials and shaders.
    """

    # Default import that's almost always needed
    DEFAULT_IMPORT = "meta/renderer_module@materialMap.json"

    def __init__(
        self,
        project_path: str = "",
        shader_target_base: str = "shaders"
    ):
        """
        Initialize the generator.

        Args:
            project_path: Root path for the project
            shader_target_base: Base path for shader references in materialMap
        """
        self.project_path = project_path
        self.shader_target_base = shader_target_base

    def generate_entry_from_material(
        self,
        material: bpy.types.Material,
        shader_def: Optional[ShaderDefinition] = None
    ) -> Optional[MaterialMapEntry]:
        """
        Generate a materialMap entry from a Blender material.

        Args:
            material: The Blender material object
            shader_def: Optional pre-computed shader definition

        Returns:
            A MaterialMapEntry, or None if generation failed
        """
        if not material or not material.mhs:
            return None

        # Get shader definition if not provided
        if shader_def is None:
            shader_def = introspect_material(material)

        if shader_def is None:
            print(f"Could not introspect material: {material.name}")
            return None

        # Get material format
        material_format = material.mhs.material_format

        # Build material name match pattern
        name_match = f".*{material_format}.*"

        # Get mappings from shader definition
        constant_mappings, texture_mappings = get_property_mappings_from_shader_definition(
            shader_def
        )

        # Get technique properties
        technique_properties = shader_def.get_technique_properties()

        # Determine shader target path
        shader_name = shader_def.name.replace("HSR_", "").lower()
        shader_target_path = f"{self.shader_target_base}/{shader_name}.surface:shader"

        # Generate entry name
        entry_name = f"usd-{material_format.lower().replace('_', '-')}"

        return MaterialMapEntry(
            name=entry_name,
            material_type="usd",
            shader_target_path=shader_target_path,
            material_name_match=name_match,
            constant_mappings=constant_mappings,
            texture_mappings=texture_mappings,
            technique_properties=technique_properties
        )

    def generate_entry_from_shader_definition(
        self,
        shader_def: ShaderDefinition,
        material_format: str = "",
        technique_properties: Optional[list] = None
    ) -> MaterialMapEntry:
        """
        Generate a materialMap entry from a shader definition.

        Args:
            shader_def: The shader definition
            material_format: Optional material format name for matching
            technique_properties: Optional list of technique properties

        Returns:
            A MaterialMapEntry
        """
        # Get mappings from shader definition
        constant_mappings, texture_mappings = get_property_mappings_from_shader_definition(
            shader_def
        )

        # Use provided technique properties or from shader def
        if technique_properties is None:
            technique_properties = shader_def.get_technique_properties()

        # Build material name match pattern
        if material_format:
            name_match = f".*{material_format}.*"
        else:
            name_match = f".*{shader_def.name}.*"

        # Determine shader target path
        shader_name = shader_def.name.replace("HSR_", "").lower()
        shader_target_path = f"{self.shader_target_base}/{shader_name}.surface:shader"

        # Generate entry name
        entry_name = f"usd-{shader_def.name.lower().replace('_', '-')}"

        return MaterialMapEntry(
            name=entry_name,
            material_type="usd",
            shader_target_path=shader_target_path,
            material_name_match=name_match,
            constant_mappings=constant_mappings,
            texture_mappings=texture_mappings,
            technique_properties=technique_properties
        )

    def generate_from_scene(
        self,
        scene: bpy.types.Scene,
        include_renderer_module_import: bool = True,
        additional_imports: Optional[list] = None
    ) -> MaterialMap:
        """
        Generate a MaterialMap from all MHS materials in the scene.

        Args:
            scene: The Blender scene to process
            include_renderer_module_import: Include default renderer module import
            additional_imports: Optional list of additional imports

        Returns:
            A MaterialMap containing all generated entries
        """
        material_map = MaterialMap()

        # Build imports list
        if include_renderer_module_import:
            material_map.imports.append(self.DEFAULT_IMPORT)

        if additional_imports:
            material_map.imports.extend(additional_imports)

        # Find all MHS materials in the scene
        processed_formats = set()

        for obj in scene.objects:
            if obj.type != 'MESH':
                continue

            for slot in obj.material_slots:
                mat = slot.material
                if not mat or not mat.mhs:
                    continue

                # Skip if format already processed
                material_format = mat.mhs.material_format
                if material_format == 'NONE' or material_format in processed_formats:
                    continue

                # Generate entry
                entry = self.generate_entry_from_material(mat)
                if entry:
                    material_map.add_entry(entry)
                    processed_formats.add(material_format)

        return material_map

    def generate_from_materials(
        self,
        materials: list,
        include_renderer_module_import: bool = True,
        additional_imports: Optional[list] = None
    ) -> MaterialMap:
        """
        Generate a MaterialMap from a list of materials.

        Args:
            materials: List of Blender materials
            include_renderer_module_import: Include default renderer module import
            additional_imports: Optional list of additional imports

        Returns:
            A MaterialMap containing all generated entries
        """
        material_map = MaterialMap()

        # Build imports list
        if include_renderer_module_import:
            material_map.imports.append(self.DEFAULT_IMPORT)

        if additional_imports:
            material_map.imports.extend(additional_imports)

        # Track processed formats to avoid duplicates
        processed_formats = set()

        for mat in materials:
            if not mat or not mat.mhs:
                continue

            material_format = mat.mhs.material_format
            if material_format == 'NONE' or material_format in processed_formats:
                continue

            entry = self.generate_entry_from_material(mat)
            if entry:
                material_map.add_entry(entry)
                processed_formats.add(material_format)

        return material_map

    def export_material_map(
        self,
        material_map: MaterialMap,
        output_path: str
    ) -> bool:
        """
        Export a MaterialMap to a JSON file.

        Args:
            material_map: The MaterialMap to export
            output_path: Path to write the JSON file

        Returns:
            True if successful, False otherwise
        """
        try:
            # Resolve relative paths
            if output_path.startswith("//"):
                output_path = bpy.path.abspath(output_path)

            # Ensure directory exists
            dir_path = os.path.dirname(output_path)
            if dir_path and not os.path.exists(dir_path):
                os.makedirs(dir_path)

            # Save the file
            material_map.save(output_path)
            print(f"Exported materialMap to: {output_path}")
            return True

        except Exception as e:
            print(f"Error exporting materialMap: {e}")
            return False


def get_mhs_materials() -> list:
    """
    Get all materials with MHS format set.

    Returns:
        List of Blender materials with MHS format != 'NONE'
    """
    hsr_materials = []
    for mat in bpy.data.materials:
        if mat.mhs and mat.mhs.material_format != 'NONE':
            hsr_materials.append(mat)
    return hsr_materials


def generate_preview_json(scene: bpy.types.Scene) -> str:
    """
    Generate a preview of the materialMap JSON that would be exported.

    Args:
        scene: The Blender scene

    Returns:
        JSON string preview
    """
    generator = MaterialMapGenerator()

    # Get settings from scene
    settings = getattr(scene.mhs, 'material_map_settings', None)
    if settings:
        generator.shader_target_base = settings.shader_target_base
        include_import = settings.import_renderer_module
        # Use new list-based additional imports
        if settings.use_additional_imports and len(settings.additional_imports) > 0:
            additional = [item.path for item in settings.additional_imports if item.path.strip()]
        else:
            additional = None
    else:
        include_import = True
        additional = None

    material_map = generator.generate_from_scene(
        scene,
        include_renderer_module_import=include_import,
        additional_imports=additional
    )

    return material_map.to_json()
