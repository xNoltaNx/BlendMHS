"""
MaterialMap Module

This module handles the generation and export of materialMap.json files
for MHS materials from Blender.

Submodules:
- schema: Data models for materialMap structure
- introspection: Node group introspection utilities
- generator: MaterialMap generation logic
- validator: Validation utilities
- auto_export: Automatic material/shader export during layout export
"""

from .schema import (
    SourceType,
    SourceChannels,
    ConstantMapping,
    TextureMapping,
    MaterialMapEntry,
    MaterialMap,
)
from .introspection import (
    ShaderProperty,
    ShaderDefinition,
    introspect_node_group,
    introspect_material,
)
from .generator import MaterialMapGenerator, get_mhs_materials, generate_preview_json
from .validator import (
    ValidationResult,
    ValidationIssue,
    validate_material_map,
    validate_entry,
    format_validation_result,
)
from .auto_export import (
    AutoMaterialExporter,
    auto_export_materials_for_layout,
    get_hsr_materials_from_objects,
    append_entries_to_material_map,
)

__all__ = [
    # Schema
    'SourceType',
    'SourceChannels',
    'ConstantMapping',
    'TextureMapping',
    'MaterialMapEntry',
    'MaterialMap',
    # Introspection
    'ShaderProperty',
    'ShaderDefinition',
    'introspect_node_group',
    'introspect_material',
    # Generator
    'MaterialMapGenerator',
    'get_mhs_materials',
    'generate_preview_json',
    # Validator
    'ValidationResult',
    'ValidationIssue',
    'validate_material_map',
    'validate_entry',
    'format_validation_result',
    # Auto Export
    'AutoMaterialExporter',
    'auto_export_materials_for_layout',
    'get_hsr_materials_from_objects',
    'append_entries_to_material_map',
]
