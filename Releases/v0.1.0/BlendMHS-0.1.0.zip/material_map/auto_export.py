"""
Material Auto-Export Module

Handles automatic export of shaders and materialMap updates when exporting layouts.
This module provides:
- Detection of materials not yet in materialMap
- Generation of shader files with overwrite protection
- Appending new entries to materialMap.json without overwriting existing ones
"""

import os
import json
import bpy
from typing import Optional

from .introspection import introspect_material, ShaderDefinition
from .generator import MaterialMapGenerator
from .schema import MaterialMap, MaterialMapEntry
from ..shader_gen import ShaderBoilerplateGenerator
from .. import cache_tracker
from ..utils import debug_log, LogCategory


def get_materials_from_objects(objects: list) -> set:
    """
    Get all unique materials used by a list of objects.

    Args:
        objects: List of Blender objects

    Returns:
        Set of material objects
    """
    materials = set()
    for obj in objects:
        if obj.type == 'MESH' and obj.data:
            for slot in obj.material_slots:
                if slot.material:
                    materials.add(slot.material)
    return materials


def get_hsr_materials_from_objects(objects: list) -> list:
    """
    Get all MHS/MHS materials (with node groups) from a list of objects.

    Args:
        objects: List of Blender objects

    Returns:
        List of materials that have MHS or MHS node groups
    """
    hsr_materials = []
    materials = get_materials_from_objects(objects)

    for mat in materials:
        if mat.node_tree:
            for node in mat.node_tree.nodes:
                if node.type == 'GROUP' and node.node_tree:
                    # Check for both HSR_ (legacy) and MHS_ (new) prefixes
                    if node.node_tree.name.startswith('HSR_') or node.node_tree.name.startswith('MHS_'):
                        hsr_materials.append(mat)
                        break

    return hsr_materials


def load_existing_material_map(filepath: str) -> Optional[dict]:
    """
    Load existing materialMap.json if it exists.

    Args:
        filepath: Path to materialMap.json

    Returns:
        Parsed JSON dict or None if file doesn't exist
    """
    if not os.path.exists(filepath):
        return None

    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        debug_log(f"Warning: Could not load existing materialMap.json: {e}", LogCategory.MATERIALMAP_EXPORT)
        return None


def get_existing_material_names(material_map_data: dict) -> set:
    """
    Get the names/patterns of materials already in the materialMap.

    Args:
        material_map_data: Parsed materialMap.json dict

    Returns:
        Set of materialNameMatch patterns
    """
    if not material_map_data:
        return set()

    existing = set()
    for entry in material_map_data.get('entries', []):
        if 'materialNameMatch' in entry:
            # Store the pattern - we'll use this to check if a material is covered
            existing.add(entry['materialNameMatch'])
        if 'name' in entry:
            existing.add(entry['name'])

    return existing


def is_material_in_map(material_name: str, existing_patterns: set) -> bool:
    """
    Check if a material is covered by existing materialMap entries.

    Args:
        material_name: Name of the Blender material
        existing_patterns: Set of existing materialNameMatch patterns

    Returns:
        True if material is already covered
    """
    import re

    for pattern in existing_patterns:
        try:
            if re.match(pattern, material_name):
                return True
        except re.error:
            # If pattern is invalid regex, try exact match
            if pattern == material_name:
                return True

    return False


def check_shader_file_exists(shader_def: ShaderDefinition, output_dir: str) -> Optional[str]:
    """
    Check if a shader file already exists for the given shader definition.

    Args:
        shader_def: ShaderDefinition to check
        output_dir: Directory where shaders are stored

    Returns:
        Path to existing file if found, None otherwise
    """
    filename = shader_def.name.replace("HSR_", "").lower() + ".surface"
    filepath = os.path.join(output_dir, filename)

    if os.path.exists(filepath):
        return filepath

    return None


def append_entries_to_material_map(
    filepath: str,
    new_entries: list[MaterialMapEntry],
    include_default_import: bool = True
) -> bool:
    """
    Append new entries to an existing materialMap.json without overwriting existing entries.

    Args:
        filepath: Path to materialMap.json
        new_entries: List of MaterialMapEntry objects to add
        include_default_import: Whether to ensure default import is present

    Returns:
        True if successful
    """
    # Load existing or create new
    existing_data = load_existing_material_map(filepath)

    if existing_data is None:
        existing_data = {
            "imports": [],
            "entries": []
        }

    # Ensure imports list exists
    if "imports" not in existing_data:
        existing_data["imports"] = []

    # Add default import if requested and not present
    default_import = "meta/renderer_module@materialMap.json"
    if include_default_import and default_import not in existing_data["imports"]:
        existing_data["imports"].insert(0, default_import)

    # Ensure entries list exists
    if "entries" not in existing_data:
        existing_data["entries"] = []

    # Get existing entry names to avoid duplicates
    existing_names = {entry.get('name') for entry in existing_data["entries"]}

    # Append new entries
    entries_added = 0
    for entry in new_entries:
        entry_dict = entry.to_dict()
        if entry_dict.get('name') not in existing_names:
            existing_data["entries"].append(entry_dict)
            existing_names.add(entry_dict.get('name'))
            entries_added += 1
            debug_log(f"Added entry '{entry_dict.get('name')}'", LogCategory.MATERIALMAP_EXPORT)
        else:
            debug_log(f"Entry '{entry_dict.get('name')}' already exists, skipping", LogCategory.MATERIALMAP_EXPORT)

    # Write back
    try:
        # Ensure directory exists
        dir_path = os.path.dirname(filepath)
        if dir_path and not os.path.exists(dir_path):
            os.makedirs(dir_path)

        with open(filepath, 'w') as f:
            json.dump(existing_data, f, indent=2)

        debug_log(f"Saved to {filepath} ({entries_added} new entries)", LogCategory.MATERIALMAP_EXPORT)
        return True
    except IOError as e:
        debug_log(f"Error saving materialMap.json: {e}", LogCategory.MATERIALMAP_EXPORT)
        return False


class AutoMaterialExporter:
    """
    Handles automatic material/shader export during layout export.
    """

    def __init__(self, project_path: str, shader_subfolder: str = "shaders"):
        """
        Initialize the exporter.

        Args:
            project_path: Root project path
            shader_subfolder: Subfolder for shaders
        """
        self.project_path = project_path
        self.shader_subfolder = shader_subfolder
        self.material_map_path = os.path.join(project_path, "materialMap.json")
        self.shader_output_dir = os.path.join(project_path, shader_subfolder)

        # Track shaders that need overwrite confirmation
        self.shaders_needing_confirmation = []
        # Track materials that need export
        self.materials_to_export = []

    def analyze_objects(self, objects: list) -> dict:
        """
        Analyze objects to determine what materials need export.

        Args:
            objects: List of objects to analyze

        Returns:
            Dict with analysis results
        """
        hsr_materials = get_hsr_materials_from_objects(objects)
        existing_map = load_existing_material_map(self.material_map_path)
        existing_patterns = get_existing_material_names(existing_map)

        materials_needing_export = []
        materials_already_covered = []
        shaders_existing = []
        shaders_new = []

        for mat in hsr_materials:
            shader_def = introspect_material(mat)
            if not shader_def:
                continue

            # Check if material is in map
            if is_material_in_map(mat.name, existing_patterns):
                materials_already_covered.append(mat)
            else:
                materials_needing_export.append(mat)

            # Check if shader file exists
            existing_path = check_shader_file_exists(shader_def, self.shader_output_dir)
            if existing_path:
                shaders_existing.append({
                    'material': mat,
                    'shader_def': shader_def,
                    'path': existing_path
                })
            else:
                shaders_new.append({
                    'material': mat,
                    'shader_def': shader_def
                })

        self.materials_to_export = materials_needing_export
        self.shaders_needing_confirmation = shaders_existing

        return {
            'materials_needing_export': materials_needing_export,
            'materials_already_covered': materials_already_covered,
            'shaders_existing': shaders_existing,
            'shaders_new': shaders_new,
            'total_hsr_materials': len(hsr_materials)
        }

    def export_new_shaders(self, force_overwrite: bool = False) -> list[str]:
        """
        Export shader files for materials that need them.

        Args:
            force_overwrite: If True, overwrite existing files

        Returns:
            List of exported shader paths
        """
        exported_paths = []

        # Ensure shader directory exists
        if not os.path.exists(self.shader_output_dir):
            os.makedirs(self.shader_output_dir)

        shader_gen = ShaderBoilerplateGenerator(output_directory=self.shader_output_dir)

        # Track which shader defs we've already exported (by name)
        exported_shader_names = set()

        for mat in self.materials_to_export:
            shader_def = introspect_material(mat)
            if not shader_def:
                continue

            # Skip if we've already exported this shader
            if shader_def.name in exported_shader_names:
                continue

            # Check if file exists
            existing_path = check_shader_file_exists(shader_def, self.shader_output_dir)

            if existing_path and not force_overwrite:
                debug_log(f"Skipping '{shader_def.name}' - file exists at {existing_path}", LogCategory.SHADER_GENERATE)
                continue

            try:
                filepath = shader_gen.export_shader(shader_def)
                exported_paths.append(filepath)
                exported_shader_names.add(shader_def.name)
                debug_log(f"Exported '{shader_def.name}' to {filepath}", LogCategory.SHADER_GENERATE)
            except Exception as e:
                debug_log(f"Error exporting '{shader_def.name}': {e}", LogCategory.SHADER_GENERATE)

        return exported_paths

    def export_material_map_entries(self) -> bool:
        """
        Export materialMap entries for materials that need them.

        Returns:
            True if successful
        """
        if not self.materials_to_export:
            return True

        generator = MaterialMapGenerator(
            project_path=self.project_path,
            shader_target_base=self.shader_subfolder
        )

        # Generate entries for new materials
        new_entries = []
        processed_formats = set()

        for mat in self.materials_to_export:
            shader_def = introspect_material(mat)
            if not shader_def:
                continue

            # Avoid duplicate entries for same shader
            if shader_def.name in processed_formats:
                continue

            entry = generator.generate_entry_from_shader_definition(
                shader_def,
                material_format=shader_def.name
            )

            if entry:
                new_entries.append(entry)
                processed_formats.add(shader_def.name)

        if new_entries:
            return append_entries_to_material_map(
                self.material_map_path,
                new_entries,
                include_default_import=True
            )

        return True

    def auto_export(self, objects: list, force_shader_overwrite: bool = False) -> dict:
        """
        Perform automatic export of materials/shaders for given objects.

        Args:
            objects: Objects being exported
            force_shader_overwrite: If True, overwrite existing shader files

        Returns:
            Dict with export results
        """
        # Analyze what needs to be exported
        analysis = self.analyze_objects(objects)

        results = {
            'analysis': analysis,
            'shaders_exported': [],
            'material_map_updated': False,
            'shaders_skipped': []
        }

        if not analysis['materials_needing_export']:
            debug_log("All materials already covered", LogCategory.MATERIALMAP_EXPORT)
            return results

        # Export shaders
        results['shaders_exported'] = self.export_new_shaders(force_shader_overwrite)

        # Track skipped shaders
        if not force_shader_overwrite:
            for item in analysis['shaders_existing']:
                if item['material'] in self.materials_to_export:
                    results['shaders_skipped'].append(item['path'])

        # Update materialMap
        results['material_map_updated'] = self.export_material_map_entries()

        return results


def auto_export_materials_for_layout(context, objects: list, force_shader_overwrite: bool = False) -> dict:
    """
    Convenience function to auto-export materials when exporting a layout.

    Args:
        context: Blender context
        objects: Objects in the layout
        force_shader_overwrite: If True, overwrite existing shader files

    Returns:
        Dict with export results
    """
    project_path = context.scene.mhs.project_path
    if not project_path:
        return {'error': 'No project path set'}

    project_path = bpy.path.abspath(project_path)

    # Get shader subfolder from settings if available
    shader_subfolder = "shaders"
    if hasattr(context.scene.mhs, 'material_map_settings'):
        settings = context.scene.mhs.material_map_settings
        shader_subfolder = settings.shader_subfolder

    exporter = AutoMaterialExporter(project_path, shader_subfolder)
    return exporter.auto_export(objects, force_shader_overwrite)
