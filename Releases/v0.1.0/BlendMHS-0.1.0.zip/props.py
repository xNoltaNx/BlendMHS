import bpy
from bpy.props import StringProperty, BoolProperty, EnumProperty, FloatProperty, PointerProperty, CollectionProperty, IntProperty, FloatVectorProperty
from bpy.app.handlers import persistent
from bpy.types import Operator, Object, PropertyGroup, Scene, Material, Image

def get_absolute_path(context, prop_name):
    path = context.scene.get(f"_{prop_name}", "")
    if path.startswith("//"):
        return bpy.path.abspath(path)
    return path.replace('\\', '/')  # Ensure forward slashes

def set_absolute_path(context, value, prop_name):
    if value.startswith("//"):
        value = bpy.path.abspath(value)
    context.scene[f"_{prop_name}"] = value.replace('\\', '/')  # Ensure forward slashes

    # Reset layout hint when project path changes (so users see it for new projects)
    if prop_name == "project_path":
        # Only reset if there are no layouts configured
        if hasattr(context.scene, 'mhs') and len(context.scene.mhs.layout_exports) == 0:
            context.scene.mhs.layout_hint_dismissed = False

def calculate_default_distance_ratio(self, context):
    obj = context.active_object
    index = obj.lod_list.values().index(self)
    if index > 0:
        prev_ratio = obj.lod_list[index - 1].distance_ratio
        return max(prev_ratio * 0.5, 0.001)  # Ensure we don't go below a minimum value
    return 1.0  # Default value for the first LOD


def on_animated_object_select(self, context):
    """Callback when an animated object is selected from the list - auto-selects the armature"""
    scene = context.scene
    idx = scene.mhs.active_animated_object_index

    if idx < 0 or idx >= len(scene.mhs.animated_objects):
        return

    item = scene.mhs.animated_objects[idx]

    if not item.armature_object:
        return

    # Deselect all objects
    bpy.ops.object.select_all(action='DESELECT')

    # Select the armature
    item.armature_object.select_set(True)
    context.view_layer.objects.active = item.armature_object

class MHS_LOD_item(PropertyGroup):
    distance_ratio: FloatProperty(
        name="Distance Ratio",
        description="Distance ratio for this LOD",
        default=1.0,
        min=0.001,
        max=1.0,
        update=lambda self, context: self.update_next_lod(context)
    )
    object: PointerProperty(
        type=Object,
        name="LOD Object",
        description="Object to use for this LOD (Manual method only)"
    )
    decimate_percentage: FloatProperty(
        name="Decimate Percentage",
        description="Percentage of polygons to keep for this LOD (Decimate method only)",
        default=50.0,
        min=1.0,
        max=100.0,
        precision=1,
        subtype='PERCENTAGE'
    )

    def update_next_lod(self, context):
        obj = context.active_object
        index = obj.mhs.lod_list.values().index(self)
        if index + 1 < len(obj.mhs.lod_list):
            next_lod = obj.mhs.lod_list[index + 1]
            next_lod.distance_ratio = max(self.distance_ratio * 0.5, 0.001)

class MHS_LightmapGroup(PropertyGroup):
    name: StringProperty(name="Group Name", default="New Group")
    objects: CollectionProperty(type=PropertyGroup)
    lightmap_resolution: EnumProperty(
        name="Lightmap Resolution",
        description="Resolution of the lightmap texture",
        items=[
            ('256', "256x256", "256x256 pixels"),
            ('512', "512x512", "512x512 pixels"),
            ('1024', "1024x1024", "1024x1024 pixels"),
            ('2048', "2048x2048", "2048x2048 pixels"),
            ('4096', "4096x4096", "4096x4096 pixels"),
        ],
        default='1024'
    )
    color: FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        default=(0.8, 0.8, 0.8),
        min=0.0,
        max=1.0,
        description="Color for the lightmap group"
    )
    show_lightmap_uv: BoolProperty(
        name="Show Lightmap UV",
        description="Toggle visibility of LightmapUV for objects in this group",
        default=False,
    )
    baked_lightmap: PointerProperty(
        name="Baked Lightmap",
        type=Image,
        description="Baked lightmap image for this group"
    )

class MHS_SphericalHarmonics(PropertyGroup):
    # L0 band (1 coefficient)
    L00: FloatVectorProperty(
        name="L00",
        description="L0,0 coefficient (ambient)",
        size=3,
        default=(0.0, 0.0, 0.0),
        subtype='COLOR'
    )

    # L1 band (3 coefficients)
    L1_1: FloatVectorProperty(
        name="L1,-1",
        description="L1,-1 coefficient",
        size=3,
        default=(0.0, 0.0, 0.0),
        subtype='COLOR'
    )
    L10: FloatVectorProperty(
        name="L10",
        description="L1,0 coefficient",
        size=3,
        default=(0.0, 0.0, 0.0),
        subtype='COLOR'
    )
    L11: FloatVectorProperty(
        name="L1,1",
        description="L1,1 coefficient",
        size=3,
        default=(0.0, 0.0, 0.0),
        subtype='COLOR'
    )

    # L2 band (5 coefficients)
    L2_2: FloatVectorProperty(
        name="L2,-2",
        description="L2,-2 coefficient",
        size=3,
        default=(0.0, 0.0, 0.0),
        subtype='COLOR'
    )
    L2_1: FloatVectorProperty(
        name="L2,-1",
        description="L2,-1 coefficient",
        size=3,
        default=(0.0, 0.0, 0.0),
        subtype='COLOR'
    )
    L20: FloatVectorProperty(
        name="L20",
        description="L2,0 coefficient",
        size=3,
        default=(0.0, 0.0, 0.0),
        subtype='COLOR'
    )
    L21: FloatVectorProperty(
        name="L21",
        description="L2,1 coefficient",
        size=3,
        default=(0.0, 0.0, 0.0),
        subtype='COLOR'
    )
    L22: FloatVectorProperty(
        name="L22",
        description="L2,2 coefficient",
        size=3,
        default=(0.0, 0.0, 0.0),
        subtype='COLOR'
    )

def update_probe_name(self, context):
    """Update the baked cubemap image name when probe name changes"""
    if self.baked_cubemap:
        # Keep the leading '.' and update the rest of the name
        self.baked_cubemap.name = f".{self.name}"

def update_probe_location(self, context):
    ### TODO This isn't working.
    """Update handler for probe location changes"""
    # Mark the probe as needing rebake when location changes
    self.needs_rebake = True

    # Update the corresponding empty object's location
    empty = bpy.data.objects.get(self.name)
    if empty:
        empty.location = self.location


def on_animation_action_select(self, context):
    """Callback when an action is selected in the animation list - sets active action and timeline range"""
    obj = context.active_object
    if not obj:
        return

    # Get the armature
    if obj.type == 'ARMATURE':
        armature = obj
    elif obj.type == 'MESH':
        armature = None
        for modifier in obj.modifiers:
            if modifier.type == 'ARMATURE' and modifier.object:
                armature = modifier.object
                break
    else:
        return

    if not armature:
        return

    # Get the selected action from the list
    if not hasattr(armature, 'mhs') or not armature.mhs.animation_export_actions:
        return

    idx = armature.mhs.active_animation_action_index
    if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
        return

    action_item = armature.mhs.animation_export_actions[idx]
    if not action_item.action:
        return

    action = action_item.action

    # Select the armature so editors properly reflect the action change
    # This is needed when the mesh is selected but we want editors to show armature's action
    if obj.type == 'MESH' and armature:
        # Deselect all and select the armature
        for o in context.view_layer.objects:
            o.select_set(False)
        armature.select_set(True)
        context.view_layer.objects.active = armature

    # Set as active action on armature
    if not armature.animation_data:
        armature.animation_data_create()
    armature.animation_data.action = action

    # Sync action slot (Blender 4.5 layered actions)
    # If our stored action_slot matches a valid slot, apply it
    # If our stored action_slot is empty, populate it from Blender's current slot
    if hasattr(armature.animation_data, 'action_suitable_slots') and hasattr(armature.animation_data, 'action_slot'):
        if action_item.action_slot:
            # Try to apply stored slot
            stored_slot = armature.animation_data.action_suitable_slots.get(action_item.action_slot)
            if stored_slot is not None:
                armature.animation_data.action_slot = stored_slot
        else:
            # No stored slot - sync from Blender's current slot
            if armature.animation_data.action_slot is None:
                # If no slot set, use the first suitable slot
                if len(armature.animation_data.action_suitable_slots) > 0:
                    armature.animation_data.action_slot = armature.animation_data.action_suitable_slots[0]
                    action_item.action_slot = armature.animation_data.action_slot.name_display
            else:
                # Slot is set - store its name_display
                action_item.action_slot = armature.animation_data.action_slot.name_display

    # Update all animation editors by setting the action in their space data
    # and tagging them for redraw
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type in {'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR'}:
                for space in area.spaces:
                    if hasattr(space, 'action'):
                        space.action = action
                area.tag_redraw()

    # Set timeline range to action's keyframe range
    if action.fcurves:
        start_frame = float('inf')
        end_frame = float('-inf')

        for fcurve in action.fcurves:
            if fcurve.keyframe_points:
                for keyframe in fcurve.keyframe_points:
                    frame = keyframe.co[0]
                    start_frame = min(start_frame, frame)
                    end_frame = max(end_frame, frame)

        if start_frame != float('inf') and end_frame != float('-inf'):
            context.scene.frame_start = int(start_frame)
            context.scene.frame_end = int(end_frame)
            context.scene.frame_current = int(start_frame)


class AnimationExportAction(PropertyGroup):
    """Enhanced action storage with metadata (mirrors Action Commander's Actions PropertyGroup)"""
    action: PointerProperty(
        type=bpy.types.Action,
        name="Action",
        description="The action to export"
    )
    enabled: BoolProperty(
        name="Export",
        description="Include this action in export",
        default=True
    )

    # Metadata (from Action Commander)
    tags: StringProperty(
        name="Tags",
        default="",
        description="Comma-separated tags for filtering (e.g., 'locomotion, combat')"
    )
    is_loop: BoolProperty(
        name="Loop",
        default=False,
        description="Mark as looping animation"
    )
    custom_name: StringProperty(
        name="Custom Name",
        default="",
        description="Display name override for export (leave empty to use action name)"
    )

    # Action Slot (stores the slot's name_display for prop_search)
    action_slot: StringProperty(
        name="Action Slot",
        default="",
        description="The action slot to use for this action (from Blender 4.5's layered actions)"
    )

    # Organization
    slot_type: EnumProperty(
        name="Slot Type",
        items=[
            ('ACTION', 'Action', 'Regular action slot'),
            ('LABEL', 'Label', 'Organizational label/separator'),
            ('FOLDER', 'Folder', 'Action folder for grouping')
        ],
        default='ACTION',
        description="Type of this list slot"
    )
    label: StringProperty(
        name="Label",
        default="---Label---",
        description="Label text for organizational separators"
    )

    # Export settings per-action
    use_custom_range: BoolProperty(
        name="Use Custom Range",
        default=False,
        description="Use custom frame range instead of action's keyframe range"
    )
    frame_start: IntProperty(
        name="Start Frame",
        default=1,
        description="Custom start frame for export"
    )
    frame_end: IntProperty(
        name="End Frame",
        default=250,
        description="Custom end frame for export"
    )

    # Bake range settings
    use_bake_range: BoolProperty(
        name="Use Bake Range",
        default=False,
        description="Use custom range when baking this action"
    )
    bake_range_start: IntProperty(
        name="Bake Start",
        default=1,
        description="Start frame for baking"
    )
    bake_range_end: IntProperty(
        name="Bake End",
        default=250,
        description="End frame for baking"
    )

    # Pose Marker as Range settings
    use_pose_marker_as_range: BoolProperty(
        name="Use Pose Marker As Range",
        default=False,
        description="Use pose markers to define action range"
    )
    pose_marker_a: StringProperty(
        name="Pose Marker A",
        default="",
        description="Start pose marker name for range"
    )
    pose_marker_b: StringProperty(
        name="Pose Marker B",
        default="",
        description="End pose marker name for range"
    )

    # Selection for batch operations
    selected: BoolProperty(
        name="Selected",
        default=False,
        description="Selected for batch operations"
    )

    # UI-only: cached display values (internal use)
    cached_frame_count: IntProperty(default=0, options={'HIDDEN', 'SKIP_SAVE'})
    cached_keyframe_count: IntProperty(default=0, options={'HIDDEN', 'SKIP_SAVE'})


class LoadableActionItem(PropertyGroup):
    """Temporary item for the Load Actions popup - represents a loadable action"""
    action_name: StringProperty(
        name="Action Name",
        description="Name of the action"
    )
    selected: BoolProperty(
        name="Selected",
        description="Select this action for loading",
        default=False
    )
    frame_count: IntProperty(
        name="Frame Count",
        description="Number of frames in the action",
        default=0
    )


class AnimatedObjectItem(PropertyGroup):
    """Item representing an animated object (mesh with armature) in the scene"""
    mesh_object: PointerProperty(
        type=Object,
        name="Mesh Object",
        description="The skinned mesh object"
    )
    armature_object: PointerProperty(
        type=Object,
        name="Armature Object",
        description="The armature controlling the mesh"
    )


class ProbeListItem(PropertyGroup):
    name: StringProperty()
    object: PointerProperty(type=Object)

class LayoutExportCollection(PropertyGroup):
    """Reference to a collection to include in layout export"""
    collection: PointerProperty(
        type=bpy.types.Collection,
        name="Collection",
        description="Collection to include in this layout export (includes all children)"
    )

class LayoutExportConfig(PropertyGroup):
    """Configuration for a single layout export"""
    name: StringProperty(
        name="Layout Name",
        description="Name of the layout file (without .usda extension)",
        default="layout"
    )
    enabled: BoolProperty(
        name="Enabled",
        description="Enable/disable this layout for export",
        default=True
    )
    collections: CollectionProperty(
        type=LayoutExportCollection,
        name="Collections",
        description="Collections to include in this layout export"
    )
    active_collection_index: IntProperty(
        name="Active Collection Index",
        default=0
    )

class LightProbeProperties(PropertyGroup):
    """Properties for light probe objects"""

    probe_index: IntProperty(
        name="Probe Index",
        description="Index of this probe",
        default=-1
    )
    resolution: EnumProperty(
        name="Resolution",
        description="Resolution of the probe's cubemap",
        items=[
            ('16', "16x16", "16x16 pixels per face"),
            ('32', "1024×1024", "32x32 pixels per face"),
            ('64', "64x64", "64x64 pixels per face"),
            ('128', "128×128", "128×128 pixels per face"),
            ('256', "256×256", "256×256 pixels per face"),
        ],
        default='32'
    )
    samples: IntProperty(
        name="Samples",
        description="Number of render samples for the cubemap",
        default=4,
        min=1,
        max=4096
    )

    influence_radius: FloatProperty(
        name="Influence Radius",
        description="Radius of influence for this light probe",
        default=1.0,
        min=0.001,
        update=lambda self, context: self.update_influence_visualization(context)
    )

    intensity: FloatProperty(
        name="Intensity",
        description="Intensity multiplier for the probe",
        default=1.0,
        min=0.0,
        soft_max=10.0
    )

    show_influence: BoolProperty(
        name="Show Influence",
        description="Visualize the probe's area of influence",
        default=True,
        update=lambda self, context: self.update_influence_visualization(context)
    )

    needs_rebake: BoolProperty(
        name="Needs Rebake",
        description="Flag indicating if probe needs to be rebaked",
        default=True
    )

    baked_cubemap: PointerProperty(
        name="Baked Cubemap",
        type=Image,
        description="Baked cubemap for this probe"
    )

    # Store the last known location
    last_location: FloatVectorProperty(
        default=(0, 0, 0),
        subtype='TRANSLATION'
    )

    def update_influence_visualization(self, context):
        """Update the probe's influence visualization"""
        obj = self.id_data
        if obj and obj.type == 'EMPTY':
            obj.empty_display_size = self.influence_radius
            obj.show_bounds = self.show_influence


class MHS_SceneProperties(PropertyGroup):

    # Shader Definition (for shader creator)
    # Note: shader_definition is added via PointerProperty in register()

    # MaterialMap Settings
    # Note: material_map_settings is added via PointerProperty in register()

    # Layout Props
    project_path: StringProperty(
        name="Project Path",
        description="Root path for the project",
        default="",
        subtype='DIR_PATH',
        get=lambda self: get_absolute_path(bpy.context, "project_path"),
        set=lambda self, value: set_absolute_path(bpy.context, value, "project_path")
    )
    layout_name: StringProperty(
        name="Layout Name (Legacy)",
        description="Legacy property - use Layout Export Configurations instead",
        default="MyLayout",
        subtype='FILE_NAME'  # This ensures valid file names
    )
    auto_export_layout_on_save: BoolProperty(
        name="Auto-Export Layout on Save",
        description="Automatically export the USDA layout whenever the blend file is saved",
        default=False
    )

    # New Layout Export System
    layout_exports: CollectionProperty(
        type=LayoutExportConfig,
        name="Layout Exports",
        description="Layout export configurations"
    )
    active_layout_index: IntProperty(
        name="Active Layout Index",
        default=0
    )

    # Layout Solo State
    soloed_layout_index: IntProperty(
        name="Soloed Layout Index",
        description="Index of the currently soloed layout (-1 if none)",
        default=-1
    )
    solo_previous_visibility: StringProperty(
        name="Solo Previous Visibility",
        description="JSON-encoded dictionary of collection visibility states before solo",
        default=""
    )

    # NUX (New User Experience) hints
    layout_hint_dismissed: BoolProperty(
        name="Layout Hint Dismissed",
        description="Whether the user has dismissed the layout setup hint",
        default=False
    )

    mhs_include_root_node: BoolProperty(
        name="Include Root Node",
        description="Include a root node in the exported USD file",
        default=False
    )
    mhs_up_axis: EnumProperty(
        name="Up Axis",
        description="Choose the up axis for the USD file",
        items=[
            ('Y', "Y Up", "Use Y as up axis"),
            ('Z', "Z Up", "Use Z as up axis"),
        ],
        default='Z'
    )

    show_lightmap_uv_properties: BoolProperty(
        name="Show Lightmap UV Properties",
        description="Show or hide Lightmap UV properties",
        default=True
    )
    lightmap_angle_limit: FloatProperty(
        name="Angle Limit",
        description="Angle limit for UV island separation",
        default=66.0,
        min=0.0,
        max=180.0
    )
    lightmap_island_margin: FloatProperty(
        name="Island Margin",
        description="Margin between UV islands",
        default=0.02,
        min=0.0,
        max=1.0
    )
    lightmap_area_weight: FloatProperty(
        name="Area Weight",
        description="Weight given to face areas when unwrapping",
        default=0.0,
        min=0.0,
        max=1.0
    )

    show_lightmap_group_properties: BoolProperty(
        name="Show Lightmap Group Properties",
        description="Show or hide Lightmap Group properties",
        default=True
    )
    # lightmap_groups: CollectionProperty(type=MHS_LightmapGroup)  # DISABLED: Causes Vulkan visualization errors
    lightmap_group_index: IntProperty()
    show_lightmap_group_visualization: BoolProperty(
        name="Show Lightmap Group Visualization",
        description="Toggle the visualization of lightmap groups in the viewport",
        default=False
    )
    lightmap_visualization_alpha: FloatProperty(
        name="Visualization Alpha Amount",
        description="Amount for the alpha of the lightmap group visualization",
        default=0.02,
        min=0.0,
        max=1.0
    )

    show_lightmap_bake_properties: BoolProperty(
        name="Show Lightmap Bake Properties",
        description="Show or hide Lightmap Bake properties",
        default=True
    )
    lightmap_resolution_modifier: EnumProperty(
        name="Resolution Modifier",
        description="Modifier for the lightmap resolution",
        items=[
            ('0.125', "1/8", "One eighth of the selected resolution"),
            ('0.25', "1/4", "One quarter of the selected resolution"),
            ('0.5', "1/2", "Half of the selected resolution"),
            ('1', "1/1", "Full selected resolution"),
        ],
        default='1'
    )
    lightmap_bake_engine: EnumProperty(
        name="Bake Engine",
        description="Choose the rendering engine for lightmap baking",
        items=[
            ('CYCLES', "Cycles", "Use Cycles for lightmap baking"),
            ('EEVEE', "EEVEE", "Use EEVEE for lightmap baking"),
        ],
        default='CYCLES'
    )
    lightmap_compute_device: EnumProperty(
        name="Compute Device",
        description="Choose the compute device for lightmap baking",
        items=[
            ('CPU', "CPU", "Use CPU for computation"),
            ('GPU', "GPU", "Use GPU for computation"),
        ],
        default='CPU'
    )
    lightmap_bake_mode: EnumProperty(
        name="Bake Mode",
        description="Choose the baking mode",
        items=[
            ('FOREGROUND', "Foreground", "Bake in the foreground"),
            ('BACKGROUND', "Background", "Bake in the background"),
        ],
        default='FOREGROUND'
    )

    # Denoising Props
    lightmap_use_denoising: BoolProperty(
        name="Use Denoising",
        description="Enable denoising for lightmaps",
        default=True
    )
    lightmap_denoise_strength: IntProperty(
        name="Denoise Strength",
        description="Strength of the denoising effect",
        default=10,
        min=0,
        max=100
    )
    lightmap_denoise_color_strength: IntProperty(
        name="Color Strength",
        description="Strength of the color denoising",
        default=10,
        min=0,
        max=100
    )
    lightmap_denoise_space_strength: IntProperty(
        name="Space Strength",
        description="Strength of the spatial denoising",
        default=10,
        min=0,
        max=100
    )

    # Animation Export Properties
    animation_sampling_rate: IntProperty(
        name="Sampling Rate",
        description="Frame rate for animation sampling (frames per second)",
        default=30,
        min=1,
        max=240
    )

    # Export Cache Properties
    force_rebuild: BoolProperty(
        name="Force Rebuild",
        description="Ignore cache and re-export all files",
        default=False
    )
    show_export_stats: BoolProperty(
        name="Show Export Stats",
        description="Display export statistics panel",
        default=False
    )

    # Export stats stored as properties for persistence
    last_export_total: IntProperty(default=0)
    last_export_exported: IntProperty(default=0)
    last_export_skipped: IntProperty(default=0)
    last_export_time_saved: FloatProperty(default=0.0)
    last_export_total_time: FloatProperty(default=0.0)
    last_export_layouts_exported: IntProperty(default=0)
    last_export_layouts_skipped: IntProperty(default=0)
    last_export_meshes_exported: IntProperty(default=0)
    last_export_meshes_skipped: IntProperty(default=0)
    last_export_materials_exported: IntProperty(default=0)
    last_export_materials_skipped: IntProperty(default=0)
    last_export_textures_exported: IntProperty(default=0)
    last_export_textures_skipped: IntProperty(default=0)
    last_export_animations_exported: IntProperty(default=0)
    last_export_animations_skipped: IntProperty(default=0)
    last_export_actions_count: IntProperty(default=0)  # Total number of animation actions exported

    # UI State Properties
    show_export_options: BoolProperty(
        name="Show Export Options",
        description="Show or hide export options panel",
        default=False
    )

    show_advanced_options: BoolProperty(
        name="Show Advanced Options",
        description="Show or hide advanced project management options (cache, purge)",
        default=False
    )

    show_folder_paths: BoolProperty(
        name="Show Folder Paths",
        description="Show or hide folder path configuration options",
        default=False
    )

    # Animated Objects List (for 3D View Animation Setup panel)
    animated_objects: CollectionProperty(
        type=AnimatedObjectItem,
        name="Animated Objects",
        description="List of animated objects (meshes with armatures) in the scene"
    )
    active_animated_object_index: IntProperty(
        name="Active Animated Object Index",
        default=0,
        update=on_animated_object_select
    )
    show_animated_objects: BoolProperty(
        name="Show Animated Objects",
        description="Show or hide the animated objects list section",
        default=True
    )
    show_global_settings: BoolProperty(
        name="Show Global Animation Settings",
        description="Show or hide the global animation settings section",
        default=False
    )
    use_custom_framerate: BoolProperty(
        name="Use Custom Frame Rate",
        description="Show custom FPS and Base fields for manual frame rate configuration",
        default=False
    )

    # Animated Objects Solo State
    soloed_animated_object_index: IntProperty(
        name="Soloed Animated Object Index",
        description="Index of the currently soloed animated object (-1 if none)",
        default=-1
    )
    animated_object_solo_previous_visibility: StringProperty(
        name="Animated Object Solo Previous Visibility",
        description="JSON-encoded dictionary of object visibility states before solo",
        default=""
    )

    # Folder Configuration Properties
    meshes_folder: StringProperty(
        name="Meshes Folder",
        default="meshes",
        description="Path for static mesh exports"
    )
    animation_folder: StringProperty(
        name="Animation Folder",
        default="animation",
        description="Path for animated mesh exports"
    )
    materials_folder: StringProperty(
        name="Materials Folder",
        default="materials",
        description="Path for material exports"
    )
    textures_folder: StringProperty(
        name="Textures Folder",
        default="textures",
        description="Path for texture exports"
    )
    layouts_folder: StringProperty(
        name="Layouts Folder",
        default="layouts",
        description="Path for layout exports"
    )

    # probe_list: CollectionProperty(type=ProbeListItem)  # DISABLED: Causes Vulkan visualization errors
    # active_lightprobe_index: IntProperty(  # DISABLED: Causes Vulkan visualization errors
    #     name="Active Light Probe",
    #     description="Index of the active light probe",
    #     default=0,
    #     min=0,
    # )

def update_active_probe(self, context):
    """Handler for when active probe index changes"""
    # Get filtered list of probes
    probes = [obj for obj in context.scene.objects
              if obj.type == 'EMPTY' and hasattr(obj, 'lightprobe')]

    # Validate index
    if probes and self.active_lightprobe_index < len(probes):
        probe = probes[self.active_lightprobe_index]
        # Select the probe in the viewport
        bpy.ops.object.select_all(action='DESELECT')
        probe.select_set(True)
        context.view_layer.objects.active = probe

class MHS_ObjectProperties(PropertyGroup):
    # UI Foldout States
    show_mesh_info: BoolProperty(
        name="Show Mesh Info",
        description="Show or hide mesh info section",
        default=False
    )
    show_evaluated_mesh: BoolProperty(
        name="Show Evaluated Mesh",
        description="Show vertex/face/triangle counts after modifiers are applied. Note: This can be slow for complex meshes",
        default=False
    )
    # Cached evaluated mesh stats (updated on-demand via Refresh button)
    eval_verts_cached: IntProperty(
        name="Cached Evaluated Vertices",
        default=-1  # -1 means not yet evaluated
    )
    eval_faces_cached: IntProperty(
        name="Cached Evaluated Faces",
        default=-1
    )
    eval_tris_cached: IntProperty(
        name="Cached Evaluated Triangles",
        default=-1
    )
    eval_cache_timestamp: FloatProperty(
        name="Evaluation Timestamp",
        description="Unix timestamp when evaluated mesh was last calculated",
        default=0.0
    )
    EVAL_CACHE_TIMEOUT: float = 5.0  # Seconds before cached values are hidden
    show_animation_info: BoolProperty(
        name="Show Animation Info",
        description="Show or hide animation info section",
        default=False
    )

    export_lods: BoolProperty(
        name="Export LODs",
        description="Include Levels of Detail in the export",
        default=False
    )
    export_lods_as_references: BoolProperty(
        name="Export LODs as References",
        description="Export LOD meshes as separate USDA files and reference them in the main object",
        default=False
    )
    export_lightmap: BoolProperty(
        name="Export Lightmap",
        description="Export the second UV channel as a lightmap",
        default=False
    )
    lod_method: EnumProperty(
        name="LOD Method",
        description="Choose the method for generating LODs",
        items=[
            ('DECIMATE', "Decimate", "Use the decimate modifier for LODs"),
            ('MANUAL', "Manual", "Use manually created LOD objects"),
        ],
        default='MANUAL'
    )
    lod_list: CollectionProperty(type=MHS_LOD_item)
    lod_list_index: IntProperty(name="Index for LOD List", default=0)
    lightmap_index: bpy.props.IntProperty(
        name="Lightmap Index",
        description="Index of the lightmap used by this object",
        default=-1,
        min=-1
    )

    # Animation Export Properties
    export_animations: BoolProperty(
        name="Export Animations",
        description="Export skeleton, skinning, and animations for this mesh",
        default=True
    )
    export_animations_separate: BoolProperty(
        name="Export Animations Separately",
        description="Export animations as separate files instead of embedding them",
        default=False
    )

    # Animation action list (for armatures)
    animation_export_actions: CollectionProperty(
        type=AnimationExportAction,
        name="Animation Export Actions",
        description="List of actions available for export"
    )
    active_animation_action_index: IntProperty(
        name="Active Animation Action Index",
        default=0,
        update=on_animation_action_select
    )

    # Action Filtering Properties (mirroring Action Commander's system)
    action_filter_name: StringProperty(
        name="Filter Name",
        default="",
        description="Filter actions by name (case-insensitive)"
    )
    action_filter_tag: StringProperty(
        name="Filter Tag",
        default="",
        description="Filter by comma-separated tags"
    )
    action_filter_tag_exclusive: BoolProperty(
        name="Exclusive Tag Match",
        default=False,
        description="All filter tags must match (AND logic). When disabled, any matching tag will show the action (OR logic)"
    )
    action_filter_invert: BoolProperty(
        name="Invert Filter",
        default=False,
        description="Invert filter results (show actions that don't match)"
    )
    action_sort_alphabetical: BoolProperty(
        name="Sort Alphabetically",
        default=False,
        description="Sort actions alphabetically instead of custom order"
    )

    # UI State: Action Box collapsed/expanded
    show_action_box: BoolProperty(
        name="Show Action Box",
        description="Show or hide the Action Box section with action operations",
        default=True
    )

    # UI State: Action Detail foldout for selected action
    show_action_detail: BoolProperty(
        name="Show Action Detail",
        description="Show or hide the action detail settings for the selected action",
        default=False
    )

    # UI State: Pose Markers foldout in action detail
    show_pose_markers: BoolProperty(
        name="Show Pose Markers",
        description="Show or hide pose markers section in action detail",
        default=False
    )


# Handlers
@persistent
def check_uv_change(dummy):
    for scene in bpy.data.scenes:
        for group in scene.mhs.lightmap_groups:
            for obj_ref in group.objects:
                obj = bpy.data.objects.get(obj_ref.name)
                if obj and obj.type == 'MESH':
                    active_uv = obj.data.uv_layers.active
                    if active_uv and active_uv.name != "LightmapUV":
                        group.show_lightmap_uv = (active_uv.name == "LightmapUV")

@persistent
def auto_refresh_animated_objects_on_load(dummy):
    """Handler to auto-refresh the animated objects list when loading a scene file"""
    try:
        for scene in bpy.data.scenes:
            if not hasattr(scene, 'mhs'):
                continue

            # Clear existing list
            scene.mhs.animated_objects.clear()

            # Find all meshes with armature modifiers
            for obj in bpy.data.objects:
                if obj.type == 'MESH':
                    for modifier in obj.modifiers:
                        if modifier.type == 'ARMATURE' and modifier.object:
                            # Add to the list
                            item = scene.mhs.animated_objects.add()
                            item.mesh_object = obj
                            item.armature_object = modifier.object
                            break  # Only add once per mesh

    except Exception as e:
        print(f"BlendMHS: Failed to refresh animated objects on load: {e}")


# Global flag to track if Blender is quitting
_blender_is_quitting = False


def _is_blender_quitting():
    """Check if Blender is in the process of quitting.

    Uses multiple methods to detect quit state:
    1. Check the global flag (set by quit_blender handler)
    2. Check if window manager has valid windows (compromised during quit)
    """
    global _blender_is_quitting

    if _blender_is_quitting:
        return True

    # Additional check: during quit, the window manager may have no valid windows
    # or the context may be compromised
    try:
        wm = bpy.context.window_manager
        if wm is None or len(wm.windows) == 0:
            return True
    except (ReferenceError, AttributeError):
        return True

    return False


@persistent
def _on_quit_blender(dummy):
    """Handler called when Blender is quitting."""
    global _blender_is_quitting
    _blender_is_quitting = True


@persistent
def auto_export_on_save(dummy):
    """Handler to auto-export USDA layout when saving the blend file"""

    # Skip auto-export if Blender is quitting to avoid hanging the editor
    if _is_blender_quitting():
        print("BlendMHS: Skipping auto-export (Blender is quitting)")
        return

    scene = bpy.context.scene
    if hasattr(scene, 'mhs') and scene.mhs.auto_export_layout_on_save:
        if scene.mhs.project_path:
            print("BlendMHS: Auto-exporting USDA layout on save...")
            try:
                from . import functions, cache_tracker

                # Get force_rebuild setting from scene
                force_rebuild = scene.mhs.force_rebuild

                # Build export summary before exporting
                summary = _build_export_summary(scene)

                # Export with cache support
                functions.write_layout_usda(bpy.context, force_rebuild=force_rebuild)

                # Reset force rebuild toggle after use
                scene.mhs.force_rebuild = False

                # Schedule a delayed UI update to ensure stats are written after save completes
                def delayed_stats_update():
                    try:
                        # Try to update scene stats from global (in case it failed during save)
                        cache_tracker.update_scene_stats_from_global()

                        # Show stats panel
                        bpy.context.scene.mhs.show_export_stats = True

                        # Force UI redraw for all 3D viewports
                        for window in bpy.context.window_manager.windows:
                            for area in window.screen.areas:
                                if area.type == 'VIEW_3D':
                                    area.tag_redraw()

                        # Show summary notification in info area
                        _show_export_summary_notification(summary)

                    except Exception as e:
                        print(f"BlendMHS: Failed to update UI after export: {e}")
                    return None  # Don't repeat

                bpy.app.timers.register(delayed_stats_update, first_interval=0.1)

                print("BlendMHS: Auto-export completed successfully")
            except Exception as e:
                print(f"BlendMHS: Auto-export failed: {str(e)}")


@persistent
def auto_refresh_animation_actions(dummy):
    """Depsgraph handler to remove deleted actions from the animation export list.

    This handler only removes actions that have been DELETED from bpy.data.actions.
    It does NOT auto-add actions - users must manually add them via the UI.
    All user metadata (tags, custom_name, is_loop, frame ranges, etc.) is preserved.
    """
    try:
        context = bpy.context
        if not context or not context.active_object:
            return

        obj = context.active_object

        # Get the armature
        armature = None
        if obj.type == 'ARMATURE':
            armature = obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    armature = modifier.object
                    break

        if not armature or not hasattr(armature, 'mhs'):
            return

        if armature.type != 'ARMATURE':
            return

        # Find actions to remove: ONLY actions that no longer exist in bpy.data.actions
        all_blender_actions = set(bpy.data.actions)
        indices_to_remove = []
        for i, item in enumerate(armature.mhs.animation_export_actions):
            if item.action and item.action not in all_blender_actions:
                # Action was deleted from Blender
                indices_to_remove.append(i)

        # Remove deleted actions (iterate backwards to avoid index issues)
        for i in sorted(indices_to_remove, reverse=True):
            armature.mhs.animation_export_actions.remove(i)

    except Exception:
        # Silently ignore errors in depsgraph handler to avoid spamming console
        pass


def _build_export_summary(scene):
    """Build a summary of what will be exported for display in notifications."""
    # Count enabled layouts
    enabled_layouts = [le for le in scene.mhs.layout_exports if le.enabled]
    layout_count = len(enabled_layouts)

    # Count unique collections across all enabled layouts
    unique_collections = set()
    for le in enabled_layouts:
        for coll_ref in le.collections:
            if coll_ref.collection:
                unique_collections.add(coll_ref.collection.name)
                # Also count child collections
                _count_child_collections(coll_ref.collection, unique_collections)

    # Count meshes and materials in those collections
    mesh_count = 0
    material_set = set()
    for coll_name in unique_collections:
        coll = bpy.data.collections.get(coll_name)
        if coll:
            for obj in coll.objects:
                if obj.type == 'MESH':
                    mesh_count += 1
                    for slot in obj.material_slots:
                        if slot.material:
                            material_set.add(slot.material.name)

    # Count textures from materials
    texture_set = set()
    for mat_name in material_set:
        mat = bpy.data.materials.get(mat_name)
        if mat and mat.use_nodes and mat.node_tree:
            for node in mat.node_tree.nodes:
                if node.type == 'TEX_IMAGE' and node.image:
                    texture_set.add(node.image.name)

    return {
        'layouts': layout_count,
        'collections': len(unique_collections),
        'meshes': mesh_count,
        'materials': len(material_set),
        'textures': len(texture_set),
    }


def _count_child_collections(collection, result_set):
    """Recursively count child collections"""
    for child in collection.children:
        result_set.add(child.name)
        _count_child_collections(child, result_set)


def _show_export_summary_notification(summary):
    """Show a notification with export summary after auto-export.

    Uses either a mouse-following tooltip (if enabled in preferences)
    or the existing popup dialog.
    """
    # Check preference for notification style
    try:
        prefs = bpy.context.preferences.addons.get(__package__)
        use_tooltip = prefs and hasattr(prefs.preferences, 'use_tooltip_notification') and prefs.preferences.use_tooltip_notification
        notification_duration = prefs.preferences.notification_duration if prefs and hasattr(prefs.preferences, 'notification_duration') else 0.5
    except Exception as e:
        print(f"BlendMHS: Could not read preferences: {e}")
        use_tooltip = True  # Default to tooltip if can't read preferences
        notification_duration = 0.5

    def show_notification():
        try:
            if use_tooltip:
                # Use new mouse-following tooltip
                from .notification import format_export_notification
                message, notification_type = format_export_notification(bpy.context.scene)

                # Find a valid 3D View context for the modal operator
                context_override = None
                for window in bpy.context.window_manager.windows:
                    for area in window.screen.areas:
                        if area.type == 'VIEW_3D':
                            for region in area.regions:
                                if region.type == 'WINDOW':
                                    context_override = {
                                        'window': window,
                                        'screen': window.screen,
                                        'area': area,
                                        'region': region,
                                    }
                                    break
                            if context_override:
                                break
                    if context_override:
                        break

                if context_override:
                    with bpy.context.temp_override(**context_override):
                        bpy.ops.mhs.export_notification(
                            'INVOKE_DEFAULT',
                            message=message,
                            icon_type=notification_type.value,
                            duration=notification_duration
                        )
                else:
                    # Fallback to popup if no 3D View available
                    print("BlendMHS: No 3D View found, using popup notification")
                    bpy.ops.mhs.show_export_results('INVOKE_DEFAULT')
            else:
                # Use existing popup
                bpy.ops.mhs.show_export_results('INVOKE_DEFAULT')
        except Exception as e:
            print(f"BlendMHS: Could not show export notification: {e}")
            import traceback
            traceback.print_exc()
        return None

    # Schedule the notification to show after a brief delay
    bpy.app.timers.register(show_notification, first_interval=0.2)

@persistent
def cleanup_deleted_objects(dummy):
    scene = bpy.context.scene
    for group in scene.mhs.lightmap_groups:
        objects_to_remove = [obj for obj in group.objects if obj.name not in bpy.data.objects]
        for obj in objects_to_remove:
            group.objects.remove(group.objects.find(obj.name))

    # Force viewport update to reflect changes
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            try:
                area.tag_redraw()
            except ReferenceError:
                # Area no longer exists, skip it
                continue
            except AttributeError:
                # area or tag_redraw might not exist, skip it
                continue

def is_light_probe(obj):
    return obj.get('is_light_probe', False)

def register():
    bpy.utils.register_class(MHS_LOD_item)
    bpy.utils.register_class(AnimationExportAction)
    bpy.utils.register_class(LoadableActionItem)
    bpy.utils.register_class(AnimatedObjectItem)
    # bpy.utils.register_class(MHS_LightmapGroup)  # DISABLED: Causes Vulkan visualization errors
    # bpy.utils.register_class(MHS_SphericalHarmonics)  # DISABLED: Causes Vulkan visualization errors
    # bpy.utils.register_class(LightProbeProperties)  # DISABLED: Causes Vulkan visualization errors
    # bpy.utils.register_class(ProbeListItem)  # DISABLED: Causes Vulkan visualization errors
    bpy.utils.register_class(LayoutExportCollection)
    bpy.utils.register_class(LayoutExportConfig)
    bpy.utils.register_class(MHS_SceneProperties)
    bpy.utils.register_class(MHS_ObjectProperties)

    Scene.mhs = PointerProperty(type=MHS_SceneProperties)
    Object.mhs = PointerProperty(type=MHS_ObjectProperties)
    # Object.lightprobe = PointerProperty(type=LightProbeProperties)  # DISABLED: Causes Vulkan visualization errors

    # bpy.app.handlers.depsgraph_update_post.append(check_uv_change)  # DISABLED: Causes Vulkan visualization errors
    # bpy.app.handlers.depsgraph_update_post.append(cleanup_deleted_objects)  # DISABLED: Causes Vulkan visualization errors

    # Only add handlers if not already registered (prevents duplicates on addon reload)
    if auto_refresh_animation_actions not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(auto_refresh_animation_actions)
    if auto_export_on_save not in bpy.app.handlers.save_post:
        bpy.app.handlers.save_post.append(auto_export_on_save)
    if auto_refresh_animated_objects_on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(auto_refresh_animated_objects_on_load)
    # Register quit handler to skip auto-export when closing Blender
    # quit_blender handler fires before Blender quits (available in Blender 4.0+)
    if hasattr(bpy.app.handlers, 'quit_blender'):
        if _on_quit_blender not in bpy.app.handlers.quit_blender:
            bpy.app.handlers.quit_blender.append(_on_quit_blender)


def unregister():

    bpy.app.handlers.save_post.remove(auto_export_on_save)
    bpy.app.handlers.depsgraph_update_post.remove(auto_refresh_animation_actions)
    if auto_refresh_animated_objects_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(auto_refresh_animated_objects_on_load)
    # Unregister quit handler
    if hasattr(bpy.app.handlers, 'quit_blender'):
        if _on_quit_blender in bpy.app.handlers.quit_blender:
            bpy.app.handlers.quit_blender.remove(_on_quit_blender)
    # bpy.app.handlers.depsgraph_update_post.remove(cleanup_deleted_objects)  # DISABLED: Causes Vulkan visualization errors
    # bpy.app.handlers.depsgraph_update_post.remove(check_uv_change)  # DISABLED: Causes Vulkan visualization errors

    del Scene.mhs
    del Object.mhs
    # del Object.lightprobe  # DISABLED: Causes Vulkan visualization errors

    # bpy.utils.unregister_class(ProbeListItem)  # DISABLED: Causes Vulkan visualization errors
    # bpy.utils.unregister_class(LightProbeProperties)  # DISABLED: Causes Vulkan visualization errors
    # bpy.utils.unregister_class(MHS_SphericalHarmonics)  # DISABLED: Causes Vulkan visualization errors
    bpy.utils.unregister_class(MHS_ObjectProperties)
    bpy.utils.unregister_class(MHS_SceneProperties)
    bpy.utils.unregister_class(LayoutExportConfig)
    bpy.utils.unregister_class(LayoutExportCollection)
    # bpy.utils.unregister_class(MHS_LightmapGroup)  # DISABLED: Causes Vulkan visualization errors
    bpy.utils.unregister_class(AnimationExportAction)
    bpy.utils.unregister_class(LoadableActionItem)
    bpy.utils.unregister_class(AnimatedObjectItem)
    bpy.utils.unregister_class(MHS_LOD_item)
