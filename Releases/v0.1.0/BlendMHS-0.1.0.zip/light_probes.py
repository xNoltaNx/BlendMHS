import bpy
import os
import json
import shutil
import zipfile
from bpy.app.handlers import persistent
from bpy.props import (FloatProperty, FloatVectorProperty, IntProperty, 
                      StringProperty, EnumProperty, BoolProperty, PointerProperty)
from bpy.types import Operator
from mathutils import Vector
from . import utils

def get_new_probe_name():
    """Get a new unique probe name"""
    probe_numbers = set()
    for obj in bpy.data.objects:
        if obj.type == 'EMPTY' and obj.name.startswith("Probe."):
            try:
                num = int(obj.name.split(".")[-1])
                probe_numbers.add(num)
            except ValueError:
                continue
    
    counter = 1
    while counter in probe_numbers:
        counter += 1
        
    return f"Probe.{counter:03d}"

def ensure_probe_collection():
    """Get or create the LightProbes collection"""
    collection = bpy.data.collections.get("LightProbes")
    if not collection:
        collection = bpy.data.collections.new("LightProbes")
        bpy.context.scene.collection.children.link(collection)
    return collection

def get_next_probe_index():
    """Get the next available probe index"""
    used_indices = set()
    for obj in bpy.data.objects:
        if obj.type == 'EMPTY' and 'lightprobe' in obj:
            idx = obj.lightprobe.probe_index
            if idx >= 0:
                used_indices.add(idx)

    index = 0
    while index in used_indices:
        index += 1
    return index

def create_probe(context, location):
    """Create a new probe at the specified location"""
    probe = bpy.data.objects.new(name=get_new_probe_name(), object_data=None)
    probe.empty_display_type = 'SPHERE'
    probe.empty_display_size = 0.5
    probe.show_bounds = True
    probe.show_name = True
    probe.location = location
    
    # Initialize probe properties
    probe.lightprobe.probe_index = get_next_probe_index()
    probe.lightprobe.last_location = location
    
    # Add to LightProbes collection
    collection = ensure_probe_collection()
    collection.objects.link(probe)
    
    return probe

def bake_probe(context, probe_obj):
    """Bake a cubemap for a light probe object"""
    if 'lightprobe' not in probe_obj:
        return None
        
    probe_properties = probe_obj.lightprobe
    
    # Skip if probe doesn't need rebaking
    if not probe_properties.needs_rebake and 'baked_cubemap' in probe_properties:
        return probe_properties.baked_cubemap
        
    try:
        # Use the cubemap_baking module to do the actual baking
        from . import cubemap_baking
        cubemap = cubemap_baking.bake_lightprobe(context, probe_obj)

        return cubemap
        
    except Exception as e:
        print(f"Failed to bake probe {probe_obj.name}: {str(e)}")
        return None
        
def update_influence_visualization(probe_obj):
    """Update the probe's influence visualization"""
    if 'lightprobe' in probe_obj:
        probe_obj.empty_display_size = probe_obj.lightprobe.influence_radius
        probe_obj.show_bounds = probe_obj.lightprobe.show_influence

def convert_to_ruf(location):
    """Convert from Blender coordinates to RUF coordinate system"""
    return [
        location.x,      # Right (same as Blender's X)
        location.z,      # Up (was Blender's Z)
        -location.y      # Forward (negative of Blender's Y)
    ]

def export_probes(context, project_path, layout_name):
    """Export light probe data including locations and cubemap references"""
    lightprobes_dir = os.path.join(project_path, "lightprobes")
    os.makedirs(lightprobes_dir, exist_ok=True)
    
    lprb_folder_name = f"{layout_name}.lprb"
    lprb_folder_path = os.path.join(lightprobes_dir, lprb_folder_name)
    
    if os.path.exists(lprb_folder_path):
        shutil.rmtree(lprb_folder_path)
    os.makedirs(lprb_folder_path)
    
    try:
        data = {"lightprobes": []}
        
        probe_objects = [obj for obj in bpy.data.objects 
                        if obj.type == 'EMPTY' and 
                        'lightprobe' in obj and
                        'baked_cubemap' in obj.lightprobe]
        probe_objects.sort(key=lambda x: x.name)
        
        for index, probe_obj in enumerate(probe_objects, 1):
            cubemap_name = f"Cubemap_{index:03d}.exr"
            cubemap_path = os.path.join(lprb_folder_path, cubemap_name)
            
            # Export the cubemap
            probe_obj.lightprobe.baked_cubemap.save_render(cubemap_path)
            
            # Create probe data
            probe_data = {
                "location": convert_to_ruf(probe_obj.location),
                "cubemap": cubemap_name,
                "intensity": probe_obj.lightprobe.intensity
            }
            data["lightprobes"].append(probe_data)
        
        # Write the JSON file
        json_path = os.path.join(lprb_folder_path, "lightprobes.json")
        with open(json_path, 'w') as f:
            json.dump(data, f, indent=4)
        
        # Create zip archive
        zip_path = os.path.join(lightprobes_dir, f"{layout_name}.lprb.zip")
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(lprb_folder_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, lightprobes_dir)
                    zipf.write(file_path, arcname)
        
        # Clean up temp folder
        shutil.rmtree(lprb_folder_path)
        return zip_path
        
    except Exception as e:
        if os.path.exists(lprb_folder_path):
            shutil.rmtree(lprb_folder_path)
        raise e

# Operators
class LIGHTPROBE_OT_add(Operator):
    bl_idname = "lightprobe.add"
    bl_label = "Add Light Probe"
    bl_description = "Add a new light probe object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        probe = create_probe(context, context.scene.cursor.location)
        
        # Make probe active and selected
        bpy.ops.object.select_all(action='DESELECT')
        context.view_layer.objects.active = probe
        probe.select_set(True)
        
        # Update the UI list
        probe_list = context.scene.mhs.probe_list
        item = probe_list.add()
        item.name = probe.name
        item.object = probe
        context.scene.mhs.active_lightprobe_index = len(probe_list) - 1
        
        return {'FINISHED'}

class LIGHTPROBE_OT_add_grid(Operator):
    bl_idname = "lightprobe.add_grid"
    bl_label = "Add Probe Grid"
    bl_description = "Add a grid of light probes"
    bl_options = {'REGISTER', 'UNDO'}
    
    size_x: IntProperty(name="X Count", default=2, min=1, max=100,
                       description="Number of probes along X axis")
    size_y: IntProperty(name="Y Count", default=2, min=1, max=100,
                       description="Number of probes along Y axis")
    size_z: IntProperty(name="Z Count", default=2, min=1, max=100,
                       description="Number of probes along Z axis")
    
    footprint_x: FloatProperty(name="X Size (m)", default=10.0, min=0.1,
                             description="Total size of grid in meters along X axis")
    footprint_y: FloatProperty(name="Y Size (m)", default=10.0, min=0.1,
                             description="Total size of grid in meters along Y axis")
    footprint_z: FloatProperty(name="Z Size (m)", default=5.0, min=0.1,
                             description="Total size of grid in meters along Z axis")
    
    use_object_bounds: BoolProperty(
        name="Use Active Object Bounds",
        description="Use the active object's bounding box to determine grid size",
        default=False
    )
    
    @classmethod
    def poll(cls, context):
        # Allow operator to run if no object is selected, or if an object is selected
        return True
    
    def get_object_dimensions(self, context):
        """Get dimensions from active object's bounds"""
        obj = context.active_object
        if not obj:
            return None
            
        # Get world-space bounds
        bounds = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        
        # Calculate dimensions
        min_x = min(v.x for v in bounds)
        max_x = max(v.x for v in bounds)
        min_y = min(v.y for v in bounds)
        max_y = max(v.y for v in bounds)
        min_z = min(v.z for v in bounds)
        max_z = max(v.z for v in bounds)
        
        return {
            'x': max_x - min_x,
            'y': max_y - min_y,
            'z': max_z - min_z,
            'center': Vector((
                (min_x + max_x) / 2,
                (min_y + max_y) / 2,
                (min_z + max_z) / 2
            ))
        }
    
    def draw(self, context):
        layout = self.layout
        
        # Object bounds checkbox
        box = layout.box()
        row = box.row()
        row.prop(self, "use_object_bounds")
        
        # Show object bounds info if checkbox is enabled
        if self.use_object_bounds:
            obj = context.active_object
            if obj:
                dims = self.get_object_dimensions(context)
                if dims:
                    col = box.column(align=True)
                    col.label(text=f"Object: {obj.name}", icon='OBJECT_DATA')
                    col.label(text=f"Size: {dims['x']:.2f}m × {dims['y']:.2f}m × {dims['z']:.2f}m")
            else:
                box.label(text="No active object", icon='ERROR')
        
        # Grid count properties
        grid_box = layout.box()
        grid_box.label(text="Probe Count", icon='GRID')
        row = grid_box.row(align=True)
        row.prop(self, "size_x")
        row.prop(self, "size_y")
        row.prop(self, "size_z")
        
        # Size properties (disabled if using object bounds)
        size_box = layout.box()
        size_box.label(text="Grid Size", icon='ARROW_LEFTRIGHT')
        row = size_box.row(align=True)
        row.enabled = not self.use_object_bounds
        row.prop(self, "footprint_x")
        row.prop(self, "footprint_y")
        row.prop(self, "footprint_z")
        
        # Calculate and show spacing information
        spacing_box = layout.box()
        spacing_box.label(text="Resulting Spacing", icon='DRIVER_DISTANCE')
        col = spacing_box.column(align=True)
        
        # Use either manual footprint or object dimensions
        if self.use_object_bounds and context.active_object:
            dims = self.get_object_dimensions(context)
            if dims:
                size_x = dims['x']
                size_y = dims['y']
                size_z = dims['z']
            else:
                size_x = self.footprint_x
                size_y = self.footprint_y
                size_z = self.footprint_z
        else:
            size_x = self.footprint_x
            size_y = self.footprint_y
            size_z = self.footprint_z
        
        spacing_x = size_x / max(self.size_x - 1, 1) if self.size_x > 1 else 0
        spacing_y = size_y / max(self.size_y - 1, 1) if self.size_y > 1 else 0
        spacing_z = size_z / max(self.size_z - 1, 1) if self.size_z > 1 else 0
        
        col.label(text=f"X Spacing: {spacing_x:.2f}m")
        col.label(text=f"Y Spacing: {spacing_y:.2f}m")
        col.label(text=f"Z Spacing: {spacing_z:.2f}m")
    
    def invoke(self, context, event):
        # If using object bounds, pre-fill the size values
        if context.active_object:
            dims = self.get_object_dimensions(context)
            if dims and self.use_object_bounds:
                self.footprint_x = dims['x']
                self.footprint_y = dims['y']
                self.footprint_z = dims['z']
        
        return context.window_manager.invoke_props_dialog(self, width=400)
    
    def execute(self, context):
        # Calculate grid parameters
        if self.use_object_bounds and context.active_object:
            dims = self.get_object_dimensions(context)
            if dims:
                size_x = dims['x']
                size_y = dims['y']
                size_z = dims['z']
                start_pos = dims['center']
            else:
                size_x = self.footprint_x
                size_y = self.footprint_y
                size_z = self.footprint_z
                start_pos = context.scene.cursor.location
        else:
            size_x = self.footprint_x
            size_y = self.footprint_y
            size_z = self.footprint_z
            start_pos = context.scene.cursor.location

        # Calculate spacing
        spacing_x = size_x / max(self.size_x - 1, 1) if self.size_x > 1 else 0
        spacing_y = size_y / max(self.size_y - 1, 1) if self.size_y > 1 else 0
        spacing_z = size_z / max(self.size_z - 1, 1) if self.size_z > 1 else 0
        
        # Calculate offset to center the grid
        offset_x = -size_x / 2 if self.size_x > 1 else 0
        offset_y = -size_y / 2 if self.size_y > 1 else 0
        offset_z = -size_z / 2 if self.size_z > 1 else 0
        
        # Create probes
        probes = []
        for x in range(self.size_x):
            for y in range(self.size_y):
                for z in range(self.size_z):
                    # Calculate position with centering offset
                    pos = Vector((
                        start_pos.x + offset_x + (x * spacing_x),
                        start_pos.y + offset_y + (y * spacing_y),
                        start_pos.z + offset_z + (z * spacing_z)
                    ))
                    
                    probe = create_probe(context, pos)
                    probes.append(probe)
        
        # Select all created probes
        bpy.ops.object.select_all(action='DESELECT')
        for probe in probes:
            probe.select_set(True)
        if probes:
            context.view_layer.objects.active = probes[-1]
            
        self.report({'INFO'}, f"Created {len(probes)} probes in a {self.size_x}x{self.size_y}x{self.size_z} grid")
        return {'FINISHED'}

class LIGHTPROBE_OT_bake(Operator):
    bl_idname = "lightprobe.bake"
    bl_label = "Bake Light Probes"
    bl_description = "Bake cubemaps for selected light probes"
    
    bake_all: BoolProperty(default=False)
    
    def execute(self, context):
        # Get probes to check
        if self.bake_all:
            probes_to_check = [obj for obj in bpy.data.objects 
                             if obj.type == 'EMPTY' and obj.lightprobe]
        else:
            probes_to_check = [obj for obj in context.selected_objects 
                             if obj.type == 'EMPTY' and obj.lightprobe]
        
        if not probes_to_check:
            self.report({'WARNING'}, "No light probes found to bake")
            return {'CANCELLED'}
            
        # Filter to only probes that need baking
        baked_count = 0
        total_count = len(probes_to_check)
        
        for probe in probes_to_check:
            # Skip if already baked and doesn't need rebake
            if (not probe.lightprobe.needs_rebake and 
                probe.lightprobe.baked_cubemap):
                continue
                
            try:
                if bake_probe(context, probe):
                    baked_count += 1
            except Exception as e:
                self.report({'ERROR'}, f"Failed to bake {probe.name}: {str(e)}")
                continue
        
        skipped_count = total_count - baked_count
        
        # Report results
        if total_count == 1:
            if baked_count == 1:
                self.report({'INFO'}, "Probe baked successfully")
            else:
                self.report({'INFO'}, "Probe already baked")
        else:
            if skipped_count > 0:
                self.report({'INFO'}, 
                           f"Baked {baked_count} probe{'s' if baked_count != 1 else ''} "
                           f"(skipped {skipped_count} already baked)")
            else:
                self.report({'INFO'}, f"Baked {baked_count} probe{'s' if baked_count != 1 else ''}")
            
        return {'FINISHED'}

class LIGHTPROBE_OT_export(Operator):
    bl_idname = "lightprobe.export"
    bl_label = "Export Light Probes"
    bl_description = "Export light probe data including locations and cubemap references"
    
    def execute(self, context):
        try:
            project_path = context.scene.mhs.project_path
            layout_name = utils.sanitize_name(context.scene.mhs.layout_name)
            zip_path = export_probes(context, project_path, layout_name)
            self.report({'INFO'}, f"Light probes exported to {zip_path}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to export light probes: {str(e)}")
            return {'CANCELLED'}

class LIGHTPROBE_OT_delete(Operator):
    bl_idname = "lightprobe.delete"
    bl_label = "Delete Light Probe"
    bl_description = "Delete the selected light probe"
    bl_options = {'REGISTER', 'UNDO'}
    
    probe_name: StringProperty(
        name="Probe Name",
        description="Name of probe to delete",
    )
    probe_names: StringProperty(
        name="Probe Names",
        description="Names of probes to delete, separated by semicolons",
    )
    
    def execute(self, context):
        names_to_delete = self.probe_names.split(';') if self.probe_names else [self.probe_name]
        deleted_count = 0
        
        for probe_name in names_to_delete:
            if not probe_name:
                continue
                
            probe_obj = bpy.data.objects.get(probe_name)
            if not probe_obj or 'lightprobe' not in probe_obj:
                continue
            
            # Clean up the cubemap if it exists
            probe_props = probe_obj.lightprobe
            if 'baked_cubemap' in probe_props:
                cubemap_image = probe_props.baked_cubemap
                if isinstance(cubemap_image, bpy.types.Image):
                    bpy.data.images.remove(cubemap_image, do_unlink=True)
            
            # Remove the probe object
            bpy.data.objects.remove(probe_obj, do_unlink=True)
            deleted_count += 1
        
        # Update probe indices
        self.reorder_indices()
        
        # Update the probe list
        probe_list = context.scene.mhs.probe_list
        probe_list.clear()
        
        # Rebuild the list with remaining probes
        remaining_probes = [obj for obj in bpy.data.objects 
                          if obj.type == 'EMPTY' and 'lightprobe' in obj]
        remaining_probes.sort(key=lambda x: (x.lightprobe.probe_index, x.name))
        
        for probe in remaining_probes:
            item = probe_list.add()
            item.name = probe.name
            item.object = probe
        
        # Adjust active index
        max_index = len(probe_list) - 1
        if context.scene.mhs.active_lightprobe_index > max_index:
            context.scene.mhs.active_lightprobe_index = max(0, max_index)
        
        # Force viewport update
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        
        self.report({'INFO'}, f"Deleted {deleted_count} probe{'s' if deleted_count != 1 else ''}")
        return {'FINISHED'}
    
    @staticmethod 
    def reorder_indices():
        """Reorder indices after deletion to maintain continuity"""
        probes = [obj for obj in bpy.data.objects 
                 if obj.type == 'EMPTY' and 'lightprobe' in obj]
        probes.sort(key=lambda x: (x.lightprobe.probe_index, x.name))
        
        for i, probe in enumerate(probes):
            probe.lightprobe.probe_index = i

class LIGHTPROBE_OT_clear_all(Operator):
    bl_idname = "lightprobe.clear_all"
    bl_label = "Clear All Probes"
    bl_description = "Remove all light probes from the scene"
    bl_options = {'REGISTER', 'UNDO'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
    
    def execute(self, context):
        probes = [obj for obj in bpy.data.objects 
                 if obj.type == 'EMPTY' and 'lightprobe' in obj]
        
        if not probes:
            self.report({'INFO'}, "No light probes to clear")
            return {'CANCELLED'}
        
        probe_count = len(probes)
        probe_names = ";".join(probe.name for probe in probes)
        
        # Use the delete operator for consistent cleanup
        bpy.ops.lightprobe.delete(probe_names=probe_names)
        
        self.report({'INFO'}, f"Cleared {probe_count} light probe{'s' if probe_count > 1 else ''}")
        return {'FINISHED'}

class LIGHTPROBE_OT_select_from_list(Operator):
    bl_idname = "lightprobe.select_from_list"
    bl_label = "Select Light Probe"
    bl_description = "Select a light probe from the list"
    bl_options = {'REGISTER', 'UNDO'}
    
    probe_name: StringProperty()
    
    def execute(self, context):
        probe_obj = bpy.data.objects.get(self.probe_name)
        if probe_obj and 'lightprobe' in probe_obj:
            context.scene.mhs.active_lightprobe_index = probe_obj.lightprobe.probe_index
            sync_ui_to_scene(context, probe_obj)
        return {'FINISHED'}

def sync_ui_to_scene(context, probe_obj):
    """Sync UI selection to scene selection"""
    if not probe_obj:
        return
        
    # Ensure the collection containing the probe is visible and selectable
    for collection in bpy.data.collections:
        if probe_obj.name in collection.objects:
            for layer_collection in context.view_layer.layer_collection.children:
                if layer_collection.collection == collection:
                    layer_collection.hide_viewport = False
                    layer_collection.collection.hide_viewport = False
                    layer_collection.collection.hide_select = False
    
    # Deselect all objects and select the probe
    bpy.ops.object.select_all(action='DESELECT')
    probe_obj.hide_viewport = False
    probe_obj.hide_select = False
    probe_obj.select_set(True)
    context.view_layer.objects.active = probe_obj

def sync_scene_to_ui(context, probe_obj):
    """Sync scene selection to UI selection"""
    if not probe_obj or 'lightprobe' not in probe_obj:
        return
    context.scene.mhs.active_lightprobe_index = probe_obj.lightprobe.probe_index

@persistent
def handle_probe_duplication(scene):
    """Handler to detect and fix duplicated probes"""
    if not scene:
        return
        
    # Get current set of probe names
    current_probes = {obj.name for obj in bpy.data.objects 
                     if obj.type == 'EMPTY' and 'lightprobe' in obj}
    
    # Compare with our tracked names
    if not hasattr(handle_probe_duplication, "known_probes"):
        handle_probe_duplication.known_probes = current_probes
        return
        
    # Find new probes (includes duplicates)
    new_probes = current_probes - handle_probe_duplication.known_probes
    
    # Process any new probes
    for probe_name in new_probes:
        obj = bpy.data.objects[probe_name]
        if obj.type == 'EMPTY' and 'lightprobe' in obj:
            # Assign new index
            obj['lightprobe']['probe_index'] = get_next_probe_index()
            obj['lightprobe']['needs_rebake'] = True
            if 'baked_cubemap' in obj['lightprobe']:
                del obj['lightprobe']['baked_cubemap']
            obj['lightprobe']['last_location'] = obj.location
    
    # Update our tracked set
    handle_probe_duplication.known_probes = current_probes
        
# Handler functions
@persistent
def check_probe_locations(scene):
    """Handler to check for probe location changes"""
    if not scene:
        return
        
    for obj in scene.objects:
        if obj.type == 'EMPTY' and 'lightprobe' in obj:
            current_loc = Vector(obj.location)
            last_loc = Vector(obj.lightprobe.last_location)
            
            if (current_loc - last_loc).length > 0.0001:  # Small threshold
                obj.lightprobe.needs_rebake = True
                obj.lightprobe.last_location = obj.location

@persistent
def sync_probe_list(scene):
    """Keep the probe list in sync with scene probes"""
    if not scene:
        return
        
    try:
        # Get current probes in scene
        current_probes = {obj.name: obj for obj in scene.objects 
                         if obj.type == 'EMPTY' and 'lightprobe' in obj}
        
        # Remove probes that no longer exist
        i = len(scene.mhs.probe_list) - 1
        while i >= 0:
            item = scene.mhs.probe_list[i]
            if item.name not in current_probes:
                scene.mhs.probe_list.remove(i)
            i -= 1
        
        # Add new probes
        existing_names = {item.name for item in scene.mhs.probe_list}
        for name, obj in current_probes.items():
            if name not in existing_names:
                item = scene.mhs.probe_list.add()
                item.name = name
                item.object = obj
                
        # Sort the list by name
        sorted_indices = sorted(range(len(scene.mhs.probe_list)), 
                              key=lambda k: scene.mhs.probe_list[k].name)
        
        # Reorder items using a temporary list
        temp_list = [(scene.mhs.probe_list[i].name, 
                      scene.mhs.probe_list[i].object) for i in sorted_indices]
        
        for i, (name, obj) in enumerate(temp_list):
            scene.mhs.probe_list[i].name = name
            scene.mhs.probe_list[i].object = obj
            
    except ReferenceError:
        # Skip if objects have been removed
        return
    except AttributeError:
        # Skip if scene structure isn't fully initialized
        return
      
@persistent
def sync_probe_selection(scene):
    """Handler to sync viewport selection with UI list"""
    if not scene:
        return
        
    active_obj = bpy.context.active_object
    if not active_obj or active_obj.type != 'EMPTY' or 'lightprobe' not in active_obj:
        return
        
    # Get the probe's index from its properties
    probe_index = active_obj['lightprobe'].get('probe_index', -1)
    if probe_index >= 0:
        # Update the active index in the UI list
        scene.mhs.active_lightprobe_index = probe_index

def register():
    bpy.utils.register_class(LIGHTPROBE_OT_add)
    bpy.utils.register_class(LIGHTPROBE_OT_add_grid)
    bpy.utils.register_class(LIGHTPROBE_OT_bake)
    bpy.utils.register_class(LIGHTPROBE_OT_export)
    bpy.utils.register_class(LIGHTPROBE_OT_delete)
    bpy.utils.register_class(LIGHTPROBE_OT_clear_all)
    bpy.utils.register_class(LIGHTPROBE_OT_select_from_list)
    
    # Register handlers
    if check_probe_locations not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(check_probe_locations)
    if sync_probe_list not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(sync_probe_list)
    if sync_probe_selection not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(sync_probe_selection)
    if handle_probe_duplication not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(handle_probe_duplication)    
    

def unregister():
    # Remove handlers
    if check_probe_locations in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(check_probe_locations)
    if sync_probe_list in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(sync_probe_list)
    if sync_probe_selection in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(sync_probe_selection)
    if handle_probe_duplication in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(handle_probe_duplication)
    
    bpy.utils.unregister_class(LIGHTPROBE_OT_select_from_list)
    bpy.utils.unregister_class(LIGHTPROBE_OT_clear_all)
    bpy.utils.unregister_class(LIGHTPROBE_OT_delete)
    bpy.utils.unregister_class(LIGHTPROBE_OT_export)
    bpy.utils.unregister_class(LIGHTPROBE_OT_bake)
    bpy.utils.unregister_class(LIGHTPROBE_OT_add_grid)
    bpy.utils.unregister_class(LIGHTPROBE_OT_add)
    
