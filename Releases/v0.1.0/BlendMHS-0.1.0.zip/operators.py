import bpy
import shutil
from bpy.types import Operator, Menu
from bpy.props import StringProperty, BoolProperty, EnumProperty, IntProperty, FloatProperty
import os
import time
from . import functions, utils
from .visualization import force_viewport_update
import random, json, tempfile, subprocess
from .shader_factory import setup_lightmaps_for_baking
from . import cache_tracker


def _show_export_notification(message, icon_type='SUCCESS'):
    """Show a mouse-following notification for export results.

    Args:
        message: The notification message to display
        icon_type: 'SUCCESS', 'WARNING', or 'ERROR'
    """
    try:
        # Get notification preferences
        prefs = bpy.context.preferences.addons.get(__package__)
        use_tooltip = prefs and hasattr(prefs.preferences, 'use_tooltip_notification') and prefs.preferences.use_tooltip_notification
        notification_duration = prefs.preferences.notification_duration if prefs and hasattr(prefs.preferences, 'notification_duration') else 0.5
    except Exception:
        use_tooltip = True
        notification_duration = 0.5

    if not use_tooltip:
        return  # Just use the operator's self.report() which is already called

    def show_notification():
        try:
            # Find a valid 3D View context for the modal operator
            context_override = None
            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        for region in area.regions:
                            if region.type == 'WINDOW':
                                context_override = {
                                    'window': window,
                                    'screen': window.screen,
                                    'area': area,
                                    'region': region,
                                }
                                break
                        if context_override:
                            break
                if context_override:
                    break

            if context_override:
                with bpy.context.temp_override(**context_override):
                    bpy.ops.mhs.export_notification(
                        'INVOKE_DEFAULT',
                        message=message,
                        icon_type=icon_type,
                        duration=notification_duration
                    )
        except Exception as e:
            print(f"BlendMHS: Could not show export notification: {e}")
        return None

    # Schedule the notification
    bpy.app.timers.register(show_notification, first_interval=0.1)


class MHS_OT_refresh_evaluated_mesh(Operator):
    """Show evaluated mesh statistics (vertices, faces, triangles after modifiers)"""
    bl_idname = "mhs.refresh_evaluated_mesh"
    bl_label = "Evaluated Mesh Info"
    bl_description = "Show mesh statistics after all modifiers are applied"
    bl_options = {'REGISTER'}

    # Store evaluated data for the popup
    _eval_data = {}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and len(obj.modifiers) > 0

    def invoke(self, context, event):
        obj = context.active_object

        # Get evaluated mesh via depsgraph
        depsgraph = context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        eval_mesh = eval_obj.data

        if eval_mesh:
            # Calculate triangle count
            tris = sum(len(p.vertices) - 2 for p in eval_mesh.polygons)

            # Store data for the popup
            MHS_OT_refresh_evaluated_mesh._eval_data = {
                'object_name': obj.name,
                'base_verts': len(obj.data.vertices),
                'base_faces': len(obj.data.polygons),
                'base_tris': sum(len(p.vertices) - 2 for p in obj.data.polygons),
                'eval_verts': len(eval_mesh.vertices),
                'eval_faces': len(eval_mesh.polygons),
                'eval_tris': tris,
                'modifier_count': len(obj.modifiers),
                'modifiers': [mod.name for mod in obj.modifiers if mod.show_viewport],
            }

            # Also update the cached values on the object
            obj.mhs.eval_verts_cached = len(eval_mesh.vertices)
            obj.mhs.eval_faces_cached = len(eval_mesh.polygons)
            obj.mhs.eval_tris_cached = tris
            obj.mhs.eval_cache_timestamp = time.time()

            return context.window_manager.invoke_popup(self, width=350)
        else:
            self.report({'WARNING'}, "Could not evaluate mesh")
            return {'CANCELLED'}

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        data = MHS_OT_refresh_evaluated_mesh._eval_data

        if not data:
            layout.label(text="No evaluated mesh data available", icon='INFO')
            return

        # Header
        box = layout.box()
        box.label(text="Evaluated Mesh Info", icon='MESH_DATA')

        # Object name
        col = box.column(align=False)
        row = col.row()
        row.label(text="Object:")
        row.label(text=data['object_name'])

        col.separator()

        # Base mesh stats
        stats_box = layout.box()
        stats_box.label(text="Base Mesh", icon='MESH_CUBE')
        col = stats_box.column(align=False)

        row = col.row()
        row.label(text="Vertices:")
        row.label(text=f"{data['base_verts']:,}")
        row.label(text="")

        row = col.row()
        row.label(text="Faces:")
        row.label(text=f"{data['base_faces']:,}")
        row.label(text="")

        row = col.row()
        row.label(text="Triangles:")
        row.label(text=f"{data['base_tris']:,}")
        row.label(text="")

        # Evaluated mesh stats
        eval_box = layout.box()
        eval_box.label(text="After Modifiers", icon='MODIFIER')
        col = eval_box.column(align=False)

        row = col.row()
        row.label(text="Vertices:")
        row.label(text=f"{data['eval_verts']:,}")
        # Show change
        vert_diff = data['eval_verts'] - data['base_verts']
        if vert_diff > 0:
            row.label(text=f"+{vert_diff:,}", icon='TRIA_UP')
        elif vert_diff < 0:
            row.label(text=f"{vert_diff:,}", icon='TRIA_DOWN')
        else:
            row.label(text="")

        row = col.row()
        row.label(text="Faces:")
        row.label(text=f"{data['eval_faces']:,}")
        face_diff = data['eval_faces'] - data['base_faces']
        if face_diff > 0:
            row.label(text=f"+{face_diff:,}", icon='TRIA_UP')
        elif face_diff < 0:
            row.label(text=f"{face_diff:,}", icon='TRIA_DOWN')
        else:
            row.label(text="")

        row = col.row()
        row.label(text="Triangles:")
        row.label(text=f"{data['eval_tris']:,}")
        tri_diff = data['eval_tris'] - data['base_tris']
        if tri_diff > 0:
            row.label(text=f"+{tri_diff:,}", icon='TRIA_UP')
        elif tri_diff < 0:
            row.label(text=f"{tri_diff:,}", icon='TRIA_DOWN')
        else:
            row.label(text="")

        # Modifiers section
        if data['modifiers']:
            mod_box = layout.box()
            mod_box.label(text=f"Active Modifiers ({len(data['modifiers'])})", icon='PREFERENCES')
            col = mod_box.column(align=True)
            for mod_name in data['modifiers']:
                col.label(text=f"  • {mod_name}")


class MHS_OT_export_layout(Operator):
    bl_idname = "mhs.export_layout"
    bl_label = "Export Layouts"
    bl_description = "Export scene to USDA format"

    @classmethod
    def poll(cls, context):
        return context.scene is not None and context.scene.mhs.project_path != ""

    def execute(self, context):
        props = context.scene.mhs
        force_rebuild = props.force_rebuild

        with utils.ensure_object_mode(context):
            try:
                # Pass force_rebuild to layout export
                result = functions.write_layout_usda(context, force_rebuild=force_rebuild)
                if result != {'FINISHED'}:
                    return result

                # Reset animation stats since this is a layout export (not skinned mesh)
                props.last_export_animations_exported = 0
                props.last_export_animations_skipped = 0
                props.last_export_actions_count = 0

                # Show stats panel
                props.show_export_stats = True

                # Reset force rebuild toggle after use
                props.force_rebuild = False

                # Show notification
                from .notification import format_export_notification
                message, notification_type = format_export_notification(context.scene)
                _show_export_notification(message, notification_type.value)

                return {'FINISHED'}

            except Exception as e:
                self.report({'ERROR'}, str(e))
                return {'CANCELLED'}

class MHS_OT_open_export_folder(Operator):
    bl_idname = "mhs.open_export_folder"
    bl_label = "Open Project Folder"
    bl_description = "Open the project folder in your file explorer"

    def execute(self, context):
        export_path = context.scene.mhs.project_path

        if not os.path.exists(export_path):
            self.report({'ERROR'}, f"Folder does not exist: {export_path}")
            return {'CANCELLED'}

        bpy.ops.wm.path_open(filepath=export_path)
        return {'FINISHED'}

class MHS_OT_export_mesh(Operator):
    bl_idname = "mhs.export_mesh"
    bl_label = "Export USDA"
    bl_description = "Export scene to USDA format"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and len(context.selected_objects) > 0

    def execute(self, context):
        props = context.scene.mhs
        force_rebuild = props.force_rebuild

        # Reset stats and start timing for mesh export
        cache_tracker.reset_stats()
        cache_tracker.reset_session_tracking()  # Reset texture export tracking for new session
        cache_tracker.set_force_rebuild_session(force_rebuild)
        start_time = time.time()

        with utils.ensure_object_mode(context):
            project_path = context.scene.mhs.project_path
            if not project_path:
                self.report({'ERROR'}, "Project path is not set")
                return {'CANCELLED'}

            meshes_folder = os.path.join(project_path, "meshes")
            os.makedirs(meshes_folder, exist_ok=True)

            # Collect mesh objects to export
            # If an armature is selected, find and export associated meshes
            mesh_objects = []
            armatures_found = []

            for obj in context.selected_objects:
                if obj.type == 'MESH':
                    mesh_objects.append(obj)
                elif obj.type == 'ARMATURE':
                    armatures_found.append(obj)
                    # Find meshes that use this armature
                    for potential_mesh in bpy.data.objects:
                        if potential_mesh.type == 'MESH':
                            for modifier in potential_mesh.modifiers:
                                if modifier.type == 'ARMATURE' and modifier.object == obj:
                                    if potential_mesh not in mesh_objects:
                                        mesh_objects.append(potential_mesh)
                                        from .utils import debug_log, LogCategory
                                        debug_log(f"Found mesh '{potential_mesh.name}' associated with armature '{obj.name}'", LogCategory.EXPORT_MESH)
                                    break

            if armatures_found:
                self.report({'INFO'}, f"Found {len(armatures_found)} armature(s), exporting {len(mesh_objects)} associated mesh(es)")

            # Group objects by mesh data to handle instancing
            exported_meshes = {}
            mesh_instances = {}

            for obj in mesh_objects:
                mesh_data_key = functions.get_mesh_data_key(obj)

                if mesh_data_key not in exported_meshes:
                    # This is the first instance of this mesh data - use object name for file
                    file_name = f"{functions.sanitize_name(obj.name)}.usda"
                    filepath = os.path.join(meshes_folder, file_name)
                    exported_meshes[mesh_data_key] = filepath
                    mesh_instances[mesh_data_key] = []

                # Add this object to the instances list
                mesh_instances[mesh_data_key].append(obj)

            # Export unique meshes
            exported_count = 0
            for mesh_data_key, filepath in exported_meshes.items():
                instances = mesh_instances[mesh_data_key]
                representative_obj = instances[0]  # Use first instance as representative

                # Export the mesh data once using the representative object
                result = functions.write_usda(context, filepath, objects=[representative_obj], force_rebuild=force_rebuild)
                if result != {'FINISHED'}:
                    return result

                exported_count += 1

                # Log instancing information
                if len(instances) > 1:
                    mesh_names = [obj.name for obj in instances]
                    from .utils import debug_log, LogCategory
                    debug_log(f"Created single mesh file for {len(instances)} instances of '{representative_obj.data.name}': {', '.join(mesh_names)}", LogCategory.EXPORT_MESH)

            total_objects = len(mesh_objects)
            if exported_count < total_objects:
                self.report({'INFO'}, f"Exported {exported_count} unique meshes for {total_objects} selected objects (instancing applied)")
            else:
                self.report({'INFO'}, f"Exported {exported_count} objects to {meshes_folder}")

            # Finalize stats and show results
            elapsed_time = time.time() - start_time
            cache_tracker.finalize_stats(elapsed_time)

            # Reset animation stats since this is a static mesh export
            props.last_export_animations_exported = 0
            props.last_export_animations_skipped = 0
            props.last_export_actions_count = 0

            props.show_export_stats = True

            # Reset force rebuild toggle after use
            props.force_rebuild = False

            # Show notification
            from .notification import format_export_notification
            message, notification_type = format_export_notification(context.scene)
            _show_export_notification(message, notification_type.value)

            return {'FINISHED'}


class MHS_OT_lod_add(Operator):
    bl_idname = "mhs.lod_add"
    bl_label = "Add LOD"
    bl_description = "Add a new LOD to the active object"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        obj = context.active_object

        # If the list is empty, add both LOD0 and LOD1 at once for better UX
        if len(obj.mhs.lod_list) == 0:
            # Add LOD0 (base mesh)
            lod0 = obj.mhs.lod_list.add()
            lod0.distance_ratio = 0.1
            lod0.decimate_percentage = 100.0  # LOD0 is always 100% (base mesh)

            # Add LOD1
            lod1 = obj.mhs.lod_list.add()
            lod1.distance_ratio = 0.05
            lod1.decimate_percentage = 50.0

            self.report({'INFO'}, "Added LOD0 (base) and LOD1")
        else:
            # Add one LOD based on the previous one
            new_lod = obj.mhs.lod_list.add()

            prev_lod = obj.mhs.lod_list[-2]  # Get the second to last item (previous LOD)
            new_lod.distance_ratio = max(prev_lod.distance_ratio * 0.5, 0.001)
            new_lod.decimate_percentage = max(prev_lod.decimate_percentage * 0.5, 1.0)

        return {'FINISHED'}

class MHS_OT_lod_remove(Operator):
    bl_idname = "mhs.lod_remove"
    bl_label = "Remove LOD"
    bl_description = "Remove the selected LOD from the active object"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and len(context.active_object.mhs.lod_list) > 0

    def execute(self, context):
        obj = context.active_object
        obj.mhs.lod_list.remove(obj.mhs.lod_list_index)
        obj.mhs.lod_list_index = min(max(0, obj.mhs.lod_list_index - 1), len(obj.mhs.lod_list) - 1)
        return {'FINISHED'}

class MHS_OT_material_slot_move(Operator):
    bl_idname = "mhs.material_slot_move"
    bl_label = "Move Material Slot"
    bl_description = "Move the material slot up or down"
    bl_options = {'REGISTER', 'UNDO'}

    direction: EnumProperty(
        items=(
            ('UP', "Up", "Move slot up"),
            ('DOWN', "Down", "Move slot down"),
        )
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.material_slots

    def execute(self, context):
        obj = context.active_object
        if self.direction == 'UP' and obj.active_material_index > 0:
            bpy.ops.object.material_slot_move(direction='UP')
        elif self.direction == 'DOWN' and obj.active_material_index < len(obj.material_slots) - 1:
            bpy.ops.object.material_slot_move(direction='DOWN')
        return {'FINISHED'}

class MHS_OT_bake_lightmap(Operator):
    bl_idname = "mhs.bake_lightmap"
    bl_label = "Bake Lightmap"
    bl_description = "Bake lightmap for the selected group or all groups"

    bake_data_file: StringProperty(default="")
    bake_all: BoolProperty(default=False)

    def execute(self, context):
        bpy.ops.object.mode_set(mode='OBJECT')

        scene = context.scene

        # Store original render settings
        original_engine = scene.render.engine
        scene.render.engine = 'CYCLES'
        scene.cycles.samples = 128
        scene.cycles.use_denoising = True
        scene.cycles.use_adaptive_sampling = False

        groups_to_bake = scene.mhs.lightmap_groups if self.bake_all else [scene.mhs.lightmap_groups[scene.mhs.lightmap_group_index]]

        try:
            if self.bake_data_file:
                return self.bake_from_file(context)
            elif scene.mhs.lightmap_bake_mode == 'FOREGROUND':
                return self.bake_foreground(context)
            else:
                return self.bake_background(context)
        finally:
            # Restore original render settings
            scene.render.engine = original_engine

    def bake_foreground(self, context):
        scene = context.scene
        groups_to_bake = scene.mhs.lightmap_groups if self.bake_all else [scene.mhs.lightmap_groups[scene.mhs.lightmap_group_index]]

        for group in groups_to_bake:
            if not group.objects:
                continue
            self.bake_group(context, group)

        # After all baking is complete, ensure all LightmapSelector connections
        for material in bpy.data.materials:
            if not material.use_nodes:
                continue

            # Find MHS group node
            mhs_group = next((node for node in material.node_tree.nodes
                            if node.type == 'GROUP' and
                            node.node_tree and
                            node.node_tree.name.startswith("MHS")), None)

            if not mhs_group:
                continue

            # Find and connect lightmap input
            lightmap_input = next((input for input in mhs_group.inputs
                                if input.name.lower() == "_lightmap"), None)

            if not lightmap_input:
                continue

            # Find or get LightmapSelector
            lightmap_selector = material.node_tree.nodes.get("LightmapSelector")
            if lightmap_selector and not lightmap_input.is_linked:
                material.node_tree.links.new(
                    lightmap_selector.outputs["Selected Lightmap"],
                    lightmap_input
                )

        self.report({'INFO'}, f"Baked lightmaps for {'all groups' if self.bake_all else 'selected group'}")
        return {'FINISHED'}

    def cleanup_existing_image(self, context, image_name):
        """Safely remove existing image and its data"""
        existing_image = bpy.data.images.get(image_name)
        if existing_image:
            # Remove from any material nodes first
            for material in bpy.data.materials:
                if material.use_nodes:
                    for node in material.node_tree.nodes:
                        if node.type == 'TEX_IMAGE' and node.image == existing_image:
                            node.image = None

            # Now remove the image
            bpy.data.images.remove(existing_image, do_unlink=True)

    def bake_group(self, context, group_data, bake_data=None):
        """Bake all objects in a lightmap group simultaneously"""
        scene = context.scene

        # Get resolution settings
        if bake_data:
            base_resolution = int(group_data['lightmap_resolution'])
            modifier = float(bake_data['lightmap_resolution_modifier'])
            group_name = group_data['name']
        else:
            base_resolution = int(group_data.lightmap_resolution)
            modifier = float(scene.mhs.lightmap_resolution_modifier)
            group_name = group_data.name

        final_resolution = int(base_resolution * modifier)
        image_name = f"Lightmap_{group_name}"

        # Clean up any existing image
        self.cleanup_existing_image(context, image_name)

        # Create new image
        image = bpy.data.images.new(
            name=image_name,
            width=final_resolution,
            height=final_resolution,
            float_buffer=True,
            alpha=False
        )

        # Configure image settings
        image.colorspace_settings.name = 'Non-Color'
        image.use_fake_user = True

        # Process all objects in group
        objects_to_bake = []
        object_list = group_data['objects'] if bake_data else group_data.objects

        bpy.ops.object.select_all(action='DESELECT')

        # Track created nodes and connections for cleanup/restore
        temp_nodes = []
        stored_connections = []

        for obj_name in object_list:
            obj = bpy.data.objects.get(obj_name if bake_data else obj_name.name)
            if not obj or obj.type != 'MESH':
                continue

            lightmap_uv = obj.data.uv_layers.get("LightmapUV")
            if not lightmap_uv:
                continue

            obj.data.uv_layers.active = lightmap_uv

            # Setup materials for baking
            if not obj.material_slots:
                # Create a new material if none exists
                mat = bpy.data.materials.new(name=f"{obj.name}_Lightmap")
                mat.use_nodes = True
                obj.data.materials.append(mat)

            for mat_slot in obj.material_slots:
                if not mat_slot.material:
                    # Create a new material if slot is empty
                    mat = bpy.data.materials.new(name=f"{obj.name}_Lightmap")
                    mat.use_nodes = True
                    mat_slot.material = mat

                mat = mat_slot.material
                if not mat.use_nodes:
                    mat.use_nodes = True

                # Store and disconnect LightmapSelector connections
                lightmap_selector = mat.node_tree.nodes.get("LightmapSelector")
                if lightmap_selector:
                    for output in lightmap_selector.outputs:
                        for link in output.links:
                            stored_connections.append((mat, output, link.to_socket))
                            mat.node_tree.links.remove(link)

                    # Clean up any existing temp nodes
                    old_node = mat.node_tree.nodes.get("Temp_Bake_Node")
                    if old_node:
                        mat.node_tree.nodes.remove(old_node)

                    # Create temporary bake image node
                    bake_node = mat.node_tree.nodes.new('ShaderNodeTexImage')
                    bake_node.name = "Temp_Bake_Node"
                    bake_node.image = image
                    bake_node.select = True
                    mat.node_tree.nodes.active = bake_node
                    temp_nodes.append((mat, bake_node))

            objects_to_bake.append(obj)
            obj.select_set(True)

        if not objects_to_bake:
            if image:
                bpy.data.images.remove(image, do_unlink=True)
            return

        context.view_layer.objects.active = objects_to_bake[0]

        try:
            # Perform the actual bake
            bpy.ops.object.bake(
                type='DIFFUSE',
                pass_filter={'DIRECT', 'INDIRECT'},
                margin=2,
                use_clear=True
            )

            # Handle denoising if enabled
            if (bake_data and bake_data['lightmap_use_denoising']) or (not bake_data and scene.mhs.lightmap_use_denoising):
                try:
                    utils.denoise_lightmap(
                        image.name,
                        strength=bake_data['lightmap_denoise_strength'] if bake_data else scene.mhs.lightmap_denoise_strength,
                        color_strength=bake_data['lightmap_denoise_color_strength'] if bake_data else scene.mhs.lightmap_denoise_color_strength,
                        space_strength=bake_data['lightmap_denoise_space_strength'] if bake_data else scene.mhs.lightmap_denoise_space_strength
                    )
                except Exception as e:
                    print(f"Denoising failed: {str(e)}")

            # Save the result
            image.pack()

            if not bake_data:
                # Clear existing lightmap if any
                if group_data.baked_lightmap:
                    old_image = group_data.baked_lightmap
                    group_data.baked_lightmap = None
                    if old_image and old_image.name in bpy.data.images:
                        bpy.data.images.remove(old_image, do_unlink=True)

                group_data.baked_lightmap = image

            self.ensure_lightmap_connections(context, objects_to_bake)

        finally:
            # Cleanup temporary nodes
            for mat, node in temp_nodes:
                if node.name in mat.node_tree.nodes:
                    mat.node_tree.nodes.remove(node)

            # Restore LightmapSelector connections
            for mat, from_socket, to_socket in stored_connections:
                mat.node_tree.links.new(from_socket, to_socket)

    def ensure_lightmap_connections(self, context, objects_to_bake):
        """Ensure lightmap connections are properly set up after baking"""
        print("\nVerifying lightmap connections...")
        for obj in objects_to_bake:
            for slot in obj.material_slots:
                if not slot.material or not slot.material.node_tree:
                    continue

                # Find MHS group node
                mhs_group = next((node for node in slot.material.node_tree.nodes
                                if node.type == 'GROUP' and
                                node.node_tree and
                                node.node_tree.name.startswith("MHS")), None)

                if not mhs_group:
                    continue

                # Find _lightmap input
                lightmap_input = next((input for input in mhs_group.inputs
                                    if input.name.lower() == "_lightmap"), None)
                if not lightmap_input:
                    continue

                # Find or create LightmapSelector
                lightmap_selector = slot.material.node_tree.nodes.get("LightmapSelector")
                if not lightmap_selector:
                    from . import shader_factory
                    num_lightmaps = len(context.scene.mhs.lightmap_groups)
                    selector_group = shader_factory.ensure_lightmap_selector_group(num_lightmaps)
                    lightmap_selector = slot.material.node_tree.nodes.new(type='ShaderNodeGroup')
                    lightmap_selector.node_tree = selector_group
                    lightmap_selector.name = "LightmapSelector"
                    lightmap_selector.location = (-400, -1000)

                # Connect LightmapSelector to _lightmap input
                if not lightmap_input.is_linked or lightmap_input.links[0].from_node != lightmap_selector:
                    print(f"Reconnecting lightmap for {obj.name} - {slot.material.name}")
                    # Remove existing connections
                    for link in lightmap_input.links:
                        slot.material.node_tree.links.remove(link)
                    # Create new connection
                    slot.material.node_tree.links.new(
                        lightmap_selector.outputs["Selected Lightmap"],
                        lightmap_input
                    )

    def bake_from_file(self, context):
        """Handle background baking from file"""
        try:
            with open(self.bake_data_file, 'r') as file:
                bake_data = json.load(file)
        except json.JSONDecodeError as e:
            self.report({'ERROR'}, f"Failed to parse bake data: {str(e)}")
            return {'CANCELLED'}

        if bpy.data.filepath != bake_data['blend_file_path']:
            blend_file_path = bake_data['blend_file_path'].replace('\\', '/')
            bpy.ops.wm.open_mainfile(filepath=blend_file_path)

        groups_to_bake = bake_data['groups'] if bake_data['bake_all'] else [bake_data['groups'][bake_data['active_group_index']]]

        for group_data in groups_to_bake:
            self.bake_group(bpy.context, group_data, bake_data)

        # After all baking is complete, set up the lightmap connections
        all_materials = set()
        for group in groups_to_bake:
            for obj_name in group['objects']:
                obj = bpy.data.objects.get(obj_name)
                if obj and obj.type == 'MESH':
                    all_materials.update(slot.material for slot in obj.material_slots if slot.material)

        # Now set up the lightmaps with the baked images
        setup_lightmaps_for_baking(list(all_materials), len(bake_data['groups']))

        with open(os.path.join(bake_data['temp_dir'], "bake_complete.signal"), 'w') as f:
            f.write("Baking complete")

        os.unlink(self.bake_data_file)
        return {'FINISHED'}

class MHS_OT_check_bake_status(Operator):
    bl_idname = "mhs.check_bake_status"
    bl_label = "Check Bake Status"
    bl_description = "Check the status of background lightmap baking"

    temp_dir: StringProperty(default="")

    def execute(self, context):
        return self.invoke(context, None)

    def invoke(self, context, event):
        wm = context.window_manager
        self._timer = wm.event_timer_add(2.0, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'TIMER':
            if os.path.exists(os.path.join(self.temp_dir, "bake_complete.signal")):
                self.update_lightmaps(context)
                return {'FINISHED'}
        return {'PASS_THROUGH'}

    def update_material_nodes(self, material, lightmap_image):
        if material.node_tree:
            for node in material.node_tree.nodes:
                if node.type == 'TEX_IMAGE' and node.name == "Lightmap Texture":
                    node.image = lightmap_image

        # Force update of all 3D Viewports
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

class MHS_OT_add_lightmap_group(Operator):
    bl_idname = "mhs.add_lightmap_group"
    bl_label = "Add Lightmap Group"
    bl_description = "Add a new lightmap group"

    def execute(self, context):
        new_group = context.scene.mhs.lightmap_groups.add()
        new_group.name = f"LightmapGroup{len(context.scene.mhs.lightmap_groups)}"

        # Assign a random color
        new_group.color = (
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
            random.uniform(0.0, 1.0),
        )

        context.scene.mhs.lightmap_group_index = len(context.scene.mhs.lightmap_groups) - 1
        return {'FINISHED'}



class MHS_OT_remove_lightmap_group(Operator):
    bl_idname = "mhs.remove_lightmap_group"
    bl_label = "Remove Lightmap Group"
    bl_description = "Remove the selected lightmap group"

    def execute(self, context):
        context.scene.mhs.lightmap_groups.remove(context.scene.mhs.lightmap_group_index)
        context.scene.mhs.lightmap_group_index = max(0, context.scene.mhs.lightmap_group_index - 1)
        force_viewport_update()
        return {'FINISHED'}

class MHS_OT_create_lightmap_uvs(Operator):
    bl_idname = "mhs.create_lightmap_uvs"
    bl_label = "Create Lightmap UVs"
    bl_description = "Create a new UV map optimized for lightmapping using Smart UV Project"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if scene.mhs.lightmap_groups:
            group = scene.mhs.lightmap_groups[scene.mhs.lightmap_group_index]
            objects = [obj for obj in bpy.data.objects if obj.name in group.objects and obj.type == 'MESH']
        else:
            objects = [obj for obj in context.selected_objects if obj.type == 'MESH']

        if not objects:
            self.report({'WARNING'}, "No mesh objects found to create lightmap UVs")
            return {'CANCELLED'}
        else:
            bpy.ops.object.select_all(action='DESELECT')

        for obj in objects:
            try:

                context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode='OBJECT')

                # Create a new UV Map
                if "LightmapUV" not in obj.data.uv_layers:
                    obj.data.uv_layers.new(name="LightmapUV")
                obj.data.uv_layers.active_index = len(obj.data.uv_layers) - 1

                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')

                # Use Smart UV Project with our custom properties
                bpy.ops.uv.smart_project(
                    angle_limit=utils.degrees_to_radians(scene.mhs.lightmap_angle_limit),
                    margin_method="SCALED",
                    rotate_method="AXIS_ALIGNED_Y",
                    island_margin=scene.mhs.lightmap_island_margin,
                    area_weight=scene.mhs.lightmap_area_weight,
                    correct_aspect=True,
                    scale_to_bounds=False
                )

                bpy.ops.object.mode_set(mode='EDIT')

            except Exception as e:
                self.report({'ERROR'}, f"Error creating lightmap UVs for {obj.name}: {str(e)}")
                continue

            bpy.ops.object.mode_set(mode='OBJECT')

        self.report({'INFO'}, f"Lightmap UVs created for {len(objects)} objects")
        return {'FINISHED'}

class MHS_OT_add_to_lightmap_group(Operator):
    bl_idname = "mhs.add_to_lightmap_group"
    bl_label = "Add to Lightmap Group"
    bl_description = "Add selected objects to the current lightmap group"

    def execute(self, context):
        scene = context.scene
        current_group = scene.mhs.lightmap_groups[scene.mhs.lightmap_group_index]

        for obj in context.selected_objects:
            if obj.type == 'MESH':
                # Check if the object is already in another group and remove it
                for group in scene.mhs.lightmap_groups:
                    if group != current_group:
                        for item in group.objects:
                            if item.name == obj.name:
                                group.objects.remove(group.objects.find(obj.name))
                                self.report({'INFO'}, f"Removed {obj.name} from group {group.name}")
                                break

                # Add the object to the current group if it's not already there
                if obj.name not in current_group.objects:
                    item = current_group.objects.add()
                    item.name = obj.name

                    # Set the lightmap index
                    obj.mhs.lightmap_index = scene.mhs.lightmap_group_index

                    if "LightmapUV" not in obj.data.uv_layers:
                        try:
                            obj.data.uv_layers.new(name="LightmapUV")
                            self.report({'INFO'}, f"Created placeholder LightmapUV for {obj.name}")
                        except Exception as e:
                            self.report({'ERROR'}, f"Error creating LightmapUV for {obj.name}: {str(e)}")

        force_viewport_update()
        return {'FINISHED'}

class MHS_OT_remove_from_lightmap_group(Operator):
    bl_idname = "mhs.remove_from_lightmap_group"
    bl_label = "Remove from Lightmap Group"
    bl_description = "Remove selected objects from the current lightmap group"

    def execute(self, context):
        group = context.scene.mhs.lightmap_groups[context.scene.mhs.lightmap_group_index]
        for obj in context.selected_objects:
            if obj.name in group.objects:
                group.objects.remove(group.objects.find(obj.name))
                obj.mhs.lightmap_index = -1  # Reset the lightmap index
        force_viewport_update()
        return {'FINISHED'}

class MHS_OT_select_lightmap_group(Operator):
    bl_idname = "mhs.select_lightmap_group"
    bl_label = "Select Lightmap Group"
    bl_description = "Select all objects in the lightmap group"

    group_name: StringProperty()

    def execute(self, context):
        group = next((group for group in context.scene.mhs.lightmap_groups if group.name == self.group_name), None)
        if group:
            bpy.ops.object.select_all(action='DESELECT')
            active_object = None
            for obj_ref in group.objects:
                obj = bpy.data.objects.get(obj_ref.name)
                if obj:
                    obj.select_set(True)
                    active_object = obj

            if active_object:
                context.view_layer.objects.active = active_object
                self.report({'INFO'}, f"Selected {len(group.objects)} objects. Active object: {active_object.name}")
            else:
                self.report({'WARNING'}, f"Selected {len(group.objects)} objects. No valid objects to set as active.")
        else:
            self.report({'ERROR'}, f"Lightmap group '{self.group_name}' not found")

        return {'FINISHED'}

class MHS_OT_clear_empty_lightmap_groups(Operator):
    bl_idname = "mhs.clear_empty_lightmap_groups"
    bl_label = "Clear Empty Lightmap Groups"
    bl_description = "Remove all lightmap groups that contain no objects"

    def execute(self, context):
        scene = context.scene
        groups_to_remove = []

        for index, group in enumerate(scene.mhs.lightmap_groups):
            if len(group.objects) == 0:
                groups_to_remove.append(index)

        # Remove groups in reverse order to avoid index shifting issues
        for index in reversed(groups_to_remove):
            scene.mhs.lightmap_groups.remove(index)

        # Update the active index if necessary
        if scene.mhs.lightmap_group_index >= len(scene.mhs.lightmap_groups):
            scene.mhs.lightmap_group_index = max(0, len(scene.mhs.lightmap_groups) - 1)

        self.report({'INFO'}, f"Removed {len(groups_to_remove)} empty lightmap groups")
        force_viewport_update()
        return {'FINISHED'}

class MHS_OT_format_material_nodes(Operator):
    bl_idname = "mhs.format_material_nodes"
    bl_label = "Format Material Nodes"
    bl_description = "Rearrange material nodes for better readability"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.active_material

    def execute(self, context):
        obj = context.active_object
        material = obj.active_material
        if not material or not material.node_tree:
            self.report({'ERROR'}, "No active material with nodes")
            return {'CANCELLED'}

        self.format_nodes(material.node_tree)
        return {'FINISHED'}

    def format_nodes(self, node_tree):
        # Collect nodes by type
        input_nodes = []
        shader_nodes = []
        output_nodes = []
        other_nodes = []

        for node in node_tree.nodes:
            if node.type in {'TEX_IMAGE', 'TEX_COORD', 'MAPPING'}:
                input_nodes.append(node)
            elif node.type in {'GROUP'} or node.type.startswith('BSDF'):
                shader_nodes.append(node)
            elif node.type == 'OUTPUT_MATERIAL':
                output_nodes.append(node)
            else:
                other_nodes.append(node)

        # Sort nodes within their categories
        for node_list in [input_nodes, shader_nodes, other_nodes]:
            node_list.sort(key=lambda n: n.location.y, reverse=True)

        # Set initial positions
        x_offset = 0
        spacing = 300

        # Position input nodes
        for i, node in enumerate(input_nodes):
            node.location.x = x_offset
            node.location.y = -i * 240
        x_offset += spacing

        # Position shader nodes
        for i, node in enumerate(shader_nodes):
            node.location.x = x_offset
            node.location.y = -i * 240
        x_offset += spacing

        # Position other nodes
        for i, node in enumerate(other_nodes):
            node.location.x = x_offset
            node.location.y = -i * 240
        x_offset += spacing

        # Position output nodes
        for i, node in enumerate(output_nodes):
            node.location.x = x_offset
            node.location.y = -i * 240

class MHS_OT_lightmap_toggle_uv(Operator):
    bl_idname = "mhs.lightmap_toggle_uv"
    bl_label = "Toggle Lightmap UV"
    bl_description = "Toggle between default and lightmap UV for objects in group"
    bl_options = {'REGISTER', 'UNDO'}

    group_name: StringProperty()
    show_lightmap: BoolProperty()

    def execute(self, context):
        # First turn off all other groups
        for group in context.scene.mhs.lightmap_groups:
            if group.name != self.group_name and group.get("show_lightmap_uv", False):
                print(f"Turning off lightmap UV for group: {group.name}")
                self.toggle_group_uv(context, group, False)

        # Then toggle the target group
        group = next((g for g in context.scene.mhs.lightmap_groups if g.name == self.group_name), None)
        if not group:
            return {'CANCELLED'}

        print(f"\nToggling lightmap UV for group: {self.group_name}")
        self.toggle_group_uv(context, group, self.show_lightmap)

        return {'FINISHED'}

    def toggle_group_uv(self, context, group, show_lightmap):
        """Helper function to toggle UV for a specific group"""
        group_index = context.scene.mhs.lightmap_groups.find(group.name)

        # Process only objects in this specific group
        for obj_ref in group.objects:
            obj = bpy.data.objects.get(obj_ref.name)

            # Skip invalid objects
            if (not obj or
                obj.type != 'MESH' or
                not hasattr(obj.mhs, 'lightmap_index') or
                obj.mhs.lightmap_index != group_index):
                continue

            print(f"Processing {obj.name} (lightmap index: {obj.mhs.lightmap_index})")

            # Check for UV layers
            if len(obj.data.uv_layers) == 0:
                continue

            lightmap_uv = obj.data.uv_layers.get("LightmapUV")
            default_uv = obj.data.uv_layers[0]

            if not lightmap_uv:
                continue

            # Set active UV layer based on toggle state
            if show_lightmap:
                obj.data.uv_layers.active = lightmap_uv
                lightmap_uv.active_render = True
            else:
                obj.data.uv_layers.active = default_uv
                default_uv.active_render = True

            # Update material nodes
            for slot in obj.material_slots:
                if not slot.material or not slot.material.node_tree:
                    continue

                lightmap_selector = slot.material.node_tree.nodes.get("LightmapSelector")
                if not lightmap_selector or lightmap_selector.type != 'GROUP':
                    continue

                if show_lightmap:
                    lightmap_node = lightmap_selector.node_tree.nodes.get(f"Lightmap_{group_index}")
                    if lightmap_node:
                        lightmap_selector.node_tree.nodes.active = lightmap_node
                else:
                    principled_node = next((node for node in slot.material.node_tree.nodes
                                          if node.type == 'BSDF_PRINCIPLED'), None)
                    if principled_node:
                        base_color_links = principled_node.inputs['Base Color'].links
                        if base_color_links:
                            base_color_node = base_color_links[0].from_node
                            if base_color_node.type == 'TEX_IMAGE':
                                slot.material.node_tree.nodes.active = base_color_node

        # Update the group's show_lightmap_uv property without triggering the update callback
        group["show_lightmap_uv"] = show_lightmap

class MHS_OT_create_material(Operator):
    bl_idname = "mhs.create_material"
    bl_label = "Create MHS Material"
    bl_description = "Create a new material with MHS properties"
    bl_options = {'REGISTER', 'UNDO'}

    material_name: StringProperty(
        name="Material Name",
        description="Name for the new material",
        default=""
    )

    def invoke(self, context, event):
        # Pre-populate with auto-generated name
        import re
        max_num = 0
        pattern = re.compile(r'^NewMhsMat(\d+)$')
        for mat in bpy.data.materials:
            match = pattern.match(mat.name)
            if match:
                num = int(match.group(1))
                if num > max_num:
                    max_num = num

        self.material_name = f"NewMhsMat{max_num + 1}"

        # Show dialog
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "material_name")

    def execute(self, context):
        obj = context.active_object
        if not obj:
            return {'CANCELLED'}

        # Use the user-provided name, or generate one if empty
        if self.material_name:
            mat_name = self.material_name
        else:
            # Fallback to auto-generated name
            import re
            max_num = 0
            pattern = re.compile(r'^NewMhsMat(\d+)$')
            for mat in bpy.data.materials:
                match = pattern.match(mat.name)
                if match:
                    num = int(match.group(1))
                    if num > max_num:
                        max_num = num
            mat_name = f"NewMhsMat{max_num + 1}"

        mat = bpy.data.materials.new(name=mat_name)
        mat.use_nodes = True

        # Clear all default nodes (removes Principled BSDF, Material Output, etc.)
        # This gives us a clean slate for the MHS shader setup
        mat.node_tree.nodes.clear()

        # If object has no material slots, add one
        if not obj.material_slots:
            obj.data.materials.append(None)

        # Assign material to active slot or first slot
        if obj.active_material_index >= 0:
            obj.material_slots[obj.active_material_index].material = mat
        else:
            obj.material_slots[0].material = mat
            obj.active_material_index = 0

        # Set initial format
        mat.mhs.material_format = 'ISOTROPIC_USD'

        # Initial shader setup
        mat.mhs.update_shader()

        self.report({'INFO'}, f"Created new MHS material: {mat_name}")
        return {'FINISHED'}

class MHS_OT_initialize_material(Operator):
    bl_idname = "mhs.initialize_material"
    bl_label = "Initialize MHS Material"
    bl_description = "Initialize MHS material properties"
    bl_options = {'REGISTER', 'UNDO'}

    material_name: StringProperty()

    def execute(self, context):
        mat = bpy.data.materials.get(self.material_name)
        if mat:
            # Set initial format
            mat.mhs.material_format = 'ISOTROPIC_USD'

            # Initial shader setup
            mat.mhs.update_shader()

            self.report({'INFO'}, f"Initialized MHS properties for {mat.name}")
        return {'FINISHED'}


class MHS_OT_add_layout_export(Operator):
    bl_idname = "mhs.add_layout_export"
    bl_label = "Add Layout Export"
    bl_description = "Add a new layout export configuration"
    bl_options = {'REGISTER', 'UNDO'}

    layout_name: StringProperty(
        name="Layout Name",
        description="Name for the new layout",
        default=""
    )

    def invoke(self, context, event):
        # Generate default name based on existing layouts
        index = len(context.scene.mhs.layout_exports) + 1
        self.layout_name = f"layout_{index}"
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "layout_name")

    def execute(self, context):
        layout_export = context.scene.mhs.layout_exports.add()

        # Use user-provided name or generate one
        if self.layout_name:
            layout_export.name = self.layout_name
        else:
            index = len(context.scene.mhs.layout_exports)
            layout_export.name = f"layout_{index}"

        context.scene.mhs.active_layout_index = len(context.scene.mhs.layout_exports) - 1

        # If objects are selected, create a collection and add them to the new layout
        selected_objects = context.selected_objects
        if selected_objects:
            # Create new collection with same name as layout
            new_collection = bpy.data.collections.new(layout_export.name)
            context.scene.collection.children.link(new_collection)

            # Move selected objects to the new collection
            for obj in selected_objects:
                # Add to new collection
                new_collection.objects.link(obj)
                # Remove from other collections (except scene collection)
                for coll in list(obj.users_collection):  # Use list() to avoid modification during iteration
                    if coll != new_collection:
                        coll.objects.unlink(obj)

            # Add collection to the layout
            coll_ref = layout_export.collections.add()
            coll_ref.collection = new_collection

            self.report({'INFO'}, f"Created layout '{layout_export.name}' with {len(selected_objects)} objects")
        else:
            self.report({'INFO'}, f"Added layout export '{layout_export.name}'")

        # Refresh UI
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

        return {'FINISHED'}


class MHS_OT_remove_layout_export(Operator):
    bl_idname = "mhs.remove_layout_export"
    bl_label = "Remove Layout Export"
    bl_description = "Remove this layout export configuration"
    bl_options = {'REGISTER', 'UNDO'}

    layout_index: IntProperty(
        name="Layout Index",
        description="Index of the layout to remove (-1 for active layout)",
        default=-1
    )

    @classmethod
    def poll(cls, context):
        return len(context.scene.mhs.layout_exports) > 0

    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # Use layout_index if provided, otherwise use active index
        index = self.layout_index if self.layout_index >= 0 else context.scene.mhs.active_layout_index

        if index < 0 or index >= len(context.scene.mhs.layout_exports):
            self.report({'WARNING'}, "Invalid layout index")
            return {'CANCELLED'}

        layout_name = context.scene.mhs.layout_exports[index].name
        context.scene.mhs.layout_exports.remove(index)

        if context.scene.mhs.active_layout_index >= len(context.scene.mhs.layout_exports):
            context.scene.mhs.active_layout_index = max(0, len(context.scene.mhs.layout_exports) - 1)

        # Refresh UI
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

        self.report({'INFO'}, f"Removed layout: {layout_name}")
        return {'FINISHED'}


class MHS_OT_add_collection_to_layout(Operator):
    bl_idname = "mhs.add_collection_to_layout"
    bl_label = "Add/Create Collection"
    bl_description = "Add an existing collection or create a new one for this layout"
    bl_options = {'REGISTER', 'UNDO'}

    layout_index: IntProperty(
        name="Layout Index",
        description="Index of the layout to add collection to (-1 for active layout)",
        default=-1
    )

    collection_name: StringProperty(
        name="Collection",
        description="Existing collection to add to layout export (leave empty to create new)"
    )

    new_collection_name: StringProperty(
        name="New Collection Name",
        description="Name for the new collection to create",
        default=""
    )

    create_new: BoolProperty(
        name="Create New Collection",
        description="Create a new collection instead of selecting an existing one",
        default=False
    )

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return len(scene.mhs.layout_exports) > 0

    def invoke(self, context, event):
        # Pre-populate new collection name based on layout name
        layout_idx = self.layout_index if self.layout_index >= 0 else context.scene.mhs.active_layout_index
        if layout_idx < len(context.scene.mhs.layout_exports):
            layout = context.scene.mhs.layout_exports[layout_idx]
            coll_count = len(layout.collections) + 1
            self.new_collection_name = f"{layout.name}_collection_{coll_count}"
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout

        # Toggle between create new or select existing
        layout.prop(self, "create_new", text="Create New Collection", toggle=True)

        if self.create_new:
            layout.prop(self, "new_collection_name", text="Name")
        else:
            layout.prop_search(self, "collection_name", bpy.data, "collections", text="Collection")

    def get_layout_collections(self, context):
        """Get a set of all collections that belong to any layout"""
        layout_collections = set()
        for layout in context.scene.mhs.layout_exports:
            for coll_ref in layout.collections:
                if coll_ref.collection:
                    layout_collections.add(coll_ref.collection)
        return layout_collections

    def execute(self, context):
        scene = context.scene

        # Determine which layout to add to
        layout_idx = self.layout_index if self.layout_index >= 0 else scene.mhs.active_layout_index
        if layout_idx >= len(scene.mhs.layout_exports):
            self.report({'ERROR'}, "Invalid layout index")
            return {'CANCELLED'}

        target_layout = scene.mhs.layout_exports[layout_idx]

        if self.create_new:
            # Create a new collection
            if not self.new_collection_name:
                self.report({'WARNING'}, "Please enter a name for the new collection")
                return {'CANCELLED'}

            collection = bpy.data.collections.new(self.new_collection_name)
            context.scene.collection.children.link(collection)
        else:
            # Use existing collection
            if not self.collection_name:
                self.report({'WARNING'}, "No collection selected")
                return {'CANCELLED'}

            collection = bpy.data.collections.get(self.collection_name)
            if not collection:
                self.report({'ERROR'}, f"Collection '{self.collection_name}' not found")
                return {'CANCELLED'}

        # Check if collection already in this layout
        for coll_ref in target_layout.collections:
            if coll_ref.collection == collection:
                self.report({'WARNING'}, f"Collection '{collection.name}' already in layout '{target_layout.name}'")
                return {'CANCELLED'}

        # Add collection to layout
        coll_ref = target_layout.collections.add()
        coll_ref.collection = collection

        # Add selected objects to the collection
        selected_objects = context.selected_objects
        added_count = 0

        if selected_objects:
            # Get all collections that belong to layouts (to enforce exclusivity)
            layout_collections = self.get_layout_collections(context)

            for obj in selected_objects:
                # Remove from ALL other collections (object can only be in one layout)
                for coll in list(obj.users_collection):
                    if coll != collection:
                        coll.objects.unlink(obj)

                # Add to target collection if not already there
                if obj.name not in collection.objects:
                    collection.objects.link(obj)
                    added_count += 1

        # Refresh UI
        for area in context.screen.areas:
            area.tag_redraw()

        if added_count > 0:
            self.report({'INFO'}, f"Added collection '{collection.name}' to layout '{target_layout.name}' with {added_count} object(s)")
        else:
            self.report({'INFO'}, f"Added collection '{collection.name}' to layout '{target_layout.name}'")
        return {'FINISHED'}


class MHS_OT_remove_collection_from_layout(Operator):
    bl_idname = "mhs.remove_collection_from_layout"
    bl_label = "Remove Collection"
    bl_description = "Remove the selected collection from this layout export"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        scene = context.scene
        if len(scene.mhs.layout_exports) == 0:
            return False
        active_layout = scene.mhs.layout_exports[scene.mhs.active_layout_index]
        return len(active_layout.collections) > 0

    def execute(self, context):
        active_layout = context.scene.mhs.layout_exports[context.scene.mhs.active_layout_index]
        index = active_layout.active_collection_index

        coll_name = active_layout.collections[index].collection.name if active_layout.collections[index].collection else "Unknown"
        active_layout.collections.remove(index)

        if active_layout.active_collection_index >= len(active_layout.collections):
            active_layout.active_collection_index = len(active_layout.collections) - 1

        # Refresh UI
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

        self.report({'INFO'}, f"Removed collection '{coll_name}'")
        return {'FINISHED'}


class MHS_OT_export_single_layout(Operator):
    bl_idname = "mhs.export_single_layout"
    bl_label = "Export Single Layout"
    bl_description = "Export only the selected layout configuration"
    bl_options = {'REGISTER'}

    layout_index: IntProperty(
        name="Layout Index",
        description="Index of the layout to export",
        default=-1
    )

    @classmethod
    def poll(cls, context):
        scene = context.scene
        # Allow if there are any layouts - specific layout validation happens in execute
        return len(scene.mhs.layout_exports) > 0

    def execute(self, context):
        # Use layout_index if provided, otherwise use active layout
        index = self.layout_index if self.layout_index >= 0 else context.scene.mhs.active_layout_index

        if index >= len(context.scene.mhs.layout_exports):
            self.report({'ERROR'}, "Invalid layout index")
            return {'CANCELLED'}

        layout_config = context.scene.mhs.layout_exports[index]

        try:
            result = functions.write_layout_usda_single(context, layout_config)
            if result == {'FINISHED'}:
                self.report({'INFO'}, f"Successfully exported layout '{layout_config.name}.usda'")
                # Show mouse-following notification
                from .notification import format_export_notification
                message, notification_type = format_export_notification(context.scene)
                _show_export_notification(message, notification_type.value)
            return result
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {str(e)}")
            _show_export_notification(f"Export failed: {str(e)}", 'ERROR')
            return {'CANCELLED'}


class MHS_OT_toggle_layout_visibility(Operator):
    """Toggle visibility of all collections in the selected layout"""
    bl_idname = "mhs.toggle_layout_visibility"
    bl_label = "Toggle Layout Visibility"
    bl_description = "Toggle visibility of all collections in this layout"
    bl_options = {'REGISTER', 'UNDO'}

    layout_index: IntProperty(
        name="Layout Index",
        description="Index of the layout to toggle visibility for",
        default=-1
    )

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return len(scene.mhs.layout_exports) > 0

    def execute(self, context):
        scene = context.scene
        index = self.layout_index if self.layout_index >= 0 else scene.mhs.active_layout_index

        if index >= len(scene.mhs.layout_exports):
            self.report({'ERROR'}, "Invalid layout index")
            return {'CANCELLED'}

        layout_config = scene.mhs.layout_exports[index]

        if len(layout_config.collections) == 0:
            self.report({'WARNING'}, f"Layout '{layout_config.name}' has no collections")
            return {'CANCELLED'}

        # Build a map of collection name to layer_collection for fast lookup
        layer_coll_map = {}
        self._build_layer_collection_map(context.view_layer.layer_collection, layer_coll_map)

        # Determine target visibility by checking if any collection is currently visible
        any_visible = False
        for coll_ref in layout_config.collections:
            if coll_ref.collection:
                layer_coll = layer_coll_map.get(coll_ref.collection.name)
                if layer_coll and not layer_coll.hide_viewport:
                    any_visible = True
                    break

        # Toggle: if any are visible, hide all; otherwise show all
        new_hide_state = any_visible  # True = hide, False = show

        # Apply visibility to all collections in this layout (and their children)
        toggled_count = 0
        for coll_ref in layout_config.collections:
            if coll_ref.collection:
                self._set_layer_collection_visibility(coll_ref.collection, layer_coll_map, new_hide_state)
                toggled_count += 1

        action = "Hiding" if new_hide_state else "Showing"
        self.report({'INFO'}, f"{action} {toggled_count} collection(s) in layout '{layout_config.name}'")
        return {'FINISHED'}

    def _build_layer_collection_map(self, layer_collection, result_map):
        """Recursively build a map of collection name -> layer_collection"""
        result_map[layer_collection.name] = layer_collection
        for child in layer_collection.children:
            self._build_layer_collection_map(child, result_map)

    def _set_layer_collection_visibility(self, collection, layer_coll_map, hide):
        """Set visibility for a collection via its layer_collection (eye icon in outliner)"""
        layer_coll = layer_coll_map.get(collection.name)
        if layer_coll:
            layer_coll.hide_viewport = hide

        # Also set visibility for child collections
        for child in collection.children:
            self._set_layer_collection_visibility(child, layer_coll_map, hide)


class MHS_OT_solo_layout_visibility(Operator):
    """Solo visibility for the selected layout - hide all other collections in the scene"""
    bl_idname = "mhs.solo_layout_visibility"
    bl_label = "Solo Layout Visibility"
    bl_description = "Show only this layout's collections and hide ALL other collections in the scene. Click again to restore previous visibility."
    bl_options = {'REGISTER', 'UNDO'}

    layout_index: IntProperty(
        name="Layout Index",
        description="Index of the layout to solo",
        default=-1
    )

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return len(scene.mhs.layout_exports) > 0

    def execute(self, context):
        import json

        scene = context.scene
        index = self.layout_index if self.layout_index >= 0 else scene.mhs.active_layout_index

        if index >= len(scene.mhs.layout_exports):
            self.report({'ERROR'}, "Invalid layout index")
            return {'CANCELLED'}

        target_layout = scene.mhs.layout_exports[index]

        # Check if this layout is already soloed - if so, unsolo (restore previous state)
        if scene.mhs.soloed_layout_index == index:
            return self._unsolo(context, scene, target_layout)

        # If a different layout is soloed, unsolo it first without restoring
        # (we'll store fresh visibility state)
        if scene.mhs.soloed_layout_index >= 0:
            scene.mhs.soloed_layout_index = -1
            scene.mhs.solo_previous_visibility = ""

        if len(target_layout.collections) == 0:
            self.report({'WARNING'}, f"Layout '{target_layout.name}' has no collections")
            return {'CANCELLED'}

        # Build a map of collection name to layer_collection for fast lookup
        layer_coll_map = {}
        self._build_layer_collection_map(context.view_layer.layer_collection, layer_coll_map)

        # Store current visibility state of ALL layer collections before making changes
        visibility_state = {}
        for coll_name, layer_coll in layer_coll_map.items():
            visibility_state[coll_name] = {
                'hide_viewport': layer_coll.hide_viewport,
                'exclude': layer_coll.exclude
            }

        # Store as JSON string
        scene.mhs.solo_previous_visibility = json.dumps(visibility_state)
        scene.mhs.soloed_layout_index = index

        # Build set of collections in the target layout (including children)
        target_collection_names = set()
        for coll_ref in target_layout.collections:
            if coll_ref.collection:
                self._collect_all_collection_names(coll_ref.collection, target_collection_names)

        # Hide ALL layer collections in the scene
        hidden_count = 0
        for coll_name, layer_coll in layer_coll_map.items():
            if coll_name not in target_collection_names:
                layer_coll.hide_viewport = True
                hidden_count += 1

        # Show all collections in the target layout (and their children)
        # Also enable (un-exclude) them if they were disabled
        shown_count = 0
        for coll_ref in target_layout.collections:
            if coll_ref.collection:
                self._set_layer_collection_visibility(coll_ref.collection, layer_coll_map, hide=False, enable=True)
                shown_count += 1

        self.report({'INFO'}, f"Solo: showing {shown_count} collection(s) in '{target_layout.name}', hiding {hidden_count} other collection(s)")
        return {'FINISHED'}

    def _unsolo(self, context, scene, target_layout):
        """Restore previous visibility state and clear solo"""
        import json

        restored_count = 0

        # Build layer collection map
        layer_coll_map = {}
        self._build_layer_collection_map(context.view_layer.layer_collection, layer_coll_map)

        # Restore previous visibility state if we have it
        if scene.mhs.solo_previous_visibility:
            try:
                visibility_state = json.loads(scene.mhs.solo_previous_visibility)

                for coll_name, layer_coll in layer_coll_map.items():
                    if coll_name in visibility_state:
                        state = visibility_state[coll_name]
                        layer_coll.exclude = state.get('exclude', False)
                        layer_coll.hide_viewport = state.get('hide_viewport', False)
                        restored_count += 1

            except json.JSONDecodeError:
                # If JSON is corrupted, just show all collections
                for coll_name, layer_coll in layer_coll_map.items():
                    layer_coll.hide_viewport = False
                    restored_count += 1

        # Clear solo state
        scene.mhs.soloed_layout_index = -1
        scene.mhs.solo_previous_visibility = ""

        self.report({'INFO'}, f"Unsolo: restored visibility for {restored_count} collection(s)")
        return {'FINISHED'}

    def _build_layer_collection_map(self, layer_collection, result_map):
        """Recursively build a map of collection name -> layer_collection"""
        result_map[layer_collection.name] = layer_collection
        for child in layer_collection.children:
            self._build_layer_collection_map(child, result_map)

    def _collect_all_collection_names(self, collection, name_set):
        """Recursively collect collection names"""
        name_set.add(collection.name)
        for child in collection.children:
            self._collect_all_collection_names(child, name_set)

    def _set_layer_collection_visibility(self, collection, layer_coll_map, hide, enable=False):
        """Set visibility for a collection via its layer_collection.

        Args:
            collection: The bpy.types.Collection to modify
            layer_coll_map: Dict mapping collection names to layer collections
            hide: Whether to hide the collection in viewport
            enable: If True, also enable (un-exclude) the collection if it was disabled
        """
        layer_coll = layer_coll_map.get(collection.name)
        if layer_coll:
            if enable and layer_coll.exclude:
                layer_coll.exclude = False
                # Also enable parent collections up the hierarchy
                self._enable_parent_layer_collections(layer_coll, layer_coll_map)
            layer_coll.hide_viewport = hide

        for child in collection.children:
            self._set_layer_collection_visibility(child, layer_coll_map, hide, enable)

    def _enable_parent_layer_collections(self, layer_coll, layer_coll_map):
        """Recursively enable parent layer collections if they are excluded."""
        for name, lc in layer_coll_map.items():
            for child in lc.children:
                if child.name == layer_coll.name:
                    if lc.exclude:
                        lc.exclude = False
                    self._enable_parent_layer_collections(lc, layer_coll_map)
                    return


class MHS_OT_toggle_animated_object_visibility(Operator):
    """Toggle visibility of the mesh and armature for this animated object"""
    bl_idname = "mhs.toggle_animated_object_visibility"
    bl_label = "Toggle Animated Object Visibility"
    bl_description = "Toggle visibility of the mesh and armature for this animated object"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(
        name="Index",
        description="Index of the animated object in the list",
        default=-1
    )

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return len(scene.mhs.animated_objects) > 0

    def execute(self, context):
        scene = context.scene
        index = self.index if self.index >= 0 else scene.mhs.active_animated_object_index

        if index < 0 or index >= len(scene.mhs.animated_objects):
            self.report({'ERROR'}, "Invalid animated object index")
            return {'CANCELLED'}

        item = scene.mhs.animated_objects[index]

        if not item.mesh_object and not item.armature_object:
            self.report({'WARNING'}, "No objects found for this entry")
            return {'CANCELLED'}

        # Determine current visibility - if either is visible, we'll hide both
        any_visible = False
        if item.mesh_object and not item.mesh_object.hide_viewport:
            any_visible = True
        if item.armature_object and not item.armature_object.hide_viewport:
            any_visible = True

        # Toggle: if any visible, hide all; otherwise show all
        new_hide_state = any_visible

        # Apply visibility
        if item.mesh_object:
            item.mesh_object.hide_viewport = new_hide_state
        if item.armature_object:
            item.armature_object.hide_viewport = new_hide_state

        action = "Hidden" if new_hide_state else "Shown"
        mesh_name = item.mesh_object.name if item.mesh_object else "N/A"
        self.report({'INFO'}, f"{action}: {mesh_name}")
        return {'FINISHED'}


class MHS_OT_solo_animated_object_visibility(Operator):
    """Solo visibility for the animated object - hide all other animated objects"""
    bl_idname = "mhs.solo_animated_object_visibility"
    bl_label = "Solo Animated Object Visibility"
    bl_description = "Show only this animated object and hide all others. Click again to restore previous visibility."
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty(
        name="Index",
        description="Index of the animated object to solo",
        default=-1
    )

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return len(scene.mhs.animated_objects) > 0

    def execute(self, context):
        import json

        scene = context.scene
        index = self.index if self.index >= 0 else scene.mhs.active_animated_object_index

        if index < 0 or index >= len(scene.mhs.animated_objects):
            self.report({'ERROR'}, "Invalid animated object index")
            return {'CANCELLED'}

        target_item = scene.mhs.animated_objects[index]

        # Check if this item is already soloed - if so, unsolo (restore previous state)
        if scene.mhs.soloed_animated_object_index == index:
            return self._unsolo(context, scene, target_item)

        # Select this row in the list
        scene.mhs.active_animated_object_index = index

        # If a different item is soloed, unsolo it first without restoring
        if scene.mhs.soloed_animated_object_index >= 0:
            scene.mhs.soloed_animated_object_index = -1
            scene.mhs.animated_object_solo_previous_visibility = ""

        # Build layer collection map for enabling excluded collections
        layer_coll_map = {}
        self._build_layer_collection_map(context.view_layer.layer_collection, layer_coll_map)

        # Store current visibility state of all animated objects before making changes
        # Also store collection exclude states for the target objects' collections
        visibility_state = {}
        collection_exclude_state = {}

        for i, item in enumerate(scene.mhs.animated_objects):
            mesh_hidden = item.mesh_object.hide_viewport if item.mesh_object else True
            armature_hidden = item.armature_object.hide_viewport if item.armature_object else True
            visibility_state[str(i)] = {
                'mesh_hidden': mesh_hidden,
                'armature_hidden': armature_hidden
            }

        # Store exclude AND hide_viewport state for all collections containing the target objects
        # This matches the layout solo implementation which stores both states
        target_objects = []
        if target_item.mesh_object:
            target_objects.append(target_item.mesh_object)
        if target_item.armature_object:
            target_objects.append(target_item.armature_object)

        for obj in target_objects:
            for coll in obj.users_collection:
                if coll.name in layer_coll_map:
                    layer_coll = layer_coll_map[coll.name]
                    if coll.name not in collection_exclude_state:
                        collection_exclude_state[coll.name] = {
                            'exclude': layer_coll.exclude,
                            'hide_viewport': layer_coll.hide_viewport
                        }

        # Store as JSON string (combine both states)
        combined_state = {
            'visibility': visibility_state,
            'collection_exclude': collection_exclude_state
        }
        scene.mhs.animated_object_solo_previous_visibility = json.dumps(combined_state)
        scene.mhs.soloed_animated_object_index = index

        # Enable (un-exclude) any collections containing the target objects
        for obj in target_objects:
            self._enable_object_collections(obj, layer_coll_map)

        # Hide all animated objects except the target
        hidden_count = 0
        for i, item in enumerate(scene.mhs.animated_objects):
            if i == index:
                # Show the target
                if item.mesh_object:
                    item.mesh_object.hide_viewport = False
                if item.armature_object:
                    item.armature_object.hide_viewport = False
            else:
                # Hide others
                if item.mesh_object:
                    item.mesh_object.hide_viewport = True
                if item.armature_object:
                    item.armature_object.hide_viewport = True
                hidden_count += 1

        mesh_name = target_item.mesh_object.name if target_item.mesh_object else "N/A"
        self.report({'INFO'}, f"Solo: showing '{mesh_name}', hiding {hidden_count} other animated object(s)")
        return {'FINISHED'}

    def _unsolo(self, context, scene, target_item):
        """Restore previous visibility state and clear solo"""
        import json

        restored_count = 0

        # Build layer collection map for restoring collection exclude state
        layer_coll_map = {}
        self._build_layer_collection_map(context.view_layer.layer_collection, layer_coll_map)

        # Restore previous visibility state if we have it
        if scene.mhs.animated_object_solo_previous_visibility:
            try:
                saved_state = json.loads(scene.mhs.animated_object_solo_previous_visibility)

                # Handle both old format (just visibility) and new format (combined)
                if 'visibility' in saved_state:
                    visibility_state = saved_state['visibility']
                    collection_exclude_state = saved_state.get('collection_exclude', {})
                else:
                    # Old format - backwards compatibility
                    visibility_state = saved_state
                    collection_exclude_state = {}

                for i, item in enumerate(scene.mhs.animated_objects):
                    str_i = str(i)
                    if str_i in visibility_state:
                        state = visibility_state[str_i]
                        if item.mesh_object:
                            item.mesh_object.hide_viewport = state.get('mesh_hidden', False)
                        if item.armature_object:
                            item.armature_object.hide_viewport = state.get('armature_hidden', False)
                        restored_count += 1

                # Restore collection exclude AND hide_viewport states
                for coll_name, coll_state in collection_exclude_state.items():
                    if coll_name in layer_coll_map:
                        layer_coll = layer_coll_map[coll_name]
                        # Handle both old format (bool) and new format (dict)
                        if isinstance(coll_state, dict):
                            layer_coll.exclude = coll_state.get('exclude', False)
                            layer_coll.hide_viewport = coll_state.get('hide_viewport', False)
                        else:
                            # Old format - backwards compatibility (just exclude bool)
                            layer_coll.exclude = coll_state

            except json.JSONDecodeError:
                # If JSON is corrupted, just show all objects
                for item in scene.mhs.animated_objects:
                    if item.mesh_object:
                        item.mesh_object.hide_viewport = False
                    if item.armature_object:
                        item.armature_object.hide_viewport = False
                    restored_count += 1

        # Clear solo state
        scene.mhs.soloed_animated_object_index = -1
        scene.mhs.animated_object_solo_previous_visibility = ""

        self.report({'INFO'}, f"Unsolo: restored visibility for {restored_count} animated object(s)")
        return {'FINISHED'}

    def _build_layer_collection_map(self, layer_collection, result_map):
        """Recursively build a map of collection name -> layer_collection"""
        result_map[layer_collection.name] = layer_collection
        for child in layer_collection.children:
            self._build_layer_collection_map(child, result_map)

    def _enable_object_collections(self, obj, layer_coll_map):
        """Enable (un-exclude) all collections containing the given object and their parents."""
        if not obj:
            return

        for coll in obj.users_collection:
            if coll.name in layer_coll_map:
                layer_coll = layer_coll_map[coll.name]
                if layer_coll.exclude:
                    layer_coll.exclude = False
                # Also enable parent collections up the hierarchy
                self._enable_parent_collections(layer_coll, layer_coll_map)

    def _enable_parent_collections(self, layer_coll, layer_coll_map):
        """Recursively enable parent collections if they are excluded."""
        # Find the parent layer collection by searching through all collections
        for name, lc in layer_coll_map.items():
            for child in lc.children:
                if child.name == layer_coll.name:
                    if lc.exclude:
                        lc.exclude = False
                    self._enable_parent_collections(lc, layer_coll_map)
                    return


class MHS_OT_clear_cache(Operator):
    """Clear the export cache to force full rebuild on next export."""
    bl_idname = "mhs.clear_cache"
    bl_label = "Clear Export Cache"
    bl_description = "Clear the export cache to force full rebuild on next export"
    bl_options = {'REGISTER'}

    def execute(self, context):
        cache_tracker.get_cache().invalidate_all()
        self.report({'INFO'}, "Export cache cleared - all files will be re-exported")
        return {'FINISHED'}


class MHS_OT_toggle_force_rebuild(Operator):
    """Toggle force rebuild mode to ignore cache on next export."""
    bl_idname = "mhs.toggle_force_rebuild"
    bl_label = "Force Rebuild (ignore cache)"
    bl_description = "Toggle force rebuild mode - when enabled, the next export will ignore the cache and re-export all files"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        scene.mhs.force_rebuild = not scene.mhs.force_rebuild
        if scene.mhs.force_rebuild:
            self.report({'INFO'}, "Force rebuild enabled - next export will ignore cache")
        else:
            self.report({'INFO'}, "Force rebuild disabled - cache will be used")
        return {'FINISHED'}


class MHS_OT_show_export_results(Operator):
    """Show detailed export results in a popup dialog"""
    bl_idname = "mhs.show_export_results"
    bl_label = "Export Results"
    bl_description = "Show detailed export statistics from the last export"
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=400)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        if scene.mhs.last_export_total == 0:
            layout.label(text="No export data available", icon='INFO')
            return

        # Read stats from scene properties
        stats = {
            'exported': scene.mhs.last_export_exported,
            'skipped': scene.mhs.last_export_skipped,
            'total': scene.mhs.last_export_total,
            'time_saved': scene.mhs.last_export_time_saved,
            'total_time': scene.mhs.last_export_total_time,
            'layouts': {
                'exported': scene.mhs.last_export_layouts_exported,
                'skipped': scene.mhs.last_export_layouts_skipped
            },
            'meshes': {
                'exported': scene.mhs.last_export_meshes_exported,
                'skipped': scene.mhs.last_export_meshes_skipped
            },
            'materials': {
                'exported': scene.mhs.last_export_materials_exported,
                'skipped': scene.mhs.last_export_materials_skipped
            },
            'textures': {
                'exported': scene.mhs.last_export_textures_exported,
                'skipped': scene.mhs.last_export_textures_skipped
            },
            'animations': {
                'exported': scene.mhs.last_export_animations_exported,
                'skipped': scene.mhs.last_export_animations_skipped
            }
        }

        box = layout.box()
        box.label(text="BlendMHS Export Results", icon='CHECKMARK')

        # Summary stats
        col = box.column(align=False)

        row = col.row()
        row.label(text="Exported:")
        row.label(text=f"{stats['exported']}")
        row.label(text="")

        row = col.row()
        row.label(text="Cache Hits:")
        row.label(text=f"{stats['skipped']}")
        row.label(text="")

        row = col.row()
        row.label(text="Time Saved:")
        row.label(text=f"~{stats['time_saved']:.1f}s")
        row.label(text="")

        row = col.row()
        row.label(text="Total Time:")
        row.label(text=f"{stats['total_time']:.2f}s")
        row.label(text="")

        # Cache hit rate
        if stats['total'] > 0:
            skip_pct = (stats['skipped'] / stats['total']) * 100
            row = col.row()
            row.label(text="Cache Hit Rate:")
            row.label(text=f"{skip_pct:.0f}%")
            row.label(text="")

        col.separator()

        # Breakdown by type
        breakdown_box = layout.box()
        breakdown_box.label(text="Breakdown by Type", icon='LINENUMBERS_ON')

        col = breakdown_box.column(align=False)

        row = col.row()
        row.label(text="Layouts:", icon='SCENE_DATA')
        row.label(text=f"{stats['layouts']['exported']} exported")
        row.label(text=f"{stats['layouts']['skipped']} cached")

        row = col.row()
        row.label(text="Meshes:", icon='MESH_DATA')
        row.label(text=f"{stats['meshes']['exported']} exported")
        row.label(text=f"{stats['meshes']['skipped']} cached")

        row = col.row()
        row.label(text="Skinned Meshes:", icon='ARMATURE_DATA')
        if stats['animations']['exported'] == 0 and stats['animations']['skipped'] == 0:
            row.label(text="N/A")
            row.label(text="")
        else:
            row.label(text=f"{stats['animations']['exported']} exported")
            row.label(text=f"{stats['animations']['skipped']} cached")

            # Show actions count on separate row
            actions_count = scene.mhs.last_export_actions_count
            row = col.row()
            row.label(text="Actions:", icon='ACTION')
            if stats['animations']['exported'] > 0 and actions_count > 0:
                # Skinned meshes were actually exported, so actions were exported
                row.label(text=f"{actions_count} exported")
                row.label(text="")
            else:
                # Skinned meshes were cached, so actions weren't re-exported
                row.label(text="N/A")
                row.label(text="(meshes cached)")

        row = col.row()
        row.label(text="Materials:", icon='MATERIAL')
        if stats['materials']['exported'] == 0 and stats['materials']['skipped'] == 0:
            row.label(text="N/A")
            row.label(text="(meshes cached)")
        else:
            row.label(text=f"{stats['materials']['exported']} exported")
            row.label(text=f"{stats['materials']['skipped']} cached")

        row = col.row()
        row.label(text="Textures:", icon='TEXTURE')
        if stats['textures']['exported'] == 0 and stats['textures']['skipped'] == 0:
            row.label(text="N/A")
            row.label(text="(materials cached)")
        else:
            row.label(text=f"{stats['textures']['exported']} exported")
            row.label(text=f"{stats['textures']['skipped']} cached")

    def execute(self, context):
        return {'FINISHED'}


class MHS_OT_export_notification(Operator):
    """Show a mouse-following notification for export results"""
    bl_idname = "mhs.export_notification"
    bl_label = "Export Notification"
    bl_description = "Display a compact notification near the mouse cursor"
    bl_options = {'REGISTER'}

    message: StringProperty(
        name="Message",
        description="The notification text to display",
        default="Export complete"
    )
    icon_type: EnumProperty(
        name="Icon Type",
        description="Type of icon/color to show",
        items=[
            ('SUCCESS', "Success", "Green checkmark"),
            ('WARNING', "Warning", "Yellow warning"),
            ('ERROR', "Error", "Red error"),
        ],
        default='SUCCESS'
    )
    duration: FloatProperty(
        name="Duration",
        description="How long to display the notification (seconds)",
        default=3.0,
        min=0.5,
        max=10.0
    )
    fade_duration: FloatProperty(
        name="Fade Duration",
        description="How long the fade-out takes (seconds)",
        default=0.5,
        min=0.1,
        max=2.0
    )

    # Instance variables for modal state
    _timer = None
    _handle = None
    _state = None

    def invoke(self, context, event):
        from .notification import NotificationState, NotificationType

        # Capture initial mouse position
        mouse_x = event.mouse_region_x
        mouse_y = event.mouse_region_y

        # If mouse position is invalid (0,0 or negative), use a sensible default
        # This happens when invoked from a timer with context override
        if mouse_x <= 0 and mouse_y <= 0:
            # Use center-top of the region as default position
            if context.region:
                mouse_x = context.region.width // 2
                mouse_y = context.region.height - 100
            else:
                mouse_x = 400
                mouse_y = 300

        self.HUD_x = mouse_x
        self.HUD_y = mouse_y

        # Debug logging
        print(f"BlendMHS: Notification invoked at position ({self.HUD_x}, {self.HUD_y})")
        print(f"BlendMHS: Message: {self.message}")

        # Map string to NotificationType enum
        type_map = {
            'SUCCESS': NotificationType.SUCCESS,
            'WARNING': NotificationType.WARNING,
            'ERROR': NotificationType.ERROR,
        }
        notification_type = type_map.get(self.icon_type, NotificationType.SUCCESS)

        # Initialize notification state
        self._state = NotificationState(
            message=self.message,
            notification_type=notification_type,
            start_time=time.time(),
            duration=self.duration,
            fade_duration=self.fade_duration,
            last_mouse_pos=(self.HUD_x, self.HUD_y)
        )

        # Store context reference for draw handler
        self._context = context

        # Register draw handler for 3D view
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_HUD, (context,), 'WINDOW', 'POST_PIXEL'
        )

        # Register timer for updates
        self._timer = context.window_manager.event_timer_add(0.033, window=context.window)

        # Add modal handler
        context.window_manager.modal_handler_add(self)

        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        # Check if notification is finished
        if self._state and self._state.is_finished:
            self.finish(context)
            return {'FINISHED'}

        # Handle mouse movement - update HUD position
        if event.type == 'MOUSEMOVE':
            self.HUD_x = event.mouse_region_x
            self.HUD_y = event.mouse_region_y
            if self._state:
                self._state.last_mouse_pos = (self.HUD_x, self.HUD_y)

        # Handle timer - trigger redraw
        if event.type == 'TIMER':
            # Tag all 3D views for redraw
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        # Pass through navigation events (allow viewport interaction)
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE',
                          'NUMPAD_1', 'NUMPAD_2', 'NUMPAD_3', 'NUMPAD_4',
                          'NUMPAD_5', 'NUMPAD_6', 'NUMPAD_7', 'NUMPAD_8', 'NUMPAD_9'}:
            return {'PASS_THROUGH'}

        # Allow all other events to pass through
        return {'PASS_THROUGH'}

    def draw_HUD(self, context):
        """Draw the notification HUD near the mouse cursor."""
        from .notification import (
            draw_notification_text,
            draw_notification_background,
            get_ui_scale
        )

        if not self._state:
            return

        alpha = self._state.alpha
        if alpha <= 0:
            return

        # Get UI scale
        ui_scale = get_ui_scale(context)

        # Calculate position (offset from cursor)
        offset_x = int(20 * ui_scale)
        offset_y = int(-30 * ui_scale)
        x = self.HUD_x + offset_x
        y = self.HUD_y + offset_y

        # Build the display text with icon
        icon = self._state.icon
        display_text = f"{icon}  {self._state.message}"

        # Calculate text dimensions for background
        font_id = 0
        font_size = int(14 * ui_scale)

        import blf
        blf.size(font_id, font_size)
        text_width, text_height = blf.dimensions(font_id, display_text)

        # Draw background
        draw_notification_background(
            x=x,
            y=y - int(4 * ui_scale),
            width=int(text_width),
            height=int(text_height + 8 * ui_scale),
            alpha=alpha,
            padding=int(10 * ui_scale)
        )

        # Draw the icon in its color
        icon_color = self._state.color
        icon_text = f"{icon}  "
        draw_notification_text(
            text=icon_text,
            x=x,
            y=y,
            color=icon_color,
            alpha=alpha,
            size=14,
            shadow=True,
            context=context
        )

        # Calculate icon width for message offset
        blf.size(font_id, font_size)
        icon_width, _ = blf.dimensions(font_id, icon_text)

        # Draw the message in white
        draw_notification_text(
            text=self._state.message,
            x=x + int(icon_width),
            y=y,
            color=(1.0, 1.0, 1.0),
            alpha=alpha,
            size=14,
            shadow=True,
            context=context
        )

    def finish(self, context):
        """Clean up the modal operator."""
        # Remove draw handler
        if self._handle:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            self._handle = None

        # Remove timer
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None

        # Force redraw to clear notification
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

    def execute(self, context):
        return {'FINISHED'}


class MHS_OT_purge_project(Operator):
    """Delete all addon-generated files from project folder"""
    bl_idname = "mhs.purge_project"
    bl_label = "Purge Project Files"
    bl_description = "Delete all exported files from the project folder (layouts, meshes, animation, materials, textures, cache)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.mhs.project_path != ""

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        import stat

        scene = context.scene
        project_path = scene.mhs.project_path

        if not project_path or not os.path.exists(project_path):
            self.report({'ERROR'}, "Project path does not exist")
            return {'CANCELLED'}

        folders_to_delete = [
            scene.mhs.layouts_folder,
            scene.mhs.meshes_folder,
            scene.mhs.animation_folder,
            scene.mhs.materials_folder,
            scene.mhs.textures_folder,
        ]

        deleted_count = 0
        file_count = 0
        failed_files = []

        def handle_remove_error(func, path, exc_info):
            """Handle permission errors during file deletion by attempting to fix permissions."""
            nonlocal failed_files
            try:
                # Try to change file permissions to allow deletion
                os.chmod(path, stat.S_IWUSR | stat.S_IRUSR | stat.S_IXUSR)
                func(path)
            except Exception as e:
                # If that also fails, track the failed file
                failed_files.append((path, str(e)))

        # First, unload any images from Blender that are in the textures folder
        # This helps prevent file locking on Windows
        textures_folder_path = os.path.join(project_path, scene.mhs.textures_folder)
        if os.path.exists(textures_folder_path):
            images_to_remove = []
            for image in bpy.data.images:
                if image.filepath:
                    abs_path = bpy.path.abspath(image.filepath)
                    if abs_path.startswith(textures_folder_path):
                        images_to_remove.append(image)

            for image in images_to_remove:
                bpy.data.images.remove(image)

        for folder in folders_to_delete:
            folder_path = os.path.join(project_path, folder)
            if os.path.exists(folder_path):
                # Count files first
                for root, dirs, files in os.walk(folder_path):
                    file_count += len(files)
                # Delete the folder with error handling for permission issues
                try:
                    shutil.rmtree(folder_path, onerror=handle_remove_error)
                    deleted_count += 1
                except Exception as e:
                    failed_files.append((folder_path, str(e)))

        # Delete cache file
        cache_path = cache_tracker.get_cache().get_cache_filepath()
        if cache_path and os.path.exists(cache_path):
            try:
                os.remove(cache_path)
                file_count += 1
            except Exception as e:
                failed_files.append((cache_path, str(e)))

        # Reset cache instance
        cache_tracker.get_cache().invalidate_all()

        # Reset export stats
        scene.mhs.last_export_total = 0
        scene.mhs.last_export_exported = 0
        scene.mhs.last_export_skipped = 0
        scene.mhs.last_export_time_saved = 0.0
        scene.mhs.last_export_total_time = 0.0

        # Refresh UI to reflect changes
        for area in context.screen.areas:
            area.tag_redraw()

        if failed_files:
            self.report({'WARNING'}, f"Purged {deleted_count} folders ({file_count} files) but {len(failed_files)} file(s) failed to delete (may be in use)")
        else:
            self.report({'INFO'}, f"Purged {deleted_count} folders ({file_count} files) and cache")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.label(text="⚠️ WARNING: This action cannot be undone!", icon='ERROR')
        layout.separator()

        # Show file counts
        project_path = scene.mhs.project_path
        if project_path and os.path.exists(project_path):
            total_files = 0

            folders = [
                (scene.mhs.layouts_folder, 'SCENE_DATA'),
                (scene.mhs.meshes_folder, 'MESH_DATA'),
                (scene.mhs.animation_folder, 'ARMATURE_DATA'),
                (scene.mhs.materials_folder, 'MATERIAL'),
                (scene.mhs.textures_folder, 'TEXTURE'),
            ]

            for folder_name, icon in folders:
                folder_path = os.path.join(project_path, folder_name)
                if os.path.exists(folder_path):
                    count = 0
                    for root, dirs, files in os.walk(folder_path):
                        count += len(files)
                    total_files += count
                    row = layout.row()
                    row.label(text=f"  {folder_name}/", icon=icon)
                    row.label(text=f"{count} files")

            # Cache
            cache_path = cache_tracker.get_cache().get_cache_filepath()
            if cache_path and os.path.exists(cache_path):
                total_files += 1
                row = layout.row()
                row.label(text="  cache", icon='FILE_CACHE')
                row.label(text="1 file")

            layout.separator()
            row = layout.row()
            row.label(text="TOTAL:", icon='ERROR')
            row.label(text=f"{total_files} files")


class MHS_OT_reset_folder_paths(Operator):
    """Reset folder paths to defaults"""
    bl_idname = "mhs.reset_folder_paths"
    bl_label = "Reset to Defaults"
    bl_description = "Reset all folder paths to their default values"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene

        scene.mhs.layouts_folder = "layouts"
        scene.mhs.meshes_folder = "meshes"
        scene.mhs.animation_folder = "animation"
        scene.mhs.materials_folder = "materials"
        scene.mhs.textures_folder = "textures"

        self.report({'INFO'}, "Folder paths reset to defaults")
        return {'FINISHED'}


class MHS_OT_export_animated_selection(Operator):
    """Export all selected animated meshes/armatures"""
    bl_idname = "mhs.export_animated_selection"
    bl_label = "Export Animated Selection"
    bl_description = "Export all selected animated meshes and armatures"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        # Check if there are any armatures or meshes with armature modifiers selected
        for obj in context.selected_objects:
            if obj.type == 'ARMATURE':
                return True
            elif obj.type == 'MESH':
                for modifier in obj.modifiers:
                    if modifier.type == 'ARMATURE' and modifier.object:
                        return True
        return False

    def execute(self, context):
        props = context.scene.mhs
        force_rebuild = props.force_rebuild

        # Reset stats and start timing
        cache_tracker.reset_stats()
        cache_tracker.reset_session_tracking()
        cache_tracker.set_force_rebuild_session(force_rebuild)
        start_time = time.time()

        # Track total actions exported
        total_actions_count = 0

        with utils.ensure_object_mode(context):
            project_path = context.scene.mhs.project_path
            if not project_path:
                self.report({'ERROR'}, "Project path is not set")
                return {'CANCELLED'}

            # Use animation folder for animated exports
            animation_folder = os.path.join(project_path, props.animation_folder)
            os.makedirs(animation_folder, exist_ok=True)

            # Collect all animated objects (armatures and meshes with armature modifiers)
            armatures_to_export = set()
            meshes_to_export = []

            for obj in context.selected_objects:
                if obj.type == 'ARMATURE':
                    armatures_to_export.add(obj)
                    # Find meshes that use this armature
                    for potential_mesh in bpy.data.objects:
                        if potential_mesh.type == 'MESH':
                            for modifier in potential_mesh.modifiers:
                                if modifier.type == 'ARMATURE' and modifier.object == obj:
                                    if potential_mesh not in meshes_to_export:
                                        meshes_to_export.append(potential_mesh)
                                    break
                elif obj.type == 'MESH':
                    # Check if has armature modifier
                    for modifier in obj.modifiers:
                        if modifier.type == 'ARMATURE' and modifier.object:
                            if obj not in meshes_to_export:
                                meshes_to_export.append(obj)
                            armatures_to_export.add(modifier.object)
                            break

            if not meshes_to_export:
                self.report({'WARNING'}, "No animated meshes found in selection")
                return {'CANCELLED'}

            # Count enabled actions for each armature
            for armature in armatures_to_export:
                # animation_export_actions is stored on the armature object's mhs property
                if hasattr(armature, 'mhs') and armature.mhs.animation_export_actions:
                    for action_item in armature.mhs.animation_export_actions:
                        if action_item.enabled and action_item.action:
                            total_actions_count += 1
                else:
                    # Fallback: count all compatible actions from the armature
                    # This matches what functions.get_actions_for_armature returns
                    all_actions = functions.get_actions_for_armature(armature)
                    total_actions_count += len(all_actions)

            # Export each animated mesh
            exported_count = 0
            for mesh_obj in meshes_to_export:
                file_name = f"{functions.sanitize_name(mesh_obj.name)}.usda"
                filepath = os.path.join(animation_folder, file_name)

                result = functions.write_usda(context, filepath, objects=[mesh_obj], force_rebuild=force_rebuild)
                if result == {'FINISHED'}:
                    exported_count += 1

            # Finalize stats
            elapsed_time = time.time() - start_time
            cache_tracker.finalize_stats(elapsed_time)

            # For animated exports, the mesh stats ARE the animation stats
            # Copy mesh stats to animation stats for correct display
            props.last_export_animations_exported = props.last_export_meshes_exported
            props.last_export_animations_skipped = props.last_export_meshes_skipped
            props.last_export_actions_count = total_actions_count
            # Clear mesh stats since these were animated meshes, not static
            props.last_export_meshes_exported = 0
            props.last_export_meshes_skipped = 0

            props.show_export_stats = True

            # Reset force rebuild toggle after use
            props.force_rebuild = False

            # Show notification
            from .notification import format_export_notification
            message, notification_type = format_export_notification(context.scene)
            _show_export_notification(message, notification_type.value)

            self.report({'INFO'}, f"Exported {exported_count} animated mesh(es) with {total_actions_count} actions to {animation_folder}")
            return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════════════
# MHS Material System Operators
# ═══════════════════════════════════════════════════════════════════════════════

class MHS_OT_assign_texture(Operator):
    """Assign a texture to a shader input slot"""
    bl_idname = "mhs.assign_texture"
    bl_label = "Assign Texture"
    bl_description = "Add a texture node for this input slot"
    bl_options = {'REGISTER', 'UNDO'}

    input_name: StringProperty(
        name="Input Name",
        description="Name of the shader input to connect texture to",
        default=""
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj:
            return False
        mat = obj.active_material
        return mat and mat.use_nodes

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material

        if not mat or not mat.use_nodes:
            self.report({'ERROR'}, "Material must use nodes")
            return {'CANCELLED'}

        node_tree = mat.node_tree

        # Get the material format to determine which shader group to look for
        material_format = mat.mhs.material_format if mat.mhs else 'NONE'

        # Map format to node group name and setup module
        format_config = {
            'ISOTROPIC_USD': ('MHS_IsotropicUSD', 'isotropic_usd'),
            'ISOTROPIC_EMISSIVE_USD': ('MHS_IsotropicEmissiveUSD', 'isotropic_emissive_usd'),
            'UNLIT': ('MHS_Unlit', 'unlit'),
            'UNLIT_BLEND': ('MHS_UnlitBlend', 'unlit_blend'),
            'UNLIT_MASKED': ('MHS_UnlitMasked', 'unlit_masked'),
        }

        if material_format not in format_config:
            self.report({'ERROR'}, f"Material format '{material_format}' does not support textures. Set Material Format first.")
            return {'CANCELLED'}

        node_group_name, module_name = format_config[material_format]

        # Find the shader group node
        group_node = None
        for node in node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree and node.node_tree.name == node_group_name:
                group_node = node
                break

        if not group_node:
            self.report({'ERROR'}, f"No {node_group_name} shader found. Set Material Format first.")
            return {'CANCELLED'}

        # Dynamically import the correct template module and call setup_texture_node_for_input
        import importlib
        template_module = importlib.import_module(f'.shader_templates.{module_name}', package='BlendMHS')
        tex_node = template_module.setup_texture_node_for_input(mat, self.input_name, None)

        if not tex_node:
            self.report({'ERROR'}, f"Failed to create texture node for '{self.input_name}'")
            return {'CANCELLED'}

        # Format the node graph for cleaner layout
        self.format_material_nodes(mat)

        self.report({'INFO'}, f"Added texture slot for '{self.input_name}'")
        return {'FINISHED'}

    def format_material_nodes(self, material):
        """Format material nodes for better readability"""
        if not material.node_tree:
            return

        node_tree = material.node_tree

        # Collect nodes by type
        uv_transform_nodes = []
        input_nodes = []
        shader_nodes = []
        output_nodes = []
        other_nodes = []

        for node in node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree:
                if node.node_tree.name == 'MHS_UVTransform':
                    uv_transform_nodes.append(node)
                elif node.node_tree.name.startswith('MHS_'):
                    shader_nodes.append(node)
                else:
                    other_nodes.append(node)
            elif node.type in {'TEX_IMAGE', 'TEX_COORD', 'MAPPING'}:
                input_nodes.append(node)
            elif node.type.startswith('BSDF'):
                shader_nodes.append(node)
            elif node.type == 'OUTPUT_MATERIAL':
                output_nodes.append(node)
            elif node.type == 'VERTEX_COLOR':
                input_nodes.append(node)
            else:
                other_nodes.append(node)

        # Sort nodes within categories by Y position
        for node_list in [uv_transform_nodes, input_nodes, shader_nodes, other_nodes]:
            node_list.sort(key=lambda n: n.location.y, reverse=True)

        # Position nodes in columns
        x_offset = -600
        spacing = 300
        y_spacing = 300

        # UV Transform nodes (leftmost)
        for i, node in enumerate(uv_transform_nodes):
            node.location.x = x_offset
            node.location.y = -i * y_spacing
        if uv_transform_nodes:
            x_offset += spacing

        # Input nodes (textures, vertex colors)
        for i, node in enumerate(input_nodes):
            node.location.x = x_offset
            node.location.y = -i * y_spacing
        if input_nodes:
            x_offset += spacing

        # Shader nodes (MHS groups)
        for i, node in enumerate(shader_nodes):
            node.location.x = x_offset
            node.location.y = -i * y_spacing
        if shader_nodes:
            x_offset += spacing

        # Other nodes
        for i, node in enumerate(other_nodes):
            node.location.x = x_offset
            node.location.y = -i * y_spacing
        if other_nodes:
            x_offset += spacing

        # Output nodes (rightmost)
        for i, node in enumerate(output_nodes):
            node.location.x = x_offset
            node.location.y = -i * y_spacing


class MHS_OT_remove_texture(Operator):
    """Remove a texture node from a shader input slot"""
    bl_idname = "mhs.remove_texture"
    bl_label = "Remove Texture"
    bl_description = "Remove the texture node for this input slot"
    bl_options = {'REGISTER', 'UNDO'}

    input_name: StringProperty(
        name="Input Name",
        description="Name of the shader input to remove texture from",
        default=""
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj:
            return False
        mat = obj.active_material
        return mat and mat.use_nodes

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material

        if not mat or not mat.use_nodes:
            self.report({'ERROR'}, "Material must use nodes")
            return {'CANCELLED'}

        node_tree = mat.node_tree

        # Find and remove the texture node for this input
        nodes_to_remove = []
        for node in node_tree.nodes:
            if node.type == 'TEX_IMAGE' and self.input_name in node.name:
                nodes_to_remove.append(node)

        if not nodes_to_remove:
            self.report({'WARNING'}, f"No texture node found for '{self.input_name}'")
            return {'CANCELLED'}

        for node in nodes_to_remove:
            node_tree.nodes.remove(node)

        self.report({'INFO'}, f"Removed texture for '{self.input_name}'")
        return {'FINISHED'}


class MHS_OT_rebuild_shader(Operator):
    """Rebuild all shader node group templates with latest updates"""
    bl_idname = "mhs.rebuild_shader"
    bl_label = "Rebuild All Shader Templates"
    bl_description = "Rebuild all MHS shader node groups to get latest template updates (UV Scale/Offset, etc.)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from .shader_templates import TEMPLATE_REGISTRY

        rebuilt_count = 0
        for format_name, template in TEMPLATE_REGISTRY.items():
            try:
                node_group_name = template.node_group_name

                # Find all materials using this node group BEFORE we delete it
                # Store their connections so we can restore them
                materials_to_update = []
                old_node_group = bpy.data.node_groups.get(node_group_name)

                if old_node_group:
                    # Find all materials that reference this node group
                    for mat in bpy.data.materials:
                        if not mat.node_tree:
                            continue
                        for node in mat.node_tree.nodes:
                            if node.type == 'GROUP' and node.node_tree == old_node_group:
                                # Store input connections (from other nodes TO this group)
                                input_connections = {}
                                for inp in node.inputs:
                                    if inp.is_linked:
                                        # Store the source node and socket
                                        link = inp.links[0]
                                        input_connections[inp.name] = {
                                            'from_node': link.from_node.name,
                                            'from_socket': link.from_socket.name,
                                        }
                                    elif hasattr(inp, 'default_value'):
                                        # Store default values for unconnected inputs
                                        try:
                                            if inp.type == 'RGBA':
                                                input_connections[inp.name] = {
                                                    'default_value': tuple(inp.default_value)
                                                }
                                            elif inp.type == 'VECTOR':
                                                input_connections[inp.name] = {
                                                    'default_value': tuple(inp.default_value)
                                                }
                                            elif inp.type == 'VALUE':
                                                input_connections[inp.name] = {
                                                    'default_value': inp.default_value
                                                }
                                        except:
                                            pass

                                # Store output connections (from this group TO other nodes)
                                output_connections = {}
                                for out in node.outputs:
                                    if out.is_linked:
                                        output_connections[out.name] = []
                                        for link in out.links:
                                            output_connections[out.name].append({
                                                'to_node': link.to_node.name,
                                                'to_socket': link.to_socket.name,
                                            })

                                materials_to_update.append({
                                    'material': mat,
                                    'node': node,
                                    'node_name': node.name,
                                    'node_location': tuple(node.location),
                                    'input_connections': input_connections,
                                    'output_connections': output_connections,
                                })

                    # Now delete the old node group
                    bpy.data.node_groups.remove(old_node_group)

                # Create the new node group
                new_node_group = template._create_node_group()

                # Update all materials to use the new node group and restore connections
                for mat_info in materials_to_update:
                    mat = mat_info['material']
                    group_node = mat_info['node']

                    # Assign the new node group
                    group_node.node_tree = new_node_group

                    # Restore input connections
                    for inp_name, conn_info in mat_info['input_connections'].items():
                        if inp_name in group_node.inputs:
                            inp = group_node.inputs[inp_name]
                            if 'from_node' in conn_info:
                                # It was connected to another node
                                from_node_name = conn_info['from_node']
                                from_socket_name = conn_info['from_socket']

                                if from_node_name in mat.node_tree.nodes:
                                    from_node = mat.node_tree.nodes[from_node_name]
                                    if from_socket_name in from_node.outputs:
                                        mat.node_tree.links.new(
                                            from_node.outputs[from_socket_name],
                                            inp
                                        )
                            elif 'default_value' in conn_info:
                                # Restore default value
                                try:
                                    inp.default_value = conn_info['default_value']
                                except:
                                    pass

                    # Restore output connections
                    for out_name, connections in mat_info['output_connections'].items():
                        if out_name in group_node.outputs:
                            out = group_node.outputs[out_name]
                            for conn_info in connections:
                                to_node_name = conn_info['to_node']
                                to_socket_name = conn_info['to_socket']

                                if to_node_name in mat.node_tree.nodes:
                                    to_node = mat.node_tree.nodes[to_node_name]
                                    if to_socket_name in to_node.inputs:
                                        mat.node_tree.links.new(
                                            out,
                                            to_node.inputs[to_socket_name]
                                        )

                rebuilt_count += 1
                self.report({'INFO'}, f"Rebuilt {node_group_name} (updated {len(materials_to_update)} materials)")

            except Exception as e:
                self.report({'WARNING'}, f"Failed to rebuild {format_name}: {str(e)}")

        if rebuilt_count > 0:
            self.report({'INFO'}, f"Rebuilt {rebuilt_count} shader template(s)")
        else:
            self.report({'WARNING'}, "No shader templates were rebuilt")

        return {'FINISHED'}


class MHS_OT_add_color_attribute(Operator):
    """Add a color attribute and automatically connect to shader"""
    bl_idname = "mhs.add_color_attribute"
    bl_label = "Add Color Attribute"
    bl_description = "Add a color attribute and connect it to the MHS shader"
    bl_options = {'REGISTER', 'UNDO'}

    # Properties matching Blender's color attribute add operator
    name: StringProperty(
        name="Name",
        default="Color"
    )

    domain: bpy.props.EnumProperty(
        name="Domain",
        items=[
            ('POINT', "Vertex", "Store values on vertices"),
            ('CORNER', "Face Corner", "Store values on face corners"),
        ],
        default='CORNER'
    )

    data_type: bpy.props.EnumProperty(
        name="Data Type",
        items=[
            ('FLOAT_COLOR', "Color", "RGBA floating point color"),
            ('BYTE_COLOR', "Byte Color", "RGBA byte color"),
        ],
        default='FLOAT_COLOR'
    )

    color: bpy.props.FloatVectorProperty(
        name="Color",
        subtype='COLOR_GAMMA',
        size=4,
        min=0.0, max=1.0,
        default=(1.0, 1.0, 1.0, 1.0)
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "name")

        row = layout.row()
        row.label(text="Domain")
        row.prop(self, "domain", expand=True)

        row = layout.row()
        row.label(text="Data Type")
        row.prop(self, "data_type", expand=True)

        layout.prop(self, "color")

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material

        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No mesh object selected")
            return {'CANCELLED'}

        # Add the color attribute using Blender's built-in operator
        bpy.ops.geometry.color_attribute_add(
            name=self.name,
            domain=self.domain,
            data_type=self.data_type,
            color=self.color
        )

        # Now auto-connect to the shader if we have an MHS material
        if mat and mat.use_nodes and mat.mhs and mat.mhs.material_format == 'ISOTROPIC_USD':
            node_tree = mat.node_tree

            # Find the MHS_IsotropicUSD group node
            group_node = None
            for node in node_tree.nodes:
                if node.type == 'GROUP' and node.node_tree and node.node_tree.name == 'MHS_IsotropicUSD':
                    group_node = node
                    break

            if group_node and 'Vertex Color' in group_node.inputs:
                # Check if already connected
                vc_input = group_node.inputs['Vertex Color']
                if not vc_input.is_linked:
                    # Create vertex color node
                    vc_node = node_tree.nodes.new('ShaderNodeVertexColor')
                    vc_node.name = 'Vertex_Color'
                    vc_node.label = 'Vertex Color'
                    vc_node.location = (group_node.location.x - 300, group_node.location.y + 200)

                    # Set the layer name to the one we just created
                    vc_node.layer_name = self.name

                    # Connect to group input
                    node_tree.links.new(vc_node.outputs['Color'], vc_input)

                    self.report({'INFO'}, f"Added color attribute '{self.name}' and connected to shader")
                else:
                    # Already connected, just update the layer name
                    for link in vc_input.links:
                        if link.from_node.type == 'VERTEX_COLOR':
                            link.from_node.layer_name = self.name
                            break
                    self.report({'INFO'}, f"Added color attribute '{self.name}' and updated existing connection")
            else:
                self.report({'INFO'}, f"Added color attribute '{self.name}'")
        else:
            self.report({'INFO'}, f"Added color attribute '{self.name}'")

        return {'FINISHED'}


class MHS_OT_disconnect_vertex_color(Operator):
    """Disconnect and remove the vertex color node and color attribute"""
    bl_idname = "mhs.disconnect_vertex_color"
    bl_label = "Remove Vertex Colors"
    bl_description = "Remove the vertex color node from the material AND the color attribute from the mesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj:
            return False
        mat = obj.active_material
        return mat and mat.use_nodes

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material

        if not mat or not mat.use_nodes:
            self.report({'ERROR'}, "Material must use nodes")
            return {'CANCELLED'}

        node_tree = mat.node_tree

        # Find vertex color node and get the layer name before removing
        layer_name = None
        nodes_to_remove = []
        for node in node_tree.nodes:
            if node.type == 'VERTEX_COLOR':
                layer_name = node.layer_name
                nodes_to_remove.append(node)

        # Remove vertex color nodes from material
        for node in nodes_to_remove:
            node_tree.nodes.remove(node)

        # Remove color attribute from the mesh if we have a layer name
        removed_attribute = False
        if obj and obj.type == 'MESH' and obj.data and layer_name:
            color_attrs = obj.data.color_attributes
            if layer_name in color_attrs:
                color_attrs.remove(color_attrs[layer_name])
                removed_attribute = True

        if removed_attribute:
            self.report({'INFO'}, f"Removed vertex color node and '{layer_name}' attribute from mesh")
        elif nodes_to_remove:
            self.report({'INFO'}, "Removed vertex color node from material")
        else:
            self.report({'INFO'}, "No vertex color node found")

        return {'FINISHED'}


class MHS_OT_sync_vertex_color_name(Operator):
    """Sync vertex color attribute name - forces all to use 'Color' for consistency"""
    bl_idname = "mhs.sync_vertex_color_name"
    bl_label = "Sync Vertex Color Names"
    bl_description = "Rename color attributes to 'Color' on all objects using this material"
    bl_options = {'REGISTER', 'UNDO'}

    # Standard name to use for all vertex colors
    STANDARD_NAME = "Color"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return False
        mat = obj.active_material
        if not mat or not mat.use_nodes:
            return False
        return True

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material

        if not mat or not mat.use_nodes:
            self.report({'ERROR'}, "Material must use nodes")
            return {'CANCELLED'}

        target_name = self.STANDARD_NAME
        node_tree = mat.node_tree

        # Find and update the vertex color node in the material
        for node in node_tree.nodes:
            if node.type == 'VERTEX_COLOR':
                node.layer_name = target_name

        # Find ALL objects that use this material and sync their color attributes
        synced_objects = []

        for mesh_obj in bpy.data.objects:
            if mesh_obj.type != 'MESH':
                continue

            # Check if this object uses the material
            uses_material = any(slot.material == mat for slot in mesh_obj.material_slots)

            if not uses_material:
                continue

            # Check if this mesh has any color attributes
            if not mesh_obj.data.color_attributes:
                continue

            # Rename ALL color attributes that don't match
            for color_attr in mesh_obj.data.color_attributes:
                if color_attr.name != target_name:
                    old_name = color_attr.name
                    color_attr.name = target_name
                    synced_objects.append((mesh_obj.name, old_name))

        # Force UI refresh
        for area in context.screen.areas:
            area.tag_redraw()

        # Report results
        if synced_objects:
            self.report({'INFO'}, f"Synced {len(synced_objects)} object(s) to use '{target_name}'")
        else:
            self.report({'INFO'}, f"All objects already use '{target_name}'")

        return {'FINISHED'}


class MHS_OT_connect_vertex_color(Operator):
    """Connect vertex colors from the mesh to the shader"""
    bl_idname = "mhs.connect_vertex_color"
    bl_label = "Connect Vertex Colors"
    bl_description = "Connect mesh vertex colors to the shader's Vertex Color input"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return False
        mat = obj.active_material
        if not mat or not mat.use_nodes:
            return False
        # Check if mesh has vertex colors
        return obj.data.color_attributes and len(obj.data.color_attributes) > 0

    # List of MHS shader node groups that support vertex colors
    VERTEX_COLOR_SHADER_GROUPS = [
        'MHS_IsotropicUSD',
        'MHS_IsotropicEmissiveUSD',
        'MHS_IsotropicSimpleUSD',
    ]

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material

        if not mat or not mat.use_nodes:
            self.report({'ERROR'}, "Material must use nodes")
            return {'CANCELLED'}

        node_tree = mat.node_tree

        # Find any MHS shader group node that has a Vertex Color input
        group_node = None
        for node in node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree:
                # Check if this is an MHS shader with vertex color support
                if node.node_tree.name in self.VERTEX_COLOR_SHADER_GROUPS:
                    if 'Vertex Color' in node.inputs:
                        group_node = node
                        break

        if not group_node:
            self.report({'ERROR'}, "No MHS shader with Vertex Color support found")
            return {'CANCELLED'}

        # Check if vertex color node already exists and is connected
        existing_vc = None
        for node in node_tree.nodes:
            if node.type == 'VERTEX_COLOR':
                existing_vc = node
                break

        if existing_vc:
            # Check if already connected
            for output in existing_vc.outputs:
                for link in output.links:
                    if link.to_socket == group_node.inputs['Vertex Color']:
                        self.report({'INFO'}, "Vertex colors already connected")
                        return {'FINISHED'}
            # Exists but not connected - connect it
            node_tree.links.new(existing_vc.outputs['Color'], group_node.inputs['Vertex Color'])
            self.report({'INFO'}, "Connected existing vertex color node")
            return {'FINISHED'}

        # Create new vertex color node
        vc_node = node_tree.nodes.new('ShaderNodeVertexColor')
        vc_node.name = 'Vertex_Color'
        vc_node.label = 'Vertex Color'
        vc_node.location = (group_node.location.x - 300, group_node.location.y + 200)

        # Set the layer name if available
        if obj.data.color_attributes.active_color:
            vc_node.layer_name = obj.data.color_attributes.active_color.name

        # Connect to group input
        node_tree.links.new(vc_node.outputs['Color'], group_node.inputs['Vertex Color'])

        self.report({'INFO'}, "Connected vertex colors to shader")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════════════
# Layout Setup Pie Menu Operators
# ═══════════════════════════════════════════════════════════════════════════════

class MHS_OT_export_active_layout(Operator):
    """Export the currently active layout configuration"""
    bl_idname = "mhs.export_active_layout"
    bl_label = "Export Active Layout"
    bl_description = "Export the active layout to USD format"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        scene = context.scene
        if scene.mhs.project_path == "":
            return False
        if len(scene.mhs.layout_exports) == 0:
            return False
        active_index = scene.mhs.active_layout_index
        if active_index >= len(scene.mhs.layout_exports):
            return False
        active_layout = scene.mhs.layout_exports[active_index]
        return active_layout.enabled and len(active_layout.collections) > 0

    def execute(self, context):
        scene = context.scene
        active_index = scene.mhs.active_layout_index
        layout_config = scene.mhs.layout_exports[active_index]

        try:
            result = functions.write_layout_usda_single(context, layout_config)
            if result == {'FINISHED'}:
                self.report({'INFO'}, f"Successfully exported layout '{layout_config.name}.usda'")
                # Show mouse-following notification
                from .notification import format_export_notification
                message, notification_type = format_export_notification(scene)
                _show_export_notification(message, notification_type.value)
            return result
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {str(e)}")
            _show_export_notification(f"Export failed: {str(e)}", 'ERROR')
            return {'CANCELLED'}


class MHS_OT_create_collection_from_selection(Operator):
    """Create a collection from selected objects and add to active layout"""
    bl_idname = "mhs.create_collection_from_selection"
    bl_label = "Create Collection from Selection"
    bl_description = "Create a new collection from selected objects and add it to the active layout (removes from other layout collections)"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(
        name="Collection Name",
        description="Name for the new collection",
        default="NewCollection"
    )

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "collection_name")

    def get_layout_collections(self, context):
        """Get a set of all collections that belong to any layout"""
        layout_collections = set()
        for layout in context.scene.mhs.layout_exports:
            for coll_ref in layout.collections:
                if coll_ref.collection:
                    layout_collections.add(coll_ref.collection)
        return layout_collections

    def execute(self, context):
        scene = context.scene
        selected_objects = context.selected_objects

        if not selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        # Create new collection
        new_collection = bpy.data.collections.new(self.collection_name)
        context.scene.collection.children.link(new_collection)

        # Get all collections that belong to layouts (before we add the new one)
        layout_collections = self.get_layout_collections(context)

        # Move selected objects to the new collection, removing from other layout collections
        removed_from_other_layouts = 0
        for obj in selected_objects:
            # First, remove from other layout collections (object can only be in one layout)
            for coll in list(obj.users_collection):
                if coll in layout_collections:
                    coll.objects.unlink(obj)
                    removed_from_other_layouts += 1

            # Add to new collection
            new_collection.objects.link(obj)

            # Remove from non-layout collections too (this is a move operation)
            for coll in list(obj.users_collection):
                if coll != new_collection:
                    coll.objects.unlink(obj)

        # Add collection to active layout if one exists
        if len(scene.mhs.layout_exports) > 0:
            active_layout = scene.mhs.layout_exports[scene.mhs.active_layout_index]
            coll_ref = active_layout.collections.add()
            coll_ref.collection = new_collection
            if removed_from_other_layouts > 0:
                self.report({'INFO'}, f"Created collection '{self.collection_name}' with {len(selected_objects)} objects, added to layout '{active_layout.name}' (removed from {removed_from_other_layouts} other layout collection(s))")
            else:
                self.report({'INFO'}, f"Created collection '{self.collection_name}' with {len(selected_objects)} objects and added to layout '{active_layout.name}'")
        else:
            self.report({'INFO'}, f"Created collection '{self.collection_name}' with {len(selected_objects)} objects")

        return {'FINISHED'}


class MHS_OT_add_selection_to_active_layout(Operator):
    """Add selected objects to a collection in the active layout"""
    bl_idname = "mhs.add_selection_to_active_layout"
    bl_label = "Add to Layout"
    bl_description = "Add selected objects to a collection that is part of the active layout"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        scene = context.scene
        if len(context.selected_objects) == 0:
            return False
        if len(scene.mhs.layout_exports) == 0:
            return False
        active_layout = scene.mhs.layout_exports[scene.mhs.active_layout_index]
        if len(active_layout.collections) == 0:
            return False

        # Check if ANY selected object is NOT in the active layout's collections
        layout_collections = set()
        for coll_ref in active_layout.collections:
            if coll_ref.collection:
                layout_collections.add(coll_ref.collection)

        for obj in context.selected_objects:
            obj_in_layout = False
            for coll in obj.users_collection:
                if coll in layout_collections:
                    obj_in_layout = True
                    break
            if not obj_in_layout:
                return True  # At least one object is not in the layout

        return False  # All selected objects are already in the layout

    def execute(self, context):
        scene = context.scene
        selected_objects = context.selected_objects
        active_layout = scene.mhs.layout_exports[scene.mhs.active_layout_index]

        if len(active_layout.collections) == 0:
            self.report({'WARNING'}, f"Layout '{active_layout.name}' has no collections. Add a collection first.")
            return {'CANCELLED'}

        # Get the first collection in the active layout
        target_collection = active_layout.collections[0].collection
        if not target_collection:
            self.report({'ERROR'}, "Target collection not found")
            return {'CANCELLED'}

        added_count = 0
        for obj in selected_objects:
            if obj.name not in target_collection.objects:
                target_collection.objects.link(obj)
                added_count += 1

        self.report({'INFO'}, f"Added {added_count} object(s) to collection '{target_collection.name}'")
        return {'FINISHED'}


class MHS_OT_remove_selection_from_active_layout(Operator):
    """Remove selected objects from the active layout's collections"""
    bl_idname = "mhs.remove_selection_from_active_layout"
    bl_label = "Remove from Layout"
    bl_description = "Remove selected objects from collections in the active layout"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        scene = context.scene
        if len(context.selected_objects) == 0:
            return False
        if len(scene.mhs.layout_exports) == 0:
            return False
        active_layout = scene.mhs.layout_exports[scene.mhs.active_layout_index]
        if len(active_layout.collections) == 0:
            return False

        # Check if ANY selected object IS in the active layout's collections
        layout_collections = set()
        for coll_ref in active_layout.collections:
            if coll_ref.collection:
                layout_collections.add(coll_ref.collection)

        for obj in context.selected_objects:
            for coll in obj.users_collection:
                if coll in layout_collections:
                    return True  # At least one object is in the layout

        return False  # No selected objects are in the layout

    def execute(self, context):
        scene = context.scene
        selected_objects = context.selected_objects
        active_layout = scene.mhs.layout_exports[scene.mhs.active_layout_index]

        # Get all collections in the active layout
        layout_collections = set()
        for coll_ref in active_layout.collections:
            if coll_ref.collection:
                layout_collections.add(coll_ref.collection)

        # Get the main scene collection
        scene_collection = scene.collection

        removed_count = 0
        for obj in selected_objects:
            was_removed = False
            for coll in list(obj.users_collection):  # Use list() to avoid modification during iteration
                if coll in layout_collections:
                    coll.objects.unlink(obj)
                    was_removed = True

            # Add object back to scene collection if it was removed from layout collections
            if was_removed:
                removed_count += 1
                # Only add to scene collection if not already there
                if obj.name not in scene_collection.objects:
                    scene_collection.objects.link(obj)

        self.report({'INFO'}, f"Removed {removed_count} object(s) from layout '{active_layout.name}' (moved to Scene Collection)")
        return {'FINISHED'}


class MHS_OT_toggle_layout_enabled(Operator):
    """Toggle the enabled state of a layout"""
    bl_idname = "mhs.toggle_layout_enabled"
    bl_label = "Toggle Layout Enabled"
    bl_description = "Toggle whether this layout is enabled for export"
    bl_options = {'REGISTER', 'UNDO'}

    layout_index: IntProperty(
        name="Layout Index",
        description="Index of the layout to toggle",
        default=-1
    )

    @classmethod
    def poll(cls, context):
        return len(context.scene.mhs.layout_exports) > 0

    def execute(self, context):
        scene = context.scene
        index = self.layout_index if self.layout_index >= 0 else scene.mhs.active_layout_index

        if index >= len(scene.mhs.layout_exports):
            self.report({'ERROR'}, "Invalid layout index")
            return {'CANCELLED'}

        layout_config = scene.mhs.layout_exports[index]
        layout_config.enabled = not layout_config.enabled

        status = "enabled" if layout_config.enabled else "disabled"
        self.report({'INFO'}, f"Layout '{layout_config.name}' {status}")
        return {'FINISHED'}


class MHS_OT_add_selection_to_collection(Operator):
    """Add selected objects to a specific collection"""
    bl_idname = "mhs.add_selection_to_collection"
    bl_label = "Add to Collection"
    bl_description = "Add selected objects to this collection (removes from other layout collections)"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(
        name="Collection Name",
        description="Name of the collection to add objects to",
        default=""
    )

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def get_layout_collections(self, context):
        """Get a set of all collections that belong to any layout"""
        layout_collections = set()
        for layout in context.scene.mhs.layout_exports:
            for coll_ref in layout.collections:
                if coll_ref.collection:
                    layout_collections.add(coll_ref.collection)
        return layout_collections

    def execute(self, context):
        target_collection = bpy.data.collections.get(self.collection_name)
        if not target_collection:
            self.report({'ERROR'}, f"Collection '{self.collection_name}' not found")
            return {'CANCELLED'}

        # Get all collections that belong to layouts
        layout_collections = self.get_layout_collections(context)

        # Get scene collection reference
        scene_collection = context.scene.collection

        selected_objects = context.selected_objects
        added_count = 0

        for obj in selected_objects:
            # Remove from ALL other collections (including scene collection)
            # This is a full move operation - object should only be in target collection
            for coll in list(obj.users_collection):
                if coll != target_collection:
                    coll.objects.unlink(obj)

            # Add to target collection if not already there
            if obj.name not in target_collection.objects:
                target_collection.objects.link(obj)
                added_count += 1

        self.report({'INFO'}, f"Moved {added_count} object(s) to collection '{self.collection_name}'")
        return {'FINISHED'}


class MHS_OT_remove_selection_from_collection(Operator):
    """Remove selected objects from a specific collection"""
    bl_idname = "mhs.remove_selection_from_collection"
    bl_label = "Remove from Collection"
    bl_description = "Remove selected objects from this collection (moves to Scene Collection)"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(
        name="Collection Name",
        description="Name of the collection to remove objects from",
        default=""
    )

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):
        target_collection = bpy.data.collections.get(self.collection_name)
        if not target_collection:
            self.report({'ERROR'}, f"Collection '{self.collection_name}' not found")
            return {'CANCELLED'}

        scene_collection = context.scene.collection
        selected_objects = context.selected_objects
        removed_count = 0

        for obj in selected_objects:
            # Remove from target collection if it's there
            if obj.name in target_collection.objects:
                target_collection.objects.unlink(obj)
                removed_count += 1

                # Add to scene collection if not in any other collection
                if obj.name not in scene_collection.objects:
                    scene_collection.objects.link(obj)

        self.report({'INFO'}, f"Removed {removed_count} object(s) from collection '{self.collection_name}'")
        return {'FINISHED'}


class MHS_OT_invoke_move_to_collection(Operator):
    """Invoke the Move to Collection menu"""
    bl_idname = "mhs.invoke_move_to_collection"
    bl_label = "Move to Collection"
    bl_description = "Move selected objects to a collection"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):
        bpy.ops.wm.call_menu(name='MHS_MT_move_to_collection')
        return {'FINISHED'}


class MHS_OT_move_selection_to_collection(Operator):
    """Move selected objects to a specific collection"""
    bl_idname = "mhs.move_selection_to_collection"
    bl_label = "Move to Collection"
    bl_description = "Move selected objects to a specific collection (removes from other layout collections)"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(
        name="Collection Name",
        description="Name of the collection to move objects to",
        default=""
    )

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def get_layout_collections(self, context):
        """Get a set of all collections that belong to any layout"""
        layout_collections = set()
        for layout in context.scene.mhs.layout_exports:
            for coll_ref in layout.collections:
                if coll_ref.collection:
                    layout_collections.add(coll_ref.collection)
        return layout_collections

    def execute(self, context):
        target_collection = bpy.data.collections.get(self.collection_name)
        if not target_collection:
            self.report({'ERROR'}, f"Collection '{self.collection_name}' not found")
            return {'CANCELLED'}

        # Get all collections that belong to layouts
        layout_collections = self.get_layout_collections(context)

        selected_objects = context.selected_objects
        moved_count = 0

        for obj in selected_objects:
            # Add to target collection if not already there
            if obj.name not in target_collection.objects:
                target_collection.objects.link(obj)

            # Remove from other collections
            # For layout collections, always remove (object can only be in one layout)
            # For non-layout collections, also remove (this is a "move" operation)
            for coll in list(obj.users_collection):  # Use list() to avoid modification during iteration
                if coll != target_collection:
                    coll.objects.unlink(obj)

            moved_count += 1

        self.report({'INFO'}, f"Moved {moved_count} object(s) to collection '{self.collection_name}'")
        return {'FINISHED'}


class MHS_OT_select_layout(Operator):
    """Set the active layout index"""
    bl_idname = "mhs.select_layout"
    bl_label = "Select Layout"
    bl_description = "Set this layout as the active layout"
    bl_options = {'REGISTER'}

    layout_index: IntProperty(
        name="Layout Index",
        description="Index of the layout to select",
        default=-1
    )

    @classmethod
    def poll(cls, context):
        return len(context.scene.mhs.layout_exports) > 0

    def execute(self, context):
        scene = context.scene
        index = self.layout_index

        if index < 0 or index >= len(scene.mhs.layout_exports):
            self.report({'ERROR'}, "Invalid layout index")
            return {'CANCELLED'}

        scene.mhs.active_layout_index = index
        layout_config = scene.mhs.layout_exports[index]

        # Refresh UI to update panel and pie menu
        for area in context.screen.areas:
            area.tag_redraw()

        self.report({'INFO'}, f"Selected layout '{layout_config.name}'")
        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════════════
# Animation Action Management Operators (Phase 3 of Action Loader Enhancement)
# ═══════════════════════════════════════════════════════════════════════════════

class MHS_OT_add_action_label(Operator):
    """Add an organizational label/separator to the action list"""
    bl_idname = "mhs.add_action_label"
    bl_label = "Add Label"
    bl_description = "Add an organizational label to the action list"
    bl_options = {'REGISTER', 'UNDO'}

    label_text: StringProperty(
        name="Label Text",
        default="---Label---",
        description="Text to display on the label"
    )

    @classmethod
    def poll(cls, context):
        return cls._get_armature(context) is not None

    @staticmethod
    def _get_armature(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "label_text", text="Label")

    def execute(self, context):
        armature = self._get_armature(context)
        if not armature:
            self.report({'WARNING'}, "No armature found")
            return {'CANCELLED'}

        # Add label slot
        item = armature.mhs.animation_export_actions.add()
        item.slot_type = 'LABEL'
        item.label = self.label_text
        item.enabled = False  # Labels don't get exported

        self.report({'INFO'}, f"Added label: {self.label_text}")
        return {'FINISHED'}


class MHS_OT_reorder_action(Operator):
    """Move action up or down in the list"""
    bl_idname = "mhs.reorder_action"
    bl_label = "Reorder Action"
    bl_description = "Move the selected action in the list"
    bl_options = {'REGISTER', 'UNDO'}

    direction: EnumProperty(
        name="Direction",
        items=[
            ('UP', 'Up', 'Move up one position'),
            ('DOWN', 'Down', 'Move down one position'),
            ('TOP', 'Top', 'Move to top of list'),
            ('BOTTOM', 'Bottom', 'Move to bottom of list'),
        ],
        default='UP'
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        return len(armature.mhs.animation_export_actions) > 1

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def execute(self, context):
        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        actions = armature.mhs.animation_export_actions
        idx = armature.mhs.active_animation_action_index
        max_idx = len(actions) - 1

        if self.direction == 'UP' and idx > 0:
            actions.move(idx, idx - 1)
            armature.mhs.active_animation_action_index = idx - 1
        elif self.direction == 'DOWN' and idx < max_idx:
            actions.move(idx, idx + 1)
            armature.mhs.active_animation_action_index = idx + 1
        elif self.direction == 'TOP' and idx > 0:
            actions.move(idx, 0)
            armature.mhs.active_animation_action_index = 0
        elif self.direction == 'BOTTOM' and idx < max_idx:
            actions.move(idx, max_idx)
            armature.mhs.active_animation_action_index = max_idx

        return {'FINISHED'}


class MHS_OT_batch_tag_actions(Operator):
    """Add or remove tags from selected/filtered actions"""
    bl_idname = "mhs.batch_tag_actions"
    bl_label = "Batch Tag Actions"
    bl_description = "Add, remove, or set tags on multiple actions"
    bl_options = {'REGISTER', 'UNDO'}

    tag: StringProperty(
        name="Tag",
        default="",
        description="Tag to add or remove"
    )

    mode: EnumProperty(
        name="Mode",
        items=[
            ('ADD', 'Add', 'Add tag to existing tags'),
            ('REMOVE', 'Remove', 'Remove tag from existing tags'),
            ('SET', 'Set', 'Replace all tags with this tag'),
        ],
        default='ADD'
    )

    apply_to: EnumProperty(
        name="Apply To",
        items=[
            ('ENABLED', 'Enabled Actions', 'Apply to all enabled actions'),
            ('ALL', 'All Actions', 'Apply to all actions'),
        ],
        default='ENABLED'
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        return len(armature.mhs.animation_export_actions) > 0

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "mode")
        layout.prop(self, "tag")
        layout.prop(self, "apply_to")

    def execute(self, context):
        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        tag = self.tag.strip().lower()
        if not tag and self.mode != 'SET':
            self.report({'WARNING'}, "No tag specified")
            return {'CANCELLED'}

        count = 0
        for item in armature.mhs.animation_export_actions:
            # Skip labels
            if item.slot_type == 'LABEL':
                continue

            # Check if should apply to this item
            if self.apply_to == 'ENABLED' and not item.enabled:
                continue

            # Parse existing tags
            existing_tags = set(t.strip().lower() for t in item.tags.split(',') if t.strip())

            if self.mode == 'ADD':
                existing_tags.add(tag)
            elif self.mode == 'REMOVE':
                existing_tags.discard(tag)
            elif self.mode == 'SET':
                existing_tags = {tag} if tag else set()

            # Update tags
            item.tags = ', '.join(sorted(existing_tags))
            count += 1

        self.report({'INFO'}, f"Updated tags on {count} actions")
        return {'FINISHED'}


class MHS_OT_batch_enable_actions(Operator):
    """Enable or disable actions matching current filter"""
    bl_idname = "mhs.batch_enable_actions"
    bl_label = "Batch Enable Actions"
    bl_description = "Enable or disable actions matching current filter"
    bl_options = {'REGISTER', 'UNDO'}

    enable: BoolProperty(
        name="Enable",
        default=True,
        description="Enable or disable the actions"
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        return len(armature.mhs.animation_export_actions) > 0

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def execute(self, context):
        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        # Get filter settings
        filter_name = armature.mhs.action_filter_name.lower().strip()
        filter_tag = armature.mhs.action_filter_tag.lower().strip()
        exclusive = armature.mhs.action_filter_tag_exclusive

        count = 0
        for item in armature.mhs.animation_export_actions:
            # Skip labels
            if item.slot_type == 'LABEL':
                continue

            if not item.action:
                continue

            # Check name filter
            match_name = True
            if filter_name:
                action_name = item.action.name.lower()
                custom_name = item.custom_name.lower() if item.custom_name else ""
                match_name = filter_name in action_name or filter_name in custom_name

            # Check tag filter
            match_tag = True
            if filter_tag:
                item_tags = set(t.strip().lower() for t in item.tags.split(',') if t.strip())
                filter_tags = set(t.strip().lower() for t in filter_tag.split(',') if t.strip())
                if exclusive:
                    match_tag = filter_tags.issubset(item_tags)
                else:
                    match_tag = bool(filter_tags & item_tags)

            # Apply if matches filter
            if match_name and match_tag:
                item.enabled = self.enable
                count += 1

        action_word = "Enabled" if self.enable else "Disabled"
        self.report({'INFO'}, f"{action_word} {count} actions")
        return {'FINISHED'}


class MHS_OT_play_action(Operator):
    """Preview/play the selected action in the viewport"""
    bl_idname = "mhs.play_action"
    bl_label = "Play Action"
    bl_description = "Set action as active and play in viewport"
    bl_options = {'REGISTER', 'UNDO'}

    action_index: IntProperty(
        name="Action Index",
        default=-1,
        description="Index of the action to play"
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        return len(armature.mhs.animation_export_actions) > 0

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def execute(self, context):
        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        idx = self.action_index if self.action_index >= 0 else armature.mhs.active_animation_action_index
        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            return {'CANCELLED'}

        item = armature.mhs.animation_export_actions[idx]
        if not item.action:
            self.report({'WARNING'}, "No action assigned")
            return {'CANCELLED'}

        action = item.action

        # Set as active action
        if not armature.animation_data:
            armature.animation_data_create()
        armature.animation_data.action = action

        # Set timeline to action range
        if item.use_custom_range:
            context.scene.frame_start = item.frame_start
            context.scene.frame_end = item.frame_end
        elif action.fcurves:
            frame_range = action.frame_range
            context.scene.frame_start = int(frame_range[0])
            context.scene.frame_end = int(frame_range[1])

        context.scene.frame_current = context.scene.frame_start

        # Start playback - if already playing, stop first then restart
        # This ensures clicking play on a different action immediately plays it
        if context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        bpy.ops.screen.animation_play()

        return {'FINISHED'}


class MHS_OT_stop_action(Operator):
    """Stop animation playback"""
    bl_idname = "mhs.stop_action"
    bl_label = "Stop Action"
    bl_description = "Stop animation playback"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        return {'FINISHED'}


class MHS_OT_clean_action_list(Operator):
    """Remove invalid or orphaned action entries from the list"""
    bl_idname = "mhs.clean_action_list"
    bl_label = "Clean Action List"
    bl_description = "Remove entries with missing or invalid actions"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        return len(armature.mhs.animation_export_actions) > 0

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def execute(self, context):
        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        # Find indices to remove (work backwards to preserve indices)
        to_remove = []
        for i, item in enumerate(armature.mhs.animation_export_actions):
            # Remove if it's an ACTION slot with no action
            if item.slot_type == 'ACTION' and not item.action:
                to_remove.append(i)

        # Remove in reverse order
        for i in reversed(to_remove):
            armature.mhs.animation_export_actions.remove(i)

        # Fix active index
        if armature.mhs.active_animation_action_index >= len(armature.mhs.animation_export_actions):
            armature.mhs.active_animation_action_index = max(0, len(armature.mhs.animation_export_actions) - 1)

        self.report({'INFO'}, f"Removed {len(to_remove)} invalid entries")
        return {'FINISHED'}


class MHS_OT_load_action(Operator):
    """Load a specific action from bpy.data.actions into the export list"""
    bl_idname = "mhs.load_action"
    bl_label = "Load Action"
    bl_description = "Load an action from the blend file into the export list"
    bl_options = {'REGISTER', 'UNDO'}

    action_name: StringProperty(
        name="Action Name",
        default="",
        description="Name of the action to load"
    )

    @classmethod
    def poll(cls, context):
        return cls._get_armature_static(context) is not None

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def execute(self, context):
        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        action = bpy.data.actions.get(self.action_name)
        if not action:
            self.report({'WARNING'}, f"Action '{self.action_name}' not found")
            return {'CANCELLED'}

        # Check if already in list
        for item in armature.mhs.animation_export_actions:
            if item.action == action:
                self.report({'INFO'}, f"Action '{self.action_name}' already in list")
                return {'FINISHED'}

        # Add to list
        item = armature.mhs.animation_export_actions.add()
        item.action = action
        item.enabled = True

        self.report({'INFO'}, f"Loaded action: {self.action_name}")
        return {'FINISHED'}


class MHS_OT_load_all_actions(Operator):
    """Open a popup to select which actions to load"""
    bl_idname = "mhs.load_all_actions"
    bl_label = "List Loadable Actions"
    bl_description = "Open a dialog to select actions to load for this armature"
    bl_options = {'REGISTER', 'UNDO'}

    # Search/filter properties
    search_filter: StringProperty(
        name="Search",
        default="",
        description="Filter actions by name"
    )
    filter_mode: EnumProperty(
        name="Filter Mode",
        items=[
            ('INCLUDE', "Include", "Show actions matching the filter"),
            ('EXCLUDE', "Exclude", "Hide actions matching the filter")
        ],
        default='INCLUDE'
    )

    # Store action data as class variable (cleared on each invoke)
    _loadable_actions = []
    _armature_name = ""

    @classmethod
    def poll(cls, context):
        return cls._get_armature_static(context) is not None

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def invoke(self, context, event):
        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        MHS_OT_load_all_actions._armature_name = armature.name

        # Get bone names
        bone_names = {bone.name for bone in armature.data.bones}
        if not bone_names:
            self.report({'WARNING'}, "Armature has no bones")
            return {'CANCELLED'}

        # Get currently loaded actions
        loaded = {item.action.name for item in armature.mhs.animation_export_actions if item.action}

        # Find compatible actions not already loaded
        loadable = []
        for action in bpy.data.actions:
            if action.name in loaded:
                continue

            # Check if action is compatible (has fcurves for bones in this armature)
            compatible = False
            for fcurve in action.fcurves:
                if 'pose.bones["' in fcurve.data_path:
                    start = fcurve.data_path.find('pose.bones["') + len('pose.bones["')
                    end = fcurve.data_path.find('"]', start)
                    if end > start:
                        bone_name = fcurve.data_path[start:end]
                        if bone_name in bone_names:
                            compatible = True
                            break

            if compatible:
                # Calculate frame count
                frame_count = 0
                if action.fcurves:
                    frame_range = action.frame_range
                    frame_count = int(frame_range[1] - frame_range[0])
                loadable.append({
                    'name': action.name,
                    'frames': frame_count,
                    'selected': False
                })

        # Sort alphabetically
        loadable.sort(key=lambda x: x['name'].lower())
        MHS_OT_load_all_actions._loadable_actions = loadable

        if not loadable:
            self.report({'INFO'}, "No loadable actions found (all compatible actions already loaded)")
            return {'CANCELLED'}

        return context.window_manager.invoke_props_dialog(self, width=350)

    def draw(self, context):
        layout = self.layout
        loadable = MHS_OT_load_all_actions._loadable_actions

        # Check if actions were loaded/duplicated (list was cleared)
        if not loadable:
            # Show completion message
            box = layout.box()
            box.label(text="Actions loaded successfully!", icon='CHECKMARK')
            box.label(text="Click OK to close.")
            return

        # Search row
        row = layout.row(align=True)
        row.prop(self, "search_filter", text="", icon='VIEWZOOM')

        # Include/Exclude toggle
        row = layout.row(align=True)
        row.prop_enum(self, "filter_mode", 'INCLUDE')
        row.prop_enum(self, "filter_mode", 'EXCLUDE')

        layout.separator()

        # Select All / Deselect All checkboxes (not aligned with buttons)
        row = layout.row()
        sub = row.row(align=True)
        op_all = sub.operator("mhs.load_actions_batch_select", text="", icon='CHECKBOX_HLT')
        op_all.select_all = True
        op_none = sub.operator("mhs.load_actions_batch_select", text="", icon='CHECKBOX_DEHLT')
        op_none.select_all = False

        # Load All button (takes most space)
        sub = row.row(align=True)
        sub.scale_x = 1.0
        sub.operator("mhs.load_actions_load_all", text="Load All")

        # Duplicate All button (small, icon only)
        sub.scale_x = 1.0
        sub.operator("mhs.load_actions_duplicate_all", text="", icon='DUPLICATE')

        layout.separator()

        # Action list in a scrollable box
        box = layout.box()
        col = box.column(align=True)

        search_lower = self.search_filter.lower().strip()
        visible_count = 0
        selected_count = 0

        for i, action_data in enumerate(loadable):
            name = action_data['name']
            name_lower = name.lower()

            # Apply filter
            matches_filter = search_lower in name_lower if search_lower else True
            if self.filter_mode == 'EXCLUDE':
                matches_filter = not matches_filter if search_lower else True

            if not matches_filter:
                continue

            visible_count += 1
            is_selected = action_data.get('selected', False)
            if is_selected:
                selected_count += 1

            row = col.row(align=True)
            # Checkbox (clickable via operator)
            icon = 'CHECKBOX_HLT' if is_selected else 'CHECKBOX_DEHLT'
            op = row.operator("mhs.load_actions_toggle_item", text="", icon=icon, emboss=False)
            op.action_index = i

            # Action icon
            row.label(text="", icon='ACTION')

            # Action name
            row.label(text=name)

            # Duplicate button for this action
            op_dup = row.operator("mhs.load_actions_duplicate_item", text="", icon='DUPLICATE')
            op_dup.action_index = i

        if visible_count == 0:
            if loadable:
                col.label(text="No matching actions", icon='INFO')
            else:
                col.label(text="All actions already loaded", icon='CHECKMARK')

        # Summary at bottom
        layout.separator()
        row = layout.row()
        row.label(text=f"{selected_count} selected / {visible_count} visible / {len(loadable)} total")

    def execute(self, context):
        armature = bpy.data.objects.get(MHS_OT_load_all_actions._armature_name)
        if not armature:
            return {'CANCELLED'}

        loadable = MHS_OT_load_all_actions._loadable_actions

        count = 0
        for action_data in loadable:
            if action_data.get('selected', False):
                action = bpy.data.actions.get(action_data['name'])
                if action:
                    item = armature.mhs.animation_export_actions.add()
                    item.action = action
                    item.enabled = True
                    count += 1

        # Clear class data
        MHS_OT_load_all_actions._loadable_actions = []
        MHS_OT_load_all_actions._armature_name = ""

        self.report({'INFO'}, f"Loaded {count} actions")
        return {'FINISHED'}


class MHS_OT_load_actions_toggle_item(Operator):
    """Toggle selection of an action in the load popup"""
    bl_idname = "mhs.load_actions_toggle_item"
    bl_label = "Toggle Action"
    bl_options = {'INTERNAL'}

    action_index: IntProperty(default=-1)

    def execute(self, context):
        loadable = MHS_OT_load_all_actions._loadable_actions
        if 0 <= self.action_index < len(loadable):
            loadable[self.action_index]['selected'] = not loadable[self.action_index].get('selected', False)
        return {'FINISHED'}


class MHS_OT_load_actions_batch_select(Operator):
    """Select or deselect all visible actions"""
    bl_idname = "mhs.load_actions_batch_select"
    bl_label = "Batch Select"
    bl_options = {'INTERNAL'}

    select_all: BoolProperty(default=True)

    def execute(self, context):
        loadable = MHS_OT_load_all_actions._loadable_actions
        for action_data in loadable:
            action_data['selected'] = self.select_all
        return {'FINISHED'}


class MHS_OT_load_actions_duplicate_item(Operator):
    """Duplicate an action from the load popup list"""
    bl_idname = "mhs.load_actions_duplicate_item"
    bl_label = "Duplicate Action"
    bl_options = {'INTERNAL', 'UNDO'}

    action_index: IntProperty(default=-1)

    def execute(self, context):
        loadable = MHS_OT_load_all_actions._loadable_actions
        armature_name = MHS_OT_load_all_actions._armature_name

        if not (0 <= self.action_index < len(loadable)):
            return {'CANCELLED'}

        action_data = loadable[self.action_index]
        action = bpy.data.actions.get(action_data['name'])
        if not action:
            return {'CANCELLED'}

        # Create duplicate
        new_action = action.copy()
        new_action.name = action.name + "_copy"

        # Add to armature's action list
        armature = bpy.data.objects.get(armature_name)
        if armature and hasattr(armature, 'mhs'):
            item = armature.mhs.animation_export_actions.add()
            item.action = new_action
            item.enabled = True

        self.report({'INFO'}, f"Duplicated '{action.name}' as '{new_action.name}'")
        return {'FINISHED'}


class MHS_OT_load_actions_duplicate_all(Operator):
    """Duplicate all visible actions in the load popup"""
    bl_idname = "mhs.load_actions_duplicate_all"
    bl_label = "Duplicate All Visible"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):
        loadable = MHS_OT_load_all_actions._loadable_actions
        armature_name = MHS_OT_load_all_actions._armature_name

        armature = bpy.data.objects.get(armature_name)
        if not armature or not hasattr(armature, 'mhs'):
            return {'CANCELLED'}

        count = 0
        for action_data in loadable:
            action = bpy.data.actions.get(action_data['name'])
            if action:
                # Create duplicate
                new_action = action.copy()
                new_action.name = action.name + "_copy"

                # Add to armature's action list
                item = armature.mhs.animation_export_actions.add()
                item.action = new_action
                item.enabled = True
                count += 1

        # Clear class data to close the popup
        MHS_OT_load_all_actions._loadable_actions = []
        MHS_OT_load_all_actions._armature_name = ""

        self.report({'INFO'}, f"Duplicated {count} actions")
        return {'FINISHED'}


class MHS_OT_load_actions_load_all(Operator):
    """Load all visible actions in the popup without selecting them first"""
    bl_idname = "mhs.load_actions_load_all"
    bl_label = "Load All Visible"
    bl_options = {'INTERNAL', 'UNDO'}

    def execute(self, context):
        loadable = MHS_OT_load_all_actions._loadable_actions
        armature_name = MHS_OT_load_all_actions._armature_name

        armature = bpy.data.objects.get(armature_name)
        if not armature or not hasattr(armature, 'mhs'):
            return {'CANCELLED'}

        count = 0
        for action_data in loadable:
            action = bpy.data.actions.get(action_data['name'])
            if action:
                # Add original action to armature's action list
                item = armature.mhs.animation_export_actions.add()
                item.action = action
                item.enabled = True
                count += 1

        # Clear class data to close the popup
        MHS_OT_load_all_actions._loadable_actions = []
        MHS_OT_load_all_actions._armature_name = ""

        self.report({'INFO'}, f"Loaded {count} actions")
        return {'FINISHED'}


class MHS_OT_add_active_action(Operator):
    """Add the armature's currently active action to the export list"""
    bl_idname = "mhs.add_active_action"
    bl_label = "Load Active Action"
    bl_description = "Add the currently active action to the export list"
    bl_options = {'REGISTER', 'UNDO'}

    target_object: StringProperty(
        name="Target Object",
        default="",
        description="Name of the armature object"
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        # Check if armature has an active action that's not in the list
        if not armature.animation_data or not armature.animation_data.action:
            return False
        action = armature.animation_data.action
        for item in armature.mhs.animation_export_actions:
            if item.action == action:
                return False
        return True

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def execute(self, context):
        # Use target_object if specified, otherwise get from context
        if self.target_object:
            armature = bpy.data.objects.get(self.target_object)
        else:
            armature = self._get_armature_static(context)

        if not armature:
            self.report({'ERROR'}, "No armature found")
            return {'CANCELLED'}

        if not armature.animation_data or not armature.animation_data.action:
            self.report({'WARNING'}, "No active action on armature")
            return {'CANCELLED'}

        action = armature.animation_data.action

        # Check if already in list
        for item in armature.mhs.animation_export_actions:
            if item.action == action:
                self.report({'INFO'}, f"Action '{action.name}' is already in the list")
                return {'CANCELLED'}

        # Add to list
        item = armature.mhs.animation_export_actions.add()
        item.action = action
        item.enabled = True

        # Set as active in the list
        armature.mhs.active_animation_action_index = len(armature.mhs.animation_export_actions) - 1

        self.report({'INFO'}, f"Added active action: '{action.name}'")
        return {'FINISHED'}


class MHS_OT_append_action_from_file(Operator):
    """Append actions from an external blend file"""
    bl_idname = "mhs.append_action_from_file"
    bl_label = "Import Actions from .blend"
    bl_description = "Append actions from another blend file"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: StringProperty(
        name="File Path",
        subtype='FILE_PATH'
    )

    filter_glob: StringProperty(
        default="*.blend",
        options={'HIDDEN'}
    )

    @classmethod
    def poll(cls, context):
        return cls._get_armature_static(context) is not None

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        import os

        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        if not os.path.exists(self.filepath):
            self.report({'ERROR'}, f"File not found: {self.filepath}")
            return {'CANCELLED'}

        # Get existing action names to avoid duplicates
        existing_names = {a.name for a in bpy.data.actions}

        # Append all actions from the file
        with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
            # Get all action names from the file
            action_names = data_from.actions
            data_to.actions = action_names

        # Add newly imported actions to the list
        count = 0
        for action in data_to.actions:
            if action and action.name not in existing_names:
                item = armature.mhs.animation_export_actions.add()
                item.action = action
                item.enabled = True
                count += 1

        self.report({'INFO'}, f"Imported {count} actions from {os.path.basename(self.filepath)}")
        return {'FINISHED'}


class MHS_OT_push_action_to_nla(Operator):
    """Push the selected action to the NLA Editor as a new strip"""
    bl_idname = "mhs.push_action_to_nla"
    bl_label = "Push to NLA"
    bl_description = "Push the selected action to the NLA Editor as a new strip"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        if len(armature.mhs.animation_export_actions) == 0:
            return False
        idx = armature.mhs.active_animation_action_index
        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            return False
        return armature.mhs.animation_export_actions[idx].action is not None

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def execute(self, context):
        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        idx = armature.mhs.active_animation_action_index
        item = armature.mhs.animation_export_actions[idx]
        action = item.action

        if not action:
            self.report({'WARNING'}, "No action selected")
            return {'CANCELLED'}

        # Ensure animation data exists
        if not armature.animation_data:
            armature.animation_data_create()

        # Create or get NLA track
        track_name = action.name + "_Track"
        track = None
        for t in armature.animation_data.nla_tracks:
            if t.name == track_name:
                track = t
                break

        if not track:
            track = armature.animation_data.nla_tracks.new()
            track.name = track_name

        # Find the end of existing strips to place new strip
        start_frame = 1
        for strip in track.strips:
            end = strip.frame_end
            if end >= start_frame:
                start_frame = int(end) + 1

        # Create the strip
        try:
            strip = track.strips.new(action.name, int(start_frame), action)
            strip.name = item.custom_name if item.custom_name else action.name

            # Apply custom frame range if set
            if item.use_custom_range:
                strip.action_frame_start = item.frame_start
                strip.action_frame_end = item.frame_end

            self.report({'INFO'}, f"Pushed '{action.name}' to NLA track '{track.name}'")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to push to NLA: {str(e)}")
            return {'CANCELLED'}

        return {'FINISHED'}


class MHS_OT_duplicate_action(Operator):
    """Duplicate the selected action and add it to the list"""
    bl_idname = "mhs.duplicate_action"
    bl_label = "Duplicate Action"
    bl_description = "Create a copy of the selected action"
    bl_options = {'REGISTER', 'UNDO'}

    action_index: IntProperty(
        name="Action Index",
        description="Index of the action to duplicate (-1 uses active)",
        default=-1
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        if len(armature.mhs.animation_export_actions) == 0:
            return False
        idx = armature.mhs.active_animation_action_index
        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            return False
        return armature.mhs.animation_export_actions[idx].action is not None

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def execute(self, context):
        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        # Use action_index if provided, otherwise fall back to active index
        idx = self.action_index if self.action_index >= 0 else armature.mhs.active_animation_action_index

        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            self.report({'WARNING'}, "Invalid action index")
            return {'CANCELLED'}

        item = armature.mhs.animation_export_actions[idx]
        action = item.action

        if not action:
            self.report({'WARNING'}, "No action selected")
            return {'CANCELLED'}

        # Duplicate the action
        new_action = action.copy()
        new_action.name = action.name + "_copy"

        # Add to the list
        new_item = armature.mhs.animation_export_actions.add()
        new_item.action = new_action
        new_item.enabled = item.enabled
        new_item.tags = item.tags
        new_item.is_loop = item.is_loop
        new_item.use_custom_range = item.use_custom_range
        new_item.frame_start = item.frame_start
        new_item.frame_end = item.frame_end

        # Select the new action
        armature.mhs.active_animation_action_index = len(armature.mhs.animation_export_actions) - 1

        self.report({'INFO'}, f"Duplicated action as '{new_action.name}'")
        return {'FINISHED'}


class MHS_OT_flip_action(Operator):
    """Flip the selected action (mirror left/right for armature)"""
    bl_idname = "mhs.flip_action"
    bl_label = "Flip Action"
    bl_description = "Create a mirrored copy of the selected action (swaps left/right bones)"
    bl_options = {'REGISTER', 'UNDO'}

    flipped_action_name: StringProperty(
        name="Flipped Action Name",
        default="",
        description="Name for the flipped action"
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        if len(armature.mhs.animation_export_actions) == 0:
            return False
        idx = armature.mhs.active_animation_action_index
        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            return False
        return armature.mhs.animation_export_actions[idx].action is not None

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def invoke(self, context, event):
        armature = self._get_armature_static(context)
        if armature:
            idx = armature.mhs.active_animation_action_index
            if 0 <= idx < len(armature.mhs.animation_export_actions):
                action = armature.mhs.animation_export_actions[idx].action
                if action:
                    self.flipped_action_name = action.name + "_Flipped"

        return context.window_manager.invoke_props_dialog(self)

    def _flip_action(self, action):
        """Create a flipped copy of the action by mirroring bone transforms"""
        import re
        new_action = bpy.data.actions.new(self.flipped_action_name)

        for fc in action.fcurves:
            pattern = re.compile(r'pose.bones\[\"(.*)"\]\.(.*)')
            m = pattern.findall(fc.data_path)

            data_path = fc.data_path
            prop = ""

            if len(m) > 0:
                item = m[0]
                bone_name = item[0]
                prop = item[1]
                flipped_bone_name = bpy.utils.flip_name(bone_name)
                flipped_path = f'pose.bones["{flipped_bone_name}"].{prop}'
                if flipped_path != fc.data_path:
                    data_path = flipped_path

            if fc.group:
                new_fc = new_action.fcurves.new(
                    data_path, index=fc.array_index, action_group=fc.group.name
                )
            else:
                new_fc = new_action.fcurves.new(data_path, index=fc.array_index)

            for kf in fc.keyframe_points:
                if "euler" in prop and fc.array_index in [1, 2]:
                    new_fc.keyframe_points.insert(kf.co.x, -kf.co.y)
                elif "quaternion" in prop and fc.array_index in [2, 3]:
                    new_fc.keyframe_points.insert(kf.co.x, -kf.co.y)
                elif "location" in prop and fc.array_index in [0]:
                    new_fc.keyframe_points.insert(kf.co.x, -kf.co.y)
                else:
                    new_fc.keyframe_points.insert(kf.co.x, kf.co.y)

        return new_action

    def execute(self, context):
        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        idx = armature.mhs.active_animation_action_index
        item = armature.mhs.animation_export_actions[idx]
        action = item.action

        if not action:
            self.report({'WARNING'}, "No action selected")
            return {'CANCELLED'}

        flipped_action = self._flip_action(action)
        flipped_action.use_fake_user = True

        new_item = armature.mhs.animation_export_actions.add()
        new_item.action = flipped_action
        new_item.enabled = item.enabled
        new_item.tags = item.tags
        new_item.is_loop = item.is_loop
        new_item.use_custom_range = item.use_custom_range
        new_item.frame_start = item.frame_start
        new_item.frame_end = item.frame_end

        armature.mhs.active_animation_action_index = len(armature.mhs.animation_export_actions) - 1

        self.report({'INFO'}, f"Created flipped action: '{flipped_action.name}'")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "flipped_action_name", text="Flipped Action Name")


class MHS_OT_bake_action(Operator):
    """Bake the selected action with customizable settings"""
    bl_idname = "mhs.bake_action"
    bl_label = "Bake Action Slot"
    bl_description = "Bake the selected action with full control over bake settings"
    bl_options = {'REGISTER', 'UNDO'}

    bake_mode: EnumProperty(
        name="Bake Mode",
        items=[
            ('NEW', "Bake to New Action", "Create a new baked action"),
            ('REPLACE', "Bake This Action", "Replace the current action with baked version"),
        ],
        default='NEW'
    )

    new_action_name: StringProperty(
        name="Name",
        default="",
        description="Name for the new baked action"
    )

    replace_if_exist: BoolProperty(
        name="Replace if Exist",
        default=True,
        description="Replace existing action with same name"
    )

    only_selected: BoolProperty(
        name="Only Selected Bone",
        default=False,
        description="Only bake keyframes for selected bones"
    )

    do_pose: BoolProperty(
        name="Bake Pose",
        default=True,
        description="Bake pose channels"
    )

    do_object: BoolProperty(
        name="Bake Object",
        default=False,
        description="Bake object transforms"
    )

    do_visual_keying: BoolProperty(
        name="Visual Keying",
        default=True,
        description="Bake based on visual transforms (includes constraints)"
    )

    do_constraint_clear: BoolProperty(
        name="Constraint Clear",
        default=False,
        description="Remove constraints after baking"
    )

    do_parents_clear: BoolProperty(
        name="Parent Clear",
        default=False,
        description="Clear parent relationships after baking"
    )

    do_clean: BoolProperty(
        name="Clean",
        default=False,
        description="Remove redundant keyframes after baking"
    )

    do_location: BoolProperty(
        name="Location",
        default=True,
        description="Bake location channels"
    )

    do_rotation: BoolProperty(
        name="Rotation",
        default=True,
        description="Bake rotation channels"
    )

    do_scale: BoolProperty(
        name="Scale",
        default=True,
        description="Bake scale channels"
    )

    do_bbone: BoolProperty(
        name="BBone",
        default=False,
        description="Bake BBone channels"
    )

    do_custom_props: BoolProperty(
        name="Custom Properties",
        default=True,
        description="Bake custom properties"
    )

    show_bake_settings: BoolProperty(
        name="Show Bake Settings",
        default=True,
        description="Show/hide bake settings section"
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        if len(armature.mhs.animation_export_actions) == 0:
            return False
        idx = armature.mhs.active_animation_action_index
        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            return False
        return armature.mhs.animation_export_actions[idx].action is not None

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def invoke(self, context, event):
        armature = self._get_armature_static(context)
        if armature:
            idx = armature.mhs.active_animation_action_index
            if 0 <= idx < len(armature.mhs.animation_export_actions):
                action = armature.mhs.animation_export_actions[idx].action
                if action:
                    self.new_action_name = action.name + "_baked"

        return context.window_manager.invoke_props_dialog(self, width=280)

    def execute(self, context):
        from bpy_extras import anim_utils

        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        idx = armature.mhs.active_animation_action_index
        item = armature.mhs.animation_export_actions[idx]
        action = item.action

        if not action:
            self.report({'WARNING'}, "No action selected")
            return {'CANCELLED'}

        if not armature.animation_data:
            armature.animation_data_create()
        original_action = armature.animation_data.action
        armature.animation_data.action = action

        frame_range = action.frame_range
        start = int(frame_range[0])
        end = int(frame_range[1])

        if item.use_custom_range:
            start = item.frame_start
            end = item.frame_end

        frames = list(range(start, end + 1))

        bake_options = anim_utils.BakeOptions(
            only_selected=self.only_selected,
            do_pose=self.do_pose,
            do_object=self.do_object,
            do_visual_keying=self.do_visual_keying,
            do_constraint_clear=self.do_constraint_clear,
            do_parents_clear=self.do_parents_clear,
            do_clean=self.do_clean,
            do_location=self.do_location,
            do_rotation=self.do_rotation,
            do_scale=self.do_scale,
            do_bbone=self.do_bbone,
            do_custom_props=self.do_custom_props,
        )

        if self.bake_mode == 'NEW':
            new_action = bpy.data.actions.new(self.new_action_name)
        else:
            new_action = action

        obj_act = [[armature, new_action]]

        baked_actions = anim_utils.bake_action_objects(
            obj_act, frames=frames, bake_options=bake_options
        )

        if baked_actions and baked_actions[0]:
            baked_action = baked_actions[0]

            if self.bake_mode == 'NEW':
                if self.replace_if_exist:
                    existing = bpy.data.actions.get(self.new_action_name)
                    if existing and existing != baked_action:
                        bpy.data.actions.remove(existing)
                baked_action.name = self.new_action_name
                baked_action.use_fake_user = True

                new_item = armature.mhs.animation_export_actions.add()
                new_item.action = baked_action
                new_item.enabled = item.enabled
                new_item.tags = item.tags
                new_item.is_loop = item.is_loop

                armature.mhs.active_animation_action_index = len(armature.mhs.animation_export_actions) - 1
                self.report({'INFO'}, f"Baked action to: '{baked_action.name}'")
            else:
                item.action = baked_action
                self.report({'INFO'}, f"Baked action in place: '{baked_action.name}'")

            armature.animation_data.action = baked_action
        else:
            armature.animation_data.action = original_action
            self.report({'WARNING'}, "Bake failed")
            return {'CANCELLED'}

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout

        row = layout.row(align=True)
        row.prop_enum(self, "bake_mode", 'NEW')
        row.prop_enum(self, "bake_mode", 'REPLACE')

        layout.separator()

        row = layout.row(align=True)
        row.prop(self, "new_action_name", text="Name")
        row.operator("mhs.bake_action_generate_name", text="", icon='FILE_REFRESH')

        layout.prop(self, "replace_if_exist")

        layout.separator()

        # Collapsible Bake Settings section
        box = layout.box()
        row = box.row()
        row.prop(self, "show_bake_settings",
                icon="TRIA_DOWN" if self.show_bake_settings else "TRIA_RIGHT",
                text="Bake Settings", emboss=False)

        if self.show_bake_settings:
            col = box.column(align=True)
            col.prop(self, "only_selected")
            col.prop(self, "do_pose")
            col.prop(self, "do_object")
            col.prop(self, "do_visual_keying")
            col.prop(self, "do_constraint_clear")
            col.prop(self, "do_parents_clear")
            col.prop(self, "do_clean")

            # Channel section inside Bake Settings
            col.separator()
            col.label(text="Channel")
            col.prop(self, "do_location")
            col.prop(self, "do_rotation")
            col.prop(self, "do_scale")
            col.prop(self, "do_bbone")
            col.prop(self, "do_custom_props")


class MHS_OT_bake_action_generate_name(Operator):
    """Generate a unique name for the baked action"""
    bl_idname = "mhs.bake_action_generate_name"
    bl_label = "Generate Name"
    bl_description = "Generate a unique name based on the source action"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        return {'FINISHED'}


class MHS_OT_new_action(Operator):
    """Create a new empty action and add it to the list"""
    bl_idname = "mhs.new_action"
    bl_label = "New Action"
    bl_description = "Create a new empty action for this armature"
    bl_options = {'REGISTER', 'UNDO'}

    action_name: StringProperty(
        name="Action Name",
        default="NewAction",
        description="Name for the new action"
    )

    @classmethod
    def poll(cls, context):
        return cls._get_armature_static(context) is not None

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def invoke(self, context, event):
        # Generate a unique default name
        base_name = "NewAction"
        counter = 1
        while f"{base_name}_{counter:03d}" in bpy.data.actions:
            counter += 1
        self.action_name = f"{base_name}_{counter:03d}"

        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        # Create new action
        new_action = bpy.data.actions.new(name=self.action_name)

        # Add to the list
        item = armature.mhs.animation_export_actions.add()
        item.action = new_action
        item.enabled = True

        # Set as active action on armature
        if not armature.animation_data:
            armature.animation_data_create()
        armature.animation_data.action = new_action

        # Select the new action
        armature.mhs.active_animation_action_index = len(armature.mhs.animation_export_actions) - 1

        self.report({'INFO'}, f"Created new action: '{new_action.name}'")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "action_name")


class MHS_OT_reorder_pose_marker(Operator):
    """Reorder pose marker in the list"""
    bl_idname = "mhs.reorder_pose_marker"
    bl_label = "Reorder Pose Marker"
    bl_description = "Move pose marker up or down in the list"
    bl_options = {'REGISTER', 'UNDO'}

    direction: bpy.props.EnumProperty(
        name="Direction",
        items=[
            ('UP', 'Up', 'Move marker up'),
            ('DOWN', 'Down', 'Move marker down'),
        ],
        default='UP'
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        if not armature.mhs.animation_export_actions:
            return False
        idx = armature.mhs.active_animation_action_index
        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            return False
        action_item = armature.mhs.animation_export_actions[idx]
        if not action_item.action:
            return False
        return len(action_item.action.pose_markers) > 0

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def execute(self, context):
        armature = self._get_armature_static(context)
        if not armature:
            return {'CANCELLED'}

        idx = armature.mhs.active_animation_action_index
        action_item = armature.mhs.animation_export_actions[idx]
        action = action_item.action

        markers = action.pose_markers
        marker_idx = action.pose_markers_index

        if self.direction == 'UP':
            if marker_idx <= 0:
                return {'CANCELLED'}
            new_idx = marker_idx - 1
        else:  # DOWN
            if marker_idx >= len(markers) - 1:
                return {'CANCELLED'}
            new_idx = marker_idx + 1

        # Swap markers by swapping their frames and names
        current_marker = markers[marker_idx]
        target_marker = markers[new_idx]

        # Store current values
        temp_name = current_marker.name
        temp_frame = current_marker.frame

        # Swap
        current_marker.name = target_marker.name
        current_marker.frame = target_marker.frame
        target_marker.name = temp_name
        target_marker.frame = temp_frame

        # Update index
        action.pose_markers_index = new_idx

        return {'FINISHED'}


class MHS_OT_add_pose_marker(Operator):
    """Add a pose marker to the action with dialog"""
    bl_idname = "mhs.add_pose_marker"
    bl_label = "Add Pose Marker"
    bl_description = "Add a new pose marker to the current action"
    bl_options = {'REGISTER', 'UNDO'}

    name: StringProperty(
        name="Name",
        default="PoseMarker",
        description="Name for the new pose marker"
    )
    frame: IntProperty(
        name="Frame",
        default=1,
        description="Frame for the pose marker"
    )
    sync_frame: bpy.props.BoolProperty(
        name="Sync Frame",
        default=True,
        description="Use current frame"
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        if not armature.mhs.animation_export_actions:
            return False
        idx = armature.mhs.active_animation_action_index
        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            return False
        action_item = armature.mhs.animation_export_actions[idx]
        return action_item.action is not None

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def invoke(self, context, event):
        self.frame = context.scene.frame_current
        armature = self._get_armature_static(context)
        idx = armature.mhs.active_animation_action_index
        action = armature.mhs.animation_export_actions[idx].action
        self.name = f"PoseMarker_{len(action.pose_markers)}"
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "name", text="Name")

        row = layout.row(align=True)
        row.prop(self, "sync_frame", text="", icon='UV_SYNC_SELECT')

        if self.sync_frame:
            row.prop(context.scene, "frame_current")
        else:
            row.prop(self, "frame", text="Frame")

    def execute(self, context):
        armature = self._get_armature_static(context)
        idx = armature.mhs.active_animation_action_index
        action = armature.mhs.animation_export_actions[idx].action

        if self.sync_frame:
            self.frame = context.scene.frame_current

        marker = action.pose_markers.new(self.name)
        marker.frame = self.frame

        self.report({'INFO'}, f"Added pose marker '{self.name}' at frame {self.frame}")
        return {'FINISHED'}


class MHS_OT_remove_pose_marker(Operator):
    """Remove the active pose marker"""
    bl_idname = "mhs.remove_pose_marker"
    bl_label = "Remove Pose Marker"
    bl_description = "Remove the active pose marker"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        if not armature.mhs.animation_export_actions:
            return False
        idx = armature.mhs.active_animation_action_index
        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            return False
        action_item = armature.mhs.animation_export_actions[idx]
        if not action_item.action:
            return False
        return len(action_item.action.pose_markers) > 0

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def execute(self, context):
        armature = self._get_armature_static(context)
        idx = armature.mhs.active_animation_action_index
        action = armature.mhs.animation_export_actions[idx].action

        marker_idx = action.pose_markers_index
        if marker_idx < 0 or marker_idx >= len(action.pose_markers):
            self.report({'WARNING'}, "No pose marker selected")
            return {'CANCELLED'}

        marker_name = action.pose_markers[marker_idx].name
        action.pose_markers.remove(action.pose_markers[marker_idx])

        # Adjust index
        if action.pose_markers_index > 0 and action.pose_markers_index >= len(action.pose_markers):
            action.pose_markers_index = len(action.pose_markers) - 1

        self.report({'INFO'}, f"Removed pose marker '{marker_name}'")
        return {'FINISHED'}


class MHS_OT_move_to_pose_marker(Operator):
    """Move timeline to the active pose marker (Shift+Click to also frame view)"""
    bl_idname = "mhs.move_to_pose_marker"
    bl_label = "Move to Pose Marker"
    bl_description = "Move timeline to pose marker. Shift+Click to also frame view"
    bl_options = {'REGISTER', 'UNDO'}

    frame_view: bpy.props.BoolProperty(
        name="Frame View",
        default=False,
        description="Also frame the view in animation editors"
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        if not armature.mhs.animation_export_actions:
            return False
        idx = armature.mhs.active_animation_action_index
        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            return False
        action_item = armature.mhs.animation_export_actions[idx]
        if not action_item.action:
            return False
        return len(action_item.action.pose_markers) > 0

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def invoke(self, context, event):
        self.frame_view = event.shift
        return self.execute(context)

    def execute(self, context):
        armature = self._get_armature_static(context)
        idx = armature.mhs.active_animation_action_index
        action = armature.mhs.animation_export_actions[idx].action

        marker_idx = action.pose_markers_index
        if marker_idx < 0 or marker_idx >= len(action.pose_markers):
            self.report({'WARNING'}, "No pose marker selected")
            return {'CANCELLED'}

        marker = action.pose_markers[marker_idx]
        context.scene.frame_current = marker.frame

        if self.frame_view:
            # Frame view in animation editors
            editor_types = ['DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR']
            for area in context.screen.areas:
                if area.type in editor_types:
                    for region in area.regions:
                        if region.type == 'WINDOW':
                            ctx = context.copy()
                            ctx['area'] = area
                            ctx['region'] = region
                            with context.temp_override(**ctx):
                                if area.type == 'DOPESHEET_EDITOR':
                                    bpy.ops.action.view_frame()
                                elif area.type == 'GRAPH_EDITOR':
                                    bpy.ops.graph.view_frame()
                                elif area.type == 'NLA_EDITOR':
                                    bpy.ops.nla.view_frame()

        return {'FINISHED'}


class MHS_MT_pose_marker_extras_menu(Menu):
    """Extras menu for pose markers"""
    bl_idname = "MHS_MT_pose_marker_extras_menu"
    bl_label = "Pose Marker Extras"

    def draw(self, context):
        layout = self.layout

        layout.operator("mhs.add_pose_marker", text="Add Marker", icon='ADD')
        layout.operator("mhs.remove_pose_marker", text="Remove Marker", icon='REMOVE')

        layout.separator()

        layout.operator("mhs.move_to_pose_marker", text="Move to Marker", icon='TIME')
        layout.operator("mhs.rename_pose_marker", text="Rename Marker", icon='FONT_DATA')

        layout.separator()

        layout.operator("mhs.clear_all_pose_markers", text="Clear All Markers", icon='TRASH')


class MHS_OT_rename_pose_marker(Operator):
    """Rename the active pose marker"""
    bl_idname = "mhs.rename_pose_marker"
    bl_label = "Rename Pose Marker"
    bl_description = "Rename the active pose marker"
    bl_options = {'REGISTER', 'UNDO'}

    new_name: StringProperty(
        name="New Name",
        default="",
        description="New name for the pose marker"
    )

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        if not armature.mhs.animation_export_actions:
            return False
        idx = armature.mhs.active_animation_action_index
        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            return False
        action_item = armature.mhs.animation_export_actions[idx]
        if not action_item.action:
            return False
        return len(action_item.action.pose_markers) > 0

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def invoke(self, context, event):
        armature = self._get_armature_static(context)
        idx = armature.mhs.active_animation_action_index
        action = armature.mhs.animation_export_actions[idx].action
        marker = action.pose_markers[action.pose_markers_index]
        self.new_name = marker.name
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        armature = self._get_armature_static(context)
        idx = armature.mhs.active_animation_action_index
        action = armature.mhs.animation_export_actions[idx].action
        marker = action.pose_markers[action.pose_markers_index]
        marker.name = self.new_name
        self.report({'INFO'}, f"Renamed marker to '{self.new_name}'")
        return {'FINISHED'}


class MHS_OT_clear_all_pose_markers(Operator):
    """Remove all pose markers from the action"""
    bl_idname = "mhs.clear_all_pose_markers"
    bl_label = "Clear All Pose Markers"
    bl_description = "Remove all pose markers from this action"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        armature = cls._get_armature_static(context)
        if not armature:
            return False
        if not armature.mhs.animation_export_actions:
            return False
        idx = armature.mhs.active_animation_action_index
        if idx < 0 or idx >= len(armature.mhs.animation_export_actions):
            return False
        action_item = armature.mhs.animation_export_actions[idx]
        if not action_item.action:
            return False
        return len(action_item.action.pose_markers) > 0

    @staticmethod
    def _get_armature_static(context):
        obj = context.active_object
        if not obj:
            return None
        if obj.type == 'ARMATURE':
            return obj
        elif obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object:
                    return modifier.object
        return None

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        armature = self._get_armature_static(context)
        idx = armature.mhs.active_animation_action_index
        action = armature.mhs.animation_export_actions[idx].action

        count = len(action.pose_markers)
        while action.pose_markers:
            action.pose_markers.remove(action.pose_markers[0])

        self.report({'INFO'}, f"Removed {count} pose markers")
        return {'FINISHED'}


def register():
    bpy.utils.register_class(MHS_OT_refresh_evaluated_mesh)
    bpy.utils.register_class(MHS_OT_export_layout)
    bpy.utils.register_class(MHS_OT_export_mesh)
    bpy.utils.register_class(MHS_OT_export_animated_selection)
    bpy.utils.register_class(MHS_OT_open_export_folder)
    bpy.utils.register_class(MHS_OT_lod_add)
    bpy.utils.register_class(MHS_OT_lod_remove)
    bpy.utils.register_class(MHS_OT_material_slot_move)
    bpy.utils.register_class(MHS_OT_create_lightmap_uvs)
    bpy.utils.register_class(MHS_OT_bake_lightmap)
    bpy.utils.register_class(MHS_OT_add_lightmap_group)
    bpy.utils.register_class(MHS_OT_remove_lightmap_group)
    bpy.utils.register_class(MHS_OT_add_to_lightmap_group)
    bpy.utils.register_class(MHS_OT_remove_from_lightmap_group)
    bpy.utils.register_class(MHS_OT_select_lightmap_group)
    bpy.utils.register_class(MHS_OT_clear_empty_lightmap_groups)
    bpy.utils.register_class(MHS_OT_check_bake_status)
    bpy.utils.register_class(MHS_OT_format_material_nodes)
    bpy.utils.register_class(MHS_OT_lightmap_toggle_uv)
    bpy.utils.register_class(MHS_OT_create_material)
    bpy.utils.register_class(MHS_OT_initialize_material)
    bpy.utils.register_class(MHS_OT_add_layout_export)
    bpy.utils.register_class(MHS_OT_remove_layout_export)
    bpy.utils.register_class(MHS_OT_add_collection_to_layout)
    bpy.utils.register_class(MHS_OT_remove_collection_from_layout)
    bpy.utils.register_class(MHS_OT_export_single_layout)
    bpy.utils.register_class(MHS_OT_toggle_layout_visibility)
    bpy.utils.register_class(MHS_OT_solo_layout_visibility)
    bpy.utils.register_class(MHS_OT_toggle_animated_object_visibility)
    bpy.utils.register_class(MHS_OT_solo_animated_object_visibility)
    bpy.utils.register_class(MHS_OT_clear_cache)
    bpy.utils.register_class(MHS_OT_toggle_force_rebuild)
    bpy.utils.register_class(MHS_OT_show_export_results)
    bpy.utils.register_class(MHS_OT_export_notification)
    bpy.utils.register_class(MHS_OT_purge_project)
    bpy.utils.register_class(MHS_OT_reset_folder_paths)
    # MHS Material System
    bpy.utils.register_class(MHS_OT_rebuild_shader)
    bpy.utils.register_class(MHS_OT_assign_texture)
    bpy.utils.register_class(MHS_OT_remove_texture)
    bpy.utils.register_class(MHS_OT_add_color_attribute)
    bpy.utils.register_class(MHS_OT_disconnect_vertex_color)
    bpy.utils.register_class(MHS_OT_sync_vertex_color_name)
    bpy.utils.register_class(MHS_OT_connect_vertex_color)
    # Layout Setup Pie Menu Operators
    bpy.utils.register_class(MHS_OT_export_active_layout)
    bpy.utils.register_class(MHS_OT_create_collection_from_selection)
    bpy.utils.register_class(MHS_OT_add_selection_to_active_layout)
    bpy.utils.register_class(MHS_OT_remove_selection_from_active_layout)
    bpy.utils.register_class(MHS_OT_toggle_layout_enabled)
    bpy.utils.register_class(MHS_OT_add_selection_to_collection)
    bpy.utils.register_class(MHS_OT_remove_selection_from_collection)
    bpy.utils.register_class(MHS_OT_invoke_move_to_collection)
    bpy.utils.register_class(MHS_OT_move_selection_to_collection)
    bpy.utils.register_class(MHS_OT_select_layout)
    # Animation Action Management Operators
    bpy.utils.register_class(MHS_OT_add_action_label)
    bpy.utils.register_class(MHS_OT_reorder_action)
    bpy.utils.register_class(MHS_OT_batch_tag_actions)
    bpy.utils.register_class(MHS_OT_batch_enable_actions)
    bpy.utils.register_class(MHS_OT_play_action)
    bpy.utils.register_class(MHS_OT_stop_action)
    bpy.utils.register_class(MHS_OT_clean_action_list)
    bpy.utils.register_class(MHS_OT_load_action)
    bpy.utils.register_class(MHS_OT_load_all_actions)
    bpy.utils.register_class(MHS_OT_load_actions_toggle_item)
    bpy.utils.register_class(MHS_OT_load_actions_batch_select)
    bpy.utils.register_class(MHS_OT_load_actions_duplicate_item)
    bpy.utils.register_class(MHS_OT_load_actions_duplicate_all)
    bpy.utils.register_class(MHS_OT_load_actions_load_all)
    bpy.utils.register_class(MHS_OT_add_active_action)
    bpy.utils.register_class(MHS_OT_append_action_from_file)
    bpy.utils.register_class(MHS_OT_push_action_to_nla)
    bpy.utils.register_class(MHS_OT_duplicate_action)
    bpy.utils.register_class(MHS_OT_flip_action)
    bpy.utils.register_class(MHS_OT_bake_action)
    bpy.utils.register_class(MHS_OT_bake_action_generate_name)
    bpy.utils.register_class(MHS_OT_new_action)
    # Pose Marker Operators
    bpy.utils.register_class(MHS_OT_reorder_pose_marker)
    bpy.utils.register_class(MHS_OT_add_pose_marker)
    bpy.utils.register_class(MHS_OT_remove_pose_marker)
    bpy.utils.register_class(MHS_OT_move_to_pose_marker)
    bpy.utils.register_class(MHS_MT_pose_marker_extras_menu)
    bpy.utils.register_class(MHS_OT_rename_pose_marker)
    bpy.utils.register_class(MHS_OT_clear_all_pose_markers)


def unregister():
    # Pose Marker Operators
    bpy.utils.unregister_class(MHS_OT_clear_all_pose_markers)
    bpy.utils.unregister_class(MHS_OT_rename_pose_marker)
    bpy.utils.unregister_class(MHS_MT_pose_marker_extras_menu)
    bpy.utils.unregister_class(MHS_OT_move_to_pose_marker)
    bpy.utils.unregister_class(MHS_OT_remove_pose_marker)
    bpy.utils.unregister_class(MHS_OT_add_pose_marker)
    bpy.utils.unregister_class(MHS_OT_reorder_pose_marker)
    # Animation Action Management Operators
    bpy.utils.unregister_class(MHS_OT_new_action)
    bpy.utils.unregister_class(MHS_OT_bake_action_generate_name)
    bpy.utils.unregister_class(MHS_OT_bake_action)
    bpy.utils.unregister_class(MHS_OT_flip_action)
    bpy.utils.unregister_class(MHS_OT_duplicate_action)
    bpy.utils.unregister_class(MHS_OT_push_action_to_nla)
    bpy.utils.unregister_class(MHS_OT_append_action_from_file)
    bpy.utils.unregister_class(MHS_OT_add_active_action)
    bpy.utils.unregister_class(MHS_OT_load_actions_load_all)
    bpy.utils.unregister_class(MHS_OT_load_actions_duplicate_all)
    bpy.utils.unregister_class(MHS_OT_load_actions_duplicate_item)
    bpy.utils.unregister_class(MHS_OT_load_actions_batch_select)
    bpy.utils.unregister_class(MHS_OT_load_actions_toggle_item)
    bpy.utils.unregister_class(MHS_OT_load_all_actions)
    bpy.utils.unregister_class(MHS_OT_load_action)
    bpy.utils.unregister_class(MHS_OT_clean_action_list)
    bpy.utils.unregister_class(MHS_OT_stop_action)
    bpy.utils.unregister_class(MHS_OT_play_action)
    bpy.utils.unregister_class(MHS_OT_batch_enable_actions)
    bpy.utils.unregister_class(MHS_OT_batch_tag_actions)
    bpy.utils.unregister_class(MHS_OT_reorder_action)
    bpy.utils.unregister_class(MHS_OT_add_action_label)
    # Layout Setup Pie Menu Operators
    bpy.utils.unregister_class(MHS_OT_select_layout)
    bpy.utils.unregister_class(MHS_OT_move_selection_to_collection)
    bpy.utils.unregister_class(MHS_OT_invoke_move_to_collection)
    bpy.utils.unregister_class(MHS_OT_remove_selection_from_collection)
    bpy.utils.unregister_class(MHS_OT_add_selection_to_collection)
    bpy.utils.unregister_class(MHS_OT_toggle_layout_enabled)
    bpy.utils.unregister_class(MHS_OT_remove_selection_from_active_layout)
    bpy.utils.unregister_class(MHS_OT_add_selection_to_active_layout)
    bpy.utils.unregister_class(MHS_OT_create_collection_from_selection)
    bpy.utils.unregister_class(MHS_OT_export_active_layout)
    # MHS Material System
    bpy.utils.unregister_class(MHS_OT_connect_vertex_color)
    bpy.utils.unregister_class(MHS_OT_sync_vertex_color_name)
    bpy.utils.unregister_class(MHS_OT_disconnect_vertex_color)
    bpy.utils.unregister_class(MHS_OT_add_color_attribute)
    bpy.utils.unregister_class(MHS_OT_remove_texture)
    bpy.utils.unregister_class(MHS_OT_assign_texture)
    bpy.utils.unregister_class(MHS_OT_rebuild_shader)
    bpy.utils.unregister_class(MHS_OT_reset_folder_paths)
    bpy.utils.unregister_class(MHS_OT_purge_project)
    bpy.utils.unregister_class(MHS_OT_export_notification)
    bpy.utils.unregister_class(MHS_OT_show_export_results)
    bpy.utils.unregister_class(MHS_OT_toggle_force_rebuild)
    bpy.utils.unregister_class(MHS_OT_clear_cache)
    bpy.utils.unregister_class(MHS_OT_solo_animated_object_visibility)
    bpy.utils.unregister_class(MHS_OT_toggle_animated_object_visibility)
    bpy.utils.unregister_class(MHS_OT_solo_layout_visibility)
    bpy.utils.unregister_class(MHS_OT_toggle_layout_visibility)
    bpy.utils.unregister_class(MHS_OT_export_single_layout)
    bpy.utils.unregister_class(MHS_OT_remove_collection_from_layout)
    bpy.utils.unregister_class(MHS_OT_add_collection_to_layout)
    bpy.utils.unregister_class(MHS_OT_remove_layout_export)
    bpy.utils.unregister_class(MHS_OT_add_layout_export)
    bpy.utils.unregister_class(MHS_OT_initialize_material)
    bpy.utils.unregister_class(MHS_OT_create_material)
    bpy.utils.unregister_class(MHS_OT_lightmap_toggle_uv)
    bpy.utils.unregister_class(MHS_OT_format_material_nodes)
    bpy.utils.unregister_class(MHS_OT_check_bake_status)
    bpy.utils.unregister_class(MHS_OT_clear_empty_lightmap_groups)
    bpy.utils.unregister_class(MHS_OT_select_lightmap_group)
    bpy.utils.unregister_class(MHS_OT_remove_from_lightmap_group)
    bpy.utils.unregister_class(MHS_OT_add_to_lightmap_group)
    bpy.utils.unregister_class(MHS_OT_remove_lightmap_group)
    bpy.utils.unregister_class(MHS_OT_add_lightmap_group)
    bpy.utils.unregister_class(MHS_OT_bake_lightmap)
    bpy.utils.unregister_class(MHS_OT_create_lightmap_uvs)
    bpy.utils.unregister_class(MHS_OT_material_slot_move)
    bpy.utils.unregister_class(MHS_OT_lod_remove)
    bpy.utils.unregister_class(MHS_OT_lod_add)
    bpy.utils.unregister_class(MHS_OT_open_export_folder)
    bpy.utils.unregister_class(MHS_OT_export_animated_selection)
    bpy.utils.unregister_class(MHS_OT_export_mesh)
    bpy.utils.unregister_class(MHS_OT_export_layout)
    bpy.utils.unregister_class(MHS_OT_refresh_evaluated_mesh)
