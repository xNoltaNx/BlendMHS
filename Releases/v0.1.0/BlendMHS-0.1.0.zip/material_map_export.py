"""
MaterialMap Export Module

This module contains PropertyGroups, UI panels, and operators for
MaterialMap and shader export functionality.
"""

import bpy
import os
from bpy.props import (
    StringProperty,
    BoolProperty,
    EnumProperty,
    PointerProperty,
    CollectionProperty,
)
from bpy.types import PropertyGroup, Operator, Panel

from .material_map import (
    MaterialMapGenerator,
    get_mhs_materials,
    generate_preview_json,
    validate_material_map,
    format_validation_result,
)
from .material_map.introspection import introspect_material
from .shader_gen import ShaderBoilerplateGenerator


# ═══════════════════════════════════════════════════════════════════════════════
# PROPERTY GROUPS
# ═══════════════════════════════════════════════════════════════════════════════

class MHS_AdditionalImportItem(PropertyGroup):
    """Single additional import path"""
    path: StringProperty(
        name="Import Path",
        description="Path to additional materialMap import",
        default=""
    )


class MHS_MaterialMapSettings(PropertyGroup):
    """Settings for materialMap.json export"""

    # Note: output_path now uses project_path from scene.mhs
    # materialMap.json is exported directly to project_path

    shader_target_base: StringProperty(
        name="Shader Target Base",
        description="Base path for shader references in materialMap",
        default="shaders"
    )

    # Default import enabled by default
    import_renderer_module: BoolProperty(
        name="Import Renderer Module MaterialMap",
        description="Include 'meta/renderer_module@materialMap.json' in imports (recommended)",
        default=True
    )

    # Additional imports as a list
    use_additional_imports: BoolProperty(
        name="Use Additional Imports",
        description="Enable additional materialMap imports",
        default=False
    )

    additional_imports: CollectionProperty(
        type=MHS_AdditionalImportItem,
        name="Additional Imports",
        description="List of additional materialMap imports"
    )

    additional_imports_index: bpy.props.IntProperty(
        name="Active Import Index",
        default=0
    )

    # Shader generation settings
    shader_subfolder: StringProperty(
        name="Shader Subfolder",
        description="Subfolder within project path for generated shaders",
        default="shaders"
    )


def get_project_path(context):
    """Get the project path from scene settings"""
    project_path = context.scene.mhs.project_path
    if project_path:
        return bpy.path.abspath(project_path)
    return ""


def get_material_map_output_path(context):
    """Get the full path for materialMap.json output"""
    project_path = get_project_path(context)
    if project_path:
        return os.path.join(project_path, "materialMap.json")
    return ""


def get_shader_output_path(context):
    """Get the full path for shader output directory"""
    project_path = get_project_path(context)
    settings = context.scene.mhs.material_map_settings
    if project_path and settings.shader_subfolder:
        return os.path.join(project_path, settings.shader_subfolder)
    return project_path


# ═══════════════════════════════════════════════════════════════════════════════
# OPERATORS
# ═══════════════════════════════════════════════════════════════════════════════

class MHS_OT_export_material_map(Operator):
    """Export materialMap.json from current scene materials"""
    bl_idname = "mhs.export_material_map"
    bl_label = "Export MaterialMap"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        # Check if there are any MHS materials and project path is set
        project_path = get_project_path(context)
        return len(get_mhs_materials()) > 0 and bool(project_path)

    def execute(self, context):
        settings = context.scene.mhs.material_map_settings

        # Create generator
        generator = MaterialMapGenerator(
            shader_target_base=settings.shader_target_base
        )

        # Parse additional imports from the list
        additional_imports = None
        if settings.use_additional_imports and len(settings.additional_imports) > 0:
            additional_imports = [
                item.path for item in settings.additional_imports if item.path.strip()
            ]

        # Generate from scene
        material_map = generator.generate_from_scene(
            context.scene,
            include_renderer_module_import=settings.import_renderer_module,
            additional_imports=additional_imports
        )

        # Validate before export
        validation_result = validate_material_map(material_map)
        if not validation_result.is_valid:
            self.report({'WARNING'}, format_validation_result(validation_result))

        # Export to project path
        output_path = get_material_map_output_path(context)
        if not output_path:
            self.report({'ERROR'}, "Project path not set")
            return {'CANCELLED'}

        success = generator.export_material_map(material_map, output_path)

        if success:
            self.report({'INFO'}, f"Exported materialMap to: {output_path}")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "Failed to export materialMap")
            return {'CANCELLED'}


class MHS_OT_preview_material_map(Operator):
    """Preview the materialMap.json that would be generated"""
    bl_idname = "mhs.preview_material_map"
    bl_label = "Preview MaterialMap"
    bl_options = {'REGISTER'}

    def execute(self, context):
        preview = generate_preview_json(context.scene)

        # Create or update a text block in Blender
        text_name = "MaterialMap Preview"
        if text_name in bpy.data.texts:
            text_block = bpy.data.texts[text_name]
            text_block.clear()
        else:
            text_block = bpy.data.texts.new(text_name)

        text_block.write(preview)

        # Move cursor to the beginning of the text and clear selection
        text_block.current_line_index = 0
        text_block.current_character = 0
        text_block.select_end_line_index = 0
        text_block.select_end_character = 0

        # Try to open in a text editor
        # First, look for an existing text editor area
        text_editor_area = None
        for area in context.screen.areas:
            if area.type == 'TEXT_EDITOR':
                text_editor_area = area
                break

        if text_editor_area:
            # Use existing text editor
            text_editor_area.spaces[0].text = text_block
            # Scroll to top
            text_editor_area.spaces[0].top = 0
            self.report({'INFO'}, "MaterialMap preview opened in Text Editor")
        else:
            # Find the 3D view to split
            view_3d_area = None
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    view_3d_area = area
                    break

            if view_3d_area:
                # Split the 3D view horizontally and create a text editor
                try:
                    # Store original area count
                    original_area_count = len(context.screen.areas)

                    # Override context to split the 3D view
                    with context.temp_override(area=view_3d_area):
                        bpy.ops.screen.area_split(direction='VERTICAL', factor=0.5)

                    # Find the new area (should be the last one or the one that's VIEW_3D but smaller)
                    if len(context.screen.areas) > original_area_count:
                        # Find the newly created area
                        for area in context.screen.areas:
                            if area.type == 'VIEW_3D' and area != view_3d_area:
                                area.type = 'TEXT_EDITOR'
                                area.spaces[0].text = text_block
                                # Scroll to top
                                area.spaces[0].top = 0
                                self.report({'INFO'}, "MaterialMap preview opened in new Text Editor")
                                break
                    else:
                        # Fallback - the split may have modified the original area
                        self.report({'INFO'}, f"MaterialMap preview created in text block '{text_name}'. Open a Text Editor to view.")
                except Exception as e:
                    self.report({'INFO'}, f"MaterialMap preview created in text block '{text_name}'. Open a Text Editor to view.")
            else:
                self.report({'INFO'}, f"MaterialMap preview created in text block '{text_name}'. Open a Text Editor to view.")

        return {'FINISHED'}


class MHS_ShaderExportItem(PropertyGroup):
    """Item for shader export selection"""
    name: StringProperty(name="Shader Name")
    selected: BoolProperty(name="Export", default=True)
    exists: BoolProperty(name="File Exists", default=False)


class MHS_ShaderExportSettings(PropertyGroup):
    """Settings for shader export dialog"""
    items: CollectionProperty(type=MHS_ShaderExportItem)


class MHS_OT_generate_all_shaders(Operator):
    """Generate .surface shader boilerplate files for all MHS materials"""
    bl_idname = "mhs.generate_all_shaders"
    bl_label = "Generate Boilerplate for All Shaders"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        # Check if there are any MHS materials and project path is set
        project_path = get_project_path(context)
        return len(get_mhs_materials()) > 0 and bool(project_path)

    def invoke(self, context, event):
        # Build list of shaders to potentially export
        shader_output_dir = get_shader_output_path(context)

        # Use scene-level property for items so other operators can access them
        export_settings = context.scene.mhs_shader_export
        export_settings.items.clear()

        # Track unique shaders
        seen_shaders = set()

        for mat in get_mhs_materials():
            shader_def = introspect_material(mat)
            if shader_def and shader_def.name not in seen_shaders:
                seen_shaders.add(shader_def.name)

                item = export_settings.items.add()
                item.name = shader_def.name
                item.selected = True

                # Check if file exists
                filename = shader_def.name.replace("MHS_", "").lower() + ".surface"
                filepath = os.path.join(shader_output_dir, filename)
                item.exists = os.path.exists(filepath)

        # Always show the dialog so user can select which shaders to generate
        return context.window_manager.invoke_props_dialog(self, width=450)

    def draw(self, context):
        layout = self.layout
        export_settings = context.scene.mhs_shader_export

        # Count existing files
        existing_count = sum(1 for item in export_settings.items if item.exists and item.selected)

        if existing_count > 0:
            layout.label(text=f"⚠️ {existing_count} shader file(s) will be overwritten!", icon='ERROR')
            layout.separator()

        layout.label(text="Select shaders to generate:", icon='FILE_SCRIPT')

        box = layout.box()
        for item in export_settings.items:
            row = box.row(align=True)
            row.prop(item, "selected", text="")

            # Show shader name with appropriate icon
            if item.exists:
                row.label(text=item.name, icon='FILE_REFRESH')
                row.label(text="(exists)", icon='ERROR')
            else:
                row.label(text=item.name, icon='FILE_NEW')
                row.label(text="(new)", icon='ADD')

        layout.separator()

        # Select all / none buttons
        row = layout.row(align=True)
        row.operator("mhs.select_all_shaders", text="Select All").select_all = True
        row.operator("mhs.select_all_shaders", text="Select None").select_all = False

        if existing_count > 0:
            layout.separator()
            layout.label(text="Overwriting may break existing shader customizations.")

    def execute(self, context):
        shader_output_dir = get_shader_output_path(context)
        export_settings = context.scene.mhs_shader_export

        # Ensure directory exists
        if not os.path.exists(shader_output_dir):
            os.makedirs(shader_output_dir)

        shader_gen = ShaderBoilerplateGenerator(
            output_directory=shader_output_dir
        )

        # Get selected shader names
        selected_shaders = {item.name for item in export_settings.items if item.selected}

        if not selected_shaders:
            self.report({'WARNING'}, "No shaders selected")
            return {'CANCELLED'}

        generated_count = 0
        skipped_count = 0

        for mat in get_mhs_materials():
            shader_def = introspect_material(mat)
            if shader_def and shader_def.name in selected_shaders:
                selected_shaders.discard(shader_def.name)  # Only process each shader once
                try:
                    shader_gen.export_shader(shader_def)
                    generated_count += 1
                except Exception as e:
                    self.report({'WARNING'}, f"Failed to generate shader for {shader_def.name}: {e}")
                    skipped_count += 1

        self.report({'INFO'}, f"Generated {generated_count} shader file(s) to: {shader_output_dir}")
        return {'FINISHED'}


class MHS_OT_select_all_shaders(Operator):
    """Select or deselect all shaders"""
    bl_idname = "mhs.select_all_shaders"
    bl_label = "Select All Shaders"
    bl_options = {'INTERNAL'}

    select_all: BoolProperty(default=True)

    def execute(self, context):
        export_settings = context.scene.mhs_shader_export
        for item in export_settings.items:
            item.selected = self.select_all
        return {'FINISHED'}


class MHS_OT_open_material_map(Operator):
    """Open the materialMap.json file in the default application"""
    bl_idname = "mhs.open_material_map"
    bl_label = "Open MaterialMap"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        # Check if materialMap.json exists
        output_path = get_material_map_output_path(context)
        return output_path and os.path.exists(output_path)

    def execute(self, context):
        import subprocess
        import platform

        output_path = get_material_map_output_path(context)
        if not output_path or not os.path.exists(output_path):
            self.report({'ERROR'}, "materialMap.json does not exist")
            return {'CANCELLED'}

        try:
            if platform.system() == 'Windows':
                os.startfile(output_path)
            elif platform.system() == 'Darwin':  # macOS
                subprocess.run(['open', output_path])
            else:  # Linux
                subprocess.run(['xdg-open', output_path])

            self.report({'INFO'}, f"Opened: {output_path}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to open file: {e}")
            return {'CANCELLED'}


class MHS_OT_add_additional_import(Operator):
    """Add a new additional import path"""
    bl_idname = "mhs.add_additional_import"
    bl_label = "Add Import"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.mhs.material_map_settings
        item = settings.additional_imports.add()
        item.path = "path/to/materialMap.json"
        settings.additional_imports_index = len(settings.additional_imports) - 1
        return {'FINISHED'}


class MHS_OT_remove_additional_import(Operator):
    """Remove the selected additional import path"""
    bl_idname = "mhs.remove_additional_import"
    bl_label = "Remove Import"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        settings = context.scene.mhs.material_map_settings
        return len(settings.additional_imports) > 0

    def execute(self, context):
        settings = context.scene.mhs.material_map_settings
        idx = settings.additional_imports_index

        if 0 <= idx < len(settings.additional_imports):
            settings.additional_imports.remove(idx)
            # Adjust index if needed
            if settings.additional_imports_index >= len(settings.additional_imports):
                settings.additional_imports_index = max(0, len(settings.additional_imports) - 1)

        return {'FINISHED'}


# ═══════════════════════════════════════════════════════════════════════════════
# UI PANELS
# ═══════════════════════════════════════════════════════════════════════════════

class MHS_PT_material_map_export_panel(Panel):
    """Panel for MaterialMap export settings"""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BlendMHS"
    bl_label = "MaterialMap Export"
    bl_parent_id = "MHS_PT_base_panel"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        prefs = context.preferences.addons.get('BlendMHS')
        if prefs is None:
            return False
        return prefs.preferences.advanced_mode

    def draw_header(self, context):
        self.layout.label(icon='FILEBROWSER')

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        settings = scene.mhs.material_map_settings

        # Check if project path is set
        project_path = get_project_path(context)

        # Output paths display
        box = layout.box()
        box.label(text="Export Paths", icon='EXPORT')

        col = box.column()

        if project_path:
            # Show where materialMap.json will be saved
            material_map_path = get_material_map_output_path(context)
            col.label(text=f"MaterialMap: {material_map_path}", icon='FILE')
        else:
            col.label(text="Set Project Path above!", icon='ERROR')

        col.prop(settings, "shader_target_base")

        # Import settings
        box = layout.box()
        box.label(text="MaterialMap Imports", icon='LINKED')

        col = box.column()

        # Info about what the import does (show first)
        info_box = col.box()
        info_box.scale_y = 0.8
        info_box.label(text="Inherits default shaders from renderer module", icon='INFO')

        # Default import toggle (ON by default, recommended)
        row = col.row()
        row.prop(settings, "import_renderer_module")
        if settings.import_renderer_module:
            row.label(text="", icon='CHECKMARK')

        # Additional imports
        col.separator()
        row = col.row()
        row.prop(settings, "use_additional_imports")

        if settings.use_additional_imports:
            # List of additional imports
            import_box = col.box()
            for idx, item in enumerate(settings.additional_imports):
                row = import_box.row(align=True)
                row.prop(item, "path", text="")
                # Highlight selected item
                if idx == settings.additional_imports_index:
                    remove_op = row.operator("mhs.remove_additional_import", icon='X', text="")

            # Add button
            row = import_box.row()
            row.operator("mhs.add_additional_import", icon='ADD', text="Add Import")

        # Materials to export (show list of MHS materials in scene)
        box = layout.box()
        box.label(text="Material → Shader Mappings", icon='MATERIAL')

        # List materials that have MHS formats set
        mhs_materials = get_mhs_materials()

        if mhs_materials:
            for mat in mhs_materials:
                row = box.row()
                row.label(text=mat.name, icon='MATERIAL')
                row.label(text="→")
                row.label(text=mat.mhs.material_format, icon='NODE_MATERIAL')
        else:
            box.label(text="No MHS materials found", icon='ERROR')

        # Shader generation options
        box = layout.box()
        box.label(text="Shader Generation", icon='FILE_SCRIPT')

        col = box.column()
        col.prop(settings, "shader_subfolder")
        # Show full shader output path
        if project_path:
            shader_path = get_shader_output_path(context)
            col.label(text=f"Output: {shader_path}", icon='FILE_FOLDER')

        row = box.row()
        row.scale_y = 1.5
        row.enabled = len(mhs_materials) > 0 and bool(project_path)
        row.operator("mhs.generate_all_shaders", icon='FILE_SCRIPT', text="Generate Boilerplate for All Shaders")

        # Export buttons
        layout.separator()

        row = layout.row()
        row.operator("mhs.preview_material_map", icon='VIEWZOOM', text="Preview")

        row = layout.row(align=True)
        row.scale_y = 2.0
        row.enabled = len(mhs_materials) > 0 and bool(project_path)
        row.operator("mhs.export_material_map", icon='EXPORT', text="Export MaterialMap")
        row.operator("mhs.open_material_map", icon='FILE_FOLDER', text="")


# ═══════════════════════════════════════════════════════════════════════════════
# REGISTRATION
# ═══════════════════════════════════════════════════════════════════════════════

# PropertyGroups and Operators (register before UI panels)
property_classes = [
    MHS_AdditionalImportItem,
    MHS_MaterialMapSettings,
    MHS_ShaderExportItem,
    MHS_ShaderExportSettings,
    MHS_OT_export_material_map,
    MHS_OT_preview_material_map,
    MHS_OT_generate_all_shaders,
    MHS_OT_select_all_shaders,
    MHS_OT_open_material_map,
    MHS_OT_add_additional_import,
    MHS_OT_remove_additional_import,
]

# UI classes (register after MHS_PT_base_panel exists)
panel_classes = [
    MHS_PT_material_map_export_panel,
]


def register_property_groups():
    """Register PropertyGroups and Operators (call before UI panels)"""
    for cls in property_classes:
        bpy.utils.register_class(cls)


def register_panels():
    """Register UI panels (call after MHS_PT_base_panel is registered)"""
    for cls in panel_classes:
        bpy.utils.register_class(cls)


def register():
    """Full registration (for standalone use)"""
    register_property_groups()
    register_panels()


def unregister():
    for cls in reversed(panel_classes):
        bpy.utils.unregister_class(cls)
    for cls in reversed(property_classes):
        bpy.utils.unregister_class(cls)
