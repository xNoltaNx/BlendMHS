import math
import bpy
import numpy as np
import re
from contextlib import contextmanager
from enum import Enum
from typing import Optional


class LogCategory(Enum):
    """Debug log categories for filtering"""
    # Export system
    EXPORT_LAYOUT = "EXPORT.LAYOUT"
    EXPORT_MESH = "EXPORT.MESH"
    EXPORT_HIERARCHY = "EXPORT.HIERARCHY"
    EXPORT_TRANSFORM = "EXPORT.TRANSFORM"
    EXPORT_REFERENCE = "EXPORT.REFERENCE"

    # Skeleton system
    SKELETON_JOINTS = "SKELETON.JOINTS"
    SKELETON_WEIGHTS = "SKELETON.WEIGHTS"
    SKELETON_ANIMATION = "SKELETON.ANIMATION"

    # Geometry Nodes
    GEOMNODES_INSTANCES = "GEOMNODES.INSTANCES"
    GEOMNODES_SOURCES = "GEOMNODES.SOURCES"

    # Cache system
    CACHE_LOAD = "CACHE.LOAD"
    CACHE_SAVE = "CACHE.SAVE"
    CACHE_HIT = "CACHE.HIT"
    CACHE_STATS = "CACHE.STATS"

    # Material system
    MATERIAL_SETUP = "MATERIAL.SETUP"
    MATERIAL_GROUPS = "MATERIAL.GROUPS"
    MATERIAL_LIGHTMAP = "MATERIAL.LIGHTMAP"

    # MaterialMap
    MATERIALMAP_EXPORT = "MATERIALMAP.EXPORT"
    MATERIALMAP_GENERATE = "MATERIALMAP.GENERATE"

    # Shader generation
    SHADER_GENERATE = "SHADER.GENERATE"

    # Initialization
    INIT_INSTALL = "INIT.INSTALL"
    INIT_REGISTER = "INIT.REGISTER"


def debug_log(message: str, category: LogCategory = None, context=None):
    """Print debug message only if debug logging is enabled.

    Args:
        message: The debug message to print
        category: LogCategory enum value for filtering
        context: Optional Blender context (unused, kept for API compatibility)

    Example:
        debug_log("Exporting mesh", LogCategory.EXPORT_MESH)
        # Output: [BlendMHS.EXPORT.MESH] Exporting mesh
    """
    try:
        # Get debug logging setting from addon preferences
        prefs = bpy.context.preferences.addons.get(__package__)
        if not prefs or not prefs.preferences.enable_debug_logging:
            return

        # Format the message with category prefix
        if category:
            prefix = f"[BlendMHS.{category.value}]"
        else:
            prefix = "[BlendMHS]"

        print(f"{prefix} {message}")

    except Exception:
        # Silently fail if preferences are not available (e.g., during registration)
        pass


def debug_log_stats(title: str, stats: dict, category: LogCategory = None, context=None):
    """Print formatted statistics block.

    Args:
        title: Title for the stats block
        stats: Dictionary of stat_name: value pairs
        category: LogCategory for filtering
        context: Optional Blender context (unused, kept for API compatibility)
    """
    try:
        # Get debug logging setting from addon preferences
        prefs = bpy.context.preferences.addons.get(__package__)
        if not prefs or not prefs.preferences.enable_debug_logging:
            return

        prefix = f"[BlendMHS.{category.value}]" if category else "[BlendMHS]"

        print(f"\n{prefix} {'=' * 40}")
        print(f"{prefix} {title}")
        print(f"{prefix} {'=' * 40}")
        for key, value in stats.items():
            print(f"{prefix}   {key}: {value}")
        print(f"{prefix} {'=' * 40}\n")

    except Exception:
        pass

# Import cv2 lazily to avoid numpy version conflicts
def get_cv2():
    """Lazy import of cv2 to avoid numpy version conflicts"""
    try:
        import cv2
        return cv2
    except ImportError as e:
        print(f"Warning: Could not import cv2: {e}")
        return None

@contextmanager
def ensure_object_mode(context):
    """
    Context manager to ensure operations happen in OBJECT mode and restore the original mode.

    Usage:
        with ensure_object_mode(context):
            # Your code here runs in OBJECT mode
            pass
        # Original mode is restored automatically
    """
    # Mode mapping from context.mode to bpy.ops.object.mode_set() mode strings
    MODE_MAP = {
        'EDIT_MESH': 'EDIT',
        'EDIT_CURVE': 'EDIT',
        'EDIT_SURFACE': 'EDIT',
        'EDIT_TEXT': 'EDIT',
        'EDIT_ARMATURE': 'EDIT',
        'EDIT_METABALL': 'EDIT',
        'EDIT_LATTICE': 'EDIT',
        'POSE': 'POSE',
        'SCULPT': 'SCULPT',
        'PAINT_WEIGHT': 'WEIGHT_PAINT',
        'PAINT_VERTEX': 'VERTEX_PAINT',
        'PAINT_TEXTURE': 'TEXTURE_PAINT',
        'PARTICLE': 'PARTICLE_EDIT',
        'PAINT_GPENCIL': 'PAINT_GPENCIL',
        'EDIT_GPENCIL': 'EDIT_GPENCIL',
        'SCULPT_GPENCIL': 'SCULPT_GPENCIL',
        'WEIGHT_GPENCIL': 'WEIGHT_GPENCIL',
        'VERTEX_GPENCIL': 'VERTEX_GPENCIL'
    }

    # Save the original mode
    original_mode = context.mode

    # Switch to object mode if not already
    if original_mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    try:
        yield
    finally:
        # Restore original mode
        if original_mode != 'OBJECT':
            try:
                target_mode = MODE_MAP.get(original_mode, original_mode)
                bpy.ops.object.mode_set(mode=target_mode)
            except:
                pass  # If mode restoration fails, stay in object mode

def sanitize_name(name):
    # Replace any non-alphanumeric characters (except underscore) with underscore
    return re.sub(r'[^a-zA-Z0-9_]', '_', name)

def degrees_to_radians(degrees):
    return degrees * (math.pi / 180)

def denoise_lightmap(image_name, strength=10, color_strength=10, space_strength=10):
        """Modified denoise function to preserve HDR values"""
        cv2 = get_cv2()
        if cv2 is None:
            print("Warning: cv2 not available, skipping denoising")
            return

        img = bpy.data.images[image_name]
        pixels = np.array(img.pixels[:])
        width, height = img.size

        # Reshape but keep as float32
        pixels = pixels.reshape((height, width, 4))

        # Separate RGB and Alpha
        rgb = pixels[..., :3]
        alpha = pixels[..., 3]

        # Apply denoising to RGB channels while preserving HDR values
        denoised_rgb = cv2.fastNlMeansDenoisingColored(
            (rgb * 255).astype(np.uint8),  # Temporary conversion for denoising
            None,
            strength,
            color_strength,
            space_strength,
            21
        ).astype(np.float32) / 255.0  # Convert back to float

        # Recombine with original alpha
        denoised = np.dstack((denoised_rgb, alpha))

        # Update the image
        img.pixels = denoised.flatten()
