"""
Coordinate System Conversion Utilities for Blender to MHS Engine USD Export

This module provides utilities for converting between Blender's Z-up coordinate system
and the MHS Engine's RUB Y-up coordinate system.

Coordinate Systems:
-------------------
Blender (Z-up, Right-handed):
  +X: Right
  +Y: Forward
  +Z: Up

MHS Engine RUB (Y-up, Right-handed):
  +X: Right
  +Y: Up
  +Z: Back (toward camera)

Conversion Formula:
------------------
(x, y, z) → (x, z, -y)
  - X stays X (right)
  - Y (forward) becomes -Z (back)
  - Z (up) becomes Y (up)
"""

from pxr import Gf


def convert_vector_blender_to_rub(vec):
    """
    Convert a 3D vector/point from Blender Z-up to RUB Y-up.

    Args:
        vec: Vector with x, y, z components (Blender Vector, tuple, or list)

    Returns:
        Converted vector: (x, z, -y)

    Examples:
        >>> convert_vector_blender_to_rub((1, 2, 3))
        (1, 3, -2)
        >>> convert_vector_blender_to_rub(Vector((1, 2, 3)))
        Vector((1, 3, -2))
    """
    if hasattr(vec, 'x'):  # Blender Vector
        return type(vec)((vec.x, vec.z, -vec.y))
    else:  # Tuple or list
        return (vec[0], vec[2], -vec[1])


def convert_matrix_blender_to_rub_rowmajor(blender_matrix):
    """
    Convert a 4x4 transform matrix from Blender Z-up to RUB Y-up.
    Returns matrix in ROW-MAJOR format for USD.

    Uses similarity transformation: USD_Matrix = C × Blender_Matrix × C⁻¹
    where C is the coordinate conversion matrix from Z-up to Y-up.

    This ensures correct handling of combined rotations on multiple axes.

    Matrix structure (ROW-MAJOR):
      Row 0: [Xx, Xy, Xz, 0] - X axis direction
      Row 1: [Yx, Yy, Yz, 0] - Y axis direction
      Row 2: [Zx, Zy, Zz, 0] - Z axis direction
      Row 3: [Tx, Ty, Tz, 1] - Translation

    Args:
        blender_matrix: Blender 4x4 Matrix (row-major)

    Returns:
        Gf.Matrix4d in ROW-MAJOR format with translation in row 3

    Examples:
        >>> # Identity transform
        >>> convert_matrix_blender_to_rub_rowmajor(Matrix.Identity(4))
        Gf.Matrix4d(1, 0, 0, 0,  0, 1, 0, 0,  0, 0, 1, 0,  0, 0, 0, 1)

        >>> # Translation at (1, 2, 3) in Blender becomes (1, 3, -2) in RUB
        >>> mat = Matrix.Translation((1, 2, 3))
        >>> result = convert_matrix_blender_to_rub_rowmajor(mat)
        >>> # result has translation at row 3: (1, 3, -2, 1)
    """
    import mathutils

    # Define coordinate conversion matrix (Z-up to Y-up)
    # This transforms: X stays X, Y becomes Z, Z becomes -Y
    conversion = mathutils.Matrix((
        (1,  0,  0, 0),
        (0,  0,  1, 0),
        (0, -1,  0, 0),
        (0,  0,  0, 1)
    ))

    # Apply similarity transform: C × M × C⁻¹
    converted_matrix = conversion @ blender_matrix @ conversion.inverted()

    # Convert to USD Gf.Matrix4d (row-major, which matches Blender's layout)
    return Gf.Matrix4d(*converted_matrix.transposed())


def convert_gf_vec3f_blender_to_rub(vec):
    """
    Convert Blender vertex/normal to RUB Y-up as Gf.Vec3f.

    Args:
        vec: Blender vector with x, y, z components

    Returns:
        Gf.Vec3f with RUB Y-up coordinates (x, z, -y)

    Examples:
        >>> normal = Vector((0, 0, 1))  # Up in Blender
        >>> convert_gf_vec3f_blender_to_rub(normal)
        Gf.Vec3f(0, 1, 0)  # Up in RUB
    """
    return Gf.Vec3f(vec.x, vec.z, -vec.y)


def format_position_log(blender_pos, rub_pos):
    """
    Format a log message showing position conversion.

    Args:
        blender_pos: Tuple of (x, y, z) in Blender space
        rub_pos: Tuple of (x, y, z) in RUB space

    Returns:
        Formatted string for logging

    Examples:
        >>> format_position_log((1, 2, 3), (1, 3, -2))
        'Blender (1.000, 2.000, 3.000) → RUB (1.000, 3.000, -2.000)'
    """
    return (f"Blender ({blender_pos[0]:.3f}, {blender_pos[1]:.3f}, {blender_pos[2]:.3f}) → "
            f"RUB ({rub_pos[0]:.3f}, {rub_pos[1]:.3f}, {rub_pos[2]:.3f})")
