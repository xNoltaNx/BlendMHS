"""
Dirty Tracking Cache System for USD Exports

This module provides a hash-based caching system to optimize USD export times by
skipping unchanged files. It stores MD5 hashes of exported content and compares
them on subsequent exports to determine what actually needs to be written.

Expected Impact:
- Skip 80-90% of file writes when scene is mostly unchanged
- Significant time savings for iterative workflows
- Maintains full rebuild capability when needed
"""

import bpy
import os
import json
import hashlib
import time
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from .utils import debug_log, debug_log_stats, LogCategory

# Module-level variable to track force_rebuild state during export
_force_rebuild_session = False

# Session-level tracking for textures already exported in this session
# This prevents duplicate exports when multiple meshes share the same texture
# Now stores tuple of (normalized_path, source_mtime) to detect mid-session changes
_exported_textures_session: Dict[str, float] = {}

# Session-level tracking for materials already exported in this session
# This prevents duplicate record_skip calls when multiple meshes share the same material
_exported_materials_session: set = set()


def set_force_rebuild_session(force_rebuild: bool):
    """Set the force rebuild state for the current export session."""
    global _force_rebuild_session
    _force_rebuild_session = force_rebuild


def get_force_rebuild_session() -> bool:
    """Get the force rebuild state for the current export session."""
    return _force_rebuild_session


def reset_session_tracking():
    """Reset session-level tracking (call at start of export)."""
    global _exported_textures_session, _exported_materials_session
    _exported_textures_session = {}
    _exported_materials_session = set()


def mark_texture_exported(texture_path: str, source_mtime: float = None):
    """Mark a texture as exported in this session with its source mtime.
    
    Args:
        texture_path: Path to the exported texture
        source_mtime: Modification time of the source texture file. If None, will try to get it.
    """
    global _exported_textures_session
    normalized_path = texture_path.replace('\\', '/').lower()
    
    if source_mtime is None:
        # Try to get the source mtime if not provided
        try:
            import os
            if os.path.exists(texture_path):
                source_mtime = os.path.getmtime(texture_path)
            else:
                source_mtime = 0.0
        except OSError:
            source_mtime = 0.0
    
    _exported_textures_session[normalized_path] = source_mtime


def is_texture_exported_this_session(texture_path: str, source_path: str = None) -> bool:
    """Check if a texture was already exported in this session.
    
    Also checks if the source file has been modified since it was marked as exported,
    to detect mid-session texture changes.
    
    Args:
        texture_path: Path to the exported texture
        source_path: Optional path to the source texture file to check for modifications
        
    Returns:
        True if texture was exported and source hasn't been modified, False otherwise
    """
    import os
    normalized_path = texture_path.replace('\\', '/').lower()
    
    if normalized_path not in _exported_textures_session:
        return False
    
    # If source path provided, check if source was modified since export
    if source_path:
        try:
            if os.path.exists(source_path):
                current_mtime = os.path.getmtime(source_path)
                stored_mtime = _exported_textures_session.get(normalized_path, 0.0)
                if current_mtime > stored_mtime:
                    # Source was modified after we marked it as exported
                    return False
        except OSError:
            pass
    
    return True


def mark_material_exported(material_path: str):
    """Mark a material as exported in this session."""
    global _exported_materials_session
    normalized_path = material_path.replace('\\', '/').lower()
    _exported_materials_session.add(normalized_path)


def is_material_exported_this_session(material_path: str) -> bool:
    """Check if a material was already exported in this session."""
    normalized_path = material_path.replace('\\', '/').lower()
    return normalized_path in _exported_materials_session


# Addon version - used to invalidate cache when addon is updated
CACHE_VERSION = "1.0"
ADDON_VERSION = "1.0.0"


class ExportStats:
    """Track statistics for current export session."""

    def __init__(self):
        self.reset()

    def reset(self):
        """Reset all statistics for a new export session."""
        self.exported = 0
        self.skipped = 0
        self.meshes_exported = 0
        self.meshes_skipped = 0
        self.materials_exported = 0
        self.materials_skipped = 0
        self.layouts_exported = 0
        self.layouts_skipped = 0
        self.textures_exported = 0
        self.textures_skipped = 0
        self.start_time = time.time()
        self.estimated_time_saved = 0.0

    def record_export(self, file_type: str, filepath: str):
        """Record that a file was exported (not skipped)."""
        self.exported += 1
        if file_type == 'mesh':
            self.meshes_exported += 1
        elif file_type == 'material':
            self.materials_exported += 1
        elif file_type == 'layout':
            self.layouts_exported += 1
        elif file_type == 'texture':
            self.textures_exported += 1

    def record_skip(self, file_type: str, filepath: str, estimated_write_time: float = 0.1):
        """Record that a file was skipped due to cache hit."""
        self.skipped += 1
        self.estimated_time_saved += estimated_write_time
        if file_type == 'mesh':
            self.meshes_skipped += 1
        elif file_type == 'material':
            self.materials_skipped += 1
        elif file_type == 'layout':
            self.layouts_skipped += 1
        elif file_type == 'texture':
            self.textures_skipped += 1

    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of the export statistics."""
        return {
            'exported': self.exported,
            'skipped': self.skipped,
            'total': self.exported + self.skipped,
            'time_saved': self.estimated_time_saved,
            'total_time': time.time() - self.start_time,
            'meshes': {'exported': self.meshes_exported, 'skipped': self.meshes_skipped},
            'materials': {'exported': self.materials_exported, 'skipped': self.materials_skipped},
            'layouts': {'exported': self.layouts_exported, 'skipped': self.layouts_skipped},
            'textures': {'exported': self.textures_exported, 'skipped': self.textures_skipped}
        }


class ExportCache:
    """Manages dirty tracking cache for USD exports."""

    def __init__(self, blend_filepath: Optional[str] = None):
        """Initialize the export cache.

        Args:
            blend_filepath: Path to the .blend file. If None, uses current blend file.
        """
        self._blend_filepath = blend_filepath
        self._cache_data: Dict[str, Any] = {}
        self._loaded = False
        self._dirty = False

    def get_cache_filepath(self) -> Optional[str]:
        """Returns hidden cache path based on .blend location.

        Cache file is stored alongside the .blend file as a hidden JSON file.
        Format: .{blend_filename}.horizon_cache.json
        Example: scene.blend → .scene.horizon_cache.json
        """
        blend_path = self._blend_filepath or bpy.data.filepath
        if not blend_path:
            return None

        directory = os.path.dirname(blend_path)
        filename = os.path.basename(blend_path)
        name_without_ext = os.path.splitext(filename)[0]

        cache_filename = f".{name_without_ext}.horizon_cache.json"
        return os.path.join(directory, cache_filename)

    def load(self) -> bool:
        """Load cache from JSON file.

        Returns:
            True if cache was loaded successfully, False otherwise.
        """
        if self._loaded:
            return True

        cache_path = self.get_cache_filepath()
        if not cache_path or not os.path.exists(cache_path):
            self._init_empty_cache()
            self._loaded = True
            return False

        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                self._cache_data = json.load(f)

            # Check if cache version matches
            if self._cache_data.get('version') != CACHE_VERSION:
                debug_log(f"Version mismatch, invalidating cache", LogCategory.CACHE_LOAD)
                self.invalidate_all()
                return False

            # Check if addon version matches
            if self._cache_data.get('addon_version') != ADDON_VERSION:
                debug_log(f"Addon version changed, invalidating cache", LogCategory.CACHE_LOAD)
                self.invalidate_all()
                return False

            self._loaded = True
            debug_log(f"Loaded cache with {len(self._cache_data.get('files', {}))} entries", LogCategory.CACHE_LOAD)
            return True

        except (json.JSONDecodeError, IOError) as e:
            debug_log(f"Failed to load cache: {e}", LogCategory.CACHE_LOAD)
            self._init_empty_cache()
            self._loaded = True
            return False

    def _init_empty_cache(self):
        """Initialize an empty cache structure."""
        self._cache_data = {
            'version': CACHE_VERSION,
            'addon_version': ADDON_VERSION,
            'created': datetime.now().isoformat(),
            'last_export': None,
            'files': {}
        }
        self._dirty = True

    def save(self) -> bool:
        """Persist cache to JSON file.

        Returns:
            True if cache was saved successfully, False otherwise.
        """
        if not self._dirty:
            return True

        cache_path = self.get_cache_filepath()
        if not cache_path:
            debug_log("Cannot save - no blend file path", LogCategory.CACHE_SAVE)
            return False

        try:
            self._cache_data['last_export'] = datetime.now().isoformat()

            with open(cache_path, 'w', encoding='utf-8') as f:
                json.dump(self._cache_data, f, indent=2)

            self._dirty = False
            debug_log(f"Saved cache with {len(self._cache_data.get('files', {}))} entries", LogCategory.CACHE_SAVE)
            return True

        except IOError as e:
            debug_log(f"Failed to save cache: {e}", LogCategory.CACHE_SAVE)
            return False

    def get_file_hash(self, filepath: str) -> Optional[str]:
        """Get stored hash for a file.

        Args:
            filepath: Path to the file to look up.

        Returns:
            The stored hash string, or None if not found.
        """
        self.load()
        normalized_path = self._normalize_path(filepath)
        file_entry = self._cache_data.get('files', {}).get(normalized_path)
        if file_entry:
            return file_entry.get('hash')
        return None

    def set_file_hash(self, filepath: str, hash_value: str, metadata: Optional[Dict[str, Any]] = None):
        """Store hash after successful export.

        Args:
            filepath: Path to the exported file.
            hash_value: MD5 hash of the exported content.
            metadata: Optional metadata to store with the hash.
        """
        self.load()
        normalized_path = self._normalize_path(filepath)

        entry = {
            'hash': hash_value,
            'last_exported': datetime.now().isoformat()
        }

        if metadata:
            entry.update(metadata)

        if 'files' not in self._cache_data:
            self._cache_data['files'] = {}

        self._cache_data['files'][normalized_path] = entry
        self._dirty = True

    def should_export(self, filepath: str, new_hash: str) -> bool:
        """Check if file needs to be exported.

        Args:
            filepath: Path to the file to check.
            new_hash: New hash of the content to be exported.

        Returns:
            True if file needs export (hash differs, not cached, or file missing from disk), False if can skip.
        """
        # Always export if file doesn't exist on disk (even if hash is cached)
        if not os.path.exists(filepath):
            return True

        stored_hash = self.get_file_hash(filepath)
        if stored_hash is None:
            return True
        return stored_hash != new_hash

    def invalidate_file(self, filepath: str):
        """Mark file as needing re-export.

        Args:
            filepath: Path to the file to invalidate.
        """
        self.load()
        normalized_path = self._normalize_path(filepath)
        if 'files' in self._cache_data and normalized_path in self._cache_data['files']:
            del self._cache_data['files'][normalized_path]
            self._dirty = True

    def invalidate_all(self):
        """Clear entire cache (force rebuild)."""
        self._init_empty_cache()
        debug_log("Cache invalidated - all files will be re-exported", LogCategory.CACHE_LOAD)

    def check_addon_version(self) -> bool:
        """Check if addon version matches cached version.

        Returns:
            True if versions match, False if cache should be invalidated.
        """
        self.load()
        return self._cache_data.get('addon_version') == ADDON_VERSION

    def get_stats(self) -> Dict[str, Any]:
        """Return cache statistics.

        Returns:
            Dictionary with cache statistics.
        """
        self.load()
        return {
            'version': self._cache_data.get('version'),
            'addon_version': self._cache_data.get('addon_version'),
            'created': self._cache_data.get('created'),
            'last_export': self._cache_data.get('last_export'),
            'file_count': len(self._cache_data.get('files', {}))
        }

    def _normalize_path(self, filepath: str) -> str:
        """Normalize file path for consistent cache keys.

        Converts to relative path from project root if possible,
        and uses forward slashes for consistency.
        """
        # Get project path if available
        project_path = None
        try:
            if hasattr(bpy.context.scene, 'mhs'):
                project_path = bpy.context.scene.mhs.project_path
        except (AttributeError, RuntimeError):
            pass

        if project_path and filepath.startswith(project_path):
            filepath = os.path.relpath(filepath, project_path)

        return filepath.replace('\\', '/')


# Global cache instance and stats
_cache_instance: Optional[ExportCache] = None
_current_stats = ExportStats()
_last_export_stats: Optional[Dict[str, Any]] = None


def get_cache() -> ExportCache:
    """Get the global cache instance, creating if necessary."""
    global _cache_instance
    if _cache_instance is None:
        _cache_instance = ExportCache()
    return _cache_instance


def reset_cache():
    """Reset the global cache instance (e.g., when blend file changes)."""
    global _cache_instance
    _cache_instance = None


def reset_stats():
    """Reset export statistics for a new export session."""
    global _current_stats
    _current_stats = ExportStats()


def record_export(file_type: str, filepath: str):
    """Record that a file was exported."""
    _current_stats.record_export(file_type, filepath)


def record_skip(file_type: str, filepath: str, estimated_write_time: float = 0.1):
    """Record that a file was skipped."""
    _current_stats.record_skip(file_type, filepath, estimated_write_time)


def finalize_stats(elapsed_time: float):
    """Finalize stats and store for UI display."""
    global _last_export_stats
    _last_export_stats = _current_stats.get_summary()
    _last_export_stats['total_time'] = elapsed_time

    # Print export results to console
    print_export_results()

    # Save to scene properties for persistence across save handlers
    try:
        scene = bpy.context.scene
        if hasattr(scene, 'mhs'):
            scene.mhs.last_export_total = _last_export_stats['total']
            scene.mhs.last_export_exported = _last_export_stats['exported']
            scene.mhs.last_export_skipped = _last_export_stats['skipped']
            scene.mhs.last_export_time_saved = _last_export_stats['time_saved']
            scene.mhs.last_export_total_time = _last_export_stats['total_time']
            scene.mhs.last_export_layouts_exported = _last_export_stats['layouts']['exported']
            scene.mhs.last_export_layouts_skipped = _last_export_stats['layouts']['skipped']
            scene.mhs.last_export_meshes_exported = _last_export_stats['meshes']['exported']
            scene.mhs.last_export_meshes_skipped = _last_export_stats['meshes']['skipped']
            scene.mhs.last_export_materials_exported = _last_export_stats['materials']['exported']
            scene.mhs.last_export_materials_skipped = _last_export_stats['materials']['skipped']
            scene.mhs.last_export_textures_exported = _last_export_stats['textures']['exported']
            scene.mhs.last_export_textures_skipped = _last_export_stats['textures']['skipped']
    except Exception:
        pass


def print_export_results():
    """Print export results to console (uses debug_log)."""
    global _last_export_stats
    if _last_export_stats is None:
        return

    stats = _last_export_stats
    total = stats['total']
    exported = stats['exported']
    skipped = stats['skipped']
    time_saved = stats['time_saved']
    total_time = stats['total_time']

    debug_log("\n" + "=" * 50, LogCategory.CACHE_STATS)
    debug_log("EXPORT RESULTS", LogCategory.CACHE_STATS)
    debug_log("=" * 50, LogCategory.CACHE_STATS)
    debug_log(f"  Exported:       {exported}", LogCategory.CACHE_STATS)
    debug_log(f"  Cache Hits:     {skipped}", LogCategory.CACHE_STATS)
    debug_log(f"  Time Saved:     ~{time_saved:.1f}s", LogCategory.CACHE_STATS)
    debug_log(f"  Total Time:     {total_time:.2f}s", LogCategory.CACHE_STATS)

    if total > 0:
        cache_hit_rate = (skipped / total) * 100
        debug_log(f"  Cache Hit Rate: {cache_hit_rate:.0f}%", LogCategory.CACHE_STATS)

    debug_log("-" * 50, LogCategory.CACHE_STATS)

    # Layouts
    layouts = stats['layouts']
    debug_log(f"  Layouts:   {layouts['exported']} exported, {layouts['skipped']} cached", LogCategory.CACHE_STATS)

    # Meshes
    meshes = stats['meshes']
    debug_log(f"  Meshes:    {meshes['exported']} exported, {meshes['skipped']} cached", LogCategory.CACHE_STATS)

    # Materials
    materials = stats['materials']
    if materials['exported'] == 0 and materials['skipped'] == 0:
        debug_log(f"  Materials: N/A (meshes cached)", LogCategory.CACHE_STATS)
    else:
        debug_log(f"  Materials: {materials['exported']} exported, {materials['skipped']} cached", LogCategory.CACHE_STATS)

    # Textures
    textures = stats['textures']
    if textures['exported'] == 0 and textures['skipped'] == 0:
        debug_log(f"  Textures:  N/A (materials cached)", LogCategory.CACHE_STATS)
    else:
        debug_log(f"  Textures:  {textures['exported']} exported, {textures['skipped']} cached", LogCategory.CACHE_STATS)

    debug_log("=" * 50 + "\n", LogCategory.CACHE_STATS)


def update_scene_stats_from_global():
    """Update scene properties from global stats - call this after export completes."""
    global _last_export_stats
    if _last_export_stats is None:
        return False

    try:
        scene = bpy.context.scene
        if hasattr(scene, 'mhs'):
            scene.mhs.last_export_total = _last_export_stats['total']
            scene.mhs.last_export_exported = _last_export_stats['exported']
            scene.mhs.last_export_skipped = _last_export_stats['skipped']
            scene.mhs.last_export_time_saved = _last_export_stats['time_saved']
            scene.mhs.last_export_total_time = _last_export_stats['total_time']
            scene.mhs.last_export_layouts_exported = _last_export_stats['layouts']['exported']
            scene.mhs.last_export_layouts_skipped = _last_export_stats['layouts']['skipped']
            scene.mhs.last_export_meshes_exported = _last_export_stats['meshes']['exported']
            scene.mhs.last_export_meshes_skipped = _last_export_stats['meshes']['skipped']
            scene.mhs.last_export_materials_exported = _last_export_stats['materials']['exported']
            scene.mhs.last_export_materials_skipped = _last_export_stats['materials']['skipped']
            scene.mhs.last_export_textures_exported = _last_export_stats['textures']['exported']
            scene.mhs.last_export_textures_skipped = _last_export_stats['textures']['skipped']
            return True
    except Exception as e:
        debug_log(f"WARNING - Failed to update scene stats: {e}", LogCategory.CACHE_STATS)
    return False


def get_last_export_stats() -> Dict[str, Any]:
    """Get statistics from the last export."""
    if _last_export_stats is None:
        return {
            'exported': 0,
            'skipped': 0,
            'total': 0,
            'time_saved': 0.0,
            'total_time': 0.0,
            'meshes': {'exported': 0, 'skipped': 0},
            'materials': {'exported': 0, 'skipped': 0},
            'layouts': {'exported': 0, 'skipped': 0},
            'textures': {'exported': 0, 'skipped': 0}
        }
    return _last_export_stats


# ============================================================================
# Hash Computation Functions
# ============================================================================

def compute_mesh_hash(obj, depsgraph=None) -> str:
    """Compute hash of mesh data including geometry, UVs, materials.

    Args:
        obj: Blender mesh object
        depsgraph: Dependency graph for evaluated mesh (optional)

    Returns:
        MD5 hash string of the mesh data
    """
    if obj.type != 'MESH':
        return ""

    hasher = hashlib.md5()
    temp_mesh = None
    eval_obj = None

    # Force update the depsgraph to ensure we get the latest mesh data
    # This is critical for detecting edit mode changes
    if depsgraph:
        depsgraph.update()

    # Get evaluated mesh if depsgraph provided, else use data mesh
    if depsgraph:
        try:
            eval_obj = obj.evaluated_get(depsgraph)
            # Use to_mesh() to get the fully evaluated mesh with all modifiers applied
            # This ensures we capture vertex positions after all transformations
            temp_mesh = eval_obj.to_mesh()
            mesh_data = temp_mesh
        except Exception:
            mesh_data = obj.data
    else:
        mesh_data = obj.data

    try:
        # Hash vertex count first (quick check for topology changes)
        hasher.update(f"vertex_count:{len(mesh_data.vertices)}".encode())
        hasher.update(f"poly_count:{len(mesh_data.polygons)}".encode())

        # Hash vertex positions using numpy for speed and accuracy
        # This captures the actual vertex coordinates after any edits
        import numpy as np
        positions = np.zeros(len(mesh_data.vertices) * 3, dtype=np.float64)
        mesh_data.vertices.foreach_get('co', positions)
        # Hash the raw bytes of the positions array for maximum accuracy
        hasher.update(positions.tobytes())

        # Hash face indices
        for poly in mesh_data.polygons:
            indices = ",".join(str(v) for v in poly.vertices)
            hasher.update(f"f:{indices}".encode())

        # Hash UV coordinates
        if mesh_data.uv_layers:
            for uv_layer in mesh_data.uv_layers:
                hasher.update(f"uv_layer:{uv_layer.name}".encode())
                uv_data = np.zeros(len(uv_layer.data) * 2, dtype=np.float64)
                uv_layer.data.foreach_get('uv', uv_data)
                hasher.update(uv_data.tobytes())

        # Hash vertex colors
        if mesh_data.color_attributes:
            for color_attr in mesh_data.color_attributes:
                hasher.update(f"color_attr:{color_attr.name}".encode())
                color_data = np.zeros(len(color_attr.data) * 4, dtype=np.float32)
                color_attr.data.foreach_get('color', color_data)
                hasher.update(color_data.tobytes())

        # Hash material assignments AND format (format affects exported material filename)
        for i, slot in enumerate(obj.material_slots):
            mat_name = slot.material.name if slot.material else "None"
            hasher.update(f"mat:{i}:{mat_name}".encode())

            # Include material format since it affects the exported material filename
            # (e.g., UNLIT_BLEND adds "_Blend" suffix, changing the reference path in mesh)
            if slot.material and hasattr(slot.material, 'mhs'):
                mat_format = slot.material.mhs.material_format
                hasher.update(f"mat_format:{i}:{mat_format}".encode())

        # Hash modifier stack state (names and types only for key identification)
        for mod in obj.modifiers:
            if mod.show_viewport:
                hasher.update(f"mod:{mod.type}:{mod.name}".encode())

        # Hash object-level export settings
        if hasattr(obj, 'mhs'):
            hasher.update(f"export_lods:{obj.mhs.export_lods}".encode())
            hasher.update(f"export_lightmap:{obj.mhs.export_lightmap}".encode())
            hasher.update(f"export_animations:{obj.mhs.export_animations}".encode())

    finally:
        # Clean up the temporary mesh if we created one
        if temp_mesh is not None and eval_obj is not None:
            eval_obj.to_mesh_clear()

    return hasher.hexdigest()


def compute_material_hash(material, texture_paths: Optional[List[str]] = None) -> str:
    """Compute hash of material including texture file mtimes.

    Args:
        material: Blender material
        texture_paths: List of texture file paths used by this material

    Returns:
        MD5 hash string of the material data
    """
    if not material:
        return ""

    hasher = hashlib.md5()

    # Hash material name
    hasher.update(f"name:{material.name}".encode())

    # Hash shader node tree structure
    if material.use_nodes and material.node_tree:
        for node in material.node_tree.nodes:
            hasher.update(f"node:{node.type}:{node.name}".encode())

            # Hash node inputs (values/defaults)
            for inp in node.inputs:
                if hasattr(inp, 'default_value'):
                    try:
                        val = inp.default_value
                        if hasattr(val, '__iter__') and not isinstance(val, str):
                            val_str = ",".join(f"{v:.4f}" if isinstance(v, float) else str(v) for v in val)
                        else:
                            val_str = f"{val:.4f}" if isinstance(val, float) else str(val)
                        hasher.update(f"inp:{inp.name}:{val_str}".encode())
                    except (TypeError, AttributeError):
                        pass

            # Hash texture images
            if node.type == 'TEX_IMAGE' and node.image:
                hasher.update(f"tex:{node.image.name}:{node.image.filepath}".encode())

    # Hash material MHS properties if available
    if hasattr(material, 'mhs'):
        hasher.update(f"format:{material.mhs.material_format}".encode())
        hasher.update(f"wrap_s:{material.mhs.texture_wrap_s}".encode())
        hasher.update(f"wrap_t:{material.mhs.texture_wrap_t}".encode())

    # Hash texture file modification times for invalidation
    if texture_paths:
        for tex_path in texture_paths:
            tex_hash = compute_texture_hash(tex_path)
            hasher.update(f"tex_mtime:{tex_hash}".encode())

    return hasher.hexdigest()


def _get_parent_chain(obj) -> List[str]:
    """Get the full parent chain for an object.

    Args:
        obj: Blender object

    Returns:
        List of parent names from immediate parent to root
    """
    chain = []
    current = obj.parent
    max_depth = 50  # Prevent infinite loops
    depth = 0
    while current and depth < max_depth:
        chain.append(current.name)
        current = current.parent
        depth += 1
    return chain


def _get_object_collections(obj) -> List[str]:
    """Get all collections an object belongs to.

    Args:
        obj: Blender object

    Returns:
        Sorted list of collection names
    """
    collections = []
    for coll in bpy.data.collections:
        if obj.name in coll.objects:
            collections.append(coll.name)
    return sorted(collections)


def _hash_collection_hierarchy(collection, hasher, visited: set, depth: int = 0, max_depth: int = 20):
    """Recursively hash a collection's hierarchy structure.

    Args:
        collection: Blender collection
        hasher: MD5 hasher object
        visited: Set of already-visited collection names to prevent cycles
        depth: Current recursion depth
        max_depth: Maximum recursion depth to prevent runaway
    """
    if depth >= max_depth or collection.name in visited:
        return

    visited.add(collection.name)
    hasher.update(f"coll_struct:{depth}:{collection.name}".encode())

    # Hash collection visibility settings
    hasher.update(f"coll_hide_viewport:{collection.hide_viewport}".encode())
    hasher.update(f"coll_hide_render:{collection.hide_render}".encode())

    # Hash child collections
    for child in sorted(collection.children, key=lambda c: c.name):
        _hash_collection_hierarchy(child, hasher, visited, depth + 1, max_depth)


def compute_layout_hash(objects: List, transforms: Optional[List] = None,
                        layout_collections: Optional[List] = None) -> str:
    """Compute hash of layout including all instance transforms and hierarchy.

    Args:
        objects: List of objects in the layout
        transforms: Optional list of transform matrices
        layout_collections: Optional list of collections that define this layout

    Returns:
        MD5 hash string of the layout data
    """
    hasher = hashlib.md5()

    # Hash object count first (quick detection of additions/removals)
    hasher.update(f"object_count:{len(objects)}".encode())

    # Sort objects by name for consistent hashing
    sorted_objects = sorted(objects, key=lambda o: o.name)

    for obj in sorted_objects:
        # Hash object name
        hasher.update(f"obj:{obj.name}".encode())

        # Hash object type
        hasher.update(f"type:{obj.type}".encode())

        # Hash world transform (matrix)
        m = obj.matrix_world
        for row in range(4):
            for col in range(4):
                hasher.update(f"m:{m[row][col]:.6f}".encode())

        # --- VISIBILITY STATE ---
        hasher.update(f"hide_viewport:{obj.hide_viewport}".encode())
        hasher.update(f"hide_render:{obj.hide_render}".encode())
        hasher.update(f"hide_select:{obj.hide_select}".encode())

        # --- FULL PARENT HIERARCHY ---
        if obj.parent:
            hasher.update(f"parent:{obj.parent.name}".encode())
            hasher.update(f"parent_type:{obj.parent_type}".encode())

            # Track parent bone for armature parenting
            if obj.parent_bone:
                hasher.update(f"parent_bone:{obj.parent_bone}".encode())

            # Hash full parent chain (grandparents, etc.)
            parent_chain = _get_parent_chain(obj)
            if parent_chain:
                hasher.update(f"parent_chain:{'>'.join(parent_chain)}".encode())

        # --- COLLECTION MEMBERSHIP ---
        obj_collections = _get_object_collections(obj)
        for coll_name in obj_collections:
            hasher.update(f"in_coll:{coll_name}".encode())

        # Hash mesh reference (data name)
        if obj.type == 'MESH' and obj.data:
            hasher.update(f"data:{obj.data.name}".encode())

            # CRITICAL: Also hash mesh geometry content so vertex changes trigger re-export
            # This was the root cause of mesh edits not triggering layout re-export
            mesh_hash = compute_mesh_hash(obj, depsgraph=bpy.context.evaluated_depsgraph_get())
            hasher.update(f"mesh_geo:{mesh_hash}".encode())

        # Hash material bindings AND material content
        for i, slot in enumerate(obj.material_slots):
            mat_name = slot.material.name if slot.material else "None"
            hasher.update(f"mat:{i}:{mat_name}".encode())

            # CRITICAL: Also hash material content so material property changes trigger re-export
            # This ensures changes to textures, colors, shader settings, etc. are detected
            if slot.material:
                texture_paths = get_material_texture_paths(slot.material)
                mat_hash = compute_material_hash(slot.material, texture_paths)
                hasher.update(f"mat_content:{mat_hash}".encode())

    # --- COLLECTION HIERARCHY STRUCTURE ---
    # Hash the structure of layout collections (if provided)
    if layout_collections:
        visited = set()
        for coll in sorted(layout_collections, key=lambda c: c.name):
            _hash_collection_hierarchy(coll, hasher, visited)

    return hasher.hexdigest()


def compute_texture_hash(filepath: str) -> str:
    """Compute hash based on texture file mtime for fast checking.

    Uses file modification time instead of content hash for speed.

    Args:
        filepath: Path to the texture file

    Returns:
        Hash string in format "filepath:mtime" or empty string if file doesn't exist
    """
    if not filepath:
        return ""

    # Resolve Blender's relative paths
    abs_path = bpy.path.abspath(filepath)

    if not os.path.exists(abs_path):
        return f"{filepath}:missing"

    try:
        mtime = os.path.getmtime(abs_path)
        return f"{filepath}:{mtime}"
    except OSError:
        return f"{filepath}:error"


def get_material_texture_paths(material) -> List[str]:
    """Get all texture file paths used by a material.

    Args:
        material: Blender material

    Returns:
        List of texture file paths
    """
    texture_paths = []

    if not material or not material.use_nodes or not material.node_tree:
        return texture_paths

    for node in material.node_tree.nodes:
        if node.type == 'TEX_IMAGE' and node.image and node.image.filepath:
            texture_paths.append(node.image.filepath)

    return texture_paths
